import vue from 'vue'
import Vuex from 'vuex'
vue.use(Vuex)

const state = {
  token: null,
  historyList: [] || JSON.parse(sessionStorage.getItem('historyList'))
}

const mutations = {
  token (state, data) {
    state.token = state
  }
}

export default new Vuex.Store({
  state,
  mutations
})
