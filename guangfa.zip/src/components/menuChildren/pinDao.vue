<template>
    <div class="menuHeaderPrevious">
      <div class="menuHeaderTop" v-show="!isCollapse">
        <img src="../../assets/home/menuTop.png" alt="">
        {{ onceTitle || '频道栏目' }}
        <span  style="float:right;margin-right: 6px;cursor: pointer;" @click="shrinkBtn">
          <img src="../../assets/home/menuArrowsLeft.png" alt="">
        </span>
      </div>
      <div class="menuHeaderTop" v-show="isCollapse">
        <span  style="float:right;margin-right: 6px;cursor: pointer;" @click="shrinkBtn">
          <img src="../../assets/home/menuArrowsRight.png" alt="">
        </span>
      </div>
    </div>
</template>

<script>
import Bus from '../../utils/busEmit'
export default {
  name: 'pinDao',
  props: ['onceTitle'],
  data () {
    return {
      isCollapse: false, // 收缩
    }
  },
  methods: {

    // 收缩
    shrinkBtn () {
      this.isCollapse = !this.isCollapse
      let menuShrink = document.getElementsByClassName('menuShrink')
      // console.log(menuShrink[0].nextElementSibling);
      // console.log(menuShrink[0].children[0].nextElementSibling);
      // let menuHeaderPrevious = document.getElementsByClassName('menuHeaderPrevious')
      if (this.isCollapse) {
        menuShrink[0].style.width = '64px'
        menuShrink[0].children[0].nextElementSibling.style.display = 'none'
      } else {
        menuShrink[0].style.width = '220px'
        menuShrink[0].children[0].nextElementSibling.style.display = 'block'
      }
      Bus.$emit('isCollapse', this.isCollapse)
    },
  }
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  .menuShrink{
    width:220px;
    max-width:220px;
    min-height:800px;
    max-height:800px;
    overflow-x: auto;
  }

</style>
