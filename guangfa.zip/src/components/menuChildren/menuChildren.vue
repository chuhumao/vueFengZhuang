<template>
    <div class="menuShrink menuBackground">
      <PinDao></PinDao>
      <el-menu
        :default-active="$route.path"
        class="el-menu-vertical-demo"
        router
        style="margin-bottom:2px;"
        @open="handleOpen"
        @close="handleClose"
        v-for="(item, index) in menuList"
        :key="index"
        background-color="#525252"
        text-color="#fff"
        :collapse="isCollapseOne"
      >
        <!--<el-submenu v-if="item.childrenList.length >= 1" :index="item.routerLink + ''">-->
        <el-submenu v-if="item.childrenList.length >= 1" :index="item.routerLink + ''" :key="index">
          <template slot="title">
            <span>{{ item.title }}</span>
          </template>
          <div  v-if="item.childrenList.length >= 1">
            <el-menu-item-group  v-for="(itemTwo, indexTwo) in item.childrenList"  :key="indexTwo">
              <!--<el-menu-item :index="itemTwo.routerLink + ''">{{ itemTwo.title }}</el-menu-item>-->
              <el-menu-item  :index="itemTwo.routerLink + ''">{{ itemTwo.title }}</el-menu-item>
            </el-menu-item-group>
          </div>
        </el-submenu>
        <el-menu-item v-else :index="item.routerLink + ''">
          <span slot="title">{{ item.title }}</span>
        </el-menu-item>
      </el-menu>
    </div>
</template>

<script>
import Bus from '../../utils/busEmit'
import PinDao from './pinDao'
export default {
  name: 'menuChildren',
  components: {
    PinDao
  },
  data () {
    return {
      menuList: [],
      isCollapseOne: null, // 收缩
    }
  },
  methods: {
    handleOpen (val, key) {
      // console.log(val);
    },
    handleClose (val, key) {
      // console.log(val);
    },
    contentMenu () {
      this.menuList = []
      this.menuList = [...JSON.parse(sessionStorage.getItem('menuListTwo')).childrenList]
      // Bus.$on('historyList', (item) => {
      //   this.menuList = [...item.val.childrenList]
      //   sessionStorage.setItem('menuListTwo', JSON.stringify(this.menuList))
      // })
      // if (this.menuList.length <= 0) {
      // }
    },

    roterLink (val) {
      // console.log(val);
      this.$forceUpdate()
      this.$router.push({path: val.routerLink})
      // sessionStorage.setItem('columnId', val.id)
      // this.paramsOnce = {routeList: this.routeList, val: val}
      // Bus.$emit('historyList', this.paramsOnce)
      // sessionStorage.setItem('menuListTwo', JSON.stringify(this.paramsOnce.val.childrenList))
    }
  },
  created () {
    this.menuList = []
    this.contentMenu()
    // this.$router.go(0)
    Bus.$on('isCollapse', (item) => {
      this.isCollapseOne = item
    })
  },
  beforeUpdate () {
    this.contentMenu()
    // Bus.$on('isCollapse', (item) => {
    //   // console.log(item);
    //   this.isCollapseOne = item
    // })
  }
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  .menuShrink{
    width:200px;
    max-width:200px;
    min-height:800px;
    max-height:800px;
    /*overflow-x: hidden;*/
  }
  .topMenuList{
    li{
      float: left;
      width: 86px;
      line-height: 50px;
      /*height: 50px;*/
      padding: 0 20px;
      font-size: 14px;
      color: #fff;
      cursor:pointer;
      list-style: none;
      position: relative;
      text-align: center;
      ul{
        /*display: none;*/
        width: 100%;
        /*height:50px;*/
        /*position: absolute;*/
        /*top: 50px;*/
        /*left: 0;*/
        z-index: 99999;
        background-color: #1E66AF;
      }
    }
    /*li:hover{*/
      /*ul{*/
        /*display: block;*/
      /*}*/
      /*li:hover{*/
        /*background: rgba(0, 0, 0, 0.1);*/
      /*}*/
    /*}*/
  }
</style>
