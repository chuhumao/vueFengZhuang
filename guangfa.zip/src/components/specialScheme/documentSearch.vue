<!-- 档案检索 -->
<template>
  <div>
    <div class="contentPadding doc-main">
      <div class="headerBtn mb-20">
        <span class="search-doc">
          <label>全宗：</label>
          <el-select v-model="params.fonds" @change="changeFonds">
            <el-option v-for="item in fonds" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc">
          <label>类型：</label>
          <el-select v-model="params.series1" @change="changeOne">
            <el-option v-for="item in oneType" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc">
          <el-select v-model="params.series2" @change="changeTwo">
            <el-option v-for="item in twoType" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc">
          <el-select v-model="params.series3" @change="changeThree">
            <el-option v-for="item in threeType" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc" v-show="typeFlag">
          <label>形式：</label>
          <el-select v-model="params.series4" @change="changeType">
            <el-option v-for="item in forthType" :key="item.value" :value="item.value" :label="item.key"></el-option>
          </el-select>
        </span>
      </div>
      <div v-show="showFlag">
        <div class="headerBtn mb-20">
          <span @click="openSea"><img src="../../assets/system/p8.png" alt="">项目信息检索</span>
          <span @click="addDoc"><img src="../../assets/home/d1.png" alt="">加入借阅车</span>
          <span class="doc-down" @click="docDown">投行底稿借阅操作指引（点击下载）</span>
        </div>
        <!-- 表格 -->
        <div class='all-Table'>
          <el-table :data="docData" stripe border @selection-change="docSelect">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="c5" label="状态" width="80px">
              <template slot-scope="scope">
                {{c5Arr[scope.row.c5]}}
              </template>
            </el-table-column>
            <el-table-column prop="c18" label="项目编号" width="80px">
            </el-table-column>
            <el-table-column prop="titleProper" label="项目名称" width="80px">
            </el-table-column>
            <el-table-column prop="yearCode" label="项目年度" width="80px">
            </el-table-column>
            <el-table-column prop="c20" label="项目类型" width="80px">
            </el-table-column>
            <el-table-column prop="c22" label="业务类型" width="110px">
            </el-table-column>
            <el-table-column prop="c24" label="项目单位全称" width="250px">
            </el-table-column>
            <el-table-column prop="c10" label="股票代码" width="80px">
            </el-table-column>
            <el-table-column prop="c28" label="承做单位" width="187px">
            </el-table-column>
            <el-table-column prop="openingType" label="公开属性" width="80px">
              <template slot-scope="scope">
                {{pubArr[scope.row.openingType]}}
              </template>
            </el-table-column>
            <el-table-column prop="retentionPeriod" label="保管期限" width="80px">
              <template slot-scope="scope">
                {{saveArr[scope.row.retentionPeriod]}}
              </template>
            </el-table-column>
            <el-table-column prop="seriesCode" label="分类号" width="80px">
            </el-table-column>
            <el-table-column prop="filingDept" label="归档部门" width="120px">
            </el-table-column>
            <el-table-column label="操作" align="center" width="179px">
              <template slot-scope="scope">
                <el-button size="mini" class="table-botton" @click="openDetail(scope.row)">查看
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="docChange" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
          </el-pagination>
        </div>
      </div>
      <!-- 检索弹框 -->
      <el-dialog :visible.sync="seaFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/system/roleAdd.png" alt="">
          检索
        </div>
        <el-form :model="paramsSea" label-width="120px" style="height: 419px;overflow-y: auto;">
          <el-form-item label="档案类型：">
            <el-input v-model="paramsSea.thseriesCode"></el-input>
          </el-form-item>
          <el-form-item label="归档部门：">
            <el-select v-model="paramsSea.thfilingDept" class="w-100" filterable>
              <el-option v-for="item in deptArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="项目编号：">
            <el-input v-model="paramsSea.thc18"></el-input>
          </el-form-item>
          <el-form-item label="年度：">
            <el-input v-model="paramsSea.thyearCode"></el-input>
          </el-form-item>
          <el-form-item label="状态：">
            <el-select v-model="paramsSea.thc5" class="w-100" filterable>
              <el-option v-for="item in statusArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="股票代码：">
            <el-input v-model="paramsSea.thc10"></el-input>
          </el-form-item>
          <el-form-item label="项目单位全称：">
            <el-input v-model="paramsSea.thc24"></el-input>
          </el-form-item>
          <el-form-item label="项目名称：">
            <el-input v-model="paramsSea.thtitleProper"></el-input>
          </el-form-item>
          <el-form-item label="项目类型：">
            <el-input v-model="paramsSea.thc20"></el-input>
          </el-form-item>
          <el-form-item label="业务类型：">
            <el-input v-model="paramsSea.thc22"></el-input>
          </el-form-item>
          <el-form-item label="承做单位：">
            <el-input v-model="paramsSea.thc28"></el-input>
          </el-form-item>
          <el-form-item label="存址号：">
            <el-input v-model="paramsSea.addressNo"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="searchSea">检索</el-button>
          <el-button type="primary" @click="paramsSea ={}">重置条件</el-button>
          <el-button @click="seaFlag = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 检索系统提示 -->
      <el-dialog :visible.sync="titleFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle2.png" alt="">
          {{titleMsg1}}
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>{{titleMsg2}}</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="titleFlag = false">确定</el-button>
        </div>
      </el-dialog>
      <!-- 查看 -->
      <el-dialog :visible.sync="dossFlag" width="1100px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/system/roleAdd.png" alt="">
          查看
        </div>
        <div>
          <el-tabs tab-position="left" style="height: 600px;">
            <el-tab-pane label="案卷层">
              <div>
                <!-- 表格 -->
                <div class="all-Table doc-doss">
                  <el-table :data="tableDoss" stripe border @selection-change="dossChange">
                    <el-table-column type="selection" width="55">
                    </el-table-column>
                    <el-table-column prop="c11" label="项目名称" width="80px">
                    </el-table-column>
                    <el-table-column prop="folderNo" label="案卷号" width="70px">
                    </el-table-column>
                    <el-table-column prop="titleProper" label="案卷名称">
                    </el-table-column>
                    <el-table-column prop="openingType" label="公开属性" width="80px">
                      <template slot-scope="scope">
                        {{openArr[scope.row.openingType]}}
                      </template>
                    </el-table-column>
                    <el-table-column prop="retentionPeriod" label="保管期限" width="80px">
                      <template slot-scope="scope">
                        {{perArr[scope.row.retentionPeriod]}}
                      </template>
                    </el-table-column>
                    <el-table-column prop="seriesCode" label="分类号" width="80px">
                    </el-table-column>
                    <el-table-column prop="c19" label="编制单位" width="80px">
                    </el-table-column>
                    <el-table-column prop="filingDept" label="归档部门" width="110px">
                    </el-table-column>
                    <el-table-column prop="filingDate" label="归档日期" width="110px">
                    </el-table-column>
                  </el-table>
                </div>
                <!--  分页 -->
                <div class="pageLayout">
                  <el-pagination @current-change="dossCurrChange" :current-page="dossParams.page" :page-size="dossParams.rows" layout="prev, pager, next, jumper" :total="dossParams.total">
                  </el-pagination>
                </div>
              </div>
            </el-tab-pane>
            <el-tab-pane label="文件层">
              <div>
                <div class="headerBtn">
                  <span @click="addFileDoc"><img src="../../assets/home/d1.png" alt="">加入借阅车</span>
                </div>
                <div>
                  <!-- 表格 -->
                  <div class="all-Table doc-doss">
                    <el-table :data="tableFiles" stripe border @selection-change="filesChange">
                      <el-table-column type="selection" width="55">
                      </el-table-column>
                      <el-table-column prop="officeArchivalCode" label="档案号" width="120px">
                      </el-table-column>
                      <el-table-column prop="storagePlace" label="存址号" width="120px">
                      </el-table-column>
                      <el-table-column prop="c220" label="案卷号" width="80px">
                      </el-table-column>
                      <el-table-column prop="caseNo" label="盒号" width="80px">
                      </el-table-column>
                      <el-table-column prop="itemNo" label="件号" width="80px">
                      </el-table-column>
                      <el-table-column prop="titleProper" label="文件题名" width="200px">
                      </el-table-column>
                      <el-table-column prop="c72" label="章节号" width="100px">
                      </el-table-column>
                      <el-table-column prop="dateOfCreation" label="文件日期" width="100px">
                      </el-table-column>
                      <el-table-column prop="yearCode" label="年度" width="80px">
                      </el-table-column>
                      <el-table-column prop="c229" label="页号" width="80px">
                      </el-table-column>
                      <el-table-column prop="seriesCode" label="分类号" width="80px">
                      </el-table-column>
                      <el-table-column prop="filingDept" label="归档部门" width="110px">
                      </el-table-column>
                      <el-table-column prop="filingDate" label="归档日期" width="110px">
                      </el-table-column>
                      <el-table-column prop="c76" label="索引备注" width="120px">
                      </el-table-column>
                      <el-table-column prop="c77" label="情况说明" width="120px">
                      </el-table-column>
                    </el-table>
                  </div>
                  <!--  分页 -->
                  <div class="pageLayout">
                    <el-pagination @current-change="filesCurrChange" :current-page="fileParams.page" :page-size="fileParams.rows" layout="prev, pager, next, jumper" :total="fileParams.total">
                    </el-pagination>
                  </div>
                </div>
              </div>
            </el-tab-pane>
          </el-tabs>
        </div>
      </el-dialog>
      <!-- 悬浮借阅车 -->
      <div>
        <div class="doc-car" @click="openBorr">
          <el-badge :value="carTotal" class="item">
          </el-badge>
        </div>
      </div>
      <!-- 借阅车弹框 -->
      <el-dialog :visible.sync="borrowFlag" class="hurdleAll" width="1100px">
        <div slot="title" class="dialog-title">
          <img src="../../assets/home/submit.png" alt />
          借阅车
        </div>
        <div>
          <div class="headerBtn mt-f14">
            <span @click="openLend"><img src="../../assets/home/read.png" alt="" />借阅</span>
            <span @click="openOutDel"><img src="../../assets/home/delete.png" alt="" />删除</span>
            <span @click="openOutRel"><img src="../../assets/home/rela.png" alt="" />关联借阅人</span>
          </div>
          <div class="all-Table doc-doss">
            <el-table :data="tableBorr" border @selection-change="borrSelect">
              <el-table-column type="selection" width="55"></el-table-column>
              <el-table-column prop="officeArchivalCode" label="档号" width="180"></el-table-column>
              <el-table-column prop="titleProper" label="题名" width="200"></el-table-column>
              <el-table-column prop="fondsCode" label="全宗"></el-table-column>
              <el-table-column prop="openingType" label="公开属性">
                <template slot-scope="scope">
                  {{outPubArr[scope.row.openingType]}}
                </template>
              </el-table-column>
              <el-table-column prop="filingDept" label="归档部门"></el-table-column>
            </el-table>
          </div>
          <!-- 分页 -->
          <div class="pageLayout">
            <el-pagination @current-change="borrCurrChange" :current-page="borrParams.page" :page-size="borrParams.rows" layout="prev, pager, next, jumper" :total="borrParams.total">
            </el-pagination>
          </div>
        </div>
      </el-dialog>
      <!-- 借阅弹框 -->
      <!-- 删除借阅车 -->
      <el-dialog :visible.sync="outDelFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle2.png" alt="">
          系统消息
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>您确定要删除吗？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="clickOutDel">确定</el-button>
          <el-button @click="outDelFlag= false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 关联借阅人 -->
      <el-dialog :visible.sync="relAddFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicAdd.png" alt="">
          选择借阅人
        </div>
        <el-form :model="paramsAdd" :rules="rulesAudit" ref="paramsAdd" label-width="120px">
          <el-form-item label="部门：" prop="deptCode">
            <el-select v-model="paramsAdd.deptCode" filterable @change="searchUser">
              <el-option v-for="item in orgArr" :key="item.organizeId" :value="item.organizeId" :label="item.flag1 +'  '+ item.organizeName"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="用户名：" prop="userId">
            <el-select v-model="paramsAdd.userId" filterable>
              <el-option v-for="item in userArr" :key="item.userId" :value="item.userId" :label="item.userName"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="clickCom">保存</el-button>
          <el-button @click="relAddFlag = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 关联前确认 -->
      <el-dialog :visible.sync="confirmFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle2.png" alt="">
          确认
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要提交数据吗?</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="clickOutAdd">确定</el-button>
          <el-button @click="confirmFlag= false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 借阅单提交 -->
      <el-dialog :visible.sync="lendFlag" class="hurdleAll" width="1170px">
        <div slot="title" class="dialog-title">
          <img src="../../assets/home/submit.png" alt />
          借阅单提交
        </div>
        <div>
          <div class="headerBtn mt-f14">
            <span @click="lendDel"><img src="../../assets/home/delete.png" alt="" />删除</span>
          </div>
          <div class="all-Table lend-table">
            <el-table :data="tableLend" border @selection-change="handleSelectionChange">
              <el-table-column type="selection" width="55"></el-table-column>
              <el-table-column prop="officeArchivalCode" label="档号" width="180"></el-table-column>
              <el-table-column prop="titleProper" label="题名" width="200"></el-table-column>
              <el-table-column prop="fondsCode" label="全宗"></el-table-column>
              <el-table-column prop="openingType" label="公开属性">
                <template slot-scope="scope">
                  {{outPubArr[scope.row.openingType]}}
                </template>
              </el-table-column>
              <el-table-column prop="filingDept" label="归档部门"></el-table-column>
            </el-table>
          </div>
          <div>
            <div class="header-lend">电子借阅单</div>
            <el-form :model="showParams" :rules="rules" ref="showParams" label-width="190px">
              <el-row :gutter="10">
                <el-col :span="8">
                  <el-form-item label="借阅人：" prop="personName">
                    <el-input v-model="showParams.personName"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="8">
                  <el-form-item label="借阅部门：" prop="deptName">
                    <el-input v-model="showParams.deptName"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="8">
                  <el-form-item label="联系方式：" prop="tel">
                    <el-input v-model="showParams.tel"></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row :gutter="10">
                <el-col :span="8">
                  <el-form-item label="申请日期：" prop="startDate">
                    <el-input v-model="showParams.startDate"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="8">
                  <el-form-item label="借阅方式：" prop="borrowType">
                    <el-select v-model="showParams.borrowType" @change="$forceUpdate()">
                      <el-option v-for="item in borrowArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span="8">
                  <el-form-item label="借阅时间(天)：" prop="endDate">
                    <el-select v-model="showParams.endDate" @change="$forceUpdate()">
                      <el-option v-for="item in borrowDayArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row :gutter="10">
                <el-col :span="8">
                  <el-form-item label="是否加水印：" prop="watermarkFlag">
                    <el-select v-model="showParams.watermarkFlag" @change="$forceUpdate()">
                      <el-option v-for="item in waterArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span="8">
                  <el-form-item label="对内/外部使用：" prop="brFaceTo">
                    <el-select v-model="showParams.brFaceTo" @change="$forceUpdate()">
                      <el-option v-for="item in faceArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <!-- 对外部使用 -->
                <el-col :span="8" v-if="showParams.brFaceTo ==1">
                  <el-form-item label="对外使用单位：" prop="brExternalDep1">
                    <el-select v-model="showParams.brExternalDep1" @change="$forceUpdate()">
                      <el-option v-for="item in exterArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row :gutter="10">
                <!-- 对外部使用 -->
                <el-col :span="8" v-if="showParams.brFaceTo ==1">
                  <el-form-item label="其他对外使用单位：" prop="brExternalDep2">
                    <el-input v-model="showParams.brExternalDep2" disabled></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-form-item label="借阅原因：" prop="reason">
                <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4}" v-model="showParams.reason"></el-input>
              </el-form-item>
              <!-- 借阅方式---选择实体借阅 -->
              <el-row :gutter="10">
                <el-col :span="8" v-if="showParams.borrowType ==2">
                  <el-form-item label="实体档案接收人姓名：" prop="acceptName">
                    <el-input v-model="showParams.acceptName"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="8" v-if="showParams.borrowType ==2">
                  <el-form-item label="实体档案接收人联系电话：" prop="acceptTel">
                    <el-input v-model="showParams.acceptTel"></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-form-item label="实体档案接收人地址：" prop="acceptAddr" v-if="showParams.borrowType ==2">
                <el-input type="textarea" :autosize="{ minRows: 1, maxRows: 1}" v-model="showParams.acceptAddr"></el-input>
              </el-form-item>
              <!-- 选择电子文档无水印 -->
              <el-form-item label="选择无水印原因：" prop="watermarkReason" v-if="showParams.watermarkFlag==2">
                <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4}" v-model="showParams.watermarkReason"></el-input>
              </el-form-item>
              <el-form-item label="是否修改：" prop="brChange" v-if="showParams.borrowType ==2">
                <el-radio v-model="showParams.brChange" label="1">是</el-radio>
                <el-radio v-model="showParams.brChange" label="0">否</el-radio>
              </el-form-item>
              <el-form-item prop="agreement2" v-if="showParams.borrowType ==2" class="requirIterm">
                <el-checkbox v-model="showParams.agreement2">擅自伪造、修改、抽换、隐匿或销毁档案的，属违法行为，将受法律追究！</el-checkbox>
              </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer all-btn">
              <el-button type="primary" @click="clickOrder">提交订阅</el-button>
              <el-button @click="lendFlag= false">关闭</el-button>
            </div>
          </div>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import { valueIndex } from '@/js/transitionText';
import { getFonds, getAndRole, getIdList, docList, listFolder, thStatus, thDept, saveTh, fileTh, addCar, fileAddCar, carCount, outList, outDelete, getListOrg, getListDept, saveRead, showBorrowDetail, submitOrder } from '@/js/getData';
export default {
  name: 'documentSearch',
  data() {
    const validateRe = (rule, value, callback) => {
      let reg = /^[\s\S]{11,}$/
      if (!reg.test(value)) {
        callback(new Error('请详细填写借阅原因（内容长度需大于10）！'))
      } else {
        callback();
      }
    }
    return {
      params: {
        page: 1,
        rows: 10,
        total: null,
        series4: 'DG'
      },
      c5Arr: ['已移交', '整理中', '已挂接', '已归档', '在库', '出库'],
      pubArr: ['', '公开', '内部', '受控', '广发商密三级', '广发商密二级', '广发商密一级'],
      saveArr: ['', '短期', '长期', '永久', '', '10年', '15年', '', '30年'],
      fonds: [],
      oneType: [],
      twoType: [],
      threeType: [],
      docData: [],
      forthType: [{ "key": "底稿", "value": "DG" }, { "key": "项目", "value": "XM" }],
      showFlag: true,
      typeFlag: true,
      seaFlag: false,
      paramsSea: {},
      statusArr: [],
      deptArr: [],
      titleFlag: false,
      titleMsg1: null,
      titleMsg2: null,
      oneTable: [],
      tableDetail: [],
      //案卷层
      openArr: ['', '公开', '内部', '受控', '广发商密三级', '广发商密二级', '广发商密一级'],
      perArr: ['', '短期', '长期', '永久', '', '10年', '15年', '', '30年'],
      dossParams: {
        page: 1,
        rows: 9,
        total: null,
      },
      dossFlag: false,
      tableDoss: [],
      dossOne: {},
      //文件层
      fileParams: {
        page: 1,
        rows: 9,
        total: null,
      },
      tableFiles: [],
      oneFiles: [],
      carTotal: null,
      //借阅
      borrowFlag: false,
      borrParams: {
        page: 1,
        rows: 9,
        total: null,
      },
      borrOne: [],
      tableBorr: [],
      outDelFlag: false,
      outPubArr: ['', '公开', '内部', '受控', '广发商密三级', '广发商密二级', '广发商密一级'],
      relAddFlag: false,
      paramsAdd: {},
      rulesAudit: {
        deptCode: [
          { required: true, message: '请选择借阅人', trigger: 'change' }
        ],
        userId: [
          { required: true, message: '请选择用户名', trigger: 'change' }
        ],
      },
      orgArr: [],
      userArr: [],
      showParams: {
        type: 'p',
        personName: null,
        deptName: null,
        tel: null,
        borrowType: null,
        startDate: null,
        endDate: null,
        watermarkFlag: null,
        reason: null,
        brFaceTo: null,
      },
      confirmFlag: false,
      lendFlag: false,
      tableLend: [],
      rules: {
        personName: [
          { required: true, message: '请输入借阅人', trigger: 'blur' }
        ],
        deptName: [
          { required: true, message: '请输入借阅部门', trigger: 'blur' }
        ],
        tel: [
          { required: true, message: '请输入联系方式', trigger: 'blur' }
        ],
        startDate: [
          { required: true, message: '请输入申请日期', trigger: 'blur' }
        ],
        region: [
          { required: true, message: '请选择活动区域', trigger: 'change' }
        ],
        borrowType: [
          { required: true, message: '请选择借阅方式', trigger: 'change' }
        ],
        endDate: [
          { required: true, message: '请选择借阅时间', trigger: 'change' }
        ],
        watermarkFlag: [
          { required: true, message: '请选择是否加水印', trigger: 'change' }
        ],
        brFaceTo: [
          { required: true, message: '请选择使用方式', trigger: 'change' }
        ],
        brExternalDep1: [
          { required: true, message: '请选择对外使用单位', trigger: 'change' }
        ],
        reason: [
          { required: true, message: '请输入借阅原因', trigger: 'blur' },
          { validator: validateRe, trigger: 'blur' }
        ],
        acceptName: [
          { required: true, message: '请输入实体档案接收人姓名', trigger: 'blur' }
        ],
        acceptTel: [
          { required: true, message: '请输入实体档案接收人联系电话', trigger: 'blur' }
        ],
        acceptAddr: [
          { required: true, message: '请输入实体档案接收人地址', trigger: 'blur' }
        ],
        brChange: [
          { required: true, message: '请选择是否修改', trigger: 'change' }
        ],
        watermarkReason: [
          { required: true, message: '请输入选择无水印原因', trigger: 'blur' }
        ],
        agreement2: [
          { required: true, message: '请勾选借阅协议!', trigger: 'change' }
        ]
      },
      // 借阅方式
      borrowArr: [{ 'name': '电子借阅', 'itemValue': '1' }, { 'name': '实体借阅', 'itemValue': '2' }],
      // 借阅时间
      borrowDayArr: [{ 'name': '2', 'itemValue': '2' }, { 'name': '3', 'itemValue': '3' }, { 'name': '4', 'itemValue': '4' }, { 'name': '5', 'itemValue': '5' }, { 'name': '6', 'itemValue': '6' }, { 'name': '7', 'itemValue': '7' }, { 'name': '8', 'itemValue': '8' }, { 'name': '9', 'itemValue': '9' }, { 'name': '10', 'itemValue': '10' }, { 'name': '20', 'itemValue': '20' }, { 'name': '30', 'itemValue': '30' }, { 'name': '50', 'itemValue': '50' }],
      // 是否加水印
      waterArr: [{ name: '电子文档添加水印', itemValue: '1' }, { name: '电子文档无水印', itemValue: '2' }],
      // 对内/外部使用
      faceArr: [{ 'name': '内部', 'itemValue': '0' }, { 'name': '外部', 'itemValue': '1' }],
      // 对外使用单位
      exterArr: [{ 'name': '证监会', 'itemValue': '证监会' }, { 'name': '人民银行', 'itemValue': '人民银行' }, { 'name': '公安机关', 'itemValue': '公安机关' }, { 'name': '外汇管理局', 'itemValue': '外汇管理局' }, { 'name': '纪委', 'itemValue': '纪委' }, { 'name': '审计署', 'itemValue': '审计署' }, { 'name': '财政部门', 'itemValue': '财政部门' }, { 'name': '税务部门', 'itemValue': '税务部门' }, { 'name': '政府机关', 'itemValue': '政府机关' }, { 'name': '其他', 'itemValue': '其他' }],
      lendOne: [],
    }
  },
  methods: {
    //获取全宗
    searchFond() {
      getFonds().then(res => {
        if (res.code == 0) {
          this.fonds = res.data;
          this.initFond();
        } else this.$message.error(res.message)
      })
    },
    //初始化选中全宗--原系统逻辑
    initFond(val) {
      if ("8106" == val) {
        this.params.fonds = 1463117877850; //广发乾和
      } else {
        this.params.fonds = 1374133141812 //新广发证券
      }
      this.fondsM();
    },
    //全宗方法
    fondsM() {
      this.searchType(this.params.fonds);
      this.initType();
    },
    //改变选中全宗
    changeFonds() {
      this.$forceUpdate();
      this.fondsM();
    },
    //根据全宗获取档案分类
    searchType(val) {
      getAndRole({ id: val }).then(res => {
        if (res.code == 0) {
          this.oneType = res.data;
        } else this.$message.error(res.message)
      })
    },
    //初始化选中档案分类--原系统逻辑
    initType() {
      if (this.params.fonds == 1463117877850) {
        this.params.series1 = 1463318429461 //管理类档案
      } else if (this.params.fonds == 1374133141812) {
        this.params.series1 = 1388742017296 //业务档案
      } else {
        this.params.series1 = null;
      }
      this.params.series2 = null;
      this.params.series3 = null;
      this.searchType1(this.params.series1, 1);
      this.initType1();
    },
    //改变第一个类型
    changeOne() {
      this.$forceUpdate();
      this.searchType1(this.params.series1, 1);
      this.params.series2 = null;
      this.params.series3 = null;
      this.initType1();
    },
    //根据档案分类id获取下级分类
    searchType1(val, val1) {
      getIdList({ id: val }).then(res => {
        if (res.code == 0) {
          if (val1 == 1) {
            this.twoType = res.data;
          } else this.threeType = res.data;
        } else this.$message.error(res.message)
      })
    },
    //初始化获取下级分类--原系统逻辑
    initType1() {
      if (this.params.series1 == 1388742017296) {
        this.params.series2 = 1388742017297 //投资银行
        this.typeFlag = true; //显示形式
      } else {
        this.params.series2 = null;
        this.typeFlag = false; //不显示形式
      }
      this.params.series3 = null;
      this.searchType1(this.params.series2, 2);
      this.initList();
    },
    //改变第二个类型
    changeTwo() {
      this.$forceUpdate();
      this.searchType1(this.params.series2, 2);
      this.params.series3 = null;
      if (this.params.series2 == 1388742017297) {
        this.typeFlag = true; //显示形式
      } else this.typeFlag = false; //不显示形式
      this.initList();
    },
    //改变第三个类型
    changeThree() {
      this.$forceUpdate();
      this.initList();
    },
    //初始化获取档案列表--原系统逻辑
    initList() {
      this.params.c5 = null;
      if (this.params.series1) {
        if (this.params.series1 == 1388742017296 && this.params.series2 == 1388742017297) { //选中业务档案；投资银行
          if (this.params.series3 == 1567558827500) { //发行材料 c5:0 原系统逻辑
            this.params.c5 = 1;
            this.resetInit();
            this.searchOne();
          } else {
            this.params.c5 = 0;
            if (this.params.series4 == 'DG') {
              this.resetInit();
              this.searchOne();
            }
          }
          this.showFlag = true;
        } else {
          this.showFlag = false;
        }
      } else this.showFlag = false;
    },
    resetInit() {
      this.params.searchType = null;
      this.params.thseriesCode = null;
      this.params.thfilingDept = null;
      this.params.thc18 = null;
      this.params.thyearCode = null;
      this.params.thc5 = null;
      this.params.thc10 = null;
      this.params.thc24 = null;
      this.params.thtitleProper = null;
      this.params.thc20 = null;
      this.params.thc22 = null;
      this.params.thc28 = null;
      this.params.addressNo = null;
    },
    //获取档案列表
    searchOne() {
      this.params.page = 1;
      this.searchList();
    },
    searchList() {
      docList(this.params).then(res => {
        if (res.code == 0) {
          if (res.data.total <= 0) {
            this.titleMsg1 = '系统消息';
            this.titleMsg2 = '该条件下查无数据!';
            this.titleFlag = true;
          }
          this.docData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    docChange(val) {
      this.params.page = val;
      this.searchList();
    },
    docSelect(val) {
      this.oneTable = val;
    },
    //改变形式
    changeType() {
      this.$forceUpdate();
      this.initList();
    },
    //项目档案检索
    getStatus() {
      thStatus().then(res => {
        if (res.code == 0) {
          this.statusArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    getDept() {
      thDept().then(res => {
        if (res.code == 0) {
          this.deptArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    openSea() {
      this.getStatus();
      this.getDept();
      this.seaFlag = true;
      this.paramsSea = {};
    },
    searchSea() {
      if (JSON.stringify(this.paramsSea) === '{}') {
        this.$message.error('请至少输入一项条件！')
      } else {
        this.resetInit();
        this.params.searchType = 1; //原系统逻辑
        Object.assign(this.params, this.paramsSea);
        this.searchOne();
        this.seaFlag = false;
      }
    },
    //加入借阅车
    addDoc() {
      let open = this.$onceWay().onceTableList(this.oneTable);
      if (open == 1) {
        let carParams = {
          infoId: this.oneTable[0].id,
          type: 'p'
        };
        addCar(carParams).then(res => {
          if (res.code == 0) {
            if (res.data.result == 1) {
              this.titleMsg1 = '系统消息';
              this.titleMsg2 = '加入借阅车成功，点击借阅车可查看详情';
              this.titleFlag = true;
              this.updateCar('add')
            } else if (res.data.result == 2) {
              this.titleMsg1 = '系统消息';
              this.titleMsg2 = '该档案已存放借阅车，点击借阅车可查看详情';
              this.titleFlag = true;
            } else {
              this.titleMsg1 = '系统消息';
              this.titleMsg2 = '对不起，加入借阅车失败,因为：' + res.data.msg;
              this.titleFlag = true;
            }
          } else this.$message.error(res.message)
        })
      }
    },
    //文件下载
    docDown() {
      valueIndex().exportFiles('/gdda-new/gdda/archiveSearch/downLoadThDgCzZy', null, '档案系统投行底稿借阅操作指引.docx', 'get');
    },
    //获取借阅车数量
    searchNum() {
      carCount().then(res => {
        if (res.code == 0) {
          this.carTotal = res.data.borrowCarCount;
        } else this.$message.error(res.message)
      })
    },
    //借阅车--增删
    updateCar(val, count) {
      if (val == 'add') {
        if (this.carTotal) {
          this.carTotal++;
        } else this.carTotal = 1;
      } else if (val == 'del') {
        if (this.carTotal >= 1) {
          this.carTotal = this.carTotal - count; //不一定是减1，是减借阅的数量
        } else {
          this.carTotal = 0;
        }
      }
    },
    //详情
    openDetail(row) {
      this.dossOne = row;
      this.dossFlag = true;
      this.searchDoss();
      this.searchFile();
    },
    //详情--案卷层
    dossChange() {

    },
    searchDoss() {
      this.dossParams.subId = this.dossOne.id;
      listFolder(this.dossParams).then(res => {
        if (res.code == 0) {
          this.tableDoss = res.data.rows;
          this.dossParams.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    dossCurrChange(val) {
      this.dossParams.page = val;
      this.searchDoss();
    },
    //详情--文件层
    searchFile() {
      this.fileParams.projectId = this.dossOne.id;
      fileTh(this.fileParams).then(res => {
        if (res.code == 0) {
          this.tableFiles = res.data.rows;
          this.fileParams.total = res.data.total;
        } else this.$message.error(res.message)

      })
    },
    filesCurrChange(val) {
      this.fileParams.page = val;
      this.searchFile();
    },
    filesChange(val) {
      this.oneFiles = val;
    },
    //详情文件层-借阅
    addFileDoc() {
      let open = this.$onceWay().onceTableList(this.oneFiles);
      if (open == 1) {
        let carParams = {
          infoId: this.oneFiles[0].id,
          type: 'f'
        }
        fileAddCar(carParams).then(res => {
          if (res.code == 0) {
            if (res.data.result == 1) {
              this.titleMsg1 = '系统消息';
              this.titleMsg2 = '加入借阅车成功，点击借阅车可查看详情';
              this.titleFlag = true;
              this.updateCar('add')
            } else if (res.data.result == 2) {
              this.titleMsg1 = '系统消息';
              this.titleMsg2 = '该档案已存放借阅车，点击借阅车可查看详情';
              this.titleFlag = true;
            } else {
              this.titleMsg1 = '系统消息';
              this.titleMsg2 = '对不起，加入借阅车失败,因为：' + res.data.msg;
              this.titleFlag = true;
            }
          } else this.$message.error(res.message)
        })
      }
    },
    //借阅车弹框
    //打开借阅车弹框
    openBorr() {
      this.borrowFlag = true;
      this.searchOneBorr();
    },
    searchOneBorr() {
      this.borrParams.page = 1;
      this.searchOutBorr();
    },
    searchOutBorr() {
      outList(this.borrParams).then(res => {
        if (res.code == 0) {
          this.tableBorr = res.data.rows;
          this.borrParams.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    borrCurrChange(val) {
      this.borrParams.page = val;
      this.searchOutBorr();
    },
    borrSelect(val) {
      this.borrOne = val;
    },
    //借阅车删除(最外层)
    openOutDel() {
      let open = this.$onceWay().onceTableListTwo(this.borrOne);
      if (open == 1) {
        this.outDelFlag = true;
      }
    },
    clickOutDel() {
      let bleng = this.borrOne.length;
      let ids = this.$onceWay().deleteId(this.borrOne);
      outDelete({ borrowCarIds: ids }).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.updateCar('del', bleng);
          this.searchOneBorr();
          this.outDelFlag = false;
        } else this.$message.error(res.message)
      })
    },
    openOutRel() {
      let open = this.$onceWay().onceTableListTwo(this.borrOne);
      if (open == 1) {
        this.searchOrg();
        this.paramsAdd = {};
        this.relAddFlag = true;
        if (this.$refs['paramsAdd']) {
          this.$nextTick(() => {
            this.$refs['paramsAdd'].clearValidate();
          })
        }
      }
    },
    //获取关联借阅人--下拉部门
    searchOrg(val) {
      getListOrg({ id: val }).then(res => {
        if (res.code == 0) {
          this.orgArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //获取关联借阅人--下拉用户(选中部门查询用户)
    searchUser(val) {
      getListDept({ id: val }).then(res => {
        if (res.code == 0) {
          this.userArr = res.data || [];
        } else this.$message.error(res.message)
      })
    },
    //关联借阅人前-确认
    clickCom() {
      this.$refs['paramsAdd'].validate((valid) => {
        if (valid) {
          this.relAddFlag = false;
          this.confirmFlag = true;
        }
      })
    },
    //关联借阅人
    clickOutAdd() {
      let bleng = this.borrOne.length;
      let ids = this.$onceWay().deleteId(this.borrOne);
      this.paramsAdd.borrowCarIds = ids;
      saveRead(this.paramsAdd).then(res => {
        if (res.code == 0) {
          this.confirmFlag = false;
          this.$message.success('操作成功!');
          this.updateCar('del', bleng);
          this.searchOneBorr();
        } else this.$message.error(res.message)
      })
    },
    //借阅
    openLend() {
      let open = this.$onceWay().onceTableListTwo(this.borrOne);
      if (open == 1) {
        this.searchBorrowDetail();
        this.lendFlag = true;
        this.showParams = {
          type: 'p',
          personName: null,
          deptName: null,
          tel: null,
          borrowType: null,
          startDate: null,
          endDate: null,
          watermarkFlag: null,
          reason: null,
          brFaceTo: null,
        }
        if (this.$refs['showParams']) {
          this.$nextTick(() => {
            this.$refs['showParams'].clearValidate();
          })
        }
      }
    },
    // 查询弹框详情
    searchBorrowDetail() {
      let ids = this.$onceWay().deleteId(this.borrOne);
      let detail = {
        borrowCarIds: ids,
        type: 'p'
      }
      this.showParams.borrowCarIds = ids
      this.showParams.infoIds = ids
      showBorrowDetail(detail).then(res => {
        if (res.code == 0) {
          this.tableLend = res.data.borrowCarContent;
          this.showParams.personName = res.data.userName
          this.showParams.deptName = res.data.tOrgName
          this.showParams.tel = res.data.mobile
          this.showParams.borrowType = res.data.type || null
          this.showParams.startDate = res.data.startDate || null,
          this.showParams.endDate = this.borrowDayArr[0].itemValue
          this.showParams.watermarkFlag = this.waterArr[0].itemValue
        } else this.$message.error(res.message)
      })
    },
    // 提交订阅
    clickOrder() {
      this.showParams.infoIds = this.$onceWay().deleteId(this.lendOne)
      let bleng = this.borrOne.length;
      this.$refs['showParams'].validate((valid) => {
        if (valid) {
          if (this.lendOne.length > 0) {
            submitOrder(this.showParams).then(res => {
              if (res.code == 0) {
                this.$message.success(res.message)
                this.searchOneBorr();
                this.updateCar('del', bleng);
                this.lendFlag = false
              } else this.$message.error(res.message)
            })
          } else this.$message.error('请至少选择一条待借阅档案！')
        }
      })
    },
    handleSelectionChange(val) {
      this.lendOne = val;
    },
    //订阅删除
    lendDel() {
      let index = -1;
      let open = this.$onceWay().onceTableList(this.lendOne);
      if (open == 1) {
        let index = this.tableLend.indexOf(this.lendOne[0])
        this.tableLend.splice(index, 1);
      }
    }
  },
  created() {
    this.searchFond();
    this.searchNum();
  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.search-doc {
  margin-top: 10px;

  label {
    font-size: 14px;
    color: #282828;
    padding-right: 5px
  }

  .el-input,
  .el-select {
    width: 200px;
  }
}

.table-botton {
  width: 80%;
  background: #08A9E6;
  color: #fff;
}

.seeDoc {
  width: 100%;
  clear: both;
  height: 500px;

  .seeDoc-left {
    width: 20%;
    float: left;
  }

  .seeDoc-right {
    width: 79%;
    float: left;
    border-left: 3px solid #1982BF;
    height: 500px;
  }
}

.doc-car {
  background: url(../../assets/home/d2.png) no-repeat;
  position: fixed;
  width: 70px;
  height: 70px;
  right: 16px;
  bottom: 70px;
  z-index: 99999;
}

.doc-main {
  background-color: #fff;
  min-height: 700px;

  .mb-20 {

    margin-bottom: 20px;
  }

  .doc-down {
    font-size: 13px;
    color: #515BED;
    float: right;
  }

  .w-100 {
    width: 100%
  }

  .doc-doss {
    width: 100%;
    height: 500px;
    overflow: auto;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .mt-f18 {
    margin-top: -18px;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .lend-table {
    max-height: 200px;
    overflow-y: auto;
    width: 100%
  }
}

</style>
