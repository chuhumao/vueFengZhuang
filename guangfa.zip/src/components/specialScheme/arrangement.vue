<!-- 综合档案整理 -->
<template>
  <div>
    <div class="ar-top">
      <span @click="open1" class="ar-span"><img src="../../assets/turnOver/ds.png" alt="" class="ar-img">设置保管期限</span>
      <span>
        <electronic style="display: inline-block;"></electronic>
      </span>
    </div>
    <!-- 保管期限弹框 -->
    <!-- 保管期限弹框--列表 -->
    <el-dialog :visible.sync="sDFlag" class="hurdleAll" width="1100px">
      <div slot="title" class="dialog-title">
        <img src="../../assets/turnOver/s6.png" alt />
        保管期限
      </div>
      <div>
        <div class="headerBtn mt-f19">
          <span @click="openAdd"><img src="../../assets/turnOver/tj.png" alt="" />添加规则</span>
          <span @click="openDel"><img src="../../assets/turnOver/delete.png" alt="" />删除规则</span>
          <span @click="openCopy"><img src="../../assets/turnOver/s7.png" alt="" />复制规则</span>
          <span @click="openExe"><img src="../../assets/turnOver/s4.png" alt="" />执行规则</span>
          <span @click="openStart"><img src="../../assets/turnOver/s3.png" alt="" />启用规则</span>
          <span @click="openEnd"><img src="../../assets/turnOver/s2.png" alt="" />禁用规则</span>
          <span @click="exportFlag = true"><img src="../../assets/turnOver/s5.png" alt="" />导出</span>
          <span @click="openImport"><img src="../../assets/turnOver/js.png" alt="" />筛选问题文件</span>
        </div>
        <div class="all-Table doc-doss">
          <el-table :data="sDTable" border @selection-change="sDSelect">
            <el-table-column type="selection" width="55"></el-table-column>
            <el-table-column prop="tgddaRetentionPeriod.serialNumber" label="规则号" width="80"></el-table-column>
            <el-table-column prop="retentionFondsName" label="全宗" width="150"></el-table-column>
            <el-table-column prop="retentionArchiveTypeName" label="档案类型" width="150"></el-table-column>
            <el-table-column prop="tgddaRetentionPeriod.yearCode" label="年度" width="80"></el-table-column>
            <el-table-column prop="tgddaRetentionPeriod.retentionPeriod" label="保管期限" width="100">
              <template slot-scope="scope">
                {{saveArr[scope.row.tgddaRetentionPeriod.retentionPeriod]}}
              </template>
            </el-table-column>
            <el-table-column prop="tgddaRetentionPeriod.retentionRule" label="保管规则"></el-table-column>
            <el-table-column prop="tgddaRetentionPeriod.isUsing" label="是否启用" width="80">
              <template slot-scope="scope">
                {{usArr[scope.row.tgddaRetentionPeriod.isUsing]}}
              </template>
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="sDCurrChange" :current-page="sDParams.page" :page-size="sDParams.rows" layout="prev, pager, next, jumper" :total="sDParams.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button @click="sDFlag= false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 保管期限--添加规则 -->
    <el-dialog :visible.sync="sdAddFlag" width="1000px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/turnOver/s6.png" alt="">
        设置保管期限
      </div>
      <div>
        <div>
          <el-form :model="params" ref="params" :rules="valiRule" label-width="100px">
            <el-row :gutter="20">
              <el-col :span="7">
                <el-form-item label="全宗：" prop="retentionFonds">
                  <el-select v-model="params.retentionFonds" @change="changeFonds" :disabled="allFlag">
                    <el-option v-for="item in fonds" :key="item.id" :value="item.id" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="7">
                <el-form-item label="档案类型：" prop="retentionArchiveType" @change="$forceUpdate()">
                  <el-select v-model="params.retentionArchiveType" :disabled="allFlag">
                    <el-option v-for="item in oneType" :key="item.id" :value="item.id" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="5">
                <el-form-item label="年度：" prop="yearCode">
                  <el-select v-model="params.yearCode" @change="$forceUpdate()" :disabled="allFlag">
                    <el-option v-for="item in yearArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="5">
                <el-form-item label="保管期限：" prop="retentionPeriod">
                  <el-select v-model="params.retentionPeriod" :disabled="allFlag">
                    <el-option v-for="item in saveDateArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="7">
                <el-form-item label="字段：" prop="limitFieldsValue">
                  <el-select v-model="params.limitFieldsValue" @change="changeField">
                    <el-option v-for="item in limitFields" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="7">
                <el-form-item label="连接关系：" prop="relationValue">
                  <el-select v-model="params.relationValue">
                    <el-option v-for="item in relation" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="10">
                <el-form-item label="关键字：" prop="remark">
                  <el-input v-model.trim="params.remark" v-show="!selectFlag"></el-input>
                  <el-select v-model="params.remark" v-show="selectFlag" @change="$forceUpdate()">
                    <el-option v-for="item in remarkArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <div class="headerBtn mb-2">
          <span class="ar-show1">操作:</span>
          <span @click="clickAdd" class="ar-100"><img src="../../assets/turnOver/tj.png" alt="">加入条件</span>
          <span @click="clickDelCond" class="ar-100"><img src="../../assets/turnOver/delete.png" alt="">删除条件</span>
        </div>
        <div class="headerBtn">
          <span class="ar-show1">连接条件:</span>
          <span class="ar-100" @click="clickAnd"><img src="../../assets/turnOver/s8.png" alt="">并且</span>
          <span class="ar-100" @click="clickOr"><img src="../../assets/turnOver/s9.png" alt="">或者</span>
          <span class="ar-100" @click="clickInter"><img src="../../assets/turnOver/s10.png" alt="">加入规则</span>
        </div>
        <div>
          <div class="all-Table ar-table">
            <el-table :data="addTable" border @selection-change="addSelect">
              <el-table-column type="selection" width="55"></el-table-column>
              <el-table-column prop="yearCode" label="年度" width="100"></el-table-column>
              <el-table-column prop="retentionPeriod" label="保管期限" width="120">
                <template slot-scope="scope">
                  {{saveArr[scope.row.retentionPeriod]}}
                </template>
              </el-table-column>
              <el-table-column prop="limitfields" label="字段" width="120"></el-table-column>
              <el-table-column prop="retentionSrules" label="保管规则">
              </el-table-column>
            </el-table>
          </div>
          <!-- 分页 -->
          <div class="pageLayout">
            <el-pagination @current-change="addCurrChange" :current-page="addParams.page" :page-size="addParams.rows" layout="prev, pager, next, jumper" :total="addParams.total">
            </el-pagination>
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="clickSdSave">保存</el-button>
        <el-button @click="sdAddFlag= false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 添加规则前做确认 -->
    <el-dialog :visible.sync="beforeFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        保存确认
      </div>
      <div class="ar-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要保存此数据吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="clickSdSave1">确定</el-button>
        <el-button @click="beforeFlag= false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 复制规则弹框 -->
    <el-dialog :visible.sync="copyFlag" width="1000px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/turnOver/s6.png" alt />
        复制保管期限
      </div>
      <div>
        <div>
          <el-form :model="paramsCopy" label-width="100px" :rules="validateCopy" ref="paramsCopy">
            <el-row :gutter="20">
              <el-col :span="7">
                <el-form-item label="全宗：" prop="retentionFonds">
                  <el-select v-model="paramsCopy.retentionFonds" @change="changeFonds">
                    <el-option v-for="item in fonds" :key="item.id" :value="item.id" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="7">
                <el-form-item label="档案类型：" prop="retentionArchiveType">
                  <el-select v-model="paramsCopy.retentionArchiveType" @change="$forceUpdate()">
                    <el-option v-for="item in oneType" :key="item.id" :value="item.id" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="5">
                <el-form-item label="年度：" prop="yearCode">
                  <el-select v-model="paramsCopy.yearCode" @change="$forceUpdate()">
                    <el-option v-for="item in yearArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="5">
                <el-form-item label="保管期限：" prop="retentionPeriod">
                  <el-select v-model="paramsCopy.retentionPeriod" @change="$forceUpdate()">
                    <el-option v-for="item in saveDateArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="beforeCopy">保存</el-button>
        <el-button @click="copyFlag= false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 复制规则前--判断 -->
    <el-dialog :visible.sync="copyFlag1" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        复制确认
      </div>
      <div class="ar-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要复制此规则吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="clickCopy">确定</el-button>
        <el-button @click="copyFlag1= false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 保管期限弹框 --删除规则 -->
    <el-dialog :visible.sync="sdDelFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        删除确认
      </div>
      <div class="ar-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要删除此数据吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="clickDel">确定</el-button>
        <el-button @click="sdDelFlag= false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 保管期限弹框 --执行规则 -->
    <el-dialog :visible.sync="executeFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        执行确认
      </div>
      <div class="ar-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要执行此规则吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="clickExe">确定</el-button>
        <el-button @click="executeFlag= false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 保管期限弹框 --启用规则 -->
    <el-dialog :visible.sync="startFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        启用确认
      </div>
      <div class="ar-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要启用此规则吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="clickStart">确定</el-button>
        <el-button @click="startFlag= false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 保管期限弹框 --禁用规则 -->
    <el-dialog :visible.sync="endFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        禁用确认
      </div>
      <div class="ar-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要禁用此规则吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="clickEnd">确定</el-button>
        <el-button @click="endFlag= false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 保管期限弹框 --导出 -->
    <el-dialog :visible.sync="exportFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        系统提示
      </div>
      <div class="ar-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要导出规则吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="clickExport">确定</el-button>
        <el-button @click="exportFlag= false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 保管期限弹框--筛选问题文件 -->
    <el-dialog :visible.sync="searchFlag" class="hurdleAll" width="900px">
      <div slot="title" class="dialog-title">
        <img src="../../assets/turnOver/s14.png" alt />
        问题档案
      </div>
      <div>
        <div class="headerBtn mt-f19">
          <span @click="saveDoc"><img src="../../assets/turnOver/bc.png" alt="" />保存</span>
          <span @click="exFlag = true"><img src="../../assets/turnOver/s5.png" alt="" />导出</span>
          <span @click="openUpload"><img src="../../assets/turnOver/dr.png" alt="" />Excel导入</span>
        </div>
        <div class="all-Table doc-doss">
          <el-table :data="tableSearch" border @selection-change="searchSelect">
            <el-table-column type="selection" width="55"></el-table-column>
            <el-table-column prop="titleProper" label="题名"></el-table-column>
            <el-table-column prop="fileCode" label="文号" width="120"></el-table-column>
            <el-table-column prop="retentionPeriod" label="保管期限" width="100">
              <template slot-scope="scope">
                {{saveArr[scope.row.retentionPeriod]}}
              </template>
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="searchCurrChange" :current-page="searchParams.page" :page-size="searchParams.rows" layout="prev, pager, next, jumper" :total="searchParams.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button @click="searchFlag= false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 筛选问题文件--保存前确认 -->
    <el-dialog :visible.sync="submitFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        系统提示
      </div>
      <div class="ar-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要提交数据吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="clickSubmit">确定</el-button>
        <el-button @click="submitFlag= false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 筛选问题文件--上传文件 -->
    <el-dialog :visible.sync="uploadProFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/home/map2.png" alt="">
        Excel导入
      </div>
      <div class="map-upload">
        上传 <el-upload class="map-demo" ref="upload" action="#" :limit='1' :auto-upload="false" accept=".xls" :on-exceed="handleExceed" :on-remove="handleRemove" :before-remove="beforeRemove" :on-change="handleChange">
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="saveUploadPro">导入</el-button>
        <el-button @click="resetUploadPro">取消</el-button>
      </div>
    </el-dialog>
    <!-- 筛选问题文件--导出前确认 -->
    <el-dialog :visible.sync="exFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        系统提示
      </div>
      <div class="ar-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要导出规则吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="exportProblem">确定</el-button>
        <el-button @click="exFlag= false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import axios from 'axios';
import { valueIndex } from '@/js/transitionText';
import { BASICURL, sdList, sdDel, sdRun, sdStart, sdEnd, getFonds, yearCodeList, fieldList, addCondition, listRule, delCond, andReten, orReten, interReten, saveReten, copyReten, importExcel, listArch, saveProblem, getAndRole } from '@/js/getData';
import electronic from '../../components/specialScheme/electronic'
export default {
  name: 'arrangement',
  components: {
    electronic
  },
  data() {
    return {
      exFlag: false,
      proUploadUrl: null,
      fonds: [],
      oneType: [],
      yearArr: [],
      executeFlag: false,
      uploadProFlag: false,
      sDFlag: false,
      sDTable: [],
      sDParams: {
        page: 1,
        rows: 8,
        total: null
      },
      addTable: [],
      addParams: {
        page: 1,
        rows: 5,
        total: null
      },
      allFlag: false,
      saveDateArr: [
        { "name": "永久", "itemValue": "3" },
        { "name": "长期", "itemValue": "2" },
        { "name": "短期", "itemValue": "1" },
        { "name": "10年", "itemValue": "5" },
        { "name": "15年", "itemValue": "6" },
        { "name": "30年", "itemValue": "8" }
      ],
      limitFields: [
        { "name": "文号", "itemValue": "FILE_CODE" },
        { "name": "题名", "itemValue": "TITLE_PROPER" },
        { "name": "文件类型", "itemValue": "C100" },
        { "name": "来源系统", "itemValue": "C92" },
        { "name": "来源模块", "itemValue": "C105" }
      ],
      relation: [
        { "name": "等于", "itemValue": "=" },
        { "name": "不等于", "itemValue": "<>" },
        { "name": "包含", "itemValue": "like" },
        { "name": "不包含", "itemValue": "not like" }
      ],
      remarkArr: [],
      arr1: [
        { "id": "OA", "text": "OA" },
        { "id": "BPM", "text": "BPM" },
        { "id": "投行", "text": "投行" },
        { "id": "印章管理", "text": "印章管理" }
      ],
      arr2: [
        { "id": "收文管理", "text": "收文管理" },
        { "id": "部门盖章", "text": "部门盖章" },
        { "id": "乾和请示", "text": "乾和请示" },
        { "id": "印章管理", "text": "印章管理" },
        { "id": "发文管理", "text": "发文管理" },
        { "id": "会议登记流程", "text": "会议登记流程" },
        { "id": "总部请示", "text": "总部请示" },
        { "id": "零售业务系统请示", "text": "零售业务系统请示" },
        { "id": "工作总结", "text": "工作总结" }
      ],
      sdAddFlag: false,
      valiRule: {
        retentionFonds: [{ required: true, message: '请选择全宗！', trigger: 'change' }],
        retentionArchiveType: [{ required: true, message: '请选择档案类型!', trigger: 'change' }],
        yearCode: [{ required: true, message: '请选择年度!', trigger: 'change' }],
        retentionPeriod: [{ required: true, message: '请选择保管期限!', trigger: 'change' }],
        limitFieldsValue: [{ required: true, message: '请选择字段!', trigger: 'change' }],
        relationValue: [{ required: true, message: '请选择连接关系!', trigger: 'change' }],
        remark: [{ required: true, message: '关键字不能为空!', trigger: 'change' }]
      },
      validateCopy: {
        retentionFonds: [{ required: true, message: '请选择全宗！', trigger: 'change' }],
        retentionArchiveType: [{ required: true, message: '请选择档案类型!', trigger: 'change' }],
        yearCode: [{ required: true, message: '请选择年度!', trigger: 'change' }],
        retentionPeriod: [{ required: true, message: '请选择保管期限!', trigger: 'change' }],
      },
      oneCond: [],
      params: {},
      selectFlag: false,
      paramsCopy: {},
      copyFlag: false,
      copyFlag1: false,
      saveArr: ['', '短期', '长期', '永久', '', '10年', '15年', '', '30年'],
      usArr: ['未启用', '已启用', '已禁用'],
      oneTable: [],
      sdDelFlag: false,
      startFlag: false,
      endFlag: false,
      exportFlag: false,
      searchFlag: false,
      tableSearch: [],
      searchParams: {
        page: 1,
        rows: 5,
        total: null
      },
      searchOne: [],
      submitFlag: false,
      values: "",
      beforeFlag: false,
    }
  },
  methods: {
    open1() {
      this.sDFlag = true;
      this.searchSdList();
    },
    // 保管期限--列表
    searchSdList() {
      sdList(this.sDParams).then(res => {
        if (res.code == 0) {
          this.sDTable = res.data.rows;
          this.sDParams.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    searchOneList() {
      this.sDParams.page = 1;
      this.searchSdList();
    },
    sDSelect(val) {
      this.oneTable = val;
    },
    sDCurrChange(val) {
      this.sDParams.page = val;
      this.searchSdList();
    },
    //保管期限--添加规则
    openAdd() {
      this.allFlag = false;
      this.sdAddFlag = true;
      this.params = {
        retentionFonds: null,
        retentionArchiveType: null,
        yearCode: null
      };
      if (this.$refs['params']) {
        this.$nextTick(() => {
          this.$refs['params'].clearValidate()
        })
      }
      this.getYear();
      this.searchFond();
      this.addOneList();
    },
    //获取全宗
    searchFond(val) {
      getFonds().then(res => {
        if (res.code == 0) {
          this.fonds = res.data;
          this.initFond();
        } else this.$message.error(res.message)
      })
    },
    //初始化选中全宗--原系统逻辑
    initFond(val) {
      this.paramsCopy.retentionFonds = this.params.retentionFonds = 1374133141812 //新广发证券
      this.paramsCopy.yearCode = this.params.yearCode = (new Date()).getFullYear() //初始化选中年份
      this.fondsM();
    },
    //全宗方法
    fondsM() {
      this.searchType(this.params.retentionFonds);
      this.initType();
    },
    //改变选中全宗
    changeFonds() {
      this.$forceUpdate();
      this.fondsM();
    },
    //根据全宗获取档案分类
    searchType(val) {
      getAndRole({ id: val }).then(res => {
        if (res.code == 0) {
          this.oneType = res.data;
        } else this.$message.error(res.message)
      })
    },
    //初始化选中档案分类--原系统逻辑
    initType() {
      if (this.paramsCopy.retentionFonds == 1374133141812) {
        this.paramsCopy.retentionArchiveType = 1379482316593 //管理类案件
      } else {
        this.paramsCopy.retentionArchiveType = null;
      }
      if (this.params.retentionFonds == 1374133141812) {
        this.params.retentionArchiveType = 1379482316593 //管理类案件
      } else {
        this.params.retentionArchiveType = null;
      }
    },
    //年度下拉
    getYear() {
      yearCodeList().then(res => {
        if (res.code == 0) {
          this.yearArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //字段改变控制关键字
    changeField(val) {
      this.remarkArr = [];
      delete this.params.remark;
      if (val == "C100") { //文件类型--显示关键字（下拉框）
        this.selectFlag = true; //1.清空关键字输入  2.获取下拉关键字数据（接口获取）
        this.getField();
      } else if (val == "C92") { //来源系统  显示关键字（下拉框）
        this.selectFlag = true; //1.清空关键字输入  2.获取下拉关键字数据（直接写死）
        this.remarkArr = this.arr1;
      } else if (val == "C105") { //来源模块  显示关键字（下拉框）
        this.selectFlag = true; //1.清空关键字输入  2.获取下拉关键字数据（直接写死）
        this.remarkArr = this.arr2;
      } else if (val == "FILE_CODE" || val == "TITLE_PROPER") { //文号 和 题名 -- 输入框
        this.selectFlag = false; //1.清空关键字输入
      }
    },
    //关键字下拉
    getField() {
      fieldList().then(res => {
        if (res.code == 0) {
          this.remarkArr = res.data;
        } else this.$message.error(res.message);
      })
    },
    //添加规则--加入条件
    clickAdd() {
      this.$refs['params'].validate((valid) => {
        if (valid) {
          let obj = {};
          let obj1 = {};
          obj = this.relation.find((item) => {
            return item.itemValue === this.params.relationValue;
          });
          obj1 = this.limitFields.find((item) => {
            return item.itemValue === this.params.limitFieldsValue;
          });
          this.params.relationText = obj.name;
          this.params.limitFieldsText = obj1.name;
          addCondition(this.params).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message);
              this.addOneList();
              this.allFlag = true;
            } else this.$message.error(res.message);
          })
        }
      })
    },
    //添加规则--加入列表
    addList() {
      listRule(this.addParams).then(res => {
        if (res.code == 0) {
          this.addTable = res.data.rows;
          this.addParams.total = res.data.total;
        } else this.$message.error(res.message);
      })
    },
    addCurrChange(val) {
      this.addParams.page = val;
      this.addList();
    },
    addOneList() {
      this.addParams.page = 1;
      this.addList();
    },
    addSelect(val) {
      this.oneCond = val;
    },
    //添加期限--删除条件
    clickDelCond() {
      if (this.oneCond.length <= 0) {
        this.$message.error('请选择要删除的规则')
      } else {
        let ids = this.$onceWay().deleteId(this.oneCond);
        delCond({ ids: ids }).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message);
            this.addOneList();
          } else this.$message.error(res.message)
        })
      }
    },
    //添加期限--并且
    clickAnd() {
      if (this.oneCond.length <= 1) {
        this.$message.error('请至少选择两条规则进行并关系外连接!')
      } else {
        this.andMethod();
      }
    },
    andMethod() {
      let flag = true;
      this.oneCond.forEach(item => {
        if (item.retentionFonds != this.oneCond[0].retentionFonds) {
          this.$message.error('请选择相同全宗的规则进行并关系外连接!');
          flag = false;
          return;
        }
        if (item.retentionArchiveType != this.oneCond[0].retentionArchiveType) {
          this.$message.error('请选择相同档案类型的规则进行并关系外连接!');
          flag = false;
          return;
        }
        if (item.retentionPeriod != this.oneCond[0].retentionPeriod) {
          this.$message.error('请选择相同保管时间的规则进行并关系外连接!');
          flag = false;
          return;
        }
        if (item.yearCode != this.oneCond[0].yearCode) {
          this.$message.error('请选择相同年度的规则进行并关系外连接!');
          flag = false;
          return;
        }
      });
      if (flag) {
        let ids = this.$onceWay().deleteId(this.oneCond);
        andReten({ ids: ids }).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message);
            this.addOneList();
          } else this.$message.error(res.message)
        })
      }
    },
    //添加期限--或者
    clickOr() {
      if (this.oneCond.length <= 1) {
        this.$message.error('请至少选择两条规则进行或关系外连接!')
      } else {
        this.orMethod();
      }
    },
    orMethod() {
      let flag = true;
      this.oneCond.forEach(item => {
        if (item.retentionFonds != this.oneCond[0].retentionFonds) {
          this.$message.error('请选择相同全宗的规则进行或关系外连接!');
          flag = false;
          return;
        }
        if (item.retentionArchiveType != this.oneCond[0].retentionArchiveType) {
          this.$message.error('请选择相同档案类型的规则进行或关系外连接!');
          flag = false;
          return;
        }
        if (item.retentionPeriod != this.oneCond[0].retentionPeriod) {
          this.$message.error('请选择相同保管时间的规则进行或关系外连接!');
          flag = false;
          return;
        }
        if (item.yearCode != this.oneCond[0].yearCode) {
          this.$message.error('请选择相同年度的规则进行或关系外连接!');
          flag = false;
          return;
        }
      });
      if (flag) {
        let ids = this.$onceWay().deleteId(this.oneCond);
        orReten({ ids: ids }).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message);
            this.addOneList();
          } else this.$message.error(res.message)
        })
      }
    },
    //添加期限--加入规则
    clickInter() {
      if (this.oneCond.length <= 1) {
        this.$message.error('请至少选择两条规则进行或关系内连接!')
      } else {
        this.interMethod();
      }
    },
    interMethod() {
      let flag = true;
      this.oneCond.forEach(item => {
        if (item.retentionFonds != this.oneCond[0].retentionFonds) {
          flag = false;
          this.$message.error('请选择相同全宗的规则进行或关系内连接!');
          return;
        }
        if (item.retentionArchiveType != this.oneCond[0].retentionArchiveType) {
          flag = false;
          this.$message.error('请选择相同档案类型的规则进行或关系内连接!');
          return;
        }
        if (item.retentionPeriod != this.oneCond[0].retentionPeriod) {
          flag = false;
          this.$message.error('请选择相同保管时间的规则进行或关系内连接!');
          return;
        }
        if (item.yearCode != this.oneCond[0].yearCode) {
          flag = false;
          this.$message.error('请选择相同年度的规则进行或关系内连接!');
          return;
        }
      });
      if (flag) {
        let ids = this.$onceWay().deleteId(this.oneCond);
        interReten({ ids: ids }).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message);
            this.addOneList();
          } else this.$message.error(res.message)
        })
      }
    },
    //添加期限--保存按钮
    clickSdSave() {
      if (this.oneCond.length <= 0) {
        this.$message.error('请选择要保存的规则!');
      } else {
        this.beforeFlag = true;
      }
    },
    clickSdSave1() {
      this.beforeFlag = false;
      let saveParams = {
        ids: "",
        yearCode: "",
        retentionPeriod: "",
        retentionFonds: "",
        retentionArchiveType: "",
      };
      this.oneCond.forEach(item => {
        saveParams.ids += item.id + ",";
        saveParams.retentionPeriod += item.retentionPeriod + ",";
        saveParams.retentionFonds += item.retentionFonds + ",";
        saveParams.retentionArchiveType += item.retentionArchiveType + ",";
        saveParams.yearCode += item.yearCode + ",";
      })
      saveReten(saveParams).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.sdAddFlag = false;
          this.searchOneList();
        } else this.$message.error(res.message);
      })
    },
    //保管期限--删除规则
    openDel() {
      let open = this.$onceWay().onceTableList(this.oneTable);
      if (open == 1) {
        this.sdDelFlag = true;
      }
    },
    clickDel() {
      sdDel({ id: this.oneTable[0].tgddaRetentionPeriod.id }).then(res => {
        if (res.code == 0) {
          this.searchOneList();
          this.sdDelFlag = false;
          this.$message.success(res.message);
        } else this.$message.error(res.message);
      })
    },
    //保管期限--复制期限
    openCopy() {
      let open = this.$onceWay().onceTableList(this.oneTable);
      if (open == 1) {
        this.paramsCopy = {
          retentionFonds: null,
          retentionArchiveType: null,
          yearCode: null
        };
        this.copyFlag = true;
        if (this.$refs['paramsCopy']) {
          this.$nextTick(() => {
            this.$refs['paramsCopy'].clearValidate()
          })
        }
        this.getYear();
        this.searchFond();
      }
    },
    beforeCopy() {
      this.$refs['paramsCopy'].validate((valid) => {
        if (valid) {
          this.copyFlag1 = true;
        }
      })
    },
    clickCopy() {
      this.copyFlag1 = false;
      let copys = {
        id: this.oneTable[0].tgddaRetentionPeriod.id,
        newRetentionFonds: this.paramsCopy.retentionFonds,
        newRetentionArchiveType: this.paramsCopy.retentionArchiveType,
        newYearCode: this.paramsCopy.yearCode,
        newRetentionPeriod: this.paramsCopy.retentionPeriod
      }
      copyReten(copys).then(res => {
        if (res.code == 0) {
          this.searchOneList();
          this.copyFlag = false;
          this.$message.success(res.message);
        } else this.$message.error(res.message)
      })
    },
    //保管期限--执行规则
    openExe() {
      let open = this.$onceWay().onceTableList(this.oneTable);
      if (open == 1) {
        this.executeFlag = true;
      }
    },
    clickExe() {
      sdRun({ id: this.oneTable[0].tgddaRetentionPeriod.id }).then(res => {
        if (res.code == 0) {
          this.searchOneList();
          this.executeFlag = false;
          this.$message.success(res.message);
        } else this.$message.error(res.message);
      })
    },
    //保管期限--启用规则
    openStart() {
      let open = this.$onceWay().onceTableList(this.oneTable);
      if (open == 1) {
        this.startFlag = true;
      }
    },
    clickStart() {
      sdStart({ id: this.oneTable[0].tgddaRetentionPeriod.id }).then(res => {
        if (res.code == 0) {
          this.searchOneList();
          this.startFlag = false;
          this.$message.success(res.message);
        } else this.$message.error(res.message);
      })
    },
    //保管期限--禁用规则
    openEnd() {
      let open = this.$onceWay().onceTableList(this.oneTable);
      if (open == 1) {
        this.endFlag = true;
      }
    },
    clickEnd() {
      sdEnd({ id: this.oneTable[0].tgddaRetentionPeriod.id }).then(res => {
        if (res.code == 0) {
          this.searchOneList();
          this.endFlag = false;
          this.$message.success(res.message);
        } else this.$message.error(res.message);
      })
    },
    //保管期限--导出规则
    clickExport() {
      this.exportFlag = false;
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/exportRule', null, '保管期限限制.xls', 'post');
    },
    //保管期限--筛选问题文件
    openImport() {
      this.importOneList();
      this.searchFlag = true;
    },
    //保管期限--筛选问题文件列表
    importList() {
      listArch(this.searchParams).then(res => {
        if (res.code == 0) {
          this.tableSearch = res.data.rows;
          this.searchParams.total = res.data.total;
        } else this.$message.error(res.message);
      })
    },
    importOneList() {
      this.searchParams.page = 1;
      this.importList();
    },
    searchSelect(val) {
      this.searchOne = val;
    },
    searchCurrChange(val) {
      this.searchParams.page = val;
      this.importList();
    },
    saveDoc() {
      if (this.searchOne.length <= 0) {
        this.$message.error('请选择要保存的档案');
      } else {
        let flag = true;
        this.values = "";
        console.log(this.values)
        this.searchOne.forEach(item => {
          if (item.retentionPeriod == "" || item.retentionPeriod == null) {
            flag = false;
          } else {
            if (this.values) {
              this.values = "," + item.id + "-" + item.retentionPeriod;
            } else {
              this.values += item.id + "-" + item.retentionPeriod;
            }
          }
        })
        if (flag) {
          this.submitFlag = true;
        } else this.$message.error('有档案的保管期限没有设置，请重新设置好后再保存');
      }
    },
    clickSubmit() {
      saveProblem({ values: this.values }).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.submitFlag = false;
          this.importOneList();
        } else this.$message.error(res.message);
      })
    },
    //保管期限--筛选问题--导出
    exportProblem() {
      this.exFlag = false;
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/exportProblemData', null, '问题档案.xls', 'post');
    },
    //保管期限--筛选问题--导入
    openUpload() {
      this.uploadProFlag = true;
      this.proUploadUrl = null;
      if (this.$refs.upload) {
        this.$nextTick(() => {
          this.$refs.upload.clearFiles();
        })
      }
    },
    // 文件超过1个时提示
    handleExceed(file, fileList) {
      this.$message.warning("只能上传一个文件")
    },
    //文件上传
    handleChange(file, fileList) {
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('type', 'map')
      formData.append('name', 'file')
      axios({
        url: BASICURL + '/gdda-new/gdda/archiveZL/uploadExcelH5',
        method: 'post',
        data: formData,
        header: {
          'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryymL45aau1VgXaJUp'
        }
      }).then((res) => {
        if (res.data.data.flag == 1) {
          this.$message.success(res.data.message);
          this.proUploadUrl = res.data.data.msg;
        } else this.$message.error(res.data.data.msg);

      })
    },
    handleRemove(file, fileList) {
      this.proUploadUrl = null;
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${ file.name }？`);
    },
    saveUploadPro() {
      if (this.proUploadUrl) {
        importExcel({ imgVal: this.proUploadUrl }).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message);
            this.uploadProFlag = false;
            this.importOneList();
          } else this.$message.error(res.data.msg)
        })
      } else this.$message.error("请选择要导入的Excel文件")
    },
    resetUploadPro() {
      this.proUploadUrl = null;
      this.uploadProFlag = false;
    },
  },
  created() {

  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.ar-delete {
  text-align: center;

  img {
    margin-bottom: -12px;
  }

  div {
    text-align: center;
    font-size: 14px;
    color: #282828;
  }
}

.doc-doss {
  width: 100%;
  height: 350px;
  overflow: auto;
}

.mt-f18 {
  margin-top: -18px;
}

.mt-f31 {
  margin-top: -31px;
}

.map-upload {
  text-align: center;

  .map-demo {
    display: inline-block;
    margin-left: 6px;

    .el-button--primary {
      background-color: #0067AC;
      border-color: #0067AC;
      border-radius: 16px;
      width: 135px;
    }
  }

  .map-demo.el-upload-list {
    width: 200px !important;
  }
}

.mt-f19 {
  margin-top: -19px;
}

.mb-2 {
  margin-bottom: 2px;
}

.ar-show1 {
  width: 63px;
  padding-left: 34px;
  font-size: 14px;
  color: #606266;
}

.ar-100 {
  width: 100px;
}

.ar-table {
  height: 280px;
  overflow-y: auto;
}

.ar-top {
  margin-bottom: 10px;

  .ar-span {
    display: inline-block;
    color: #282828;
    font-size: 12px;
    cursor: pointer;
    margin-right: 10px;
    cursor: pointer;
  }

  .ar-img {
    vertical-align: middle;
    margin-right: 4px;
  }
}

</style>
