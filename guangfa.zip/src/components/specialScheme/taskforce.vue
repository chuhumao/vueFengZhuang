<!-- 专项档案服务 -->
<template>
  <div>
    <div class="right-bottom-content">
      <div class="bottom-div" @click="searchCust">
        <p class="bottom-div-p1"><img src="../../assets/home/c1.png" alt="" /></p>
        <p class="bottom-div-p2">客户档案</p>
      </div>
      <div class="bottom-div" @click="searchCan">
        <p class="bottom-div-p1"><img src="../../assets/home/c2.png" alt="" /></p>
        <p class="bottom-div-p2">专责小组</p>
      </div>
      <div class="bottom-div">
        <p class="bottom-div-p1"><img src="../../assets/home/c3.png" alt="" /></p>
        <p class="bottom-div-p2">客户关系地图</p>
      </div>
      <div class="bottom-div" @click="searchView">
        <p class="bottom-div-p1"><img src="../../assets/home/c4.png" alt="" /></p>
        <p class="bottom-div-p2">档案可视化</p>
      </div>
      <div class="bottom-div" @click="searchEle">
        <p class="bottom-div-p1"><img src="../../assets/home/c5.png" alt="" /></p>
        <p class="bottom-div-p2">电子档案查询系统</p>
      </div>
      <div class="bottom-div" @click="searchSyst">
        <p class="bottom-div-p1"><img src="../../assets/home/c6.png" alt="" /></p>
        <p class="bottom-div-p2">电子档案质检系统</p>
      </div>
      <div class="bottom-div" @click="openMap">
        <p class="bottom-div-p1"><img src="../../assets/home/c7.png" alt="" /></p>
        <p class="bottom-div-p2">归档地图</p>
      </div>
      <div class="bottom-div" @click="openDoc">
        <p class="bottom-div-p1"><img src="../../assets/home/c8.png" alt="" /></p>
        <p class="bottom-div-p2">投行档案借阅</p>
      </div>
    </div>
    <!-- 专责小组 -->
    <el-dialog :visible.sync="groupFlag" class="give groups" width="1200">
      <div slot="title" class="titl">
        <img src="../../assets/home/g1.png" alt />
        专责工作小组管理
      </div>
      <div>
        <div class="groups-left">
          <p class="groups-title">专责小组查询
            <img src="../../assets/home/g2.png" alt="" />
          </p>
          <div>
            <p class="groups-icons">
              <span @click="openAdd"><img src="../../assets/home/g3.png" alt="" />新增</span>
              <span @click="openDetail"><img src="../../assets/home/g4.png" alt="" />修改</span>
              <span @click="openDel"><img src="../../assets/home/g5.png" alt="" />删除</span>
              <span @click="openSend"><img src="../../assets/home/g6.png" alt="" />发送代办</span>
              <span @click="openCancel"><img src="../../assets/home/g7.png" alt="" />取消代办</span>
              <span @click="openExport"><img src="../../assets/home/g8.png" alt="" />导出选中</span>
              <span @click="exportMethod()"><img src="../../assets/home/g9.png" alt="" />导出全部</span></p>
            <div>
              <div class="common1">
                <div class="label">
                  <label>小组名称：</label>
                </div>
                <el-input placeholder="请输入关键字" v-model.trim="params.c101"></el-input>
              </div>
              <div class="common1">
                <div class="label">
                  <label>联络人：</label>
                </div>
                <el-select v-model="params.filingUserId" filterable :filter-method="searchUser" @blur="blurUser">
                  <el-option v-for="item in userArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
                </el-select>
              </div>
              <div class="common1">
                <div class="label">
                  <label>状态：</label>
                </div>
                <el-select v-model="params.c22">
                  <el-option v-for="item in typeArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
                </el-select>
              </div>
              <div class="com-btn1" @click="searchOne">
                <img src="../../assets/home/g10.png" alt="" />查询
              </div>
            </div>
            <div>
              <div class="all-Table task-Table">
                <el-table :data="taskData" border stripe @selection-change="handleSelectionChange">
                  <el-table-column type="selection" width="40">
                  </el-table-column>
                  <el-table-column label="小组名称" prop="c101"></el-table-column>
                  <el-table-column label="文号" prop="fileCode"></el-table-column>
                  <el-table-column label="联络人" prop="filingUserName" width="100"></el-table-column>
                  <el-table-column label="状态" prop="status" width="80">
                    <template slot-scope="scope">
                      <span v-if="scope.row.status == 1">已终止</span>
                      <span v-else>正常</span>
                    </template>
                  </el-table-column>
                </el-table>
              </div>
              <div>
                <el-pagination @current-change="currChange" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
                </el-pagination>
              </div>
            </div>
          </div>
        </div>
        <div class="group-rigth">
          <p class="groups-title">专责小组信息
            <img src="../../assets/home/g2.png" alt="" />
          </p>
          <div>
            <el-form label-width="100px" class="groups-form" :rules="addRule" :model="paramsAdd" ref="paramsAdd" :disabled="disableds">
              <el-form-item label="小组名称:" prop="c101">
                <el-input v-model.trim="paramsAdd.c101"></el-input>
              </el-form-item>
              <el-form-item label="发文名称:" prop="titleProper">
                <el-input v-model.trim="paramsAdd.titleProper"></el-input>
              </el-form-item>
              <el-form-item label="文号:" prop="fileCode" class="half-input">
                <el-input v-model.trim="paramsAdd.fileCode"></el-input>
              </el-form-item>
              <el-form-item label="发文日期:" class="groups-date half-input1" prop="dateOfCreation">
                <el-date-picker type="date" value-format="yyyy-MM-dd" v-model="paramsAdd.dateOfCreation">
                </el-date-picker>
              </el-form-item>
              <el-form-item label="联络人:" prop="filingUser" class="half-input">
                <el-select v-model="paramsAdd.filingUser" :filter-method="searchUser1" filterable @change="changeFiling">
                  <el-option v-for="item in userArr1" :key="item.id" :label="item.text" :value="item.id"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="归档部门:" prop="filingDept" class="half-input1">
                <el-select v-model="paramsAdd.filingDept" filterable @change="$forceUpdate()">
                  <el-option v-for="item in deptArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="小组成员:" prop="c113">
                <el-input type="textarea" v-model="paramsAdd.c113"></el-input>
              </el-form-item>
              <el-form-item label="小组职责:" prop="contentDescription">
                <el-input type="textarea" v-model="paramsAdd.contentDescription"></el-input>
              </el-form-item>
              <el-form-item label="备注:" prop="remarks">
                <el-input type="textarea" v-model="paramsAdd.remarks"></el-input>
              </el-form-item>
              <el-form-item>
                <!-- 初始化 -->
                <p v-show="disableds" class="disable-p">
                  <span @click="typeNormal"><img src="../../assets/home/g11.png" alt="" />正常</span>
                  <span @click="typeStop"><img src="../../assets/home/g12.png" alt="" />已终止</span>
                  <span @click="typeNot"><img src="../../assets/home/g13.png" alt="" />无变化</span>
                  <span @click="clickDetail"><img src="../../assets/home/g14.png" alt="" />保存</span>
                </p>
                <!-- 编辑 -->
                <p class="groups-p" v-show="detailFlag">
                  <span @click="typeNormal"><img src="../../assets/home/g11.png" alt="" />正常</span>
                  <span @click="typeStop"><img src="../../assets/home/g12.png" alt="" />已终止</span>
                  <span @click="typeNot"><img src="../../assets/home/g13.png" alt="" />无变化</span>
                  <span @click="clickDetail"><img src="../../assets/home/g14.png" alt="" />保存</span>
                </p>
                <!-- 新增 -->
                <p class="groups-p" v-show="addFlag">
                  <span @click="clickAdd"><img src="../../assets/home/g14.png" alt="" />保存</span>
                </p>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </div>
    </el-dialog>
    <!--不能打开专责小组提示 -->
    <el-dialog :visible.sync="notFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/u5.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>对不起，您还不是专责小组联络员!</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-18">
        <el-button type="primary" @click="notFlag = false">确定</el-button>
      </div>
    </el-dialog>
    <!-- 删除确认提示 -->
    <el-dialog :visible.sync="delFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        确认
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>您确认要删除吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-18">
        <el-button type="primary" @click="clickDel">确定</el-button>
        <el-button @click="delFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 发送代办确认提示 -->
    <el-dialog :visible.sync="sendFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        确认
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>您确认要发送待办吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-18">
        <el-button type="primary" @click="clickSend">确定</el-button>
        <el-button @click="sendFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 取消代办确认 -->
    <el-dialog :visible.sync="cancelFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        确认
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>您确认要取消待办吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-18">
        <el-button type="primary" @click="clickCancel">确定</el-button>
        <el-button @click="cancelFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 归档地图 -->
    <el-dialog :visible.sync="mapFlag" width="1100px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/home/map.png" alt="">
        归档地图
      </div>
      <div>
        <div class="headerBtn mapHeader">
          <span @click="openMapAdd"><img src="../../assets/home/input.png" alt="">录入</span>
          <span @click="openDetailMap"><img src="../../assets/home/g4.png" alt="">编辑</span>
          <span @click="openDelMap"><img src="../../assets/home/g5.png" alt="">删除</span>
          <span @click="downMapFlag = true"><img src="../../assets/home/g8.png" alt="">导出模板</span>
          <span @click="openUpload"><img src="../../assets/home/input.png" alt="">导入数据</span>
          <span @click="openSea"><img src="../../assets/home/search1.png" alt="">检索</span>
        </div>
        <!--分类列表 -->
        <div class='all-Table type-table'>
          <el-table :data="tableMap" stripe border @selection-change="selectMap" class="w-100">
            <el-table-column type="selection" width="40">
            </el-table-column>
            <el-table-column prop="processName" label="流程名称" width="100">
            </el-table-column>
            <el-table-column prop="status" label="状态" width="80">
            </el-table-column>
            <el-table-column prop="systemName" label="系统名称" width="100">
            </el-table-column>
            <el-table-column prop="dockingUser" label="管理员" width="80">
            </el-table-column>
            <el-table-column prop="belongDept" label="部门名称" width="120">
            </el-table-column>
            <el-table-column prop="processIntro" label="流程简介">
            </el-table-column>
            <el-table-column prop="remark" label="备注" width="100">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="mapChange" :current-page="paramsMap.page" :page-size="paramsMap.rows" layout="prev, pager, next, jumper" :total="paramsMap.total">
          </el-pagination>
        </div>
      </div>
    </el-dialog>
    <!-- 归档地图检索 -->
    <el-dialog :visible.sync="mapSeaFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/home/search.png" alt="">
        检索
      </div>
      <el-form :model="paramsMap" label-width="100px">
        <el-form-item label="系统名称：">
          <el-select v-model="paramsMap.systemName" filterable :filter-method="searchSys" @blur="getSys" class="w-100" placeholder="请输入系统名称检索">
            <el-option v-for="item in sysArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="流程名称：">
          <el-select v-model="paramsMap.processName" filterable :filter-method="searchPro" @blur="getPro" class="w-100" placeholder="请输入流程名称检索">
            <el-option v-for="item in proArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="状态：">
          <el-input v-model="paramsMap.status"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="searchs">检索</el-button>
        <el-button type="primary" @click="resetMap">重置条件</el-button>
        <el-button @click="mapSeaFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 录入归档地图 -->
    <el-dialog :visible.sync="addMapFlag" width="900px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/home/map1.png" alt="">
        录入归档地图信息
      </div>
      <el-form :model="addMap" label-width="100px">
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="系统名称：">
              <el-input v-model="addMap.systemName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="流程名称：">
              <el-input v-model="addMap.processName"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="流程简介：">
          <el-input v-model="addMap.processIntro" type="textarea"></el-input>
        </el-form-item>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="管理员：">
              <el-input v-model="addMap.dockingUser"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="部门名称：">
              <el-input v-model="addMap.belongDept"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="状态：">
              <el-input v-model="addMap.status"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="备注：">
          <el-input v-model="addMap.remark" type="textarea"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="mapAddFlag = true">保存</el-button>
        <el-button type="primary" @click="addMap = {}">重置</el-button>
        <el-button @click="addMapFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 录入确认 -->
    <el-dialog :visible.sync="mapAddFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        录入确认
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-18">
        <el-button type="primary" @click="clickAddMap">确定</el-button>
        <el-button @click="mapAddFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 编辑归档地图 -->
    <el-dialog :visible.sync="detailMapFlag" width="900px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/home/map1.png" alt="">
        编辑归档地图信息
      </div>
      <el-form :model="detailMap" label-width="100px">
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="系统名称：">
              <el-input v-model="detailMap.systemName"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="流程名称：">
              <el-input v-model="detailMap.processName"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="流程简介：">
          <el-input v-model="detailMap.processIntro" type="textarea"></el-input>
        </el-form-item>
        <el-row :gutter="20">
          <el-col :span="8">
            <el-form-item label="管理员：">
              <el-input v-model="detailMap.dockingUser"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="部门名称：">
              <el-input v-model="detailMap.belongDept"></el-input>
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="状态：">
              <el-input v-model="detailMap.status"></el-input>
            </el-form-item>
          </el-col>
        </el-row>
        <el-form-item label="备注：">
          <el-input v-model="detailMap.remark" type="textarea"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="mapDetailFlag= true">保存</el-button>
        <el-button @click="detailMapFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 修改确认 -->
    <el-dialog :visible.sync="mapDetailFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        修改确认
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要编辑保存数据吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-18">
        <el-button type="primary" @click="clickDetailMap">确定</el-button>
        <el-button @click="mapDetailFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 归档地图--删除 -->
    <el-dialog :visible.sync="delMapFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicDel.png" alt="">
        删除确认
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要删除该归档地图信息吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-18">
        <el-button type="primary" @click="clickDelMap">确定</el-button>
        <el-button @click="delMapFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 归档地图--导出模板确认 -->
    <el-dialog :visible.sync="downMapFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要下载该模板吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-18">
        <el-button type="primary" @click="exportMap">确定</el-button>
        <el-button @click="downMapFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 归档地图--上传文件 -->
    <el-dialog :visible.sync="uploadMapFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/home/map2.png" alt="">
        Excel文件导入
      </div>
      <div class="map-upload">
        上传 <el-upload class="map-demo" ref="upload" action="#" :limit='1' :auto-upload="false" accept=".xls" :on-exceed="handleExceed" :on-change="handleChange" :on-remove="handleRemove" :before-remove="beforeRemove">
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="saveUploadMap">导入</el-button>
        <el-button @click="resetUploadMap">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 导入失败导出错误信息 -->
    <el-dialog :visible.sync="errFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicDel.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>是否要导出错误信息？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-18">
        <el-button type="primary" @click="clickErr">确定</el-button>
        <el-button @click="errFlag = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import qs from 'qs'
import axios from 'axios';
import { valueIndex } from '@/js/transitionText';
import { BASICURL, canAccess, taskList, saveTask, typeSelect, userSelect, allDept, taskNormal, taskStop, taskNoChange, taskDelete, taskCancel, taskSend, taskExport, mapList, sysSelect, sysProcess, saveMap, detailsMap, delMap, mapUploadSave, custArch, viewArch, elecrArch, sysArch } from '@/js/getData';
export default {
  name: 'taskforce',
  data() {
    return {
      errMsg: null,
      errFlag: false,
      sendFlag: false,
      cancelFlag: false,
      delFlag: false,
      addFlag: false,
      detailFlag: false,
      groupFlag: false,
      notFlag: false,
      params: {
        page: 1,
        rows: 11,
        total: null,
        filingUserId: ''
      },
      disableds: true,
      taskData: [],
      paramsAdd: {
        filingUser: ''
      },
      typeArr: [],
      userArr: [],
      userArr1: [],
      deptArr: [],
      addRule: {
        c101: [{ required: true, message: '小组名称不能为空！', trigger: 'blur' }],
        titleProper: [{ required: true, message: '发文名称不能为空！', trigger: 'blur' }],
        fileCode: [{ required: true, message: '文号不能为空！', trigger: 'blur' }],
        dateOfCreation: [{ required: true, message: '请选择发文日期！', trigger: 'change' }],
        filingUser: [{ required: true, message: '请选择联络人！', trigger: 'change' }],
        filingDept: [{ required: true, message: '请选择归档部门！', trigger: 'change' }],
        c113: [{ required: true, message: '小组成员不能为空！', trigger: 'blur' }],
        contentDescription: [{ required: true, message: '小组职责不能为空！', trigger: 'blur' }],
        remarks: [{ required: true, message: '备注不能为空！', trigger: 'blur' }],
      },
      onceTable: [],
      //归档地图
      mapFlag: false,
      paramsMap: {
        page: 1,
        rows: 8,
        total: null
      },
      tableMap: [],
      sysArr: [],
      proArr: [],
      mapSeaFlag: false,
      addMapFlag: false,
      addMap: {},
      mapAddFlag: false,
      detailMapFlag: false,
      detailMap: {},
      mapDetailFlag: false,
      mapArr: [],
      delMapFlag: false,
      uploadMapFlag: false,
      mapUploadUrl: null,
      downMapFlag: false,
    }
  },
  methods: {
    // 专责小组
    //初始化判断是否可以访问专责小组
    searchCan() {
      canAccess().then(res => {
        if (res.code == 0) {
          if (!res.data.canAccess) {
            this.notFlag = true;
          } else {
            this.params = {};
            this.paramsAdd = {};
            this.groupFlag = true;
            if (this.$refs['paramsAdd']) {
              this.$nextTick(() => {
                this.$refs['paramsAdd'].clearValidate();
              })
            };
            this.disableds = true;
            this.addFlag = false;
            this.detailFlag = false;
            this.searchList();
          }
        } else this.$message.error(res.message);
      })
    },
    //查询列表
    searchOne() {
      this.params.page = 1;
      this.searchList()
    },
    searchList() {
      taskList(this.params).then(res => {
        if (res.code == 0) {
          this.taskData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message);
      })
    },
    currChange(val) {
      this.params.page = val;
      this.searchList()
    },
    //获取状态数组
    getType() {
      typeSelect().then(res => {
        if (res.code == 0) {
          this.typeArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //查询获取联络人数组
    searchUser(val) {
      this.getUser(val);
    },
    //表单获取联络人数组
    searchUser1(val) {
      this.getUser1(val);
    },

    //查询--联络人回显
    blurUser(e) {
      this.params.filingUserId = e.target.value
    },
    //新增、修改--联络人回显
    changeFiling(e) {
      this.$forceUpdate();
      let obj = {};
      obj = this.userArr1.find((item) => {
        return item.id === e;
      });
      this.paramsAdd.filingUserName = obj.text;
    },
    blurFiling(e) {
      this.paramsAdd.filingUser = e.target.value
    },
    getUser(val) {
      userSelect({ q: val }).then(res => {
        if (res.code == 0) {
          this.userArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    getUser1(val) {
      userSelect({ q: val }).then(res => {
        if (res.code == 0) {
          this.userArr1 = res.data;
        } else this.$message.error(res.message)
      })
    },
    //归档部门
    getDept() {
      allDept().then(res => {
        if (res.code == 0) {
          this.deptArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //新增--打开
    openAdd() {
      this.disableds = false;
      this.addFlag = true;
      this.detailFlag = false;
      this.paramsAdd = {};
      if (this.$refs['paramsAdd']) {
        this.$nextTick(() => {
          this.$refs['paramsAdd'].clearValidate()
        })
      }
    },
    //新增--保存
    clickAdd() {
      this.$refs['paramsAdd'].validate((valid) => {
        if (valid) {
          saveTask(this.paramsAdd).then(res => {
            if (res.code == 0) {
              if (res.data.result == 1) {
                this.successTask();
                this.addFlag = false;
                this.$message.success('保存成功！');
              } else if (res.data.result == 2) {
                this.$message.error('小组名称已经存在，请重新输入！');
              } else {
                this.$message.error('保存失败！');
              }
            } else this.$message.error(res.message)
          })
        }
      })
    },
    handleSelectionChange(val) {
      this.onceTable = val
    },
    openDetail() {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.onceTable.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        this.paramsAdd = JSON.parse(JSON.stringify(this.onceTable[0]));
        this.searchUser1(this.paramsAdd.filingUser)
        this.disableds = false;
        this.detailFlag = true;
        this.addFlag = false;
      }
    },
    clickDetail() {
      this.$refs['paramsAdd'].validate((valid) => {
        if (valid) {
          saveTask(this.paramsAdd).then(res => {
            if (res.code == 0) {
              if (res.data.result == 1) {
                this.$message.success('保存成功！');
                this.successTask();
              } else if (res.data.result == 2) {
                this.$message.error('小组名称已经存在，请重新输入！');
              } else {
                this.$message.error('保存失败！');
              }
            } else this.$message.error(res.message)
          })
        }
      })
    },
    //操作成功 
    successTask() {
      this.paramsAdd = {};
      if (this.$refs['paramsAdd']) {
        this.$nextTick(() => {
          this.$refs['paramsAdd'].clearValidate();
        })
      }
      this.searchOne();
      this.disableds = true;
      this.detailFlag = false;
    },
    //编辑--正常
    typeNormal() {
      let subId = this.onceTable[0].id;
      taskNormal({ subId: subId }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == -1) {
            this.$message.error('操作失败！');
          } else if (res.data.optFlag == 2) {
            this.$message.error('小组名称已经存在，请重新输入！');
          } else {
            this.$message.success('操作成功！');
            this.successTask();
          }
        } else this.$message.error(res.message)
      })
    },
    //编辑--已终止
    typeStop() {
      let subId = this.onceTable[0].id;
      axios({
        url: BASICURL + '/gdda-new/gdda/zzxz/stop?subId=' + subId,
        method: 'post',
        data: qs.stringify(this.paramsAdd, { arrayFormat: 'repeat' })
      }).then(res => {
        if (res.data.code == 0) {
          if (res.data.data.optFlag == -1) {
            this.$message.error('操作失败！');
          } else if (res.data.data.optFlag == 2) {
            this.$message.error('小组名称已经存在，请重新输入！');
          } else {
            this.$message.success('操作成功！');
            this.successTask();
          }
        } else this.$message.error(res.data.message)
      })
    },
    //编辑--无变化
    typeNot() {
      let subId = this.onceTable[0].id;
      taskNoChange({ subId: subId }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == -1) {
            this.$message.error('操作失败！');
          } else if (res.data.optFlag == 2) {
            this.$message.error('小组名称已经存在，请重新输入！');
          } else {
            this.$message.success('操作成功！');
            this.successTask();
          }
        } else this.$message.error(res.message)
      })
    },
    //删除
    openDel() {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.onceTable.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        this.delFlag = true;
      }
    },
    clickDel() {
      let id = this.onceTable[0].id;
      taskDelete({ id: id }).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.successTask();
          this.delFlag = false;
        } else this.$message.error(res.message)
      })
    },
    //发送代办
    openSend() {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.onceTable.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        this.sendFlag = true;
      }
    },
    clickSend() {
      let id = this.onceTable[0].id;
      taskSend({ id: id }).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.successTask();
          this.sendFlag = false;
        } else this.$message.error(res.message)
      })
    },
    //取消代办
    openCancel() {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.onceTable.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        this.cancelFlag = true;
      }
    },
    clickCancel() {
      let id = this.onceTable[0].id;
      taskCancel({ id: id }).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.successTask();
          this.cancelFlag = false;
        } else this.$message.error(res.message)
      })
    },
    //导出选中
    openExport() {
      let open = this.$onceWay().onceTableListTwo(this.onceTable);
      if (open == 1) {
        let ids = this.$onceWay().deleteId(this.onceTable);
        this.exportMethod(ids)
      }
    },
    //导出方法
    exportMethod(val) {
      let ids = { id: val } || {};
      valueIndex().exportFiles('/gdda-new/gdda/zzxz/export', ids, '专责小组详情.xls', 'get');
    },
    //归档地图
    //归档地图--打开
    openMap() {
      this.searchOneMap();
      this.mapFlag = true;
    },
    searchs() {
      this.searchOneMap();
      this.mapSeaFlag = false;
    },
    //归档地图--查询
    searchOneMap() {
      this.paramsMap.page = 1;
      this.searchMap();
    },
    searchMap() {
      mapList(this.paramsMap).then(res => {
        if (res.code == 0) {
          this.tableMap = res.data.rows;
          this.paramsMap.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    mapChange(val) {
      this.paramsMap.page = val;
      this.searchMap();
    },
    openSea() {
      this.paramsMap = {
        page: 1,
        rows: 8,
        total: null,
        systemName: '',
        processName: ''
      };
      this.searchPro();
      this.searchSys();
      this.mapSeaFlag = true;
    },
    //重置查询条件
    resetMap() {
      this.paramsMap = {
        page: 1,
        rows: 8,
        total: null,
        systemName: '',
        processName: ''
      }
    },
    //归档地图--查询--流程数组
    searchPro(val) {
      sysProcess({ q: val }).then(res => {
        if (res.code == 0) {
          this.proArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //归档地图--系统查询没有匹配值--回显输入值
    getPro(e) {
      this.paramsMap.processName = e.target.value;
    },
    //归档地图--查询--系统名称
    searchSys(val) {
      sysSelect({ q: val }).then(res => {
        if (res.code == 0) {
          this.sysArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //归档地图--系统查询没有匹配值--回显输入值
    getSys(e) {
      this.paramsMap.systemName = e.target.value;
    },
    selectMap(val) {
      this.mapArr = val;

    },
    //归档地图--新增
    openMapAdd() {
      this.addMap = {};
      this.addMapFlag = true;
    },
    clickAddMap() {
      saveMap(this.addMap).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.addMapFlag = false;
          this.mapAddFlag = false;
          this.searchOneMap();
        } else this.$message.error(res.message)
      })
    },
    //归档地图--详情
    getDetailMap() {
      let id = this.mapArr[0].id;
      detailsMap({ id: id }).then(res => {
        if (res.code == 0) {
          this.detailMap = res.data.data;
        } else this.$message.error(res.message)
      })
    },
    //归档地图--编辑
    openDetailMap() {
      let open = this.$onceWay().onceTableList(this.mapArr);
      if (open == 1) {
        this.getDetailMap();
        this.detailMapFlag = true;
      }
    },
    clickDetailMap() {
      axios({
        url: BASICURL + '/gdda-new/gdda/archiveMap/editFilingMapFile?subId=' + this.detailMap.id,
        method: 'post',
        data: qs.stringify(this.detailMap, {
          arrayFormat: 'repeat'
        }),
      }).then((res) => {
        if (res.data.code == 0) {
          this.detailMapFlag = false;
          this.mapDetailFlag = false;
          this.searchOneMap();
          this.$message.success(res.data.message);
        } else this.$message.error(res.data.message);
      })
    },
    //归档地图--删除
    openDelMap() {
      let open = this.$onceWay().onceTableListTwo(this.mapArr);
      if (open == 1) {
        this.delMapFlag = true;
      }
    },
    clickDelMap() {
      let ids = [];
      this.mapArr.forEach(item => {
        ids.push(item.id)
      })
      delMap({ ids: ids.join(',') }).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.delMapFlag = false;
          this.searchOneMap();
        } else this.$message.error(res.message)
      })
    },
    //归档地图导出模板
    exportMap() {
      valueIndex().exportFiles('/gdda-new/gdda/archiveMap/downloadExcel', null, '归档地图模板.xls', 'post');
    },
    // 文件超过1个时提示
    handleExceed(file, fileList) {
      this.$message.warning(`当前只能选择 1 个文件，本次已选择了 ${file.length} 个文件`)
    },
    //文件上传
    handleChange(file, fileList) {
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('type', 'map')
      formData.append('name', 'file')
      axios({
        url: BASICURL + '/gdda-new/gdda/archiveZL/uploadExcelH5',
        method: 'post',
        data: formData,
        header: {
          'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryymL45aau1VgXaJUp'
        }
      }).then((res) => {
        if (res.data.data.flag == 1) {
          this.$message.success(res.data.message);
          this.mapUploadUrl = res.data.data.msg;
        } else this.$message.error(res.data.data.msg);

      })
    },
    handleRemove(file, fileList) {
      this.mapUploadUrl = null;
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${ file.name }？`);
    },
    //归档地图文件--上传保存
    openUpload() {
      this.errMsg = null;
      this.uploadMapFlag = true;
      this.mapUploadUrl = null;
      if (this.$refs.upload) {
        this.$nextTick(() => {
          this.$refs.upload.clearFiles();
        })
      }
    },
    saveUploadMap() {
      mapUploadSave({ imgVal: this.mapUploadUrl }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == "-1") {
            this.errFlag = true;
            this.errMsg = res.data.msg;
          } else if (res.data.optFlag == "-2") {
            this.$message.error("导入失败" + res.data.msg)
          } else {
            this.$message.success(res.data.msg);
            this.uploadMapFlag = false;
            this.searchOneMap();
          }
        } else this.$message.error(res.data.msg)
      })
    },
    clickErr() {
      window.open(BASICURL + '/gdda-new/gdda/archiveZL/exportError?excelId=' + this.errMsg)
    },
    resetUploadMap() {
      this.mapUploadUrl = null;
      this.uploadMapFlag = false;
    },
    //打开投行档案借阅
    openDoc() {
      this.$router.push({ name: 'DocumentSearch' })
    },
    //打开客户档案
    searchCust() {
      custArch().then(res => {
        if (res.code == 0) {
          window.open(res.data);
        } else this.$message.error(res.message)
      })
    },
    //打开档案可视化
    searchView() {
      viewArch().then(res => {
        if (res.code == 0) {
          window.open(res.data);
        } else this.$message.error(res.message)
      })
    },
    //电子档案查询系统
    searchEle() {
      elecrArch().then(res => {
        if (res.code == 0) {
          window.open(res.data);
        } else this.$message.error(res.message)
      })
    },
    //电子档案质检系统
    searchSyst() {
      sysArch().then(res => {
        if (res.code == 0) {
          window.open(res.data);
        } else this.$message.error(res.message)
      })
    }
  },
  created() {
    this.getType();
    this.getUser();
    this.getUser1();
    this.getDept();
  }
}

</script>
<style scoped lang="less">
@import "../../css/public";
@import "../../css/dialog";

.type-table {
  height: 406px;
  overflow-y: auto;
}

.mapHeader {
  margin-bottom: 20px;

  >span {
    cursor: pointer;
    margin-right: 30px;
  }
}

.task-Table {
  height: 346px;
  overflow-y: auto;
  margin-bottom: 10px;
  padding-top: 20px;
}

.half-input {
  width: 49%;
  display: inline-block;
}

.half-input1 {
  width: 50%;
  display: inline-block;
}

.mt-18 {
  margin-top: -18px;
}

.right-bottom-content {
  margin-top: 20px;
  clear: both;

  .bottom-div {
    margin-left: 10px;
    float: left;
    display: inline-block;
    /*width: 81px;*/
    width: 22%;
    height: 98px;

    .bottom-div-p1 {
      height: 54px;
      background-color: #004892;
      text-align: center;
      line-height: 54px;
      cursor: pointer;

      img {
        vertical-align: middle;
      }
    }

    .bottom-div-p2 {
      text-align: center;
      font-size: 14px;
      color: #282828
    }
  }
}

.map-upload {
  text-align: center;

  .map-demo {
    display: inline-block;
    margin-left: 6px;

    .el-button--primary {
      background-color: #0067AC;
      border-color: #0067AC;
      border-radius: 16px;
      width: 135px;
    }
  }

  .map-demo.el-upload-list {
    width: 200px !important;
  }
}

.disable-p {
  height: 40px;
  line-height: 40px;
  background-color: #F5F7FA;
  color: #C0C4CC;
  cursor: not-allowed;
  width: 100%;
  text-align: right;

  span {
    margin-right: 10px;

    img {
      vertical-align: middle;
      margin-right: 6px;
    }
  }
}

.w-100 {
  width: 100%;
}

</style>
