<!-- 设置电子归档章 -->
<template>
  <div>
    <span @click="openEle" class="ar-span"><img src="../../assets/turnOver/jg.png" class="ar-img" alt="">设置电子归档章</span>
    <span @click="openBatch" class="ar-span"><img src="../../assets/turnOver/s1.png" class="ar-img" alt="">批量挂接</span>
    <!-- 设置电子归档--列表 -->
    <el-dialog :visible.sync="elecFlag" class="hurdleAll" width="1100px">
      <div slot="title" class="dialog-title">
        <img src="../../assets/turnOver/s6.png" alt />
        电子归档章
      </div>
      <div>
        <div class="headerBtn mt-f19">
          <span @click="openAdd"><img src="../../assets/turnOver/tj.png" alt="" />添加归档章</span>
          <span @click="openDetail"><img src="../../assets/turnOver/bj.png" alt="" />编辑归档章</span>
          <span @click="openSend"><img src="../../assets/turnOver/bj.png" alt="" />设置归档章内容</span>
          <span @click="openSee"><img src="../../assets/turnOver/ck.png" alt="" />查看</span>
          <span @click="openStart"><img src="../../assets/turnOver/s3.png" alt="" />启用归档章</span>
          <span @click="openEnd"><img src="../../assets/turnOver/s2.png" alt="" />禁用归档章</span>
          <span @click="openDel"><img src="../../assets/turnOver/delete.png" alt="" />删除归档章</span>
        </div>
        <div class="all-Table doc-doss">
          <el-table :data="eleTable" border @selection-change="eleSelect">
            <el-table-column type="selection" width="55"></el-table-column>
            <el-table-column prop="retentionFondsName" label="全宗" width="180"></el-table-column>
            <el-table-column prop="retentionArchiveTypeName" label="档案类型" width="150"></el-table-column>
            <el-table-column prop="tgddaElectronicSeal.electronicSealName" label="归档章名"></el-table-column>
            <el-table-column prop="tgddaElectronicSeal.createUserName" label="创建人" width="80"></el-table-column>
            <el-table-column prop="tgddaElectronicSeal.createDate" label="创建时间" width="160"></el-table-column>
            <el-table-column prop="tgddaElectronicSeal.isUsing" label="是否启用" width="80">
              <template slot-scope="scope">
                {{usArr[scope.row.tgddaElectronicSeal.isUsing]}}
              </template>
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="eleCurrChange" :current-page="eleParams.page" :page-size="eleParams.rows" layout="prev, pager, next, jumper" :total="eleParams.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button @click="elecFlag= false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 启用归档章 -->
    <el-dialog :visible.sync="startFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        启用确认
      </div>
      <div class="ar-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要启用此归档章吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="clickStart">确定</el-button>
        <el-button @click="startFlag= false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 禁用归档章 -->
    <el-dialog :visible.sync="endFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        禁用确认
      </div>
      <div class="ar-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要禁用此归档章吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="clickEnd">确定</el-button>
        <el-button @click="endFlag= false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 删除归档章 -->
    <el-dialog :visible.sync="delFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        删除确认
      </div>
      <div class="ar-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要删除此归档章吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="clickDel">确定</el-button>
        <el-button @click="delFlag= false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 查看归档章 -->
    <el-dialog :visible.sync="seeFlag" width="900px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/turnOver/s13.png" alt="">
        查看材料
      </div>
      <div class="ele-emb">
        <embed :src='seeFile' type="application/pdf" width="100%" height="100%">
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button @click="seeFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 添加归档章 -->
    <el-dialog :visible.sync="addFlag" width="1000px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/turnOver/s11.png" alt />
        添加归档章
      </div>
      <div>
        <p class="send-p">归档章类型</p>
        <el-form :model="addParams" ref="addParams" :rules="addValidate" label-width="100px">
          <el-row :gutter="20">
            <el-col :span="8">
              <el-form-item label="全宗：" prop="electronicSealFonds">
                <el-select v-model="addParams.electronicSealFonds" @change="changeFonds">
                  <el-option v-for="item in fonds" :key="item.id" :value="item.id" :label="item.name"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="档案类型：" prop="electronicSealArchiveType" @change="$forceUpdate()">
                <el-select v-model="addParams.electronicSealArchiveType">
                  <el-option v-for="item in oneType" :key="item.id" :value="item.id" :label="item.name"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="归档章名：" prop="electronicSealName">
                <el-input v-model="addParams.electronicSealName"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <p class="send-p">归档章规格设置</p>
          <el-row :gutter="20">
            <el-col :span="6">
              <el-form-item label="行数：" prop="electronicSealRowCount">
                <el-input v-model="addParams.electronicSealRowCount"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="列数：" prop="electronicSealColumnCount">
                <el-input v-model="addParams.electronicSealColumnCount"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="7">
              <el-form-item label="盖章位置：" prop="electronicSealPlace">
                <el-select v-model="addParams.electronicSealPlace" @change="$forceUpdate()">
                  <el-option v-for="item in placeArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="6">
              <el-form-item label="单行高：" prop="electronicSealRowWidth">
                <el-input v-model="addParams.electronicSealRowWidth"></el-input><span class="ele-cm">cm</span>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="单行宽：" prop="electronicSealRowHeight">
                <el-input v-model="addParams.electronicSealRowHeight"></el-input><span class="ele-cm">cm</span>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="clickAdd">保存</el-button>
        <el-button @click="addFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!--编辑归档章 -->
    <el-dialog :visible.sync="detailFlag" width="1000px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/turnOver/s12.png" alt />
        编辑归档章
      </div>
      <div>
        <p class="send-p">归档章类型</p>
        <el-form :model="detailParams" ref="detailParams" :rules="addValidate" label-width="100px">
          <el-row :gutter="20">
            <el-col :span="8">
              <el-form-item label="全宗：" prop="electronicSealFonds">
                <el-select v-model="detailParams.electronicSealFonds" @change="changeFonds1">
                  <el-option v-for="item in fonds1" :key="item.id" :value="item.id" :label="item.name"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="档案类型：" prop="electronicSealArchiveType" @change="$forceUpdate()">
                <el-select v-model="detailParams.electronicSealArchiveType">
                  <el-option v-for="item in oneType1" :key="item.id" :value="item.id" :label="item.name"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item label="归档章名：" prop="electronicSealName">
                <el-input v-model="detailParams.electronicSealName"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
          <p class="send-p">归档章规格设置</p>
          <el-row :gutter="20">
            <el-col :span="6">
              <el-form-item label="行数：" prop="electronicSealRowCount">
                <el-input v-model="detailParams.electronicSealRowCount"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="列数：" prop="electronicSealColumnCount">
                <el-input v-model="detailParams.electronicSealColumnCount"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="7">
              <el-form-item label="盖章位置：" prop="electronicSealPlace">
                <el-select v-model="detailParams.electronicSealPlace" @change="$forceUpdate()">
                  <el-option v-for="item in placeArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                </el-select>
              </el-form-item>
            </el-col>
          </el-row>
          <el-row :gutter="20">
            <el-col :span="6">
              <el-form-item label="单行高：" prop="electronicSealRowWidth">
                <el-input v-model="detailParams.electronicSealRowWidth"></el-input>
              </el-form-item>
            </el-col>
            <el-col :span="6">
              <el-form-item label="单行宽：" prop="electronicSealRowHeight">
                <el-input v-model="detailParams.electronicSealRowHeight"></el-input>
              </el-form-item>
            </el-col>
          </el-row>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="clickDetail">保存</el-button>
        <el-button @click="detailFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 设置归档内容 -->
    <el-dialog :visible.sync="sendFlag" width="1100px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/turnOver/s11.png" alt />
        设置归档章内容
      </div>
      <div>
        <div>
          <el-form :model="sendAddParam" ref="sendAddParam" :rules="sendValidate" label-width="92px">
            <el-row :gutter="5">
              <el-col :span="5">
                <el-form-item label="第：" prop="electronicSealRow">
                  <el-select class="ele-sel" v-model="sendAddParam.electronicSealRow" @change="$forceUpdate()">
                    <el-option v-for="item in rowsArr" :key="item.value" :value="item.value" :label="item.text"></el-option>
                  </el-select><span>行</span>
                </el-form-item>
              </el-col>
              <el-col :span="5">
                <el-form-item label="第：" prop="electronicSealColumn" @change="$forceUpdate()">
                  <el-select class="ele-sel" v-model="sendAddParam.electronicSealColumn">
                    <el-option v-for="item in colArr" :key="item.value" :value="item.value" :label="item.text"></el-option>
                  </el-select>列
                </el-form-item>
              </el-col>
              <el-col :span="6">
                <el-form-item label="格子内容：" prop="fieldCode">
                  <el-select v-model="sendAddParam.fieldCode" @change="changeField">
                    <el-option v-for="item in cellArr" :key="item.value" :value="item.value" :label="item.text"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="6">
                <el-form-item label="字体大小：" prop="fontSize">
                  <el-select v-model="sendAddParam.fontSize" placeholder="字号越小字体越小">
                    <el-option v-for="item in sizeArr" :key="item.value" :value="item.value" :label="item.text"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="2">
                <div class="headerBtn ml-5"><span @click="addSendRow"><img src="../../assets/turnOver/tj.png" alt />添加</span></div>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <div class="headerBtn">
          <span @click="delSendRow"><img src="../../assets/turnOver/delete.png" alt />删除</span>
        </div>
        <div>
          <div class="all-Table ar-table">
            <el-table :data="sendTable" border @selection-change="sendSelect">
              <el-table-column type="selection" width="55"></el-table-column>
              <el-table-column prop="electronicSealRow" label="行号" width="120"></el-table-column>
              <el-table-column prop="electronicSealColumn" label="列号" width="120">
              </el-table-column>
              <el-table-column prop="field" label="格子内容"></el-table-column>
              <el-table-column prop="fontSize" label="字体大小" width="120">
              </el-table-column>
            </el-table>
          </div>
          <!-- 分页 -->
          <div class="pageLayout">
            <el-pagination @current-change="sendCurrChange" :current-page="sendParams.page" :page-size="sendParams.rows" layout="prev, pager, next, jumper" :total="sendParams.total">
            </el-pagination>
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f31">
        <el-button type="primary" @click="saveSendRow">保存并生成归档章</el-button>
        <el-button @click="sendFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 批量挂接材料 -->
    <el-dialog :visible.sync="batchFlag" width="900px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/turnOver/s6.png" alt />
        批量挂接材料
      </div>
      <div class="h-300">
        <div>
          <el-form :model="batchParams" ref="batchParams" :rules="batchValidate" label-width="100px">
            <el-row :gutter="20">
              <el-col :span="8">
                <el-form-item label="全宗：" prop="fonds">
                  <el-select v-model="batchParams.fonds" @change="changeFonds2">
                    <el-option v-for="item in fonds2" :key="item.id" :value="item.id" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="档案类型:" prop="series" @change="$forceUpdate()">
                  <el-select v-model="batchParams.series">
                    <el-option v-for="item in oneType2" :key="item.id" :value="item.id" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
              <el-col :span="8">
                <el-form-item label="匹配方式" prop="matchingData">
                  <el-select v-model="batchParams.matchingData" @change="$forceUpdate()">
                    <el-option v-for="item in matchArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
              </el-col>
            </el-row>
          </el-form>
        </div>
        <div>
          <div class="ele-upload">
            上传 <el-upload class="ele-demo" ref="upload" action="#" :on-remove="handleRemove" :before-remove="beforeRemove" :auto-upload="false" :on-change="handleChange">
              <el-button size="small" type="primary">上传</el-button>
            </el-upload>
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="clickBatch">确认</el-button>
        <el-button @click="batchFlag = false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { listElec, startElec, endElec, delElec, seeElec, saveElec, detaiElec, addElec, sendListElec, addElecSend, delElecSend, saveElecSend, savePl, getFonds, getAndRole, BASICURL, showListSeriesByFonds } from '@/js/getData';
import axios from 'axios';
export default {
  name: 'electronic',
  data() {
    return {
      usArr: ['未启用', '已启用', '已禁用'],
      placeArr: [{ "name": "左对齐", "itemValue": "1" }, { "name": "居中", "itemValue": "2" }, { "name": "右对齐", "itemValue": "3" }],
      elecFlag: false,
      eleTable: [],
      eleParams: {
        page: 1,
        rows: 6,
        total: null
      },
      eleOne: [],
      startFlag: false,
      endFlag: false,
      delFlag: false,
      seeFlag: false,
      seeFile: "",
      addParams: {},
      addValidate: {
        electronicSealFonds: [{ required: true, message: '请选择全宗！', trigger: 'change' }],
        electronicSealArchiveType: [{ required: true, message: '请选择档案类型!', trigger: 'change' }],
        electronicSealName: [{ required: true, message: '归档章名不能为空!', trigger: 'blur' }],
        electronicSealRowCount: [{ required: true, message: '行数不能为空!', trigger: 'blur' }],
        electronicSealColumnCount: [{ required: true, message: '列数不能为空!', trigger: 'blur' }],
        electronicSealPlace: [{ required: true, message: '请选择盖章位置!', trigger: 'change' }],
        electronicSealRowWidth: [{ required: true, message: '单行高不能为空!', trigger: 'blur' }],
        electronicSealRowHeight: [{ required: true, message: '单行宽不能为空!', trigger: 'blur' }]
      },
      fonds: [],
      oneType: [],
      fonds1: [],
      oneType1: [],
      detailParams: {},
      detailFlag: false,
      sendTable: [],
      sendParams: {
        page: 1,
        rows: 6,
        total: null
      },
      sendFlag: false,
      rowsArr: [],
      colArr: [],
      sizeArr: [
        { "value": "1", "text": "1" },
        { "value": "2", "text": "2" },
        { "value": "3", "text": "3" },
        { "value": "4", "text": "4" },
        { "value": "5", "text": "5" },
        { "value": "6", "text": "6" },
        { "value": "7", "text": "7" },
        { "value": "8", "text": "8" }
      ],
      sendAddParam: {},
      cellArr: [
        { "value": "year_code", "text": "年度" },
        { "value": "series_code", "text": "分类号" },
        { "value": "filing_dept", "text": "归档部门" },
        { "value": "retention_period", "text": "保管期限" },
        { "value": "item_no", "text": "件号" }
      ],
      sendOne: [],
      sendValidate: {
        electronicSealRow: [{ required: true, message: '请选择行号！', trigger: 'change' }],
        electronicSealColumn: [{ required: true, message: '请选择列号!', trigger: 'change' }],
        fieldCode: [{ required: true, message: '请选择格子内容!', trigger: 'change' }],
        fontSize: [{ required: true, message: '请选择字体大小!', trigger: 'change' }],
      },
      batchFlag: false,
      batchParams: {},
      batchValidate: {
        fonds: [{ required: true, message: '请选择全宗！', trigger: 'change' }],
        series: [{ required: true, message: '请选择档案类型!', trigger: 'change' }],
        matchingData: [{ required: true, message: '请选择匹配方式!', trigger: 'change' }],
      },
      matchArr: [{ "name": "合同号", "itemValue": "1" }, { "name": "档号", "itemValue": "2" }],
      fonds2: [],
      oneType2: [],
      fileList: [],
      addFlag: false,
    }
  },
  methods: {
    //列表方法
    openEle() {
      this.searchOneList();
      this.elecFlag = true;
    },
    searchList() {
      listElec(this.eleParams).then(res => {
        if (res.code == 0) {
          this.eleTable = res.data.rows;
          this.eleParams.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    searchOneList() {
      this.eleParams.page = 1;
      this.searchList();
    },
    eleSelect(val) {
      this.eleOne = val;
    },
    eleCurrChange(val) {
      this.eleParams.page = val;
      this.searchList();
    },
    //启用归档章
    openStart() {
      let open = this.$onceWay().onceTableList(this.eleOne);
      if (open == 1) {
        this.startFlag = true;
      }
    },
    clickStart() {
      startElec({ id: this.eleOne[0].tgddaElectronicSeal.id }).then(res => {
        if (res.code == 0) {
          this.searchOneList();
          this.startFlag = false;
          this.$message.success(res.message);
        } else this.$message.error(res.message);
      })
    },
    //禁用归档章
    openEnd() {
      let open = this.$onceWay().onceTableList(this.eleOne);
      if (open == 1) {
        this.endFlag = true;
      }
    },
    clickEnd() {
      endElec({ id: this.eleOne[0].tgddaElectronicSeal.id }).then(res => {
        if (res.code == 0) {
          this.searchOneList();
          this.endFlag = false;
          this.$message.success(res.message);
        } else this.$message.error(res.message);
      })
    },
    //删除归档章
    openDel() {
      let open = this.$onceWay().onceTableList(this.eleOne);
      if (open == 1) {
        this.delFlag = true;
      }
    },
    clickDel() {
      delElec({ id: this.eleOne[0].tgddaElectronicSeal.id }).then(res => {
        if (res.code == 0) {
          this.searchOneList();
          this.delFlag = false;
          this.$message.success(res.message);
        } else this.$message.error(res.message);
      })
    },
    //查看归档章
    openSee() {
      let open = this.$onceWay().onceTableList(this.eleOne);
      if (open == 1) {
        if (this.eleOne[0].tgddaElectronicSeal.path) {
          this.seeFlag = true;
          this.seeFile = BASICURL + '/gdda-new/gdda/archiveZL/electronicSealViewPdf?id=' + this.eleOne[0].tgddaElectronicSeal.id;
        } else this.$message.error('无法查看，该归档章还未生成，请在 \"设置归档章内容\" 中设置生成');
      }
    },
    //添加归档章
    openAdd() {
      this.addParams = {
        electronicSealFonds: null,
        electronicSealArchiveType: null,
      };
      this.addFlag = true;
      this.searchFond();
      if (this.$refs['addParams']) {
        this.$nextTick(() => {
          this.$refs['addParams'].clearValidate()
        })
      }
    },
    clickAdd() {
      this.$refs['addParams'].validate((valid) => {
        if (valid) {
          addElec(this.addParams).then(res => {
            if (res.code == 0) {
              this.searchOneList();
              this.addFlag = false;
              this.$message.success(res.message);
            } else this.$message.error(res.message);
          })
        }
      })
    },
    //获取全宗
    searchFond() {
      getFonds().then(res => {
        if (res.code == 0) {
          this.fonds = res.data;
          this.initFond();
        } else this.$message.error(res.message)
      })
    },
    //初始化选中全宗--原系统逻辑
    initFond(val) {
      this.addParams.electronicSealFonds = 1374133141812 //新广发证券
      this.fondsM();
    },
    //全宗方法
    fondsM() {
      this.searchType(this.addParams.electronicSealFonds);
      this.initType();
    },
    //改变选中全宗
    changeFonds() {
      this.$forceUpdate();
      this.fondsM();
    },
    //根据全宗获取档案分类
    searchType(val) {
      getAndRole({ id: val }).then(res => {
        if (res.code == 0) {
          this.oneType = res.data;
        } else this.$message.error(res.message)
      })
    },
    //初始化选中档案分类--原系统逻辑
    initType() {
      if (this.addParams.electronicSealFonds == 1374133141812) {
        this.addParams.electronicSealArchiveType = 1379482316593 //管理类案件
      } else {
        this.addParams.electronicSealArchiveType = null;
      }
    },
    //归档章编辑
    openDetail() {
      let open = this.$onceWay().onceTableList(this.eleOne);
      if (open == 1) {
        this.searchFond1();
        this.getDetail();
        this.detailFlag = true;
        if (this.$refs['detailParams']) {
          this.$nextTick(() => {
            this.$refs['detailParams'].clearValidate()
          })
        }
      }
    },
    getDetail() {
      detaiElec({ id: this.eleOne[0].tgddaElectronicSeal.id }).then(res => {
        if (res.code == 0) {
          this.detailParams = res.data;
          this.detailParams.electronicSealFonds = parseInt(res.data.electronicSealFonds);
          this.detailParams.electronicSealArchiveType = parseInt(res.data.electronicSealArchiveType);
          this.searchType1(res.data.electronicSealFonds);
        } else this.$message.error(res.message)
      })
    },
    searchFond1() {
      getFonds().then(res => {
        if (res.code == 0) {
          this.fonds1 = res.data;
        } else this.$message.error(res.message)
      })
    },
    //初始化选中档案分类--原系统逻辑
    initType1() {
      if (this.detailParams.electronicSealFonds == 1374133141812) {
        this.detailParams.electronicSealArchiveType = 1379482316593 //管理类案件
      } else {
        this.detailParams.electronicSealArchiveType = null;
      }
    },
    //改变选中全宗
    changeFonds1() {
      this.$forceUpdate();
      this.searchType1(this.detailParams.electronicSealFonds);
      this.initType1();
    },
    //根据全宗获取档案分类
    searchType1(val) {
      getAndRole({ id: val }).then(res => {
        if (res.code == 0) {
          this.oneType1 = res.data;
        } else this.$message.error(res.message)
      })
    },
    //保存详情
    clickDetail() {
      this.detailParams.id = this.eleOne[0].tgddaElectronicSeal.id;
      this.$refs['detailParams'].validate(valid => {
        if (valid) {
          saveElec(this.detailParams).then(res => {
            if (res.code == 0) {
              this.searchOneList();
              this.detailFlag = false;
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    //设置归档章内容
    openSend() {
      let open = this.$onceWay().onceTableList(this.eleOne);
      if (open == 1) {
        this.sendOneList();
        this.searchTwoArr();
        this.sendAddParam = {};
        if (this.$refs['sendAddParam']) {
          this.$nextTick(() => {
            this.$refs['sendAddParam'].clearValidate()
          })
        }
        this.sendFlag = true;
      }
    },
    searchSendList() {
      this.sendParams.id = this.eleOne[0].tgddaElectronicSeal.id;
      sendListElec(this.sendParams).then(res => {
        if (res.code == 0) {
          this.sendTable = res.data.rows;
          this.sendParams.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    sendCurrChange(val) {
      this.sendParams.page = val;
      this.searchSendList();
    },
    sendOneList() {
      this.sendParams.page = 1;
      this.searchSendList();
    },
    sendSelect(val) {
      this.sendOne = val;
    },
    //获取行列的下拉数据
    searchTwoArr() { //需要接口
      this.rowsArr = [];
      this.colArr = [];
      detaiElec({ id: this.eleOne[0].tgddaElectronicSeal.id }).then(res => {
        if (res.code == 0) {
          //行数据
          let row = parseInt(res.data.electronicSealRowCount);
          for (let i = 1; i <= row; i++) {
            this.rowsArr.push({ "value": i, "text": i });
          }
          //列数据
          let column = parseInt(res.data.electronicSealColumnCount);
          for (var i = 1; i <= column; i++) {
            this.colArr.push({ "value": i, "text": i });
          }
        } else this.$message.error(res.message)
      })
    },
    //格子内容change
    changeField(e) {
      this.$forceUpdate();
      let obj = {};
      obj = this.cellArr.find((item) => {
        return item.value === e;
      })
      this.sendAddParam.field = obj.text;
    },
    //设置归档内容--添加
    addSendRow() {
      this.$refs['sendAddParam'].validate(valid => {
        if (valid) {
          this.sendAddParam.id = this.eleOne[0].tgddaElectronicSeal.id;
          addElecSend(this.sendAddParam).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message);
              this.sendOneList();
              this.sendAddParam = {};
              if (this.$refs['sendAddParam']) {
                this.$nextTick(() => {
                  this.$refs['sendAddParam'].clearValidate()
                })
              }
            } else this.$message.error(res.message)
          })
        }
      })
    },
    //设置归档内容--删除
    delSendRow() {
      let open = this.$onceWay().onceTableList(this.sendOne);
      if (open == 1) {
        delElecSend({ id: this.sendOne[0].id }).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message);
            this.sendOneList();
          } else this.$message.error(res.message)
        })
      }
    },
    //设置归档内容--保存并生成归档章
    saveSendRow() {
      saveElecSend({ ids: this.eleOne[0].tgddaElectronicSeal.id }).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.sendFlag = false;
          this.searchOneList();
        } else this.$message.error(res.message)
      })
    },
    //批量挂接
    openBatch() {
      this.searchFond2();
      this.batchFlag = true;
      this.batchParams = {};
      this.fileList = [];
      if (this.$refs['batchParams']) {
        this.$nextTick(() => {
          this.$refs['batchParams'].clearValidate()
        })
      }
      if (this.$refs.upload) {
        this.$nextTick(() => {
          this.$refs.upload.clearFiles();
        })
      }
    },
    searchFond2() {
      getFonds().then(res => {
        if (res.code == 0) {
          this.fonds2 = res.data;
        } else this.$message.error(res.message)
      })
    },
    //改变选中全宗
    changeFonds2() {
      this.$forceUpdate();
      this.searchType2(this.batchParams.fonds);
    },
    //根据全宗获取档案分类
    searchType2(val) {
      showListSeriesByFonds({ id: val }).then(res => {
        if (res.code == 0) {
          this.oneType2 = res.data;
        } else this.$message.error(res.message)
      })
    },
    //批量挂接上传
    //确定按钮--文件上传--多个上传
    handleRemove(file, fileList) {
      let index = -1;
      for (let i = 0; i < this.fileList.length; i++) {
        let item = this.fileList[i].path
        if (item.indexOf(file.name) >= 0) {
          index = i;
          break;
        }
      }
      this.fileList.splice(index, 1)
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${ file.name }？`);
    },
    //文件上传
    handleChange(file, fileList) {
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('type', 'plHanging')
      formData.append('name', 'file')
      axios({
        url: BASICURL + '/gdda-new/gdda/archiveZL/uploadPlPicture',
        method: 'post',
        data: formData,
        header: {
          'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryymL45aau1VgXaJUp'
        }
      }).then((res) => {
        if (res.data.data.result == 1) {
          this.$message.success('上传成功！');
          this.fileList.push(res.data.data.pathAndMD5)
        } else this.$message.error('上传失败' + res.data.data.msg);
      })
    },
    clickBatch() {
      this.$refs['batchParams'].validate(valid => {
        if (valid) {
          if (this.fileList.length <= 0) {
            this.$message.error('请选择要上传的文件!')
          } else {
            let fileArr2 = [];
            this.fileList.forEach(item => {
              fileArr2.push(JSON.stringify(item))
            })
            this.batchParams.imgVal = "[" + fileArr2.join(',') + "]";
            this.batchParams.batchId = new Date().getTime();
            savePl(this.batchParams).then(res => {
              if (res.code == 0) {
                this.batchFlag = false;
                this.$message.success('上传成功!');
              } else {
                if (res.data.optFlag == 1) {
                  this.$message.error('请重新上传文件!');
                } else if (res.data.optFlag == -1) {
                  this.$message.error('上传失败!');
                }
              }
            })
          }
        }
      })
    }
  },
  created() {

  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.ele-emb {
  width: 100%;
  height: 400px;

}

.ele-sel {
  width: 83%;
  margin-right: 3px;
}

.ml-5 {
  margin-left: 5px;
}

.h-300 {
  height: 300px;
}

.ar-span {
  display: inline-block;
  color: #282828;
  font-size: 12px;
  cursor: pointer;
  margin-right: 10px;
  cursor: pointer;
}

.ar-img {
  vertical-align: middle;
  margin-right: 4px;
}


.mt-f19 {
  margin-top: -19px;
}

.ar-table {
  height: 280px;
  overflow-y: auto;
}

.mt-f31 {
  margin-top: -31px;
}

.mt-f18 {
  margin-top: -18px;
}

.doc-doss {
  width: 100%;
  height: 350px;
  overflow: auto;
}

.ar-delete {
  text-align: center;

  img {
    margin-bottom: -12px;
  }

  div {
    text-align: center;
    font-size: 14px;
    color: #282828;
  }
}

.ele-upload {
  margin-top: 20px;
  border-top: 3px solid #0067AD;
  padding-top: 25px;

  .ele-demo {
    display: inline-block;
    margin-left: 6px;

    .el-button--primary {
      background-color: #0067AC;
      border-color: #0067AC;
      border-radius: 16px;
      width: 135px;
    }
  }

  .map-demo.el-upload-list {
    width: 200px !important;
  }
}

.send-p {
  margin-top: -10px;
  margin-bottom: 10px;
  color: #333;
  font-weight: 600;
}

.ele-cm {
  position: absolute;
  width: 20px;
  margin-left: 4px;
}

</style>
