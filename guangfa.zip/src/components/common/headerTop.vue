<template>
  <!-- 头部logo -->
  <div class="headerTop">
    <!-- 中部菜单 -->
    <div class="header-crumbs" style="display: inline-block;">
      <ul class="topMenuList">
        <li v-for="(item, index) in routeList" :key="index" @click.prevent="roterLink(item)">
          {{ item.title }}
          <ul class="menuListUlShow" v-if="item.childrenList.length >= 1">
            <!--<li class="menuListTwo" v-for="(itemTwo, indexTwo) in item.childrenList" :key="indexTwo" @click.stop="roterLinkTwo(itemTwo, item)">-->
            <li class="menuListTwo" v-for="(itemTwo, indexTwo) in item.childrenList" :key="indexTwo" @click.prevent="roterLinkTwo(itemTwo, item)">
              {{ itemTwo.title }}
              <img v-if="itemTwo.childrenList.length >= 1" src="../../assets/hurdle/bottomArrows.png" alt="">
              <ul class="menuListThree" v-if="itemTwo.childrenList.length >= 1">
                <li v-for="(itemThree, indexThree) in itemTwo.childrenList" :key="indexThree" @click.stop="roterLinkThree(itemThree, itemTwo)">
                  {{ itemThree.title }}
                </li>
              </ul>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  </div>
</template>
<script>
import Bus from '../../utils/busEmit'
export default {
  name: 'HeaderTop',
  data: function () {
    return {
      routeList: [
        {
          title: '首页',
          id: 1,
          routerLink: '/homePage',
          imgSrc: null,
          childrenList: []
        },
        {
          title: '系统管理',
          id: 3,
          routerLink: '',
          imgSrc: null,
          childrenList: [{
            id: 8,
            title: '系统权限管理',
            routerLink: '',
            childrenList: [{
              id: 9,
              title: '角色管理',
              routerLink: '/roleManage',
              childrenList: []
            },
            {
              id: 10,
              title: '用户管理',
              routerLink: '/userManage',
              childrenList: []
            }
            ]
          },
          {
            title: '数据权限管理',
            id: 9,
            routerLink: '',
            imgSrc: null,
            childrenList: [
              { id: 11, title: '角色数据权限', routerLink: '/roleData', childrenList: [] },
              { id: 12, title: '用户数据权限', routerLink: '/userData', childrenList: [] }
            ]
          },
          {
            id: 10,
            title: '功能模块管理',
            routerLink: '/functionManage',
            imgSrc: null,
            childrenList: []
          },
          {
            id: 11,
            title: '缓存管理',
            routerLink: '/cacheManage',
            childrenList: []
          },
          {
            id: 12,
            title: '索引管理',
            routerLink: '/indexManage',
            childrenList: []
          }
          ]
        },
        {
          title: '档案移交',
          id: 13,
          routerLink: '',
          imgSrc: null,
          childrenList: [
            { id: 3, title: '代办失败', routerLink: '/agencyFailure', childrenList: [] },
            { id: 4, title: '指定承办人', routerLink: '/designate', childrenList: [] },
            {
              id: 5,
              title: '确认状态',
              routerLink: '',
              childrenList: [
                { id: 6, title: '已确认', routerLink: '/confirmed', childrenList: [] },
                { id: 7, title: '待确认', routerLink: '/confirm', childrenList: [] }
              ]
            },
            { id: 14, title: '欠交', routerLink: '/arrearsMange', childrenList: [] },
            {
              id: 15,
              title: '审核',
              routerLink: '',
              childrenList: [
                { id: 115, title: '综合员审核', routerLink: '/synthesizeAuditMange', childrenList: [] },
                { id: 116, title: '领导审核', routerLink: '/bossAuditMange', childrenList: [] },
                { id: 117, title: '档案管理审核', routerLink: '/recordMange', childrenList: [] }
              ]
            },
            { id: 18, title: '档案已移交', routerLink: '/recordTurnOverMange', childrenList: [] },
            { id: 19, title: '移交(全部)', routerLink: '/allMange', childrenList: [] }
          ]
        },
        {
          title: '档案整理',
          id: 2,
          routerLink: '',
          imgSrc: null,
          childrenList: [{
            id: 4,
            title: '栏目管理',
            routerLink: '/hurdleManage',
            childrenList: []
          },
          {
            id: 5,
            title: '新闻管理',
            routerLink: '/newManage',
            childrenList: []
          },
          { id: 7, title: '专题管理', routerLink: '/specialTopicManage', childrenList: [] }
          ]
        },
        {
          title: '档案保存',
          id: 3,
          routerLink: '/fileSave',
          imgSrc: null,
          childrenList: []
        },
        {
          title: '综合档案移交申请',
          id: 13,
          routerLink: '',
          imgSrc: null,
          childrenList: [
            { id: 101, title: '移交申请', routerLink: '/applyForList', childrenList: [] },
            { id: 102, title: '移交申请审核', routerLink: '/applyAudit', childrenList: [] },
            { id: 103, title: '移交申请完成', routerLink: '/accomplishList', childrenList: [] },
            { id: 104, title: '移交申请作废', routerLink: '/cancellationList', childrenList: [] }
          ]
        },
        {
          title: '综合档案整理',
          id: 19,
          routerLink: '/fileMange',
          imgSrc: null,
          childrenList: []
        },
        {
          title: '材料模板管理',
          id: 21,
          routerLink: '/materials',
          imgSrc: null,
          childrenList: []
        },
        {
          title: '库房管理',
          id: 20,
          routerLink: '',
          imgSrc: null,
          childrenList: [
            { id: 21, title: '库房管理', routerLink: '/storehouse', childrenList: [] },
          ]
        }
      ],
      paramsOnce: {}
    }
  },
  methods: {
    roterLink (val) {
      sessionStorage.removeItem('menuListTwo')
      this.paramsOnce = { routeList: this.routeList, val: val }
      sessionStorage.setItem('menuListTwo', JSON.stringify(val))
      Bus.$emit('historyList', this.paramsOnce.val)
      this.$router.push({ path: val.routerLink })
    },
    roterLinkTwo (val, valFu) {
      sessionStorage.removeItem('menuListTwo')
      sessionStorage.setItem('menuListTwo', JSON.stringify(valFu))
      Bus.$emit('historyList', val)
      this.$router.push({ path: val.routerLink })
    },
    roterLinkThree (val, valFu) {
      sessionStorage.removeItem('menuListTwo')
      sessionStorage.setItem('menuListTwo', JSON.stringify(valFu))
      Bus.$emit('historyList', val)
      this.$router.push({ path: val.routerLink })
    }
  },
  created () {
    // this.getBreadcrumb()
  },
  beforeUpdate () {
    // console.log('我是父级')
  }

}

</script>
<style scoped lang="less">
.left-p1 {
  width: 231px;
  height: 51px;
  line-height: 51px;
  background-color: #00A7EB;
  display: inline-block;
  float: left;

  img {
    vertical-align: middle;
    margin-left: 8px;
  }
}

.el-menu-demo {
  height: 51px;
}

.topMenuList {
  li {
    float: left;
    width: 114px;
    line-height: 50px;
    height: 50px;
    padding: 0 10px;
    font-size: 14px;
    color: #fff;
    cursor: pointer;
    list-style: none;
    position: relative;
    text-align: center;

    img {
      /*vertical-align: middle; */
      position: absolute;
      right: 8px;
      top: 17px;
    }

    ul {
      display: none;
      width: 100%;
      /*height:50px;*/
      position: absolute;
      top: 50px;
      left: 0;
      z-index: 99999;
      background-color: #1E66AF;
    }

    .menuListThree {
      left: 134px;
      top: 0;
    }
  }

  li:hover {
    .menuListUlShow {
      display: block;
    }

    li:hover {
      background: rgba(0, 0, 0, 0.1);
    }
  }

  .menuListTwo:hover {
    .menuListThree {
      display: block;
    }

    li:hover {
      background: rgba(0, 0, 0, 0.1);
    }
  }
}

</style>
<style lang="less">
.el-menu--horizontal>.el-submenu .el-submenu__title {
  height: 51px;
  line-height: 51px;
}

.el-menu--horizontal .el-menu .el-submenu>.el-submenu__title {
  height: 51px;
  line-height: 51px;
}

.el-menu--horizontal .el-menu .el-menu-item {
  height: 51px;
  line-height: 51px;
}

.el-menu--horizontal>.el-menu-item {
  height: 51px;
  line-height: 51px;
}

</style>
