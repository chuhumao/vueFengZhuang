<template>
  <div>
    <!-- 上方显示 -->
    <div>
      <p class="left-p1"><img src="../../assets/home/hlogo.png" alt="" /></p>
      <p class="left-p2"><span>{{userName}}欢迎回来</span><img src="../../assets/home/hicon.png" alt="" /></p>
    </div>
    <div style="min-height: 600px;max-height: 600px;overflow: auto">
      <el-menu :default-active="$route.path" router :default-openeds="activeIndex" style="width: 200px;margin:10px;"
               unique-opened @select="handSelect" @open="handleOpen" background-color="#525252" text-color="#fff"
               v-for="(item,itemKey) in menuList" :key="itemKey">
        <el-menu-item class="itemList" :index="item.routerLink + ''" style="text-align:left;text-indent:16px;">
          <span class="itemList" style="color: #fff!important;">{{ item.title }}</span>
          <span style="float: right;" @click="deleteBtn(itemKey, item)"><img src="../../assets/home/deleteImg.png" alt /></span>
        </el-menu-item>
      </el-menu>
    </div>
    <div class="left-search">
      <!-- 查询 -->
      <div class="search-top">
        <div class="top-one">
          <img src="../../assets/home/hrule.png" alt="" width="39" />
          <p class="top-p"><span class="top-span1">当前角色</span>
            <span class="top-span2">
              <el-select v-model="showParams.singleRoleId" @change="$forceUpdate()" disabled>
                <el-option v-for="item in roleArr" :key="item.roleId" :value="item.roleId" :label="item.roleName"></el-option>
              </el-select>
            </span>
          </p>
        </div>
        <div class="top-one">
          <img src="../../assets/home/hposi.png" alt="" width="39" />
          <p class="top-p">
            <span class="top-span1">所在部门</span>
            <span class="top-span2">
              <el-select v-model="showParams.singleDeptId" @change="$forceUpdate()" disabled>
                <el-option v-for="item in deptArr" :key="item.code" :value="item.code" :label="item.name"></el-option>
              </el-select>
            </span>
          </p>
        </div>
      </div>
      <!-- 退出系统 -->
      <div class="search-out">
        <p @click="returnOut"><img src="../../assets/home/loginout.png" alt="" /><span>退出系统</span></p>
      </div>
      <div>
      </div>
    </div>
  </div>
</template>
<script>
import Bus from '../../utils/busEmit'
import { outLogin, getRole } from '@/js/getData'
export default {
  name: 'menuList',
  data () {
    return {
      showParams: {},
      roleArr: [],
      deptArr: [],
      userName: null,
      // 点击时获取到的菜单
      activeIndex: [],
      openList: null,
      // 接收菜单数组并调用渲染
      menuList: [],
      menuListTwo: new Set()
    }
  },
  methods: {
    handleOpen (key, keyPath) {
      // console.log(key)
      // 当前打开的sub-menu的 key 数组 关闭其他子菜单
      this.activeIndex = [key]
    },
    handSelect (key, keyPath) {
      // console.log(key, keyPath)
    },
    getBreadcrumb () {
      // this.openList = this.$route.path
      Bus.$on('historyList', (item) => {
        if (item.routerLink == "" || item.routerLink == null) {
          // console.log(item);
        } else {
          this.menuListTwo.add(item)
          this.menuList = [...this.menuListTwo]
        }
        this.$forceUpdate()
        // this.menuListTwo = []
        // this.menuListTwo.push(JSON.parse(sessionStorage.getItem('menuListTwo')))
        // this.menuListTwo.forEach((val, index) => {
        //   if (item.id == val.id) {
        //     this.menuList.splice(index, 1)
        //     this.menuList.push(item)
        //   }
        // })
        // this.menuList = [...item, ...this.menuList]
        // console.log(this.menuList)
        // this.menuListTwo = this.menuList
      })
    },
    // 点击子菜单更换图片
    colorSpan (val) {
      // console.log(val)
      this.menuList.forEach((item) => {
        if (item.childrenList) {
          item.childrenList.forEach((itemChildren) => {
            itemChildren.selectJudgeImg = false
          })
        }
      })
      val.selectJudgeImg = !val.selectJudgeImg
      // sessionStorage.setItem('menuListArr', JSON.stringify(this.menuList))
    },
    // 删除浏览记录
    deleteBtn (val, item) {
      this.menuList.splice(val, 1)
      this.menuListTwo.delete(item)
      this.$forceUpdate()
    },
    // 获取角色/部门/名称
    getAll () {
      getRole().then(res => {
        if (res.code == 0) {
          this.userName = res.data.userName
          this.roleArr = res.data.newRole
          this.deptArr = res.data.newDept
          this.roleArr.unshift({ 'roleId': 'all', 'roleName': '---所有角色---' })
          this.showParams.singleDeptId = this.deptArr[0].code
          this.showParams.singleRoleId = this.roleArr[0].roleId
        } else this.$message.error(res.message)
      })
    },
    // 退出登录
    returnOut () {
      outLogin().then(res => {

      })
    }
  },
  // watch: {
  //   $route: 'getBreadcrumb'
  // },
  created () {
    this.getAll()
    this.getBreadcrumb()
  },
  mounted () {

  },
  beforeUpdate () {
    // console.log(this.menuList);
  }
}

</script>
<style scoped lang="less">
.router-link-span {
  display: block;
  width: 100%;
  height: 100%;
}

:hover {
  color: rgb(255, 208, 75);
}

.headerTop {
  padding: 0;
  background-color: #004892;
  height: 51px !important;
}

.left-p1 {
  width: 100%;
  height: 51px;
  line-height: 51px;
  background-color: #00A7EB;

  img {
    vertical-align: middle;
    margin-left: 8px;
  }
}

.left-p2 {
  height: 43px;
  background-color: #E60E10;
  line-height: 43px;

  span {
    margin-left: 8px;
    color: #fff;
    font-size: 12px;
  }

  img {
    vertical-align: middle;
    float: right;
    margin: 6px;
    /*margin-left: 120px;*/
  }

}

.left-search {
  /*position: fixed;*/
  /*bottom: 60px;*/
  box-sizing: border-box;
  padding: 0 12px;
  margin-bottom: 16.3%;

  .search-top {
    /*width: 211px;*/
    height: 137px;
    /*margin-left: 10px;*/
    background-color: #525252;

    .top-one {
      padding-top: 19px;
      clear: both;

      img {
        margin-left: 10px;
        margin-right: 9px;
        float: left;
      }

      .top-p {
        display: inline-block;
        width: 63%;

        span {
          display: block;

          .el-select {
            /*width: 60%;*/
            height: 30px;
          }
        }

        .top-span1 {
          margin-bottom: 6px;
          font-size: 12px;
          color: #E8EDF4
        }

        .top-span2 {
          /*width: 144px;*/
          height: 20px;
        }

      }
    }

  }

  .search-out {
    margin-top: 9px;
    /*width: 211px;*/
    height: 31px;
    /*margin-left: 10px;*/
    background-color: #525252;

    p {
      cursor: pointer;
      text-align: center;
      font-size: 12px;
      color: #E8EDF4;
      height: 31px;
      line-height: 31px;

      img {
        vertical-align: middle;
        margin-top: -3px;
        margin-right: 5px;
      }
    }
  }

}

.el-menu {
  border-right: none;
}

</style>
<style lang="less">
.top-span2 {
  .el-input__inner {
    height: 20px !important;
    line-height: 20px !important;
  }

  .el-input__icon {
    line-height: 20px !important;
  }
}
</style>
