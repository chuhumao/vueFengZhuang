<template>
  <div class="ztTextarea">
      <div class="home-center-div1">
        <el-carousel :interval="3000" type="card" height="200px" style="margin-top: 20px">
          <el-carousel-item v-for="(item, index) in carouseImg" :key="index">
            <h3 class="medium">
              <el-image :src="item.valImg"></el-image>
              <!--<img :src="item.valImg">-->
            </h3>
            <span class="fuDiv">
                  {{item.title}}
              <!--<span></span>-->
                  <span>
                    <!--<span class="carouselImgBtn" @click="showAddContent(item.id)">-->
                      <!--<img src="../../assets/home/imgBtnAdd.png" alt="">-->
                      <!--新增-->
                    <!--</span>-->
                    <span class="carouselImgBtn" @click="showAddContent(item.id)">
                      <img src="../../assets/home/imgBtnEdit.png" alt="">
                      编辑
                    </span>
                  </span>
                  </span>
          </el-carousel-item>
        </el-carousel>
      </div>

    <!--展厅-->
    <el-dialog
      :visible.sync="hallVisibleAdd"
      width="1100px"
      class="give"
      :before-close="handleClose"
    >
      <div slot="title"  class="titl">展厅</div>
      <div>
        <el-tabs class="elTabsCss" tab-position="left" style="height: 100%;" @tab-click="handleClickTwo">
          <!-- 左侧 -->
          <el-tab-pane label="左侧展厅" class="elTabsCssTwo">
            <el-tabs tab-position="center" style="height: 100%;"  @tab-click="handleClickThree">
              <!-- 左侧展厅标题 -->
              <el-tab-pane label="左侧展厅标题">
                <div style="margin-bottom: 10px;">
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleAdd('1', 'left')">新增</el-button>
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleEdit">编辑</el-button>
                  <el-button class="btn-content" type="danger" @click="titleDelete('1')">删除</el-button>
                </div>
                <div class="all-Table">
                  <el-table
                    :data="leftTitleTable"
                    style="width: 100%"
                    border
                    show-overflow-tooltip
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column
                      type="selection"
                      width="80"
                      align="center">
                    </el-table-column>
                    <el-table-column
                      prop="title"
                      label="标题">
                    </el-table-column>
                    <el-table-column
                      width="100"
                      label="操作">
                      <template slot-scope="scope">
                        <el-button type="primary" @click="showTableContent(scope)">查看</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="pageLayout">
                  <el-pagination
                    @current-change="handleLeftTitle"
                    :current-page="leftTitleParams.page"
                    :page-size="leftTitleParams.rows"
                    layout="prev, pager, next, jumper"
                    :total="leftTitleParams.total">
                  </el-pagination>
                </div>
              </el-tab-pane>
              <!-- 左侧展厅内容上栏 -->
              <el-tab-pane label="左侧展厅内容上栏">
                <div style="margin-bottom: 10px;">
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleAddContent('11','historys')">新增</el-button>
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleEditContent">编辑</el-button>
                  <el-button class="btn-content" type="danger" @click="titleDelete('2')">删除</el-button>
                </div>
                <div class="all-Table">
                  <el-table
                    :data="leftTopTable"
                    style="width: 100%"
                    border
                    show-overflow-tooltip
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column
                      type="selection"
                      width="80"
                      align="center">
                    </el-table-column>
                    <el-table-column
                      prop="time"
                      label="时间">
                    </el-table-column>
                    <el-table-column
                      prop="event"
                      label="事件">
                    </el-table-column>
                    <el-table-column
                      prop="desc"
                      label="说明">
                    </el-table-column>
                    <el-table-column
                      width="100"
                      label="操作">
                      <template slot-scope="scope">
                        <el-button type="primary" @click="showTableContentTop(scope)">查看</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="pageLayout">
                  <el-pagination
                    @current-change="handleLeftTop"
                    :current-page="leftTopParams.page"
                    :page-size="leftTopParams.rows"
                    layout="prev, pager, next, jumper"
                    :total="leftTopParams.total">
                  </el-pagination>
                </div>
              </el-tab-pane>
              <!-- 左侧展厅内容下栏 -->
              <el-tab-pane label="左侧展厅内容下栏">
                <div style="margin-bottom: 10px;">
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleAddContentTwo('111', 'mergers')">新增</el-button>
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleEditContentTwo">编辑</el-button>
                  <el-button class="btn-content" type="danger" @click="titleDelete('2')">删除</el-button>
                </div>
                <div class="all-Table">
                  <el-table
                    :data="leftRightTable"
                    style="width: 100%"
                    border
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column
                      type="selection"
                      width="80"
                      align="center">
                    </el-table-column>
                    <el-table-column
                      prop="event"
                      label="事件">
                    </el-table-column>
                    <el-table-column
                      prop="desc"
                      label="说明">
                    </el-table-column>
                    <el-table-column
                      width="100"
                      label="操作">
                      <template slot-scope="scope">
                        <el-button type="primary" @click="showTableContentBottom(scope)">查看</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="pageLayout">
                  <el-pagination
                    @current-change="handleLeftRight"
                    :current-page="leftRightParams.page"
                    :page-size="leftRightParams.rows"
                    layout="prev, pager, next, jumper"
                    :total="leftRightParams.total">
                  </el-pagination>
                </div>
              </el-tab-pane>
            </el-tabs>
          </el-tab-pane>
          <!-- 中央 -->
          <el-tab-pane label="中央展厅" class="elTabsCssTwo">
            <el-tabs tab-position="center"   @tab-click="handleClickThree">
              <!-- 中央展厅标题 -->
              <el-tab-pane label="中央展厅标题">
                <div style="margin-bottom: 10px;">
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleAdd('2', 'center')">新增</el-button>
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleEdit">编辑</el-button>
                  <el-button class="btn-content" type="danger" @click="titleDelete('1')">删除</el-button>
                </div>
                <div class="all-Table">
                  <el-table
                    :data="centerTitleTable"
                    style="width: 100%"
                    border
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column
                      type="selection"
                      width="80"
                      align="center">
                    </el-table-column>
                    <el-table-column
                      prop="title"
                      label="标题">
                    </el-table-column>
                    <el-table-column
                      width="100"
                      label="操作">
                      <template slot-scope="scope">
                        <el-button type="primary" @click="showTableContent(scope)">查看</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="pageLayout">
                  <el-pagination
                    @current-change="handleCenterTitle"
                    :current-page="centerTitleParams.page"
                    :page-size="centerTitleParams.rows"
                    layout="prev, pager, next, jumper"
                    :total="centerTitleParams.total">
                  </el-pagination>
                </div>
              </el-tab-pane>
              <!-- 中央展厅内容上栏 -->
              <el-tab-pane label="中央展厅内容上栏">
                <div style="margin-bottom: 10px;">
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleAddContent('22', 'historys3')">新增</el-button>
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleEditContent">编辑</el-button>
                  <el-button class="btn-content" type="danger" @click="titleDelete('2')">删除</el-button>
                </div>
                <div class="all-Table">
                  <el-table
                    :data="centerTopTable"
                    style="width: 100%"
                    border
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column
                      type="selection"
                      width="80"
                      align="center">
                    </el-table-column>
                    <el-table-column
                      prop="time"
                      label="时间">
                    </el-table-column>
                    <el-table-column
                      prop="event"
                      label="事件">
                    </el-table-column>
                    <el-table-column
                      prop="desc"
                      label="说明">
                    </el-table-column>
                    <el-table-column
                      width="100"
                      label="操作">
                      <template slot-scope="scope">
                        <el-button type="primary" @click="showTableContentTop(scope)">查看</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="pageLayout">
                  <el-pagination
                    @current-change="handleCenterTop"
                    :current-page="centerTopParams.page"
                    :page-size="centerTopParams.rows"
                    layout="prev, pager, next, jumper"
                    :total="centerTopParams.total">
                  </el-pagination>
                </div>
              </el-tab-pane>
              <!-- 中央展厅内容下栏 -->
              <el-tab-pane label="中央展厅内容下栏">
                <div style="margin-bottom: 10px;">
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleAddContentTwo('222', 'mergers3')">新增</el-button>
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleEditContentTwo">编辑</el-button>
                  <el-button class="btn-content" type="danger" @click="titleDelete('2')">删除</el-button>
                </div>
                <div class="all-Table">
                  <el-table
                    :data="centerRightTable"
                    style="width: 100%"
                    border
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column
                      type="selection"
                      width="80"
                      align="center">
                    </el-table-column>
                    <el-table-column
                      prop="event"
                      label="事件">
                    </el-table-column>
                    <el-table-column
                      prop="desc"
                      label="说明">
                    </el-table-column>
                    <el-table-column
                      width="100"
                      label="操作">
                      <template slot-scope="scope">
                        <el-button type="primary" @click="showTableContentBottom(scope)">查看</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="pageLayout">
                  <el-pagination
                    @current-change="handleCenterRight"
                    :current-page="centerRightParams.page"
                    :page-size="centerRightParams.rows"
                    layout="prev, pager, next, jumper"
                    :total="centerRightParams.total">
                  </el-pagination>
                </div>
              </el-tab-pane>
            </el-tabs>
          </el-tab-pane>
          <!-- 右侧 -->
          <el-tab-pane label="右侧展厅" class="elTabsCssTwo">
            <el-tabs tab-position="center"   @tab-click="handleClickThree">
              <!-- 右侧展厅标题 -->
              <el-tab-pane label="右侧展厅标题">
                <div style="margin-bottom: 10px;">
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleAdd('3', 'right')">新增</el-button>
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleEdit">编辑</el-button>
                  <el-button class="btn-content" type="danger" @click="titleDelete('1')">删除</el-button>
                </div>
                <div class="all-Table">
                  <el-table
                    :data="rightTitleTable"
                    style="width: 100%"
                    border
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column
                      type="selection"
                      width="80"
                      align="center">
                    </el-table-column>
                    <el-table-column
                      prop="title"
                      label="标题">
                    </el-table-column>
                    <el-table-column
                      width="100"
                      label="操作">
                      <template slot-scope="scope">
                        <el-button type="primary" @click="showTableContent(scope)">查看</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="pageLayout">
                  <el-pagination
                    @current-change="handleRightTitle"
                    :current-page="rightTitleParams.page"
                    :page-size="rightTitleParams.rows"
                    layout="prev, pager, next, jumper"
                    :total="rightTitleParams.total">
                  </el-pagination>
                </div>
              </el-tab-pane>
              <!-- 右侧展厅内容上栏 -->
              <el-tab-pane label="右侧展厅内容上栏">
                <div style="margin-bottom: 10px;">
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleAddContent('33', 'historys2')">新增</el-button>
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleEditContent">编辑</el-button>
                  <el-button class="btn-content" type="danger" @click="titleDelete('2')">删除</el-button>
                </div>
                <div class="all-Table">
                  <el-table
                    :data="rightTopTable"
                    style="width: 100%"
                    border
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column
                      type="selection"
                      width="80"
                      align="center">
                    </el-table-column>
                    <el-table-column
                      prop="time"
                      label="时间">
                    </el-table-column>
                    <el-table-column
                      prop="event"
                      label="事件">
                    </el-table-column>
                    <el-table-column
                      prop="desc"
                      label="说明">
                    </el-table-column>
                    <el-table-column
                      width="100"
                      label="操作">
                      <template slot-scope="scope">
                        <el-button type="primary" @click="showTableContentTop(scope)">查看</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="pageLayout">
                  <el-pagination
                    @current-change="handleRightTop"
                    :current-page="rightTopParams.page"
                    :page-size="rightTopParams.rows"
                    layout="prev, pager, next, jumper"
                    :total="rightTopParams.total">
                  </el-pagination>
                </div>
              </el-tab-pane>
              <!-- 右侧展厅内容下栏 -->
              <el-tab-pane label="右侧展厅内容下栏">
                <div style="margin-bottom: 10px;">
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleAddContentTwo('333', 'mergers2')">新增</el-button>
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleEditContentTwo">编辑</el-button>
                  <el-button class="btn-content" type="danger" @click="titleDelete('2')">删除</el-button>
                </div>
                <div class="all-Table">
                  <el-table
                    :data="rightRightTable"
                    style="width: 100%"
                    border
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column
                      type="selection"
                      width="80"
                      align="center">
                    </el-table-column>
                    <el-table-column
                      prop="event"
                      label="事件">
                    </el-table-column>
                    <el-table-column
                      prop="desc"
                      label="说明">
                    </el-table-column>
                    <el-table-column
                      width="100"
                      label="操作">
                      <template slot-scope="scope">
                        <el-button type="primary" @click="showTableContentBottom(scope)">查看</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="pageLayout">
                  <el-pagination
                    @current-change="handleRightRight"
                    :current-page="rightRightParams.page"
                    :page-size="rightRightParams.rows"
                    layout="prev, pager, next, jumper"
                    :total="rightRightParams.total">
                  </el-pagination>
                </div>
              </el-tab-pane>
            </el-tabs>
          </el-tab-pane>
        </el-tabs>
      </div>
    </el-dialog>
    <!-- 展厅--标题 -->
    <el-dialog
      :visible.sync="hallVisibleTitle"
      width="400px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">新增标题</div>
      <br/>
      <el-form :model="paramsAddTitle" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="新闻标题：" prop="title">
          <el-input v-model="paramsAddTitle.title" style="width: 80%;"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="leftBtnTitle">保存</el-button>
      </div>
    </el-dialog>
    <!-- 展厅--上栏内容 -->
    <el-dialog
      :visible.sync="hallVisibleContent"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">新增1</div>
      <br/>
      <el-form :model="paramsAddTopContent" :rules="rulesAuditTop" ref="ruleFormAddCenterContentTop" label-width="120px" class="demo-ruleForm">
        <el-form-item label="时间：" prop="time">
          <el-date-picker
            v-model="paramsAddTopContent.time"
            type="date"
            format="yyyy 年 MM 月 dd 日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="事件：" prop="event">
          <el-input  type="textarea" v-model="paramsAddTopContent.event" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片：">
          <el-upload
            ref="AddBtnImgTwo"
            class="upload-demo"
            action="#"
            :multiple="false"
            :auto-upload="false"
            :limit="1"
            accept="image/jpeg,image/png,image/jpg"
            list-type="picture"
            :on-exceed="handleExceed"
            :on-change="handleChange"
            :on-remove="handleRemove"
          >
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
        </el-form-item>
        <el-form-item label="说明：" prop="desc">
          <el-input  type="textarea" v-model="paramsAddTopContent.desc" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="centerTopBtnTitle">保存</el-button>
      </div>
    </el-dialog>
    <!-- 展厅--下栏内容 -->
    <el-dialog
      :visible.sync="hallVisibleBottom"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">新增</div>
      <br/>
      <el-form :model="paramsAddBottomContent" :rules="rulesAuditBottom" ref="ruleFormAddCenterContentBottom" label-width="120px" class="demo-ruleForm">
        <el-form-item label="事件：" prop="event">
          <el-input  type="textarea" v-model="paramsAddBottomContent.event" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item label="图片：" class="editorXin">
          <el-upload
            ref="AddBtnImg"
            class="upload-demo"
            action="#"
            :multiple="false"
            :auto-upload="false"
            :limit="1"
            accept="image/jpeg,image/png,image/jpg"
            list-type="picture"
            :on-exceed="handleExceed"
            :on-change="handleChange"
            :on-remove="handleRemove"
          >
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
        </el-form-item>
        <el-form-item label="说明：" prop="desc">
          <el-input  type="textarea" v-model="paramsAddBottomContent.desc" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="rightLeftBtnTitle">保存</el-button>
      </div>
    </el-dialog>

    <!-- 展厅--标题编辑 -->
    <el-dialog
      :visible.sync="editTitleContent"
      width="400px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">编辑</div>
      <br/>
      <el-form :model="paramsEditTitle" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="新闻标题：" prop="title">
          <el-input v-model="paramsEditTitle.title" style="width: 80%;"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="leftBtnTitleEdit">保存</el-button>
      </div>
    </el-dialog>
    <!-- 展厅--上栏内容编辑 -->
    <el-dialog
      :visible.sync="editCenterContent"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">编辑</div>
      <br/>
      <el-form :model="paramsEditContent" :rules="rulesAuditTop" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="时间：" prop="time">
          <el-date-picker
            v-model="paramsEditContent.time"
            type="date"
            format="yyyy 年 MM 月 dd 日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="事件：" prop="event">
          <el-input  type="textarea" v-model="paramsEditContent.event" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片：">
          <el-upload
            ref="AddBtnImg"
            class="upload-demo"
            action="#"
            :multiple="false"
            :auto-upload="false"
            :limit="1"
            accept="image/jpeg,image/png,image/jpg"
            list-type="picture"
            :on-exceed="handleExceed"
            :on-change="handleChange"
            :on-remove="handleRemove"
          >
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
          <img :src="imgUrlHost+imgZtUrl+paramsEditContent.img" alt=""  class="avatar">
        </el-form-item>
        <el-form-item label="说明：" prop="desc">
          <el-input  type="textarea" v-model="paramsEditContent.desc" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="centerBtnContent">保存</el-button>
      </div>
    </el-dialog>
    <!-- 展厅--下栏内容编辑 -->
    <el-dialog
      :visible.sync="editCenterContentTwo"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">编辑</div>
      <br/>
      <el-form :model="paramsEditContent" :rules="rulesAuditBottom" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="事件：" prop="event">
          <el-input  type="textarea" v-model="paramsEditContent.event" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item label="图片：" class="editorXin">
          <el-upload
            ref="AddBtnImg"
            class="upload-demo"
            action="#"
            :multiple="false"
            :auto-upload="false"
            :limit="1"
            accept="image/jpeg,image/png,image/jpg"
            list-type="picture"
            :on-exceed="handleExceed"
            :on-change="handleChange"
            :on-remove="handleRemove"
          >
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
          <img :src="imgUrlHost+imgZtUrl+paramsEditContent.img" alt=""  class="avatar">
        </el-form-item>
        <el-form-item label="说明：" prop="desc">
          <el-input  type="textarea" v-model="paramsEditContent.desc" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="centerBtnContent">保存</el-button>
      </div>
    </el-dialog>
    <!-- 删除弹框 -->
    <el-dialog :visible.sync="deleteTitleContent" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicDel.png" alt="">
        删除
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要删除此专题吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitFormDelete">确定</el-button>
        <el-button @click="deleteTitleContent = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 展厅--查看标题 -->
    <el-dialog
      :visible.sync="titleLookDialog"
      width="400px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">查看</div>
      <br/>
      <el-form :model="paramsAddTitle" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="新闻标题：" prop="title">
          <el-input v-model="paramsAddTitle.title" style="width: 80%;"></el-input>
        </el-form-item>
      </el-form>
    </el-dialog>
    <!-- 展厅--查看上栏内容 -->
    <el-dialog
      :visible.sync="topLookDialog"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">查看</div>
      <br/>
      <el-form :model="paramsAddTopContent" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="时间：" prop="time">
          <!--<el-date-picker-->
            <!--v-model="paramsAddTopContent.time"-->
            <!--type="date"-->
            <!--format="yyyy 年 MM 月 dd 日"-->
            <!--value-format="yyyy-MM-dd"-->
            <!--placeholder="选择时间">-->
          <!--</el-date-picker>-->
          <el-input  type="text" v-model="paramsAddTopContent.time" style="width: 50%;" readonly></el-input>
        </el-form-item>
        <el-form-item label="事件：" prop="event">
          <el-input  type="textarea" v-model="paramsAddTopContent.event" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片：">
          <img :src="imgUrlHost+imgZtUrl+paramsAddTopContent.img" alt=""  class="avatar">
        </el-form-item>
        <el-form-item label="说明：" prop="desc">
          <el-input  type="textarea" v-model="paramsAddTopContent.desc" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <br/>
    </el-dialog>
    <!-- 展厅--查看下栏内容 -->
    <el-dialog
      :visible.sync="bottomLookDialog"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">查看</div>
      <br/>
      <el-form :model="paramsAddBottomContent" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="事件：" prop="event">
          <el-input  type="textarea" v-model="paramsAddBottomContent.event" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item label="图片：" class="editorXin">
          <img :src="imgUrlHost+imgZtUrl+paramsAddBottomContent.img" alt=""  class="avatar">
        </el-form-item>
        <el-form-item label="说明：" prop="desc">
          <el-input  type="textarea" v-model="paramsAddBottomContent.desc" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <br/>
    </el-dialog>

    <!--荣耀室-->
    <el-dialog
      :visible.sync="honourAdd"
      width="1100px"
      class="give"
      :before-close="handleClose"
    >
      <div slot="title"  class="titl">荣耀室</div>
      <div>
        <el-tabs class="elTabsCss" tab-position="left" style="height: 100%; min-height: 562px;"  @tab-click="resetTable">
          <!-- 电视墙 -->
          <el-tab-pane label="电视墙" class="elTabsCssTwo">
            <el-tabs tab-position="center" style="height: 100%;"  @tab-click="resetTable">
              <!-- 广发上市 -->
              <el-tab-pane label="广发上市">
                <div style="margin-bottom: 10px;">
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="hoursAddBtn('gfss', 'img', 'videowall')">新增</el-button>
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="hoursEditBtnGffss">编辑</el-button>
                  <el-button class="btn-content" type="danger" @click="deleteBtn">删除</el-button>
                </div>
                <div class="all-Table">
                  <el-table
                    :data="gfssTable"
                    style="width: 100%"
                    border
                    show-overflow-tooltip
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column
                      type="selection"
                      width="80"
                      align="center">
                    </el-table-column>
                    <el-table-column
                      prop="itemImg"
                      label="名称">
                    </el-table-column>
                    <el-table-column
                      width="100"
                      label="操作">
                      <template slot-scope="scope">
                        <el-button type="primary" @click="showImgContent(scope)">查看</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="pageLayout">
                  <el-pagination
                    @current-change="hoursGfssPageBtn"
                    :current-page="gfssParams.page"
                    :page-size="gfssParams.rows"
                    layout="prev, pager, next, jumper"
                    :total="gfssParams.total">
                  </el-pagination>
                </div>
              </el-tab-pane>
              <!-- 视频 -->
              <el-tab-pane label="视频">
                <div style="margin-bottom: 10px;">
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="videoAddBtn">新增</el-button>
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="videoAddBtnGffss">编辑</el-button>
                  <el-button class="btn-content" type="danger" @click="deleteBtn">删除</el-button>
                </div>
                <div class="all-Table">
                  <el-table
                    :data="videoTable"
                    style="width: 100%"
                    border
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column
                      type="selection"
                      width="80"
                      align="center">
                    </el-table-column>
                    <el-table-column
                      prop="itemName"
                      label="名称">
                    </el-table-column>
                    <el-table-column
                      width="100"
                      label="操作">
                      <template slot-scope="scope">
                        <el-button type="primary" @click="showImgContentVideo(scope)">查看</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="pageLayout">
                  <el-pagination
                    @current-change="hoursGfssPageBtn"
                    :current-page="videoParams.page"
                    :page-size="videoParams.rows"
                    layout="prev, pager, next, jumper"
                    :total="videoParams.total">
                  </el-pagination>
                </div>
              </el-tab-pane>
              <!-- 社会责任 -->
              <el-tab-pane label="社会责任">
                <div style="margin-bottom: 10px;">
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="responsAddBtn">新增</el-button>
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="hoursEditBtnRespons">编辑</el-button>
                  <el-button class="btn-content" type="danger" @click="deleteBtn">删除</el-button>
                </div>
                <div class="all-Table">
                  <el-table
                    :data="responsibilityTable"
                    style="width: 100%"
                    border
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column
                      type="selection"
                      width="80"
                      align="center">
                    </el-table-column>
                    <el-table-column
                      prop="itemTitle"
                      show-overflow-tooltip
                      label="事件">
                    </el-table-column>
                    <el-table-column
                      prop="itemDesc"
                      show-overflow-tooltip
                      label="介绍1">
                    </el-table-column>
                    <el-table-column
                      prop="itemDesc1"
                      show-overflow-tooltip
                      label="介绍2">
                    </el-table-column>
                    <el-table-column
                      width="100"
                      label="操作">
                      <template slot-scope="scope">
                        <el-button type="primary" @click="showImgContentDuty(scope)">查看</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="pageLayout">
                  <el-pagination
                    @current-change="hoursGfssPageBtnRespon"
                    :current-page="responsibilityParams.page"
                    :page-size="responsibilityParams.rows"
                    layout="prev, pager, next, jumper"
                    :total="responsibilityParams.total">
                  </el-pagination>
                </div>
              </el-tab-pane>
            </el-tabs>
          </el-tab-pane>
          <!-- 荣耀墙 -->
          <el-tab-pane label="荣耀墙">
            <br/>
            <div style="margin-bottom: 10px;">
              <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="hoursAddBtn('honor', 'img')">新增</el-button>
              <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="hoursEditBtn">编辑</el-button>
              <el-button class="btn-content" type="danger" @click="deleteBtn">删除</el-button>
            </div>
            <div class="all-Table">
              <el-table
              :data="honourTable"
              style="width: 100%"
              border
              show-overflow-tooltip
              @selection-change="handleSelectionChange"
            >
              <el-table-column
                type="selection"
                width="80"
                align="center">
              </el-table-column>
              <el-table-column
                prop="honorImg"
                label="名称">
              </el-table-column>
              <el-table-column
                width="100"
                label="操作">
                <template slot-scope="scope">
                  <el-button type="primary" @click="showImgContent(scope)">查看</el-button>
                </template>
              </el-table-column>
            </el-table>
            </div>
            <div class="pageLayout">
              <el-pagination
                @current-change="hoursPageBtn"
                :current-page="honourParams.page"
                :page-size="honourParams.rows"
                layout="prev, pager, next, jumper"
                :total="honourParams.total">
              </el-pagination>
            </div>
          </el-tab-pane>
          <!-- 公司文化 -->
          <el-tab-pane label="公司文化"  class="elTabsCssTwo">
            <el-tabs tab-position="center"  @tab-click="resetTable">
              <!-- 发展历程 -->
              <el-tab-pane label="发展历程">
                <div style="margin-bottom: 10px;">
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleAddContent(4)">新增</el-button>
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="companyOneEditBtn">编辑</el-button>
                  <el-button class="btn-content" type="danger" @click="deleteBtn">删除</el-button>
                </div>
                <div class="all-Table">
                  <el-table
                    :data="historyTable"
                    style="width: 100%"
                    border
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column
                      type="selection"
                      width="80"
                      align="center">
                    </el-table-column>
                    <el-table-column
                      prop="honorTime"
                      label="时间">
                    </el-table-column>
                    <el-table-column
                      prop="honorEvent"
                      show-overflow-tooltip
                      label="事件">
                    </el-table-column>
                    <el-table-column
                      prop="honorDesc"
                      show-overflow-tooltip
                      label="描述">
                    </el-table-column>
                    <el-table-column
                      width="100"
                      label="操作">
                      <template slot-scope="scope">
                        <el-button type="primary" @click="showImgContentDevelop(scope)">查看</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="pageLayout">
                  <el-pagination
                    @current-change="historyPage"
                    :current-page="historyParams.page"
                    :page-size="historyParams.rows"
                    layout="prev, pager, next, jumper"
                    :total="historyParams.total">
                  </el-pagination>
                </div>
              </el-tab-pane>
              <!-- 收购兼并历程 -->
              <el-tab-pane label="收购兼并历程">
                <div style="margin-bottom: 10px;">
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leftTitleAddContentTwo('444')">新增</el-button>
                  <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="companyTwoEditBtn">编辑</el-button>
                  <el-button class="btn-content" type="danger" @click="deleteBtn">删除</el-button>
                </div>
                <div class="all-Table">
                  <el-table
                    :data="mergeTable"
                    style="width: 100%"
                    border
                    @selection-change="handleSelectionChange"
                  >
                    <el-table-column
                      type="selection"
                      width="80"
                      align="center">
                    </el-table-column>
                    <el-table-column
                      prop="honorEvent"
                      show-overflow-tooltip
                      label="事件">
                    </el-table-column>
                    <el-table-column
                      prop="honorDesc"
                      show-overflow-tooltip
                      label="说明">
                    </el-table-column>
                    <el-table-column
                      width="100"
                      label="操作">
                      <template slot-scope="scope">
                        <el-button type="primary" @click="showImgContentReap(scope)">查看</el-button>
                      </template>
                    </el-table-column>
                  </el-table>
                </div>
                <div class="pageLayout">
                  <el-pagination
                    @current-change="mergeParamsPage"
                    :current-page="mergeParams.page"
                    :page-size="mergeParams.rows"
                    layout="prev, pager, next, jumper"
                    :total="mergeParams.total">
                  </el-pagination>
                </div>
              </el-tab-pane>
            </el-tabs>
          </el-tab-pane>
          <!-- 人物长廊 -->
          <el-tab-pane label="人物长廊"  class="elTabsCssTwo">
            <br/>
            <div style="margin-bottom: 10px;">
              <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="hoursAddBtn('leader')">新增</el-button>
              <el-button class="btn-content" type="primary" style="background-color:#0067AD" @click="leaderEditBtn">编辑</el-button>
              <el-button class="btn-content" type="danger" @click="deleteBtn">删除</el-button>
            </div>
            <div class="all-Table">
              <el-table
                :data="leaderTable"
                style="width: 100%"
                border
                @selection-change="handleSelectionChange"
              >
                <el-table-column
                  type="selection"
                  width="80"
                  align="center">
                </el-table-column>
                <el-table-column
                  prop="honorName"
                  label="名称">
                </el-table-column>
                <el-table-column
                  prop="honorDesc"
                  show-overflow-tooltip
                  label="介绍">
                </el-table-column>
                <el-table-column
                  width="100"
                  label="操作">
                  <template slot-scope="scope">
                    <el-button type="primary" @click="showImgContentUser(scope)">查看</el-button>
                  </template>
                </el-table-column>
              </el-table>
            </div>
            <div class="pageLayout">
              <el-pagination
                @current-change="leaderPageBtn"
                :current-page="leaderParams.page"
                :page-size="leaderParams.rows"
                layout="prev, pager, next, jumper"
                :total="leaderParams.total">
              </el-pagination>
            </div>
          </el-tab-pane>
        </el-tabs>
      </div>
    </el-dialog>
    <!-- 电视墙--广发上市--新增 -->
    <el-dialog
      :visible.sync="hoursGffssBtn"
      width="444px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">新增</div>
      <br/>
      <el-form :model="hoursImageUrl" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="图片：" class="editorXin">
          <el-upload
            class="avatar-uploader"
            action="#"
            :show-file-list="false"
            :multiple="false"
            :auto-upload="false"
            accept="image/jpeg,image/png,image/jpg"
            :on-change="hoursUploadGffss">
            <img v-if="hoursImageUrl.itemImg" :src="imgUrlHost+imgRytUrl+hoursImageUrl.itemImg" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="hoursAddBtnContentGffss">确定</el-button>
        <el-button @click="hoursGffssBtn = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 电视墙--广发上市--编辑 -->
    <el-dialog
      :visible.sync="hoursGffssBtnEdit"
      width="444px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">编辑</div>
      <br/>
      <el-form :model="hoursImageUrl" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="图片：" class="editorXin">
          <el-upload
            class="avatar-uploader"
            action="#"
            :show-file-list="false"
            :multiple="false"
            :auto-upload="false"
            accept="image/jpeg,image/png,image/jpg"
            :on-change="hoursUploadGffss">
            <img v-if="hoursImageUrl.itemImg" :src="imgUrlHost+imgRytUrl+hoursImageUrl.itemImg" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="hoursEditBtnContentGffss">确定</el-button>
        <el-button @click="hoursGffssBtnEdit = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 电视墙--视频--新增 -->
    <el-dialog
      :visible.sync="hoursVideoBtn"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">
        <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
        新增
      </div>
      <br/>
      <el-form :model="videoAddParams" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="名称：" prop="itemName">
          <el-input v-model="videoAddParams.itemName" placeholder="请输入名称" style="width: 70%;"></el-input>
        </el-form-item>
        <el-form-item label="封面：" class="editorXin">
          <!--<el-upload-->
            <!--class="avatar-uploader"-->
            <!--action="#"-->
            <!--:show-file-list="false"-->
            <!--:multiple="false"-->
            <!--:auto-upload="false"-->
            <!--accept="image/jpeg,image/png,image/jpg"-->
            <!--:on-change="hoursUploadVideo">-->
            <!--<img v-if="videoAddParams.itemImg" :src="imgUrlHost+imgRytUrl+videoAddParams.itemImg" class="avatar">-->
            <!--<i v-else class="el-icon-plus avatar-uploader-icon"></i>-->
          <!--</el-upload>-->
          <el-upload
            ref="AddBtnImg"
            class="upload-demo"
            action="#"
            :multiple="false"
            :auto-upload="false"
            :limit="1"
            accept="image/jpeg,image/png,image/jpg"
            list-type="picture"
            :on-change="hoursUploadVideo"
            :on-remove="handleRemove"
          >
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
        </el-form-item>
        <el-form-item label="视频：" class="editorXin">
          <el-upload
            class="avatar-uploader"
            action="#"
            :show-file-list="false"
            :multiple="false"
            :auto-upload="false"
            accept="video/mp4,video/ogg,video/flv,video/avi,video/wmv,video/rmvb"
            :on-change="hoursUploadVideoTwo">
            <!--<img v-if="videoAddParams.itemFlv" :src="imgUrlHost+ '/'+ videoAddParams.itemFlv" class="avatar">-->
            <video  v-if="videoAddParams.itemFlv" width="320" height="240" controls>
              <source :src="imgUrlHost+imgRytUrl+videoAddParams.itemFlv" type="video/mp4">
            </video>
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="hoursAddBtnContentVideo">确定</el-button>
        <el-button @click="hoursVideoBtn = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 电视墙--视频--编辑 -->
    <el-dialog
      :visible.sync="hoursVideoBtnEdit"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">编辑</div>
      <br/>
      <el-form :model="videoAddParams" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="名称：" prop="itemName">
          <el-input v-model="videoAddParams.itemName" placeholder="请输入名称" style="width: 70%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="封面：">
          <!--<el-upload-->
            <!--class="avatar-uploader"-->
            <!--action="#"-->
            <!--:show-file-list="false"-->
            <!--:multiple="false"-->
            <!--:auto-upload="false"-->
            <!--accept="image/jpeg,image/png,image/jpg"-->
            <!--:on-change="hoursUploadVideo">-->
            <!--<img v-if="videoAddParams.itemImg" :src="imgUrlHost+imgRytUrl+videoAddParams.itemImg" class="avatar">-->
            <!--<i v-else class="el-icon-plus avatar-uploader-icon"></i>-->
          <!--</el-upload>-->
          <el-upload
            ref="AddBtnImg"
            class="upload-demo"
            action="#"
            :multiple="false"
            :auto-upload="false"
            :limit="1"
            accept="image/jpeg,image/png,image/jpg"
            list-type="picture"
            :on-change="hoursUploadVideo"
            :on-remove="handleRemove"
          >
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
          <img :src="imgUrlHost+imgRytUrl+videoAddParams.itemImg" class="avatar">
        </el-form-item>
        <el-form-item class="editorXin" label="视频：">
          <el-upload
            class="avatar-uploader"
            action="#"
            :show-file-list="false"
            :multiple="false"
            :auto-upload="false"
            accept="video/mp4,video/ogg,video/flv,video/avi,video/wmv,video/rmvb"
            :on-change="hoursUploadVideoTwo">
            <!--<img v-if="videoAddParams.itemFlv" :src="imgUrlHost+ '/'+ videoAddParams.itemFlv" class="avatar">-->
            <video  v-if="videoAddParams.itemFlv" width="320" height="240" controls>
              <source :src="imgUrlHost+imgRytUrl+videoAddParams.itemFlv" type="video/mp4">
            </video>
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="hoursEditBtnContentVideo">确定</el-button>
        <el-button @click="hoursVideoBtnEdit = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 社会责任--新增 -->
    <el-dialog
      :visible.sync="responsVideoBtn"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">新增</div>
      <br/>
      <el-form :model="responsAddParams" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="事件：" prop="itemTitle">
          <el-input v-model="responsAddParams.itemTitle" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片1：">
          <el-upload
            class="avatar-uploader"
            action="#"
            :show-file-list="false"
            :multiple="false"
            :auto-upload="false"
            accept="image/jpeg,image/png,image/jpg"
            :on-change="hoursUploadVideoTwoAddOne">
            <img v-if="responsAddParams.itemImg" :src="imgUrlHost+imgRytUrl+responsAddParams.itemImg" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
        <el-form-item label="介绍1：" prop="itemDesc">
          <el-input  type="textarea" v-model="responsAddParams.itemDesc" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片2：">
          <el-upload
            class="avatar-uploader"
            action="#"
            :show-file-list="false"
            :multiple="false"
            :auto-upload="false"
            accept="image/jpeg,image/png,image/jpg"
            :on-change="hoursUploadVideoTwoAdd">
            <img v-if="responsAddParams.itemImg1" :src="imgUrlHost+imgRytUrl+ responsAddParams.itemImg1" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
        <el-form-item label="介绍2：" prop="itemDesc1">
          <el-input  type="textarea" v-model="responsAddParams.itemDesc1" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="hoursAddBtnContentRespons">确定</el-button>
        <el-button @click="responsVideoBtn = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 社会责任--编辑 -->
    <el-dialog
      :visible.sync="responsVideoBtnEdit"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">编辑</div>
      <br/>
      <el-form :model="responsAddParams" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="事件：" prop="itemTitle">
          <el-input v-model="responsAddParams.itemTitle" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片1：">
          <el-upload
            class="avatar-uploader"
            action="#"
            :show-file-list="false"
            :multiple="false"
            :auto-upload="false"
            accept="image/jpeg,image/png,image/jpg"
            :on-change="hoursUploadVideoTwoAddOne">
            <img v-if="responsAddParams.itemImg" :src="imgUrlHost+imgRytUrl+responsAddParams.itemImg" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
        <el-form-item label="介绍1：" prop="itemDesc">
          <el-input  type="textarea" v-model="responsAddParams.itemDesc" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片2：">
          <el-upload
            class="avatar-uploader"
            action="#"
            :show-file-list="false"
            :multiple="false"
            :auto-upload="false"
            accept="image/jpeg,image/png,image/jpg"
            :on-change="hoursUploadVideoTwoAdd">
            <img v-if="responsAddParams.itemImg1" :src="imgUrlHost+imgRytUrl+ responsAddParams.itemImg1" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
        <el-form-item label="介绍2：" prop="itemDesc1">
          <el-input  type="textarea" v-model="responsAddParams.itemDesc1" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="hoursEditBtnContentRespons">确定</el-button>
        <el-button @click="responsVideoBtnEdit = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 公司文化--发展历程--新增 -->
    <el-dialog
      :visible.sync="companyOne"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">新增</div>
      <br/>
      <el-form :model="companyOneAddContent" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="时间：" prop="honorTime">
          <el-date-picker
            v-model="companyOneAddContent.honorTime"
            type="date"
            format="yyyy 年 MM 月 dd 日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="事件：" prop="honorEvent">
          <el-input  type="textarea" v-model="companyOneAddContent.honorEvent" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片：">
          <el-upload
            ref="AddBtnImg"
            class="upload-demo"
            action="#"
            :multiple="false"
            :auto-upload="false"
            :limit="1"
            accept="image/jpeg,image/png,image/jpg"
            list-type="picture"
            :on-exceed="handleExceed"
            :on-change="companyOneChange"
            :on-remove="handleRemove"
          >
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
        </el-form-item>
        <el-form-item label="描述：" prop="honorDesc">
          <el-input  type="textarea" v-model="companyOneAddContent.honorDesc" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="companyOneBtnTitle">保存</el-button>
      </div>
    </el-dialog>
    <!-- 公司文化--发展历程--编辑 -->
    <el-dialog
      :visible.sync="companyOneEdit"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">编辑</div>
      <br/>
      <el-form :model="companyOneAddContent" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="时间：" prop="honorTime">
          <el-date-picker
            v-model="companyOneAddContent.honorTime"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="事件：" prop="honorEvent">
          <el-input  type="textarea" v-model="companyOneAddContent.honorEvent" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片：">
          <el-upload
            ref="AddBtnImg"
            class="upload-demo"
            action="#"
            :multiple="false"
            :auto-upload="false"
            :limit="1"
            accept="image/jpeg,image/png,image/jpg"
            list-type="picture"
            :on-exceed="handleExceed"
            :on-change="companyOneChange"
            :on-remove="handleRemove"
          >
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
          <img :src="imgUrlHost+imgRytUrl+companyOneAddContent.honorImg" alt=""  class="avatar">
          <!--<img :src="imgUrlHost+imgZtUrl+companyOneAddContent.honorImg" alt=""  class="avatar">-->
        </el-form-item>
        <el-form-item label="描述：" prop="honorDesc">
          <el-input  type="textarea" v-model="companyOneAddContent.honorDesc" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="companyOneBtnTitleEdit">保存</el-button>
      </div>
    </el-dialog>
    <!-- 公司文化--收购兼并历程--新增 -->
    <el-dialog
      :visible.sync="companyTwo"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">新增</div>
      <br/>
      <el-form :model="companyTwoAddContent" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="事件：" prop="honorEvent">
          <el-input  type="textarea" v-model="companyTwoAddContent.honorEvent" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片：">
          <el-upload
            ref="AddBtnImg"
            class="upload-demo"
            action="#"
            :multiple="false"
            :auto-upload="false"
            :limit="1"
            accept="image/jpeg,image/png,image/jpg"
            list-type="picture"
            :on-exceed="handleExceed"
            :on-change="companyTwoChange"
            :on-remove="handleRemove"
          >
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
        </el-form-item>
        <el-form-item label="描述：" prop="honorDesc">
          <el-input  type="textarea" v-model="companyTwoAddContent.honorDesc" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="companyTwoBtnTitle">保存</el-button>
      </div>
    </el-dialog>
    <!-- 公司文化--收购兼并历程--编辑 -->
    <el-dialog
      :visible.sync="companyTwoEdit"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">编辑</div>
      <br/>
      <el-form :model="companyTwoAddContent" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="事件：" prop="honorEvent">
          <el-input  type="textarea" v-model="companyTwoAddContent.honorEvent" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片：">
          <el-upload
            ref="AddBtnImg"
            class="upload-demo"
            action="#"
            :multiple="false"
            :auto-upload="false"
            :limit="1"
            accept="image/jpeg,image/png,image/jpg"
            list-type="picture"
            :on-exceed="handleExceed"
            :on-change="companyTwoChange"
            :on-remove="handleRemove"
          >
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
          <img :src="imgUrlHost+imgRytUrl+companyTwoAddContent.honorImg" alt=""  class="avatar">
        </el-form-item>
        <el-form-item label="描述：" prop="honorDesc">
          <el-input  type="textarea" v-model="companyTwoAddContent.honorDesc" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="companyTwoBtnTitleEdit">保存</el-button>
      </div>
    </el-dialog>


    <!-- 人物长廊--新增 -->
    <el-dialog
      :visible.sync="leaderAdd"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">新增</div>
      <br/>
      <el-form :model="leaderAddContent" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="名称：" prop="honorName">
          <el-input v-model="leaderAddContent.honorName" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片：">
          <el-upload
            ref="AddBtnImg"
            class="upload-demo"
            action="#"
            :multiple="false"
            :auto-upload="false"
            :limit="1"
            accept="image/jpeg,image/png,image/jpg"
            list-type="picture"
            :on-exceed="handleExceed"
            :on-change="companyThreeChange"
            :on-remove="handleRemove"
          >
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
        </el-form-item>
        <el-form-item label="介绍：" prop="honorDesc">
          <el-input  type="textarea" v-model="leaderAddContent.honorDesc" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="companyThreeBtnTitle">保存</el-button>
      </div>
    </el-dialog>
    <!-- 人物长廊--编辑 -->
    <el-dialog
      :visible.sync="leaderEdit"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">编辑</div>
      <br/>
      <el-form :model="leaderAddContent" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="名称：" prop="honorName">
          <el-input v-model="leaderAddContent.honorName" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片：">
          <el-upload
            ref="AddBtnImg"
            class="upload-demo"
            action="#"
            :multiple="false"
            :auto-upload="false"
            :limit="1"
            accept="image/jpeg,image/png,image/jpg"
            list-type="picture"
            :on-exceed="handleExceed"
            :on-change="companyThreeChange"
            :on-remove="handleRemove"
          >
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
          <img :src="imgUrlHost+imgRytUrl+leaderAddContent.honorImg" alt=""  class="avatar">
        </el-form-item>
        <el-form-item label="介绍：" prop="honorDesc">
          <el-input  type="textarea" v-model="leaderAddContent.honorDesc" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="companyThreeBtnTitleEdit">保存</el-button>
      </div>
    </el-dialog>
    <!-- 荣耀墙新增 -->
    <el-dialog
      :visible.sync="hoursImgBtn"
      width="444px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">新增</div>
      <br/>
      <el-form :model="hoursImageUrl" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="图片：" class="editorXin">
          <el-upload
            class="avatar-uploader"
            action="#"
            :show-file-list="false"
            :multiple="false"
            :auto-upload="false"
            accept="image/jpeg,image/png,image/jpg"
            :on-change="hoursUpload">
            <img v-if="hoursImageUrl.honorImg" :src="imgUrlHost+imgRytUrl+hoursImageUrl.honorImg" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="hoursAddBtnContent">确定</el-button>
        <el-button @click="hoursImgBtn = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 荣耀墙编辑 -->
    <el-dialog
      :visible.sync="hoursImgBtnEdit"
      width="444px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">编辑</div>
      <br/>
      <el-form :model="hoursImageUrl" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="图片：" class="editorXin">
          <el-upload
            class="avatar-uploader"
            action="#"
            :show-file-list="false"
            :multiple="false"
            :auto-upload="false"
            accept="image/jpeg,image/png,image/jpg"
            :on-change="hoursUpload">
            <img v-if="hoursImageUrl.honorImg" :src="imgUrlHost+imgRytUrl+hoursImageUrl.honorImg" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="hoursEditBtnContent">确定</el-button>
        <el-button @click="hoursImgBtnEdit = false">取消</el-button>
      </div>
    </el-dialog>
    <!--删除弹框-->
    <el-dialog :visible.sync="dialogDelete" width="444px" class="hurdleAll" :before-close="handleClose">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicDel.png" alt="">
        删除
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要删除此专题吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitFormDeleteTwo">确定</el-button>
        <el-button @click="dialogDelete = false">取消</el-button>
      </div>
    </el-dialog>

    <!--  广发上市or荣耀墙--查看 -->
    <el-dialog
      :visible.sync="hoursImgBtnShow"
      width="444px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">查看</div>
      <br/>
      <el-form :model="hoursImageUrl" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="图片：" class="editorXin">
          <!--<el-upload-->
            <!--class="avatar-uploader"-->
            <!--action="#"-->
            <!--:show-file-list="false"-->
            <!--:multiple="false"-->
            <!--:auto-upload="false"-->
            <!--accept="image/jpeg,image/png,image/jpg"-->
            <!--:on-change="hoursUpload">-->
            <!--<i v-else class="el-icon-plus avatar-uploader-icon"></i>-->
          <!--</el-upload>-->
          <img v-if="hoursImageUrl.itemImg" :src="imgUrlHost+imgRytUrl+hoursImageUrl.itemImg" class="avatar">
          <img v-else-if="hoursImageUrl.honorImg" :src="imgUrlHost+imgRytUrl+hoursImageUrl.honorImg" class="avatar">
        </el-form-item>
      </el-form>
      <br/>
    </el-dialog>
    <!-- 电视墙--视频--查看 -->
    <el-dialog
      :visible.sync="hoursImgBtnShowVideo"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">
        <!--<img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">-->
        查看
      </div>
      <br/>
      <el-form :model="videoAddParams" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="名称：" prop="itemName">
          <el-input v-model="videoAddParams.itemName" placeholder="请输入名称" style="width: 70%;"></el-input>
        </el-form-item>
        <el-form-item label="封面：" class="editorXin">
          <img :src="imgUrlHost+imgRytUrl+videoAddParams.itemImg" class="avatar">
        </el-form-item>
        <el-form-item label="视频：" class="editorXin">
          <video  v-if="videoAddParams.itemFlv" width="320" height="240" controls>
            <source :src="imgUrlHost+imgRytUrl+videoAddParams.itemFlv" type="video/mp4">
          </video>
        </el-form-item>
      </el-form>
      <br>
    </el-dialog>
    <!-- 社会责任--查看 -->
    <el-dialog
      :visible.sync="hoursImgBtnShowDuty"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">查看</div>
      <br/>
      <el-form :model="responsAddParams" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="事件：" prop="itemTitle">
          <el-input v-model="responsAddParams.itemTitle" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片1：">
          <!--<el-upload-->
            <!--class="avatar-uploader"-->
            <!--action="#"-->
            <!--:show-file-list="false"-->
            <!--:multiple="false"-->
            <!--:auto-upload="false"-->
            <!--accept="image/jpeg,image/png,image/jpg"-->
            <!--:on-change="hoursUploadVideoTwoAddOne">-->
            <!--<i v-else class="el-icon-plus avatar-uploader-icon"></i>-->
          <!--</el-upload>-->
          <img v-if="responsAddParams.itemImg" :src="imgUrlHost+imgRytUrl+responsAddParams.itemImg" class="avatar">
        </el-form-item>
        <el-form-item label="介绍1：" prop="itemDesc">
          <el-input  type="textarea" v-model="responsAddParams.itemDesc" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片2：">
          <el-upload
            class="avatar-uploader"
            action="#"
            :show-file-list="false"
            :multiple="false"
            :auto-upload="false"
            accept="image/jpeg,image/png,image/jpg"
            :on-change="hoursUploadVideoTwoAdd">
            <img v-if="responsAddParams.itemImg1" :src="imgUrlHost+imgRytUrl+ responsAddParams.itemImg1" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon"></i>
          </el-upload>
        </el-form-item>
        <el-form-item label="介绍2：" prop="itemDesc1">
          <el-input  type="textarea" v-model="responsAddParams.itemDesc1" style="width: 50%;"></el-input>
        </el-form-item>
        <!--<el-form-item style="text-align: center;" class="dialog-footer all-btn">-->
          <!--<el-button type="primary" @click="hoursAddBtnContentRespons">确定</el-button>-->
          <!--<el-button @click="responsVideoBtn = false">取消</el-button>-->
        <!--</el-form-item>-->
      </el-form>
      <br>
    </el-dialog>
    <!-- 人物长廊--查看 -->
    <el-dialog
      :visible.sync="hoursImgBtnShowUser"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">查看</div>
      <br/>
      <el-form :model="leaderAddContent" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="名称：" prop="honorName">
          <el-input v-model="leaderAddContent.honorName" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片：">
          <img :src="imgUrlHost+imgRytUrl+leaderAddContent.honorImg" class="avatar">
        </el-form-item>
        <el-form-item label="介绍：" prop="honorDesc">
          <el-input  type="textarea" v-model="leaderAddContent.honorDesc" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <br>
    </el-dialog>
    <!-- 公司文化--发展历程--查看 -->
    <el-dialog
      :visible.sync="hoursImgBtnShowDevelop"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">查看</div>
      <br/>
      <el-form :model="companyOneAddContent" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="时间：" prop="honorTime">
          <!--<el-date-picker-->
            <!--v-model="companyOneAddContent.honorTime"-->
            <!--type="date"-->
            <!--format="yyyy 年 MM 月 dd 日"-->
            <!--value-format="yyyy-MM-dd"-->
            <!--placeholder="选择时间">-->
          <!--</el-date-picker>-->
          <el-input  type="text" v-model="companyOneAddContent.honorTime" style="width: 50%;" readonly></el-input>
        </el-form-item>
        <el-form-item label="事件：" prop="honorEvent">
          <el-input  type="textarea" v-model="companyOneAddContent.honorEvent" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片：">
          <img :src="imgUrlHost+imgRytUrl+companyOneAddContent.honorImg" class="avatar">
        </el-form-item>
        <el-form-item label="描述：" prop="honorDesc">
          <el-input  type="textarea" v-model="companyOneAddContent.honorDesc" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <!--<div slot="footer" class="dialog-footer all-btn">-->
        <!--<el-button type="primary" @click="companyOneBtnTitle">保存</el-button>-->
      <!--</div>-->
      <br>
    </el-dialog>
    <!-- 公司文化--收购兼并历程--查看 -->
    <el-dialog
      :visible.sync="hoursImgBtnShowReap"
      width="600px"
      class="give give-title"
      :before-close="handleCloseTwo">
      <div slot="title" class="titl">查看</div>
      <br/>
      <el-form :model="companyTwoAddContent" :rules="rulesAudit" ref="ruleFormAddCenterContent" label-width="120px" class="demo-ruleForm">
        <el-form-item label="事件：" prop="honorEvent">
          <el-input  type="textarea" v-model="companyTwoAddContent.honorEvent" style="width: 50%;"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="图片：">
          <img :src="imgUrlHost+imgRytUrl+companyTwoAddContent.honorImg" class="avatar">
        </el-form-item>
        <el-form-item label="描述：" prop="honorDesc">
          <el-input  type="textarea" v-model="companyTwoAddContent.honorDesc" style="width: 50%;"></el-input>
        </el-form-item>
      </el-form>
      <br>
      <!--<div slot="footer" class="dialog-footer all-btn">-->
        <!--<el-button type="primary" @click="companyTwoBtnTitle">保存</el-button>-->
      <!--</div>-->
    </el-dialog>
  </div>
</template>

<script>
import { saveZtzt, saveZtztItem, ztListItems, ztGetZtztTitle, ztEditZtzt, ztEditItem,
  ztTitleDelete, honorRoomList, honorAddVWItem, honorAddHr, honorEditHr, honorEditVWItem,
  honorDeleteOnce} from '@/js/getData.js'
import { uploadPicture, honorUploadPicture, honorAddVideoVWItem } from '../../js/uploadImg'
import axios from 'axios'
import { DEV_HOST } from '@/js/http.js'
export default {
  name: 'zt',
  data () {
    return {
      imgZtUrl: '/gdda-new/res/images/ztztImgs/',
      imgRytUrl: '/gdda-new/res/images/rysImgs/',
      hoursImgBtnShowReap: false,
      hoursImgBtnShowDevelop: false,
      hoursImgBtnShowUser: false,
      hoursImgBtnShowDuty: false,
      hoursImgBtnShowVideo: false,
      hoursImgBtnShow: false,
      dialogDelete: false,
      imgUrlHost: DEV_HOST,
      // 展厅新增弹框
      hallVisibleAdd: false,
      // 左侧栏table
      leftTitleTable: [],
      leftTopTable: [],
      leftRightTable: [],
      // 中央栏table
      centerTitleTable: [],
      centerTopTable: [],
      centerRightTable: [],
      // 右侧栏table
      rightTitleTable: [],
      rightTopTable: [],
      rightRightTable: [],
      // 展厅--栏标题
      paramsAddTitle: {},
      // 展厅--上栏内容
      paramsAddTopContent: {},
      // 展厅--下栏内容
      paramsAddBottomContent: {},
      // 图片上传之后返回的接收参数
      fileList: '', // 上传图片之后的名字（左上）
      fileListRight: '', // 上传图片之后的名字（左下）
      fileListCenter: '', // 上传图片之后的名字（中上）
      fileListCenterRight: '', // 上传图片之后的名字（中下）
      fileListRightRight: '', // 上传图片之后的名字（右上）
      fileListRightRightTwo: '', // 上传图片之后的名字（右下）
      // 左标题
      leftTitleParams: {type: 'historys', page: 1, rows: 6},
      hallVisibleTitle: false,
      // 中标题
      centerTitleParams: {type: 'historys3', page: 1, rows: 6},
      hallVisibleCenterTitle: false,
      // 右标题
      rightTitleParams: {type: 'historys2', page: 1, rows: 6},
      hallVisibleRightTitle: false,
      // 左上
      leftTopParams: {type: 'historys', page: 1, rows: 6},
      hallVisibleContent: false,
      // 左下
      leftRightParams: {type: 'mergers', page: 1, rows: 6},
      hallVisibleBottom: false,
      // 中上
      centerTopParams: {type: 'historys3', page: 1, rows: 6},
      hallVisibleCenterContent: false,
      // 中下
      centerRightParams: {type: 'mergers3', page: 1, rows: 6},
      hallVisibleCenterBottom: false,
      // 右上
      rightTopParams: {type: 'historys2', page: 1, rows: 6},
      hallVisibleRightContent: false,
      // 右下
      rightRightParams: {type: 'mergers2', page: 1, rows: 6},
      hallVisibleRightBottom: false,
      /**/
      carouseImg: [
        { id: 1, valImg: require('../../assets/home/zhanting.jpg'), title: '展厅' },
        { id: 2, valImg: require('../../assets/home/dashiji.png'), title: '大事记' },
        { id: 3, valImg: require('../../assets/home/rongyushi.png'), title: '荣誉室' }
      ],
      rulesAudit: {
        title: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        event: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        time: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        desc: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        itemTitle: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        itemDesc: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        itemDesc1: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        itemName: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        honorTime: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        honorEvent: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        honorDesc: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        honorName: [{ required: true, message: '请注意填写', trigger: 'blur'}],
      },
      rulesAuditTop: {
        event: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        time: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        desc: [{ required: true, message: '请注意填写', trigger: 'blur'}]
      },
      rulesAuditBottom: {
        event: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        time: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        desc: [{ required: true, message: '请注意填写', trigger: 'blur'}]
      },
      // 被选中的数据
      onceTable: [],
      // 展厅-标题编辑
      editTitleContent: false,
      paramsEditTitle: {},
      // 展厅-上栏编辑 下栏编辑
      editCenterContent: false,
      editCenterContentTwo: false, // 下栏编辑
      paramsEditContent: {},
      // 展厅-删除
      deleteTitleContent: false,

      /* --------荣耀室-------- */
      honourAdd: false,
      gfssParams: {type: 'gfss', page: 1, rows: 6}, // 广发上市
      gfssTable: [], // 广发上市
      leaderParams: {type: 'leader', page: 1, rows: 6}, // 人物长廊
      leaderTable: [], // 人物长廊
      historyParams: {type: 'history', page: 1, rows: 6}, // 历史
      historyTable: [], // 历史
      mergeParams: {type: 'merger', page: 1, rows: 6}, // 收购历史
      mergeTable: [], // 收购历史
      honourParams: {type: 'honor', page: 1, rows: 6}, // 荣誉墙
      honourTable: [], // 荣誉墙
      responsibilityParams: {type: 'responsibility', page: 1, rows: 6}, // 社会责任
      responsibilityTable: [], // 社会责任
      videoParams: {type: 'video', page: 1, rows: 6}, // 电视墙
      videoTable: [], // 电视墙
      // 上传图片
      hoursImgBtn: false,
      hoursImageUrl: {
        // type: null,
        // name: null,
        // picture: null,
        honorImg: null,
        itemImg: null
      },
      // 编辑
      hoursImgBtnEdit: false,
      // 电视墙
      hoursGffssBtn: false,
      // 广发上市
      hoursGffssBtnEdit: false,
      // 视频
      hoursVideoBtn: false,
      hoursVideoBtnEdit: false,
      videoAddParams: {
        itemType: 'video',
        type: 'videowall',
        itemImg: null,
        itemFlv: null
      },

      // 社会责任
      responsVideoBtn: false,
      responsVideoBtnEdit: false,
      responsAddParams: {
        itemType: 'responsibility',
        type: 'videowall',
        itemImg: null,
        itemImgTwo: null
      },

      // 公司历程
      companyOne: false,
      companyOneEdit: false,
      companyOneAddContent: {
        type: 'history'
      },
      // 收获历程
      companyTwo: false,
      companyTwoEdit: false,
      companyTwoAddContent: {
        type: 'merger'
      },
      // 人物长廊
      leaderAdd: false,
      leaderEdit: false,
      leaderAddContent: {
        type: 'leader'
      },
      // 展厅--标题查看弹框
      titleLookDialog: false,
      // 展厅--上栏查看弹框
      topLookDialog: false,
      // 展厅--下栏查看弹框
      bottomLookDialog: false
    }
  },
  methods: {
    handleRemove (val) {
      this.paramsEditContent.img = null
      this.companyOneAddContent.honorImg = null
      this.companyTwoAddContent.honorImg = null
      this.leaderAddContent.honorImg = null
      this.videoAddParams.itemImg = null
    },
    /* 荣耀墙--广发之最 */
    showImgContent (index) {
      this.hoursImageUrl = {}
      this.hoursImageUrl = JSON.parse(JSON.stringify(index.row))
      this.hoursImgBtnShow = true
    },
    /* 视频 */
    showImgContentVideo (index) {
      this.videoAddParams = {}
      this.videoAddParams = JSON.parse(JSON.stringify(index.row))
      this.hoursImgBtnShowVideo = true
    },
    /* 社会责任 */
    showImgContentDuty (index) {
      this.responsAddParams = {}
      this.responsAddParams = JSON.parse(JSON.stringify(index.row))
      this.hoursImgBtnShowDuty = true
    },
    /* 人物长廊 */
    showImgContentUser (index) {
      this.leaderAddContent = {}
      this.leaderAddContent = JSON.parse(JSON.stringify(index.row))
      this.hoursImgBtnShowUser = true
    },
    /* 公司发展历程 */
    showImgContentDevelop (index) {
      this.companyOneAddContent = {}
      this.companyOneAddContent = JSON.parse(JSON.stringify(index.row))
      this.hoursImgBtnShowDevelop = true
    },
    /* 公司收购兼并历程 */
    showImgContentReap (index) {
      this.companyTwoAddContent = {}
      this.companyTwoAddContent = JSON.parse(JSON.stringify(index.row))
      this.hoursImgBtnShowReap = true
    },
    showTableContent (index) {
      this.paramsAddTitle = {}
      this.paramsAddTitle = JSON.parse(JSON.stringify(index.row))
      this.titleLookDialog = true
    },
    showTableContentTop (index) {
      this.paramsAddTopContent = {}
      this.paramsAddTopContent = JSON.parse(JSON.stringify(index.row))
      this.topLookDialog = true
    },
    showTableContentBottom (index) {
      this.paramsAddBottomContent = {}
      this.paramsAddBottomContent = JSON.parse(JSON.stringify(index.row))
      this.bottomLookDialog = true
    },
    handleClick (tab, event) {
      console.log(tab, event)
    },
    handleClickTwo () {
      this.showZtTitle()
      this.showZtContent()
      this.clearImgDel()
    },
    handleClickThree () {
      this.showZtTitle()
      this.showZtContent()
      this.clearImgDel()
    },
    handleSelectionChange (val) {
      this.onceTable = val
    },
    // 新增 标题
    leftTitleAdd (val, item) {
      if (val == 1) {
        this.hallVisibleTitle = true
        this.paramsAddTitle = {type: item}
        this.clearImgDel()
      } else if (val == 2) {
        this.hallVisibleTitle = true
        this.paramsAddTitle = {type: item}
        this.clearImgDel()
      } else if (val == 3) {
        this.hallVisibleTitle = true
        this.paramsAddTitle = {type: item}
        this.clearImgDel()
      }
      this.clearImgDel()
    },
    // 新增 上栏内容
    leftTitleAddContent (val, item) {
      if (val == 11) {
        this.hallVisibleContent = true
        this.paramsAddTopContent = {type: item}
        this.clearImgDel()
      } else if (val == 22) {
        this.hallVisibleContent = true
        this.paramsAddTopContent = {type: item}
        this.clearImgDel()
      } else if (val == 33) {
        this.hallVisibleContent = true
        this.paramsAddTopContent = {type: item}
        this.clearImgDel()
      } else if (val == 4) {
        this.companyOne = true
        this.companyOneAddContent = {type: 'history'}
        this.clearImgDel()
      }
      this.clearImgDel()
    },
    // 新增 下栏内容
    leftTitleAddContentTwo (val, item) {
      if (val == 111) {
        this.hallVisibleBottom = true
        this.paramsAddBottomContent = {type: item}
      } else if (val == 222) {
        this.hallVisibleBottom = true
        this.paramsAddBottomContent = {type: item}
      } else if (val == 333) {
        this.hallVisibleBottom = true
        this.paramsAddBottomContent = {type: item}
      } else if (val == 444) {
        this.companyTwo = true
        this.companyTwoAddContent = {
          type: 'merger'
        }
      }
      this.clearImgDel()
    },
    // 编辑 标题
    leftTitleEdit () {
      this.paramsEditTitle = []
      let item = this.selectLength()
      if (item == 1) {
        this.editTitleContent = true
        this.paramsEditTitle = JSON.parse(JSON.stringify(this.onceTable[0]))
        this.clearImgDel()
      }
    },
    // 编辑 上栏内容
    leftTitleEditContent () {
      this.paramsEditContent = []
      let item = this.selectLength()
      if (item == 1) {
        this.editCenterContent = true
        this.paramsEditContent = JSON.parse(JSON.stringify(this.onceTable[0]))
        this.fileList = this.paramsEditContent.img
        let item = this.paramsEditContent.time.split('年')
        if (item.length >= 2) {
          let itemHours = item[1].split('月')
          let itemData = itemHours[1].split('日')
          let itemOnce = `${item[0]}-${itemHours[0]}-${itemData[0]}`
          this.paramsEditContent.time = JSON.parse(JSON.stringify(itemOnce))
        }
        this.clearImgDel()
      }
    },
    // 编辑 下栏内容
    leftTitleEditContentTwo () {
      this.paramsEditContent = []
      let item = this.selectLength()
      if (item == 1) {
        this.editCenterContentTwo = true
        this.paramsEditContent = JSON.parse(JSON.stringify(this.onceTable[0]))
        this.fileList = this.paramsEditContent.img
        this.clearImgDel()
      }
    },
    // 轮播图新增弹框
    showAddContent (val) {
      if (val == 1) {
        this.hallVisibleAdd = true
        this.showZtContent()
        this.showZtTitle()
      } else if (val == 2) {
        console.log('新增的，不知道是啥，meizuo')
      } else if (val == 3) {
        this.honourAdd = true
        this.showHonourTable()
      }
    },
    // 展厅--标题保存
    leftBtnTitle () {
      this.$refs['ruleFormAddCenterContent'].validate((valida) => {
        if (valida) {
          saveZtzt(this.paramsAddTitle).then(res => {
            if (res.code == 0) {
              this.$message.success('添加成功')
              this.paramsAddTitle = {}
              this.hallVisibleTitle = false
              this.showZtTitle()
            } else {
              this.$message.error('添加失败')
            }
          })
        }
      })
    },
    // 展厅--上栏保存
    centerTopBtnTitle () {
      this.$refs['ruleFormAddCenterContentTop'].validate((valida) => {
        if (valida) {
          if (this.fileList) {
            this.paramsAddTopContent.img = this.fileList
            saveZtztItem(this.paramsAddTopContent).then(res => {
              if (res.code == 0) {
                this.$message.success('添加成功')
                this.paramsAddTopContent = {}
                this.clearImgDel()
                this.fileList = ''
                this.hallVisibleContent = false
                this.showZtContent()
              } else {
                this.$message.error('添加失败')
              }
            })
          } else {
            this.$message.error('请选择图片')
          }
        }
      })
    },
    // 展厅--下栏保存
    rightLeftBtnTitle () {
      this.$refs['ruleFormAddCenterContentBottom'].validate((valida) => {
        if (valida) {
          if (this.fileList) {
            this.paramsAddBottomContent.img = this.fileList
            saveZtztItem(this.paramsAddBottomContent).then(res => {
              if (res.code == 0) {
                this.$message.success('添加成功')
                this.paramsAddBottomContent = {}
                this.showZtContent()
                this.fileList = ''
                this.clearImgDel()
                this.hallVisibleBottom = false
              } else {
                this.$message.error('添加失败')
              }
            })
          } else {
            this.$message.error('请选择图片')
          }
        }
      })
    },
    /* --------编辑------- */
    // 展厅--标题编辑保存
    leftBtnTitleEdit () {
      this.$refs['ruleFormAddCenterContent'].validate((valida) => {
        if (valida) {
          ztEditZtzt(this.paramsEditTitle).then(res => {
            if (res.code == 0) {
              this.$message.success('编辑成功')
              // this.leftLeftBtnTitleEdit = {type: 'left'}
              this.editTitleContent = false
              this.showZtTitle()
            } else {
              this.$message.error('编辑失败')
            }
          })
        }
      })
    },
    // 展厅--上栏编辑 下栏编辑
    centerBtnContent () {
      this.$refs['ruleFormAddCenterContent'].validate((valida) => {
        if (valida) {
          if (this.fileList) {
            this.paramsEditContent.img = this.fileList
            ztEditItem(this.paramsEditContent).then(res => {
              if (res.code == 0) {
                this.$message.success('编辑成功')
                this.fileList = ''
                this.editCenterContent = false
                this.editCenterContentTwo = false
                this.clearImgDel()
                this.showZtContent()
              } else {
                this.$message.error('添加失败')
              }
            })
          } else {
            this.$message.error('请选择图片')
          }
        }
      })
    },
    /* --------删除------- */
    titleDelete (val) {
      this.paramsEditTitle = []
      let item = this.selectLength()
      if (item == 1) {
        this.deleteTitleContent = true
        this.paramsEditTitle = JSON.parse(JSON.stringify(this.onceTable[0]))
        this.paramsEditTitle.val = val
      }
    },
    submitFormDelete () {
      let params = {
        id: this.paramsEditTitle.id,
        type: this.paramsEditTitle.type
      }
      ztTitleDelete(params).then(res => {
        if (res.code == 0) {
          this.$message.success('删除成功')
          this.deleteTitleContent = false
          this.showZtTitle()
          this.showZtContent()
        } else {
          this.$message.error('删除失败')
        }
      })
      // if (this.paramsEditTitle.val == 1) {
      // } else if (this.paramsEditTitle.val == 2) {
      //   console.log('上下栏内容')
      // }
    },
    /* 选择条目 */
    selectLength () {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.onceTable.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        return 1
      }
    },
    // 展厅--上栏下栏上传图片
    handleChange (file, fileList) {
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('type', 'history')
      formData.append('name', 'img')
      axios({
        url: uploadPicture,
        method: 'post',
        data: formData,
        header: {
          'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryifZvuMMCEDoSb64E'
        }
      }).then((res) => {
        this.fileList = res.data.data.path
        this.paramsEditContent.img = res.data.data.path
      })
    },
    // 文件超过1个时提示
    handleExceed (file, fileList) {
      this.$message.warning(`当前只能选择 1 个文件，本次已选择了 ${file.length} 个文件`)
    },
    /* 关闭弹框 */
    handleClose () {
      this.hallVisibleAdd = false
      this.honourAdd = false
    },
    // 新增 编辑关闭弹框
    handleCloseTwo () {
      this.hallVisibleTitle = false
      this.hallVisibleContent = false
      this.hallVisibleBottom = false
      this.editTitleContent = false
      this.editCenterContent = false
      this.editCenterContentTwo = false
      this.deleteTitleContent = false
      this.hoursImgBtn = false
      this.hoursGffssBtn = false
      this.hoursGffssBtnEdit = false
      this.hoursVideoBtn = false
      this.hoursVideoBtnEdit = false
      this.companyOneEdit = false
      this.companyOne = false
      this.responsVideoBtnEdit = false
      this.responsVideoBtn = false
      this.hoursImgBtnEdit = false
      this.companyTwo = false
      this.companyTwoEdit = false
      this.leaderAdd = false
      this.leaderEdit = false
      this.titleLookDialog = false
      this.topLookDialog = false
      this.bottomLookDialog = false
      this.hoursImgBtnShow = false
      this.hoursImgBtnShowVideo = false
      this.hoursImgBtnShowDuty = false
      this.hoursImgBtnShowUser = false
      this.hoursImgBtnShowDevelop = false
      this.hoursImgBtnShowReap = false
    },
    /* 展厅标题展示 */
    showZtTitle () {
      this.onceTable = []
      // 左标题
      ztGetZtztTitle(this.leftTitleParams).then(res => {
        this.leftTitleTable = res.data.rows
        this.leftTitleParams.total = res.data.total
      })
      // 中标题
      ztGetZtztTitle(this.centerTitleParams).then(res => {
        this.centerTitleTable = res.data.rows
        this.centerTitleParams.total = res.data.total
      })
      // 右标题
      ztGetZtztTitle(this.rightTitleParams).then(res => {
        this.rightTitleTable = res.data.rows
        this.rightTitleParams.total = res.data.total
      })
    },
    /* 展厅内容展示 */
    showZtContent () {
      this.onceTable = []
      // 左上
      ztListItems(this.leftTopParams).then(res => {
        this.leftTopTable = res.data.rows
        this.leftTopParams.total = res.data.total
      })
      // 左下
      ztListItems(this.leftRightParams).then(res => {
        this.leftRightTable = res.data.rows
        this.leftRightParams.total = res.data.total
      })
      // 中上
      ztListItems(this.centerTopParams).then(res => {
        this.centerTopTable = res.data.rows
        this.centerTopParams.total = res.data.total
      })
      // 中下 this.paramsAddCenterRightContent
      ztListItems(this.centerRightParams).then(res => {
        this.centerRightTable = res.data.rows
        this.centerRightParams.total = res.data.total
      })
      // 右上
      ztListItems(this.rightTopParams).then(res => {
        this.rightTopTable = res.data.rows
        this.rightTopParams.total = res.data.total
      })
      ztListItems(this.rightRightParams).then(res => {
        this.rightRightTable = res.data.rows
        this.rightRightParams.total = res.data.total
      })
    },
    /* 左上分页 */
    handleLeftTop (val) {
      this.leftTopParams.page = val
      this.showZtContent()
    },
    /* 左下分页 */
    handleLeftRight (val) {
      this.leftRightParams.page = val
      this.showZtContent()
    },
    /* 中上分页 */
    handleCenterTop (val) {
      this.centerTopParams.page = val
      this.showZtContent()
    },
    /* 中下分页 */
    handleCenterRight (val) {
      this.centerRightParams.page = val
      this.showZtContent()
    },
    /* 右上分页 */
    handleRightTop (val) {
      this.rightTopParams.page = val
      this.showZtContent()
    },
    /* 右下分页 */
    handleRightRight (val) {
      this.rightRightParams.page = val
      this.showZtContent()
    },
    /* 左标题 */
    handleLeftTitle (val) {
      this.leftTitleParams.page = val
      this.showZtTitle()
    },
    /* 中标题 */
    handleCenterTitle (val) {
      this.centerTitleParams.page = val
      this.showZtTitle()
    },
    /* 右标题 */
    handleRightTitle (val) {
      this.rightTitleParams.page = val
      this.showZtTitle()
    },

    /* --------荣誉室--------- */
    showHonourTable () {
      // 广发上市
      honorRoomList(this.gfssParams).then(res => {
        this.gfssTable = res.data.rows
        this.gfssParams.total = res.data.total
      })
      // 电视墙--视频
      honorRoomList(this.videoParams).then(res => {
        this.videoTable = res.data.rows
        this.videoParams.total = res.data.total
      })
      // 电视墙--社会责任
      honorRoomList(this.responsibilityParams).then(res => {
        this.responsibilityTable = res.data.rows
        this.responsibilityParams.total = res.data.total
      })
      // 公司文化--历史
      honorRoomList(this.historyParams).then(res => {
        this.historyTable = res.data.rows
        this.historyParams.total = res.data.total
      })
      // 公司文化--收获历史
      honorRoomList(this.mergeParams).then(res => {
        this.mergeTable = res.data.rows
        this.mergeParams.total = res.data.total
      })
      // 荣誉墙
      honorRoomList(this.honourParams).then(res => {
        this.honourTable = res.data.rows
        this.honourParams.total = res.data.total
      })
      // 人物长廊
      honorRoomList(this.leaderParams).then(res => {
        this.leaderTable = res.data.rows
        this.leaderParams.total = res.data.total
      })

    },
    // 图片新增弹框
    hoursAddBtn (val, item, itemVal) {
      if (val == 'gfss') {
        this.hoursGffssBtn = true
        this.hoursImageUrl = {
          itemType: val,
          type: itemVal,
          name: item,
          itemImg: null
        }
      } else if (val == 'honor') {
        this.hoursImgBtn = true
        this.hoursImageUrl = {
          type: val,
          name: item,
          honorImg: null
        }
      } else if (val == 'leader') {
        this.leaderAdd = true
        this.leaderAddContent = {
          type: val,
          honorImg: null
        }
      }
      this.clearImgDel()
    },
    // 广发图片上传
    hoursUploadGffss (val) {
      let formData = new FormData()
      formData.append('picture', val.raw)
      formData.append('type', this.hoursImageUrl.type)
      formData.append('name', this.hoursImageUrl.name)
      axios({
        url: honorUploadPicture,
        method: 'post',
        data: formData,
        header: {
          'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryifZvuMMCEDoSb64E'
        }
      }).then((res) => {
        this.hoursImageUrl.itemImg = res.data.data.path
      })
    },
    // 视频--图片上传
    hoursUploadVideo (val) {
      let formData = new FormData()
      formData.append('picture', val.raw)
      formData.append('type', 'video')
      formData.append('name', 'img')
      axios({
        url: honorUploadPicture,
        method: 'post',
        data: formData,
        header: {
          'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryifZvuMMCEDoSb64E'
        }
      }).then((res) => {
        this.videoAddParams.itemImg = res.data.data.path
      })
    },
    // 视频中的视频上传
    hoursUploadVideoTwo (val) {
      let formData = new FormData()
      formData.append('video', val.raw)
      formData.append('type', 'video')
      formData.append('name', 'flv')
      axios({
        url: honorAddVideoVWItem,
        method: 'post',
        data: formData,
        header: {
          'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryifZvuMMCEDoSb64E'
        }
      }).then((res) => {
        this.videoAddParams.itemFlv = res.data.data.path
      })
    },
    // 社会责任--图片二
    hoursUploadVideoTwoAdd (val) {
      let formData = new FormData()
      formData.append('picture', val.raw)
      formData.append('type', 'video')
      formData.append('name', 'img')
      axios({
        url: honorUploadPicture,
        method: 'post',
        data: formData,
        header: {
          'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryifZvuMMCEDoSb64E'
        }
      }).then((res) => {
        this.responsAddParams.itemImg1 = res.data.data.path
      })
    },
    // 社会责任--图片一
    hoursUploadVideoTwoAddOne (val) {
      let formData = new FormData()
      formData.append('picture', val.raw)
      formData.append('type', 'video')
      formData.append('name', 'img')
      axios({
        url: honorUploadPicture,
        method: 'post',
        data: formData,
        header: {
          'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryifZvuMMCEDoSb64E'
        }
      }).then((res) => {
        this.responsAddParams.itemImg = res.data.data.path
      })
    },
    // 电视墙--广发上市新增
    hoursAddBtnContentGffss () {
      if (this.hoursImageUrl.itemImg == null) {
        this.$message.error('请选择图片')
      } else {
        honorAddVWItem(this.hoursImageUrl).then(res => {
          if (res.code == 0) {
            this.$message.success('添加完成')
            this.hoursGffssBtn = false
            this.showHonourTable()
          } else {
            this.$message.error('添加失败')
          }
        })
      }
    },
    // 广发上市编辑
    hoursEditBtnGffss () {
      let item = this.selectLength()
      if (item == 1) {
        this.hoursImageUrl = []
        this.clearImgDel()
        this.hoursGffssBtnEdit = true
        this.hoursImageUrl = JSON.parse(JSON.stringify(this.onceTable[0]))
      }
    },
    hoursEditBtnContentGffss () {
      honorEditVWItem(this.hoursImageUrl).then(res => {
        if (res.code == 0) {
          this.$message.success('编辑完成')
          this.hoursGffssBtnEdit = false
          this.showHonourTable()
        } else {
          this.$message.error('编辑失败')
        }
      })
    },

    // 电视墙--视频新增
    videoAddBtn () {
      this.videoAddParams = {
        itemType: 'video',
        type: 'videowall',
        itemImg: null,
        itemFlv: null
      }
      this.hoursVideoBtn = true
      this.clearImgDel()
    },
    // 电视墙--视频新增
    hoursAddBtnContentVideo () {
      this.$refs['ruleFormAddCenterContent'].validate((valida) => {
        if (valida) {
          if (this.videoAddParams.itemImg == null) {
            this.$message.error('请选择图片')
          } else if (this.videoAddParams.itemFlv == null) {
            this.$message.error('请选择视频')
          } else {
            honorAddVWItem(this.videoAddParams).then(res => {
              if (res.code == 0) {
                this.$message.success('添加完成')
                this.hoursVideoBtn = false
                this.showHonourTable()
              } else {
                this.$message.error('添加失败')
              }
            })
          }
        }
      })
    },
    // 电视墙--社会责任
    hoursAddBtnContentRespons () {
      this.$refs['ruleFormAddCenterContent'].validate((valida) => {
        if (valida) {
          if (this.responsAddParams.itemImg == null) {
            this.$message.error('请选择图片')
          } else if (this.responsAddParams.itemImg1 == null) {
            this.$message.error('请选择图片')
          } else {
            honorAddVWItem(this.responsAddParams).then(res => {
              if (res.code == 0) {
                this.$message.success('添加完成')
                this.responsVideoBtn = false
                this.showHonourTable()
              } else {
                this.$message.error('添加失败')
              }
            })
          }
        }
      })
    },
    // 电视墙--视频编辑
    videoAddBtnGffss () {
      this.videoAddParams = []
      let item = this.selectLength()
      if (item == 1) {
        this.hoursVideoBtnEdit = true
        this.videoAddParams = JSON.parse(JSON.stringify(this.onceTable[0]))
        this.clearImgDel()
      }
    },
    hoursEditBtnContentVideo () {
      this.$refs['ruleFormAddCenterContent'].validate((valida) => {
        if (valida) {
          honorEditVWItem(this.videoAddParams).then(res => {
            if (res.code == 0) {
              this.$message.success('编辑完成')
              this.hoursVideoBtnEdit = false
              this.showHonourTable()
            } else {
              this.$message.error('编辑失败')
            }
          })
        }
      })
    },
    // 社会责任--新增
    responsAddBtn () {
      this.responsAddParams = {
        itemType: 'responsibility',
        type: 'videowall',
        itemImg: null,
        itemImg1: null
      }
      this.responsVideoBtn = true
    },
    // 社会责任--编辑
    hoursEditBtnRespons () {
      this.hoursImageUrl = []
      let item = this.selectLength()
      if (item == 1) {
        this.responsVideoBtnEdit = true
        this.responsAddParams = JSON.parse(JSON.stringify(this.onceTable[0]))
        this.clearImgDel()
      }
    },
    hoursEditBtnContentRespons () {
      honorEditVWItem(this.responsAddParams).then(res => {
        if (res.code == 0) {
          this.$message.success('编辑完成')
          this.responsVideoBtnEdit = false
          this.showHonourTable()
        } else {
          this.$message.error('编辑失败')
        }
      })
    },
    // 公司文化--发展历程上传图片
    companyOneChange (file, fileList) {
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('type', 'history')
      formData.append('name', 'img')
      axios({
        url: uploadPicture,
        method: 'post',
        data: formData,
        header: {
          'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryifZvuMMCEDoSb64E'
        }
      }).then((res) => {
        this.companyOneAddContent.honorImg = res.data.data.path
      })
    },
    companyTwoChange (file, fileList) {
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('type', 'merger')
      formData.append('name', 'img')
      axios({
        url: uploadPicture,
        method: 'post',
        data: formData,
        header: {
          'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryifZvuMMCEDoSb64E'
        }
      }).then((res) => {
        this.companyTwoAddContent.honorImg = res.data.data.path
      })
    },
    companyThreeChange (file, fileList) {
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('type', 'leader')
      formData.append('name', 'img')
      axios({
        url: uploadPicture,
        method: 'post',
        data: formData,
        header: {
          'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryifZvuMMCEDoSb64E'
        }
      }).then((res) => {
        this.leaderAddContent.honorImg = res.data.data.path
      })
    },
    // 公司文化--保存
    companyOneBtnTitle () {
      console.log(this.companyOneAddContent);
      this.$refs['ruleFormAddCenterContent'].validate((valida) => {
        if (valida) {
          if (this.companyOneAddContent.honorImg == null || this.companyOneAddContent.honorImg == '') {
            // this.paramsAddTopContent.img = this.fileList
            this.$message.error('请选择图片')
          } else {
            honorAddHr(this.companyOneAddContent).then(res => {
              if (res.code == 0) {
                this.$message.success('添加成功')
                this.companyOne = false
                this.showZtContent()
              } else {
                this.$message.error('添加失败')
              }
            })
          }
        }
      })
    },
    // 历程--编辑
    companyOneEditBtn () {
      this.companyOneAddContent = []
      let item = this.selectLength()
      if (item == 1) {
        this.clearImgDel()
        this.companyOneEdit = true
        this.companyOneAddContent = JSON.parse(JSON.stringify(this.onceTable[0]))
        console.log(this.companyOneAddContent);
        let item = this.companyOneAddContent.honorTime.split('年')
        if (item.length >= 2) {
          let itemHours = item[1].split('月')
          let itemData = itemHours[1].split('日')
          let itemOnce = `${item[0]}-${itemHours[0]}-${itemData[0]}`
          this.companyOneAddContent.honorTime = JSON.parse(JSON.stringify(itemOnce))
        }
      }
    },
    // 公司文化--历程编辑
    companyOneBtnTitleEdit () {
      this.$refs['ruleFormAddCenterContent'].validate((valida) => {
        if (valida) {
          if (this.companyOneAddContent.honorImg) {
            // this.paramsAddTopContent.img = this.fileList
            honorEditHr(this.companyOneAddContent).then(res => {
              if (res.code == 0) {
                this.$message.success('编辑成功')
                this.companyOneEdit = false
                this.showHonourTable()
              } else {
                this.$message.error('编辑失败')
              }
            })
          } else {
            this.$message.error('请选择图片')
          }
        }
      })
    },
    // 公司文化--历史历程保存
    companyTwoBtnTitle () {
      this.$refs['ruleFormAddCenterContent'].validate((valida) => {
        if (valida) {
          if (this.companyTwoAddContent.honorImg) {
            // this.paramsAddTopContent.img = this.fileList
            honorAddHr(this.companyTwoAddContent).then(res => {
              if (res.code == 0) {
                this.$message.success('添加成功')
                this.companyTwo = false
                this.showHonourTable()
              } else {
                this.$message.error('添加失败')
              }
            })
          } else {
            this.$message.error('请选择图片')
          }
        }
      })
    },
    // 历史历程--编辑
    companyTwoEditBtn () {
      this.companyTwoAddContent = []
      let item = this.selectLength()
      if (item == 1) {
        this.clearImgDel()
        this.companyTwoEdit = true
        this.companyTwoAddContent = JSON.parse(JSON.stringify(this.onceTable[0]))
      }
    },
    // 公司文化--历史历程编辑
    companyTwoBtnTitleEdit () {
      this.$refs['ruleFormAddCenterContent'].validate((valida) => {
        if (valida) {
          if (this.companyTwoAddContent.honorImg) {
            // this.paramsAddTopContent.img = this.fileList
            honorEditHr(this.companyTwoAddContent).then(res => {
              if (res.code == 0) {
                this.$message.success('添加成功')
                this.companyTwoEdit = false
                this.showHonourTable()
              } else {
                this.$message.error('添加失败')
              }
            })
          } else {
            this.$message.error('请选择图片')
          }
        }
      })
    },

    // 人物长廊
    companyThreeBtnTitle () {
      this.$refs['ruleFormAddCenterContent'].validate((valida) => {
        if (valida) {
          if (this.leaderAddContent.honorImg) {
            honorAddHr(this.leaderAddContent).then(res => {
              if (res.code == 0) {
                this.$message.success('添加成功')
                this.leaderAdd = false
                this.showHonourTable()
              } else {
                this.$message.error('添加失败')
              }
            })
          } else {
            this.$message.error('请选择图片')
          }
        }
      })
    },
    // 人物长廊--编辑
    leaderEditBtn () {
      this.leaderAddContent = {}
      let item = this.selectLength()
      if (item == 1) {
        this.leaderEdit = true
        this.leaderAddContent = JSON.parse(JSON.stringify(this.onceTable[0]))
        this.clearImgDel()
      }
    },
    // 人物长廊--编辑
    companyThreeBtnTitleEdit () {
      this.$refs['ruleFormAddCenterContent'].validate((valida) => {
        if (valida) {
          if (this.leaderAddContent.honorImg) {
            // this.paramsAddTopContent.img = this.fileList
            honorEditHr(this.leaderAddContent).then(res => {
              if (res.code == 0) {
                this.$message.success('添加成功')
                this.leaderEdit = false
                this.showHonourTable()
              } else {
                this.$message.error('添加失败')
              }
            })
          } else {
            this.$message.error('请选择图片')
          }
        }
      })
    },
    // 荣耀墙图片上传
    hoursUpload (val) {
      let formData = new FormData()
      formData.append('picture', val.raw)
      formData.append('type', this.hoursImageUrl.type)
      formData.append('name', this.hoursImageUrl.name)
      axios({
        url: honorUploadPicture,
        method: 'post',
        data: formData,
        header: {
          'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryifZvuMMCEDoSb64E'
        }
      }).then((res) => {
        this.hoursImageUrl.honorImg = res.data.data.path
      })
    },
    // 荣誉墙新增
    hoursAddBtnContent () {
      if (this.hoursImageUrl.honorImg == null) {
        this.$message.error('请选择图片')
      } else {
        this.clearImgDel()
        honorAddHr(this.hoursImageUrl).then(res => {
          if (res.code == 0) {
            this.$message.success('添加完成')
            this.hoursImgBtn = false
            this.showHonourTable()
          } else {
            this.$message.error('添加失败')
          }
        })
      }
    },
    // 荣誉墙编辑
    hoursEditBtn () {
      this.hoursImageUrl = []
      let item = this.selectLength()
      if (item == 1) {
        this.hoursImgBtnEdit = true
        this.hoursImageUrl = JSON.parse(JSON.stringify(this.onceTable[0]))
        this.clearImgDel()
      }
    },
    hoursEditBtnContent () {
      honorEditHr(this.hoursImageUrl).then(res => {
        if (res.code == 0) {
          this.$message.success('编辑完成')
          this.hoursImgBtnEdit = false
          this.showHonourTable()
        } else {
          this.$message.error('编辑失败')
        }
      })
    },
    // 荣耀墙分页
    hoursPageBtn (val) {
      this.honourParams.page = val
      this.showHonourTable()
    },
    leaderPageBtn (val) {
      this.leaderParams.page = val
      this.showHonourTable()
    },
    hoursGfssPageBtn (val) {
      this.gfssParams.page = val
      this.showHonourTable()
    },
    hoursGfssPageBtnRespon (val) {
      this.responsibilityParams.page = val
      this.showHonourTable()
    },
    historyPage (val) {
      this.historyParams.page = val
      this.showHonourTable()
    },
    mergeParamsPage (val) {
      this.mergeParams.page = val
      this.showHonourTable()
    },
    deleteBtn () {
      let item = this.selectLength()
      if (item == 1) {
        this.dialogDelete = true
      }
    },
    /* 删除 */
    submitFormDeleteTwo () {
      let params = {
        id: this.onceTable[0].id,
        // type: this.onceTable[0].type
      }
      honorDeleteOnce(params).then(res => {
        if (res.result == 1) {
          this.$message.success('删除成功')
          this.dialogDelete = false
          // this. gfssParams = {type: 'gfss', page: 1, rows: 6}
          // this.leaderParams = {type: 'leader', page: 1, rows: 6}
          // this.historyParams = {type: 'history', page: 1, rows: 6}
          // this.mergeParams = {type: 'merger', page: 1, rows: 6}
          // this.honourParams = {type: 'honor', page: 1, rows: 6}
          // this.responsibilityParams = {type: 'responsibility', page: 1, rows: 6}
          // this.videoParams = {type: 'video', page: 1, rows: 6}
          this.showHonourTable()
        } else {
          this.$message.error('删除失败')
        }
      })
    },
    resetTable () {
      this.showHonourTable()
    },
    clearImgDel () {
      if (this.$refs['AddBtnImg']) {
        this.$refs['AddBtnImg'].clearFiles()
      }
      if (this.$refs['AddBtnImgTwo']) {
        this.$refs['AddBtnImgTwo'].clearFiles()
      }
      if (this.$refs['ruleFormAddCenterContent']) {
        this.$refs['ruleFormAddCenterContent'].clearValidate()
      }
      if (this.$refs['ruleFormAddCenterContentTop']) {
        this.$refs['ruleFormAddCenterContentTop'].clearValidate()
      }
      if (this.$refs['ruleFormAddCenterContentBottom']) {
        this.$refs['ruleFormAddCenterContentBottom'].clearValidate()
      }
      this.$nextTick(() => {
        if (this.$refs['AddBtnImg']) {
          this.$refs['AddBtnImg'].clearFiles()
        }
        if (this.$refs['AddBtnImgTwo']) {
          this.$refs['AddBtnImgTwo'].clearFiles()
        }
        if (this.$refs['ruleFormAddCenterContent']) {
          this.$refs['ruleFormAddCenterContent'].clearValidate()
        }
        if (this.$refs['ruleFormAddCenterContentTop']) {
          this.$refs['ruleFormAddCenterContentTop'].clearValidate()
        }
        if (this.$refs['ruleFormAddCenterContentBottom']) {
          this.$refs['ruleFormAddCenterContentBottom'].clearValidate()
        }
      })
    }
  },
  created () {
    /* 展厅内容与标题 */ // 后面需要放在点击按钮里面，而不是放在页面中
    this.showZtContent()
    this.showZtTitle()
    this.showHonourTable()
  }
}
</script>

<style scoped lang="less">
  @import "../../css/dialog";
  @import "../../css/public";
  .el-carousel__item h3 {
    width: 290px;
    height: 200px;
    color: #475669;
    font-size: 14px;
    opacity: 0.75;
    line-height: 200px;
    margin: 0;
    position: relative;
    img{
      /*width: 100%;*/
      height: 227px;
    }
  }
  .fuDiv{
    position: absolute;
    left: 0;
    bottom: 0;
    width: 100%;
    height: 30px;
    font-size: 15px;
    background: rgba(0, 103, 173, 0.6);
    text-align: left;
    text-indent: 12px;
    line-height: 30px;
    color: #fff;
    >span{
      float: right;
      font-size: 12px;
      .carouselImgBtn{
        float: left;
        width:56px;
        height:20px;
        margin:6px 4px 0;
        line-height:20px;
        color: #0067AD;
        background-color: #fff;
        img{
          vertical-align: baseline;
          width: 10px;
        }
      }
    }
  }

  .btn-content{
    height: 30px;
    line-height: 0;
  }
  .avatar-uploader {
    /*text-align: center;*/
  }
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    width: 178px;
    height: 178px;
    border: 1px solid #8c939d;
    font-size: 28px;
    color: #8c939d;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
  /*.demo-ruleForm{*/
    /*img{*/
      /*width: 120px;*/
    /*}*/
  /*}*/
</style>
<style lang="less">
  .upload-demo{
    .el-upload-list{
      width: 50%!important;
    }
  }

  .elTabsCss{
    >.el-tabs__header{
      width: 120px;
      min-height: 592px!important;
      border: 1px solid!important;
      background-color: #3C3C3C;
      .el-tabs__nav-wrap{
        width: 123px;
      }
      .el-tabs__item{
        width: 119px;
        color: #fff;
        background-color: rgba(51, 51, 51, 0.5);
        margin: 10px 0;
        text-align: center;
      }
      .el-tabs__active-bar{
        display: none;
      }
    }
    .elTabsCssTwo{
      margin-top:10px;
      .el-tabs__item{
        width: 150px;
        margin: 0 4px;
        border-radius: 10px 10px 0 0;
        background-color: #EEF2F7;
        border: 1px solid #EEF2F7;
        text-align: center;
      }
      .el-tabs__item.is-active{
        color: #454545;
        background-color: #fff;
      }
    }
  }
  .ztTextarea{
    .el-textarea{
      width: 80%!important;
      textarea{
        height: 80px;
      }
    }
  }
  .elTabsCss{
    .el-tabs__item.is-active{
      color: #409EFF!important;
    }
  }
</style>
