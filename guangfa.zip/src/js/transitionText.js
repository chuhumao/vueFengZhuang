import qs from 'qs'
import { DEV_HOST } from './http.js'
import axios from 'axios'
import { Message } from 'element-ui'

const valueIndex = function() {
  return {
    mecharList: function(val, valDate) {
      for (let i = val.length - 1; i >= 0; i--) {
        let valIndex = Math.floor(Math.random() * (i + 1)) // 获取到随机的下标;
        let responeIndex = val[valIndex]
        val[valIndex] = val[i]
        val[i] = responeIndex
      }
      return val
    },
    //导出各种文件
    exportFiles: function(url, params, filename, type) {
      axios({
        method: type,
        url: DEV_HOST + url,
        params: params,
        responseType: 'blob' //二进制流
      }).then(res => {
        Message.success('下载成功');
        const downloadElement = document.createElement('a');
        const href = window.URL.createObjectURL(res.data);
        downloadElement.href = href;
        downloadElement.download = filename;
        document.body.appendChild(downloadElement);
        downloadElement.click();
        document.body.removeChild(downloadElement); // 下载完成移除元素
        window.URL.revokeObjectURL(href) // 释放掉blob对象
      }).catch(err => {
        console.log(err);
        Message.error("请求超时");
      })
    },
    //将base64转换为blob
    dataURLtoBlob: function(dataurl) {
      var arr = dataurl.split(','),
        mime = arr[0].match(/:(.*?);/)[1],
        bstr = atob(arr[1]),
        n = bstr.length,
        u8arr = new Uint8Array(n);
      while (n--) {
        u8arr[n] = bstr.charCodeAt(n);
      }
      return new Blob([u8arr], { type: mime });
    },
    //将blob转换为file
    blobToFile: function(theBlob, fileName) {
      theBlob.lastModifiedDate = new Date();
      theBlob.name = fileName;
      return theBlob;
    },

  }
}

export {
  valueIndex
}
