import { DEV_HOST, fetch, post, patch, put, postConfig, get } from './http.js'
export const BASICURL = DEV_HOST
// gdda-new/gdda/datum/listTreeJson
// 树形菜单
export const listTreeJson = data => post('gdda-new/gdda/datum/listTreeJson', data)
// 子级树形菜单
export const childrenData = data => post('gdda-new/gdda/datum/childrenData', data)
// 树形菜单判断类型
export const judgeType = data => post('gdda-new/gdda/datum/judgeType', data)
// 统一管理：列表
export const fileListForJson = data => post('gdda-new/gdda/datum/fileListForJson', data)
// 统一管理：添加or编辑
export const saveFile = data => post('gdda-new/gdda/datum/saveFile', data)
// 统一管理：编辑获取详情
export const getMaterial = data => post('gdda-new/gdda/datum/getMaterial', data)
// 统一管理：删除
export const deleteMaterial = data => post('gdda-new/gdda/datum/deleteMaterial', data)
// 统一管理：查看列表
export const yjRecordList = data => post('gdda-new/gdda/datum/yjRecordList', data)
// 材料模板：列表
export const listForJson = data => post('gdda-new/gdda/datum/listForJson', data)
// 材料模板：档案类型（新增）
export const saveArchiveType = data => post('gdda-new/gdda/datum/saveArchiveType', data)
// 材料模板：部门列表（新增）
export const ListOrg = data => post('gdda-new/gdda/util/ListOrg', data)
// 材料模板：材料列表（新增）
export const materialList = data => post('gdda-new/gdda/datum/materialList', data)
// 材料模板：编辑数据获取（新增）
export const mateGet = data => post('gdda-new/gdda/datum/get', data)
// 材料模板：删除
export const mateDelete = data => post('gdda-new/gdda/datum/delete', data)
