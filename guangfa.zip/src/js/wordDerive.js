import Vue from 'vue'
import { DEV_HOST } from './http'
import axios from 'axios'
export const wordPull = (url, name) => {
  axios.get(DEV_HOST + '/' + url, { // url: 接口地址
    responseType: `arraybuffer` // 一定要写
  }).then(res => {
    if (res.status == 200) {
      let blob = new Blob([res.data], {
        type: `application/msword` // word文档为msword,pdf文档为pdf
      })
      let objectUrl = URL.createObjectURL(blob)
      let link = document.createElement('a')
      let fname = name // 下载文件的名字
      link.href = objectUrl
      link.setAttribute('download', fname)
      document.body.appendChild(link)
      link.click()
      // this.$message.success('导出成功')
    } else {
      this.$message({
        type: 'error',
        message: '导出失败'
      })
    }
  })
}
