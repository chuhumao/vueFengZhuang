import { DEV_HOST } from './http'
// 首页展厅图片上传
// export const uploadPicture = `${DEV_HOST}/gdda-new/gdda/ztzt/uploadPicture`
export const uploadPicture = `${DEV_HOST}/gdda-new/gdda/honorRoom/uploadPicture`
// 荣耀公用上传图片
export const honorUploadPicture = `${DEV_HOST}/gdda-new/gdda/honorRoom/uploadPicture`
// 荣耀上传视频
export const honorAddVideoVWItem = `${DEV_HOST}/gdda-new/gdda/honorRoom/uploadVideo`
// 专题上传文件
export const topicUpload = `${DEV_HOST}/gdda-new/rewrite/cms/subject/uploadPicture`
