import { DEV_HOST, fetch, post, patch, put, postConfig, get } from './http.js'
export const BASICURL = DEV_HOST
// 上表格第一级
export const listArchiveZL = data => post('gdda-new/rewrite/zl/listArchiveZL', data)
// 下表格第一级
export const listDoc = data => post('gdda-new/rewrite/zl/listDoc', data)
// 拟稿部门
export const listDept = data => post('gdda-new/rewrite/zl/listDept', data)
// 拟稿人类型
export const listUserByDeptId = data => post('gdda-new/rewrite/zl/listUserByDeptId', data)
// 归档部门
export const listAllDept = data => post('gdda-new/gdda/archiveZL/listAllDept', data)
// 分类号类型
export const findSeriesCode = data => post('gdda-new/rewrite/zl/findSeriesCode', data)
// 按件--录入
export const addArchiveZL = data => post('gdda-new/rewrite/zl/addArchiveZL', data)
// 按件--编辑
export const editFileAnJian = data => post('gdda-new/rewrite/zl/editFileAnJian', data)
// 按件--编辑保存
export const updateFileAnJian = data => post('gdda-new/rewrite/zl/updateFileAnJian', data)
// 按件--特殊编辑保存
export const updateSpecialFileAnJia = data => post('gdda-new/rewrite/zl/updateSpecialFileAnJian', data)
// 按件--删除
export const deleteArchiveZL = data => post('gdda-new/rewrite/zl/deleteArchiveZL', data)
// 按件--盒号--检索
export const findArchiveZL = data => post('gdda-new/rewrite/zl/findArchiveZL', data)
// 按件--盒号--检索（拟稿人搜索）
export const findUser = data => post('gdda-new/gdda/archiveZL/findUser', data)
// 按件--盒号--保存
export const saveCaseNoByBatch = data => post('gdda-new/rewrite/zl/saveCaseNoByBatch', data)
// 按件--Excel文件上传
export const uploadExcelH5 = data => postConfig('gdda-new/gdda/archiveZL/uploadExcelH5', data)
// 按件--Excel文件上传保存（录入）
export const uploadExcel = data => post('gdda-new/rewrite/zl/uploadExcel', data)
// 按件--Excel文件上传保存（整理）
export const uploadExcelZl = data => post('gdda-new/rewrite/zl/uploadExcelZl', data)
// 按件--文件类型
export const listFileType = data => fetch('gdda-new/rewrite/zl/listFileType', data)
// 按件--盖章类型
export const listGzdj = data => fetch('gdda-new/rewrite/zl/listGzdj', data)
// 按件--来文系统
export const listLwxt = data => fetch('gdda-new/rewrite/zl/listLwxt', data)
// 按件--加盖电子章
export const coverElectronicSeal = data => post('gdda-new/rewrite/zl/coverElectronicSeal', data)
// 按件--撤销电子章
export const removeElectronicSeal = data => post('gdda-new/rewrite/zl/removeElectronicSeal', data)
// 按件--保存
export const saveFileWrk = data => post('gdda-new/rewrite/zl/saveFileWrk', data)
// 按件--查看--左侧树形菜单
export const listAnJianTree = data => post('gdda-new/rewirte/gdda/archiveCleanUp/listAnJianTree', data)
// 按件--查看--左侧树形菜单（查看文件是否存在）
export const powerDocView = data => post('gdda-new/rewrite/zl/powerDocView', data)
// 按件--上传（下表格）
export const uploadPicture = data => postConfig('gdda-new/gdda/archiveYj/uploadPicture', data)
// 按件--上传保存（下表格）
export const saveZlUploadDoc = data => postConfig('gdda-new/rewrite/zl/saveZlUploadDoc', data)
// 按件--修改详情获取数据（下表格）
export const editDocAnJian = data => fetch('gdda-new/rewrite/zl/editDocAnJian', data)
// 按件--修改详情保存（下表格）
export const updateDoc = data => post('gdda-new/rewrite/zl/updateDoc', data)
// 按件--删除（下表格）
export const deleteDoc = data => post('gdda-new/rewrite/zl/deleteDoc', data)

// 业务--列表数据（上表格）
export const listThArchiveZL = data => post('gdda-new/rewrite/zl/listThArchiveZL', data)
// 业务--列表数据（下表格--案卷层）
export const listThFolderData = data => post('gdda-new/gdda/archiveZL/listThFolderData', data)
// 业务--列表数据（下表格--文件层）
export const listTouHangFileData = data => post('gdda-new/gdda/archiveZL/listTouHangFileData', data)
// 业务--查看--左侧树形菜单数据
export const listTreeJsonByTh = data => post('gdda-new/rewrite/zl/listTreeJsonByTh', data)
// 业务--查看--右侧数据
export const viewByTh = data => post('gdda-new/rewrite/zl/viewByTh', data)
// 业务--查看--查看电子全文是否存在
export const powerDocViewUtil = data => post('gdda-new/gdda/util/powerDocView', data)
// 业务--检索--状态
export const listThStatus = data => post('gdda-new/gdda/archiveZL/listThStatus', data)
// 业务--添加项目--获取信息
export const getInitJjProject = data => post('gdda-new/rewrite/zl/getInitJjProject', data)
// 业务--添加项目--保存信息
export const saveThProject = data => post('gdda-new/rewrite/zl/saveThProject', data)
// 业务--修改项目--获取信息
export const getThProject = data => post('gdda-new/rewrite/zl/getThProject', data)
// 业务--修改项目--保存信息
export const updateThProject = data => post('gdda-new/rewrite/zl/updateThProject', data)
// 业务--删除
export const deleteThProject = data => post('gdda-new/rewrite/zl/deleteThProject', data)
// 业务--整理
export const zLingThProject = data => post('gdda-new/rewrite/zl/zLingThProject', data)
// 业务--导入Excel
export const uploadThExcel = data => post('gdda-new/rewrite/zl/uploadThExcel', data)
// 业务--导入Excel错误
export const exportError = data => post('gdda-new/gdda/archiveZL/exportError', data)
// 业务--质检
export const thQuality = data => post('gdda-new/rewrite/zl/thQuality', data)
// 业务--保存
export const saveWrk = data => post('gdda-new/rewrite/zl/saveWrk', data)
// 业务--挂接信息
export const listThHangingData = data => post('gdda-new/rewrite/zl/listThHangingData', data)
// 业务--挂接信息第二级Tab
export const listThHangingDataiData = data => post('gdda-new/rewrite/zl/listThHangingDataiData', data)
// 业务--案卷层--添加案卷获取详情
export const getInitJjFolder = data => post('gdda-new/rewrite/zl/getInitJjFolder', data)
// 业务--案卷层--添加案卷保存
export const saveThFolder = data => post('gdda-new/rewrite/zl/saveThFolder', data)
// 业务--案卷层--修改案卷获取详情
export const getJjFolder = data => post('gdda-new/rewrite/zl/getJjFolder', data)
// 业务--案卷层--修改案卷保存
export const updateThFolder = data => post('gdda-new/rewrite/zl/updateThFolder', data)
// 业务--案卷层--删除案卷保存
export const deleteThFolder = data => post('gdda-new/rewrite/zl/deleteThFolder', data)
// 业务--文件层--添加案卷获取详情
export const getInitJjFile = data => post('gdda-new/rewrite/zl/getInitJjFile', data)
// 业务--文件层--添加案卷获取案卷号
export const listThFolderById = data => post('gdda-new/rewrite/zl/listThFolderById', data)
// 业务--文件层--添加案卷获取案卷题名
export const listJjFolderByIdAndNo = data => post('gdda-new/rewrite/zl/listJjFolderByIdAndNo', data)
// 业务--文件层--添加案卷保存
export const saveThFile = data => post('gdda-new/rewrite/zl/saveThFile', data)
// 业务--文件层--修改案卷详情
export const getThFile = data => post('gdda-new/rewrite/zl/getThFile', data)
// 业务--文件层--修改案卷保存
export const updateThFile = data => post('gdda-new/rewrite/zl/updateThFile', data)
// 业务--文件层--删除案卷
export const deleteThFile = data => post('gdda-new/rewrite/zl/deleteThFile', data)
// 业务--文件层--文件上传
export const saveThZlUploadDoc = data => post('gdda-new/rewrite/zl/saveThZlUploadDoc', data)
// 业务--文件层--删除材料列表
export const listThDocData = data => post('gdda-new/rewrite/zl/listThDocData', data)
// 业务--文件层--导入Excel
export const uploadThFileExcel = data => post('gdda-new/rewrite/zl/uploadThFileExcel', data)
// 业务--文件层--修改脊背题名--盒号下拉框
export const getCaseNoByC18 = data => post('gdda-new/rewrite/zl/getCaseNoByC18', data)
// 业务--文件层--修改脊背题名--根据盒号获取脊背题名
export const getTitleByCaseNo = data => post('gdda-new/rewrite/zl/getTitleByCaseNo', data)
// 业务--文件层--修改脊背题名--保存
export const updateJbTitle = data => post('gdda-new/rewrite/zl/updateJbTitle', data)


// 会计--列表数据
export const listAccountArchiveZL = data => post('gdda-new/rewrite/zl/listAccountArchiveZL', data)
// 会计--录入保存
export const saveAccountFile = data => post('gdda-new/rewrite/zl/saveAccountFile', data)
// 会计--编辑获取详情
export const getAccountFile = data => post('gdda-new/rewrite/zl/getAccountFile', data)
// 会计--编辑保存
export const updateAccountFile = data => post('gdda-new/rewrite/zl/updateAccountFile', data)
// 会计--查看--左侧树形菜单
export const listAnJianTreeLeft = data => post('gdda-new/storeManage/listAnJianTree', data)
// 会计--查看--左侧树形菜单（检查文件是否存在）
export const powerDocViewLeft = data => post('gdda-new/gdda/util/powerDocView', data)


// 基建--列表数据
export const listJijianArchiveZL = data => post('gdda-new/rewrite/zl/listJijianArchiveZL', data)
// 基建--查看（上表格）
export const listTreeJsonByJj = data => post('gdda-new/rewrite/zl/listTreeJsonByJj', data)
// 基建--查看（上表格）
export const viewByJj = data => post('gdda-new/rewrite/zl/viewByJj', data)
// 基建--添加数据--保存（上表格）
export const saveJjProject = data => post('gdda-new/rewrite/zl/saveJjProject', data)
// 基建--修改数据--获取详情（上表格）
export const getJjProject = data => post('gdda-new/rewrite/zl/getJjProject', data)
// 基建--修改数据--保存（上表格）
export const updateJjProject = data => post('gdda-new/rewrite/zl/updateJjProject', data)
// 基建--下载Excel（上表格）
export const downloadExcel = '/gdda-new/gdda/archiveZL/downloadExcel'
// 基建--导入Excel模板（上表格）
export const uploadJjExcel = data => post('gdda-new/rewrite/zl/uploadJjExcel', data)
// 基建--归档（上表格）
export const gdJijianPro = data => post('gdda-new/rewrite/zl/gdJijianPro', data)
// 基建--打印脊背（上表格）
export const printJijianJibei = '/gdda-new/gdda/archiveZL/printJijianJibei'
// 基建--打印卷内目录（上表格）
export const printJijianJn = '/gdda-new/gdda/archiveZL/printJijianJn'
// 基建--列表数据（下表格）--案卷层
export const listJjFolderData = data => post('gdda-new/rewrite/zl/listJjFolderData', data)
// 基建--添加数据保存（下表格）--案卷层
export const saveJjFolder = data => post('gdda-new/rewrite/zl/saveJjFolder', data)
// 基建--修改数据保存（下表格）--案卷层
export const updateJjFolder = data => post('gdda-new/rewrite/zl/updateJjFolder', data)
// 基建--列表数据（下表格）--文件层
export const listJijianFileData = data => post('gdda-new/rewrite/zl/listJijianFileData', data)
// 基建--添加数据--获取序号（下表格）--文件层
export const getItemNoByFid = data => post('gdda-new/rewrite/zl/getItemNoByFid', data)
// 基建--添加数据--保存（下表格）--文件层
export const saveJjFile = data => post('gdda-new/rewrite/zl/saveJjFile', data)
// 基建--修改数据--获取详情（下表格）--文件层
export const getJjFile = data => post('gdda-new/rewrite/zl/getJjFile', data)
// 基建--修改数据--保存（下表格）--文件层
export const updateJjFile = data => post('gdda-new/rewrite/zl/updateJjFile', data)
// 基建--上传--保存（下表格）--文件层
export const saveStaffZlUploadDoc = data => post('gdda-new/rewrite/zl/saveStaffZlUploadDoc', data)
// 基建--删除材料--列表（下表格）--文件层
export const listDocumentData = data => post('gdda-new/rewrite/zl/listDocumentData', data)


// 实物--列表（上表格）
export const listPhysicalArchiveZL = data => post('gdda-new/rewrite/zl/listPhysicalArchiveZL', data)
// 实物--录入--添加获取详情（上表格）
export const getInitPhysicalFile = data => post('gdda-new/rewrite/zl/getInitPhysicalFile', data)
// 实物--录入--添加保存（上表格）
export const savePhysicalFile = data => post('gdda-new/rewrite/zl/savePhysicalFile', data)
// 实物--录入--编辑获取详情（上表格）
export const getPhysicalFile = data => post('gdda-new/rewrite/zl/getPhysicalFile', data)
// 实物--录入--编辑保存（上表格）
export const updatePhysicalFile = data => post('gdda-new/rewrite/zl/updatePhysicalFile', data)
// 实物--编辑（上表格）
export const deletePhysical = data => post('gdda-new/rewrite/zl/deletePhysical', data)
// 实物--导入表格--保存（上表格）
export const uploadPhysicalExcel = data => post('gdda-new/rewrite/zl/uploadPhysicalExcel', data)
// 实物--列表（下表格）
export const listFileDocData = data => post('gdda-new/rewrite/zl/listFileDocData', data)
// 实物--查看左侧树形列表（下表格）
export const listAnJianTreeSwLeft = data => post('gdda-new/gdda/util/listAnJianTree', data)


// 声像--列表（上表格）
export const listShengxArchiveZL = data => post('gdda-new/rewrite/zl/listShengxArchiveZL', data)
// 声像--录入获取详情（上表格）
export const getInitStaffFolder = data => post('gdda-new/rewrite/zl/getInitStaffFolder', data)
// 声像--录入保存（上表格）
export const saveShengxFolder = data => post('gdda-new/rewrite/zl/saveShengxFolder', data)
// 声像--编辑获取详情（上表格）
export const getShengxFolder = data => post('gdda-new/rewrite/zl/getShengxFolder', data)
// 声像--编辑保存（上表格）
export const updateShengxFolder = data => post('gdda-new/rewrite/zl/updateShengxFolder', data)
// 声像--删除（上表格）
export const deleteStaffFolder = data => post('gdda-new/rewrite/zl/deleteStaffFolder', data)
// 声像--导出目录保存（上表格）
export const uploadShengxExcel = data => post('gdda-new/rewrite/zl/uploadShengxExcel', data)
// 声像--保存（上表格）
export const saveWrkFolder = data => post('gdda-new/rewrite/zl/saveWrkFolder', data)
// 声像--列表（下表格）
export const listShengxFilePage = data => post('gdda-new/rewrite/zl/listShengxFilePage', data)
// 声像--查看--树形菜单（下表格）
export const listFileTree = data => post('gdda-new/rewrite/zl/listFileTree', data)
// 声像--查看--右侧详情（下表格）
export const getShengxFileByView = data => post('gdda-new/rewrite/zl/getShengxFileByView', data)
// 声像--查看--查看是否是PDF（下表格）
export const powerDocViewByShengx = data => post('gdda-new/rewrite/zl/powerDocViewByShengx', data)

// 声像--录入--获取详情（下表格）
export const getInitShengxFile = data => post('gdda-new/rewrite/zl/getInitShengxFile', data)
// 声像--录入--保存（下表格）
export const saveShengxFile = data => post('gdda-new/rewrite/zl/saveShengxFile', data)
// 声像--编辑--获取详情（下表格）
export const getShengxFile = data => post('gdda-new/rewrite/zl/getShengxFile', data)
// 声像--编辑--保存（下表格）
export const updateShengxFile = data => post('gdda-new/rewrite/zl/updateShengxFile', data)
// 声像--删除（下表格）
export const deleteStaffFile = data => post('gdda-new/rewrite/zl/deleteStaffFile', data)
// 声像--导入Excel保存（下表格）
export const uploadShengxExcelFile = data => post('gdda-new/rewrite/zl/uploadShengxExcelFile', data)
