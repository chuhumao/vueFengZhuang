import { DEV_HOST, fetch, post, patch, put, postConfig, get } from './http.js'
export const BASICURL = DEV_HOST;
//登录---账号登录
//ERP登录
export const erpLogin = data => post('gdda-new/sysmng/tuser/loginErpNew', data);
//获取部门角色信息
export const getRole = data => post('gdda-new/overwritehome/khda', data);
//部门--角色登录
export const selectLogin = data => post('gdda-new/overwriteuser/khda', data);
//部门--角色所有登录
export const allLogin = data => post('gdda-new/overwritehome/khda2', data);
//登录退出
export const outLogin = data => fetch('gdda-new/sysmng/user/logout', data);
//我的借阅
//我的借阅--最外层列表
export const outList = data => post('gdda-new/gdda/borrowCarMng/borrowList', data);
//我的借阅--弹框列表
export const borrowList = data => post('gdda-new/gdda/borrowCarMng/borrowListBySelectedNew', data);
//我的借阅--最外层删除
export const outDelete = data => post('gdda-new/gdda/borrowCarMng/deleteBorrowItems', data);
//我的借阅--弹框查询回显
export const showBorrowDetail = data => post('gdda-new/gdda/borrowCarMng/showBorrowDetail', data);
//我的借阅--提交订阅
export const submitOrder = data => post('gdda-new/gdda/borrowCarMng/submitBorrowOrderNew', data);
//我的借阅--关联借阅人--获取部门
export const getListOrg = data => post('gdda-new/gdda/util/ListOrg', data);
//我的借阅--关联借阅人--获取用户
export const getListDept = data => post('gdda-new/gdda/archiveYj/newListUserByDept', data);
//我的借阅--关联借阅人--借阅
export const saveRead = data => post('gdda-new/gdda/borrowCarMng/saveChangeUser', data);
//我的移交
//我的移交--移交正常
export const successTrans = data => post('gdda-new/gdda/archiveYj/listHandOverQrData?status=5&series1=1379482316593&bs=yyj', data);
//我的移交--移交失败
export const errorTrans = data => post('gdda-new/gdda/archiveYj/listHandOverQrData?status=1&series1=1379482316593', data);
//档案查询
export const searchArchive = data => fetch('gdda-new/gdda/archiveSearch/searchArchive', data);
// 展厅新增
export const saveZtztItem = data => post('gdda-new/gdda/ztzt/saveZtztItem', data);
// 展厅标题新增
export const saveZtzt = data => post('gdda-new/gdda/ztzt/saveZtzt', data);
// 展厅标题回显
export const ztGetZtztTitle = data => post('gdda-new/gdda/ztzt/getZtztTitle', data);
// 展厅标题修改
export const ztEditZtzt = data => post('gdda-new/gdda/ztzt/editZtzt', data);
// 展厅上栏修改 下栏修改
export const ztEditItem = data => post('gdda-new/gdda/ztzt/editItem', data);
// 展厅标题删除
export const ztTitleDelete = data => post('gdda-new/gdda/ztzt/delete', data);
// 展厅内容回显
export const ztListItems = data => post('gdda-new/gdda/ztzt/listItems', data);
// 荣耀室table数据
export const honorRoomList = data => post('gdda-new/gdda/honorRoom/list', data);
// 荣耀墙--新增
export const honorAddHr = data => post('gdda-new/gdda/honorRoom/addHr', data);
// 荣耀墙--修改
export const honorEditHr = data => post('gdda-new/gdda/honorRoom/editHr', data);
// 广发上市--新增
export const honorAddVWItem = data => post('gdda-new/gdda/honorRoom/addVWItem', data);
// 广发上市--修改
export const honorEditVWItem = data => post('gdda-new/gdda/honorRoom/editVWItem', data);
// 广发上市--修改
export const honorDeleteOnce = data => post('gdda-new/gdda/honorRoom/delete', data);
//通知公告
//通知公告--显示
export const topNew = data => post('gdda-new/cms/news/listTopNews', data);
//通知公告弹框--列表
export const listNew = data => post('gdda-new/cms/news/listMoreNews?columnId=8a8262025a49cb81015a49ce29740001', data);
//通知公告弹框--详情
export const detailNew = data => post('gdda-new/cms/news/newsDetail', data);
//通知公告弹框--标记已读
export const readNew = data => post('gdda-new/cms/news/updateNewsForBeReaded', data);
//栏目管理
//栏目管理--左侧列表
export const listColumnTreeData = data => post('gdda-new/rewrite/cms/column/listColumnTreeData', data);
//栏目管理--列表
export const hurdleList = data => post('gdda-new/rewrite/cms/column/listColumnData', data);
//栏目管理--添加
export const saveColumnAdd = data => post('gdda-new/rewrite/cms/column/saveColumn', data);
//栏目管理--修改
export const updateColumnEdit = data => post('gdda-new/rewrite/cms/column/updateColumn', data);
//栏目管理--删除
export const deleteColumnOnce = data => post('gdda-new/rewrite/cms/column/deleteColumn', data);
//新闻管理
//新闻管理--列表
export const listNewsData = data => post('gdda-new/rewrite/cms/news/listNewsData', data);

//专题
//专题列表
export const topicList = data => post('gdda-new/rewrite/cms/subject/listSubjectData', data);
//专题新增
export const topicAdd = data => post('gdda-new/rewrite/cms/subject/saveSubject', data);
//专题删除
export const topicDel = data => post('gdda-new/rewrite/cms/subject/deleteSubject', data);
//专题--弹框列表
export const topicDetail = data => post('gdda-new/rewrite/cms/subject/listSubjectFileData', data);
//专题--弹框删除
export const detailDel = data => post('gdda-new/rewrite/cms/subject/deleteFile', data);
//专题-弹框专题tree
export const detailTree = data => post('gdda-new/rewrite/cms/subject/listSubjectTree', data);
//专题--弹框查看专题文件--查看材料列表文件//综合档案确认--查看材料
export const detailDoc = data => post('gdda-new/rewrite/cms/subject/powerDocView', data);
//专题--弹框下载文件
export const downDoc = data => fetch('gdda-new/cms/subject/downLoadFile', data);
//专题--弹框文件预览
export const viewPdf = data => fetch('gdda-new/cms/subject/viewPdf', data);
//专题--弹框上传文件保存
export const saveUpload = data => post('gdda-new/rewrite/cms/subject/saveUploadSubjectFile', data);
// 归档部门
export const branchListOrg = data => post('gdda-new/gdda/util/ListOrg', data);
// 归档部门--人
export const branchListTUser = data => post('gdda-new/gdda/util/ListTUser', data);
// 新闻删除
export const deleteNews = data => post('gdda-new/rewrite/cms/news/deleteNews', data);
// 新闻--编辑获取信息
export const userGetNews = data => post('gdda-new/cms/news/getNews', data);
// 新闻--新增（广发之最）
export const addSaveNews = data => post('gdda-new/rewrite/cms/news/saveNews', data);
// 新闻--编辑（广发之最）
export const editUpdateNews = data => post('gdda-new/rewrite/cms/news/updateNews', data);
// 新闻--新增（广发名人堂）
export const addSaveHallOfFame = data => post('gdda-new/rewrite/cms/fame/saveHallOfFame', data);
// 新闻--编辑获取信息（广发名人堂）
export const editUserGetNews = data => post('gdda-new/rewrite/cms/news/getNews', data);
// 新闻--编辑（广发名人堂）
export const editUpdateHallOfFame = data => post('gdda-new/rewrite/cms/fame/updateHallOfFame', data);
// 新闻发布
export const releaseNews = data => post('gdda-new/rewrite/cms/news/releaseNews', data);
// 新闻公开 与 隐藏
export const updateNewsOfOpenOrNOt = data => post('gdda-new/rewrite/cms/news/updateNewsOfOpenOrNOt', data);
// 新闻置顶 与 取消
export const updateNewsOfTopOrNot = data => post('gdda-new/rewrite/cms/news/updateNewsOfTopOrNot', data);
// 新闻加粗 与 取消
export const updateNewsOfBoldOrNot = data => post('gdda-new/rewrite/cms/news/updateNewsOfBoldOrNot', data);
// 新闻红标 与 取消
export const updateNewsOfRedOrNot = data => post('gdda-new/rewrite/cms/news/updateNewsOfRedOrNot', data);
// 新闻管理--部门大事记or广发大事记--新增
export const addSaveDsj1 = data => post('gdda-new/rewrite/cms/dsj/saveDsj', data);
export const addSaveDsjContent = data => postConfig('gdda-new/rewrite/cms/dsj/saveDsjContent', data);
// 新闻管理--部门大事记or广发大事记--编辑获取大事记内容
export const roleListDsjContentData = data => post('gdda-new/rewrite/cms/dsj/listDsjContentData', data);
// 新闻管理--部门大事记or广发大事记--编辑
export const editUpdateDsj = data => post('gdda-new/rewrite/cms/dsj/updateDsj', data);
// 新闻管理--部门大事记or广发大事记--删除
export const deleteDsjContent = data => post('gdda-new/rewrite/cms/dsj/deleteDsjContent', data);
// 发送大事记--所选部门
export const listDsjAuthorByDept = data => post('gdda-new/cms/dsj/listDsjAuthorByDept', data);
// 发送大事记--所选部门
export const addSaveMemorabilia = data => post('gdda-new/rewrite/cms/dsj/saveMemorabilia', data);
//系统权限管理--角色管理
//角色管理--角色列表
export const listRole = data => post('gdda-new/rewrite/sysmng/role/listForJson', data);
//获取父角色ID
export const roleId = data => fetch('gdda-new/rewrite/sysmng/role/list', data);
//角色管理--角色新增/编辑
export const saveRole = data => post('gdda-new/rewrite/sysmng/role/save', data);
//角色管理--角色详情
export const detailRole = data => post('gdda-new/rewrite/sysmng/role/get', data);
//角色管理--编辑判断（显示角色编辑还是专项编辑）
export const roleSaveBefore = data => fetch('gdda-new/rewrite/sysmng/role/getExclusiveRole', data);
//角色管理--专项角色详情
export const detailRoleDlg = data => fetch('gdda-new/rewrite/sysmng/role/openAddExclusiveRoleDlg', data);
//角色管理--修改专项
export const saveRoleDlg = data => post('gdda-new/rewrite/sysmng/role/exclusiveRoleSave', data);
//角色管理--角色删除
export const deleteRole = data => post('gdda-new/rewrite/sysmng/role/delete', data);
//角色管理--获取角色赋权树
export const roleTree = data => post('gdda-new/rewrite/sysmng/resourcepower/listRsTreeJson', data);
//角色管理--获取角色赋权树选中状态
export const selectTree = data => post('gdda-new/rewrite/sysmng/resourcepower/listForJson', data);
//角色管理--角色赋权
export const saveRoleFor = data => post('gdda-new/rewrite/sysmng/resourcepower/saveForRole', data);
//角色管理--获取数据赋权状态
export const dataState = data => post('gdda-new/rewrite/sysmng/roleDataPower/getEntity2', data);
//角色管理--数据赋权保存/更新 （前两个按钮）
export const saveData1 = data => post('gdda-new/rewrite/sysmng/roleDataPower/save', data);
//角色管理--数据赋权保存/更新 （最后一个按钮）
export const saveData2 = data => post('gdda-new/rewrite/sysmng/roleDataPower/saveRoleDataPowerNew', data);
export const oldListSeriesByFondsAndRole = data => post('gdda-new/gdda/util/oldListSeriesByFondsAndRole', data);
//角色管理--所辖用户左侧列表
export const userList = data => post('gdda-new/rewrite/sysmng/roleDataPower/listForJson', data);
//角色管理--所辖用户右侧查询、列表
export const userSearch = data => post('gdda-new/rewrite/sysmng/roleDataPower/listForJson2', data);
//角色管理--所辖用户增加
export const userAdd = data => post('gdda-new/rewrite/sysmng/roleDataPower/saveuser', data);
//角色管理--所辖用户删除
export const userDelete = data => post('gdda-new/rewrite/sysmng/roleDataPower/delete', data);
//角色管理--新增专项
export const addItem = data => post('gdda-new/rewrite/sysmng/role/exclusiveRoleSave', data);
//用户管理--组织机构树
export const userlistTopForTreeJson = data => fetch('gdda-new/rewrite/sysmng/org/listTopForTreeJson', data);
//用户管理--用户列表
export const userlistForJson = data => post('gdda-new/rewrite/sysmng/org/listForJson', data);
//用户管理--用户列表(角色新增）
export const userAddSave = data => post('gdda-new/rewrite/sysmng/org/save2', data);
//用户管理--角色按钮(角色新增）
export const userAddSaveOnce = data => post('gdda-new/rewrite/sysmng/org/save', data);
//用户管理--启用
export const userDeleteByOrgUser = data => post('gdda-new/rewrite/sysmng/org/deleteByOrgUser', data);
//用户管理--启用 封停
export const userUpdateStateStart = data => post('gdda-new/rewrite/sysmng/org/updateState', data);
//用户管理--根据用户名查找
export const userListByName = data => post('gdda-new/rewrite/sysmng/org/listByName', data);
//用户管理--根据角色名查找
export const roleListForJson2 = data => fetch('gdda-new/rewrite/sysmng/role/listForJson2', data);
//用户管理--根据角色名查找
export const addUrrOnce = data => post('gdda-new/rewrite/sysmng/org/addUrr', data);
//用户管理--根据角色名查找
export const roleListRoleForJson = data => post('gdda-new/rewrite/sysmng/org/listRoleForJson', data);
//用户管理--列表删除用户
export const roleDeleteByOrgUser = data => post('gdda-new/sysmng/org/deleteByOrgUser', data);
//用户管理--角色删除用户
export const roleDeleteTuserRole = data => post('gdda-new/rewrite/sysmng/org/deleteTuserRole', data);
//角色管理--全宗赋权--全宗选中
export const archSelect = data => post('gdda-new/rewrite/sysmng/roleDataPower/listFondsPower', data);
//角色管理--全宗赋权--全宗赋权
export const archAdd = data => post('gdda-new/rewrite/sysmng/roleDataPower/saveRoleFondsPower', data);
//角色管理--新增全宗
//角色管理--新增全宗--全宗子列表
export const listGeneral = data => post('gdda-new/rewrite/sysmng/roleDataPower/listFondsSeries', data);
//角色管理--新增全宗--获取所有档案类型
export const allFiles = data => post('gdda-new/gdda/util/ListAllArchiveType', data);
//角色管理--新增全宗--左侧下拉
export const leftGeneral = data => post('gdda-new/rewrite/sysmng/roleDataPower/listFondsTreeJson', data);
//角色管理--新增全宗--分类新增
export const addGeneral = data => post('gdda-new/rewrite/sysmng/roleDataPower/addNewSeriesSave', data);
//角色管理--新增全宗--获取档案类型
export const arcType = data => post('gdda-new/rewrite/sysmng/roleDataPower/listArchiveType', data);
//角色管理--新增全宗--分类编辑
export const detailGeneral = data => post('gdda-new/rewrite/sysmng/roleDataPower/editSeriesSave', data);
//角色管理--新增全宗--分类删除
export const delGeneral = data => post('gdda-new/rewrite/sysmng/roleDataPower/delSeries', data);
//角色管理--新增全宗--全宗新增
export const addFonds = data => post('gdda-new/rewrite/sysmng/roleDataPower/addNewFondsSave', data);
//角色管理--新增全宗--全宗编辑
export const detailFonds = data => post('gdda-new/rewrite/sysmng/roleDataPower/editFondsSave', data);
//角色管理--新增全宗--全宗删除
export const deleFonds = data => post('gdda-new/rewrite/sysmng/roleDataPower/delFonds', data);
//功能模块管理
//功能模块--左侧数
export const funTree = data => post('gdda-new/sysmng/resource/listTreeJson', data);
//功能模块--右侧列表
export const funList = data => post('gdda-new/sysmng/resource/listForJson', data);
//功能模块--新增/修改
export const funSave = data => post('gdda-new/sysmng/resource/save', data);
//功能模块--修改回显
export const funDetail = data => post('gdda-new/sysmng/resource/get', data);
//功能模块--删除
export const funDel = data => post('gdda-new/sysmng/resource/delete', data);
//数据权限管理--用户数据权限（左侧菜单）（传参按照后端规则  暂时被写死）
export const treeListDept = data => post('gdda-new/sysmng/dataAccess/treeListDept?deptName=%25E5%258A%259E%25E5%2585%25AC%25E5%25AE%25A4', data);
//数据权限管理--用户数据权限（列表）（传参按照后端规则  暂时被写死）
export const tUserListForJson = data => post('gdda-new/sysmng/dataAccess/tUserListForJson', data);
//数据权限管理--用户数据权限（属性名第一级下拉框）
export const getPropertyName = data => post('gdda-new/sysmng/dataAccess/getPropertyName', data);
//数据权限管理--用户数据权限（属性名第2级下拉框）
export const listPropertyValues = data => post('gdda-new/sysmng/dataAccess/listPropertyValues', data);
//数据权限管理--用户数据权限（数据赋权，添加）
export const addFieldAccess = data => post('gdda-new/sysmng/dataAccess/addFieldAccess', data);
//数据权限管理--用户数据权限（数据赋权）
export const getDataView = data => post('gdda-new/sysmng/dataAccess/getDataView', data);
//数据权限管理--用户数据权限（查看数据赋权）
export const showListFieldAccess = data => post('gdda-new/sysmng/dataAccess/listFieldAccess', data);
//数据权限管理--用户数据权限（查看数据赋权--编辑）
export const showEditFieldAccess = data => post('gdda-new/sysmng/dataAccess/editFieldAccess', data);
//数据权限管理--用户数据权限（查看数据赋权--删除）
export const showDeleteFieldAccess = data => post('gdda-new/sysmng/dataAccess/deleteFieldAccess', data);
//数据权限管理--角色数据权限（列表）
export const roleListForJson = data => post('gdda-new/sysmng/dataAccess/roleListForJson', data);
//缓存管理
//缓存管理--列表
export const cacheList = data => post('gdda-new/sysmng/newCache/listForJson', data);
//缓存管理--新增、编辑
export const cacheSave = data => post('gdda-new/sysmng/newCache/save', data);
//缓存管理--详情
export const cacheDetail = data => post('gdda-new/sysmng/newCache/getEntity', data);
//缓存管理--更新缓存
export const cacheUpdate = data => post('gdda-new/sysmng/newCache/beupdate', data);
//缓存管理--删除缓存
export const cacheDel = data => post('gdda-new/sysmng/newCache/delete', data);
//移交申请--列表
export const listHandOverSqData = data => post('gdda-new/rewrite/gdda/archiveYjSq/listHandOverSqData', data);
//移交申请--获取档案类型
export const ListSeriesList = data => post('gdda-new/gdda/util/ListSeries', data);
//移交申请--获取档案详情
export const showGetYjSqShInitInfo = data => post('gdda-new/rewrite/gdda/archiveYjSq/getYjSqShInitInfo', data);
//移交申请--获取档案详情(左侧边框）
export const showListSeriesByFondsAndRole = data => post('gdda-new/gdda/util/listSeriesByFondsAndRole', data);
//移交申请--获取档案详情(右侧边框）
export const showListSeriesByFonds = data => post('gdda-new/gdda/util/listSeriesByFonds', data);
//移交申请--移交申请（确定）
export const btnYjSqSave = data => post('gdda-new/rewrite/gdda/archiveYjSq/yjSqSave', data);
//移交申请--移交申请（获取申请数据）
export const getYjSqInitInfo = data => post('gdda-new/rewrite/gdda/archiveYjSq/getYjSqInitInfo', data);
//移交申请--移交申请（申请人搜索）
export const findChangeUser = data => post('gdda-new/gdda/archiveYj/findChangeUser', data);
//移交申请--移交申请（确定按钮）
export const btnSendYjSqOa = data => post('gdda-new/rewrite/gdda/archiveYjSq/sendYjSqOa', data);
//移交申请--移交申请（重发移交申请审核代办按钮）
export const btnSendYjSqDb = data => post('gdda-new/rewrite/gdda/archiveYjSq/sendYjSqDb', data);
//移交申请--移交申请审核（同意按钮）
export const btnYjSqShPass = data => post('gdda-new/rewrite/gdda/archiveYjSq/yjSqShPass', data);
//移交申请--移交申请审核（退回按钮）
export const btnYjSqShBack = data => post('gdda-new/rewrite/gdda/archiveYjSq/yjSqShBack', data);
//移交申请--移交申请审核（结束按钮）
export const btnYjSqShEnd = data => post('gdda-new/rewrite/gdda/archiveYjSq/yjSqShEnd', data);
//移交申请--移交申请审核（重发移交申请审核代办按钮）
export const btnSendYjSqShDb = data => post('gdda-new/rewrite/gdda/archiveYjSq/sendYjSqShDb', data);
//索引管理
//索引管理--创建archives档案索引库
export const indexArch = data => fetch('gdda-new/gdda/archiveSearch/indexArchive', data);
//索引管理--创建Document文档索引库
export const indexDoc = data => fetch('gdda-new/gdda/archiveSearch/indexDocument', data);
//索引管理--全量索引Archive/增量索引Archive
export const indexData = data => post('gdda-new/gdda/archiveSearch/indexData', data);
//索引管理--全量索引Document/增量索引Document
export const indexDocData = data => post('gdda-new/gdda/archiveSearch/indexDocumentData', data);
//删除Archive索引库
export const deleteArch = data => post('gdda-new/gdda/archiveSearch/delete/gdda-archive', data);
//删除Document索引库
export const deleteDoc = data => post('gdda-new/gdda/archiveSearch/delete/gdda-document', data);
//索引类型列表
export const indexTypeList = data => post('gdda-new/khda/esManage/listTableTreeJson', data);
//获取索引字段类型集合
export const indexTypeMap = data => fetch('gdda-new/khda/esManage/getESMappingType', data);
//创建索引--保存
export const indexSave = data => postConfig('gdda-new/khda/esManage/addIndexName', data);
//索引导入数据 --执行
export const indexImport = data => post('gdda-new/khda/esManage/importData', data);
//索引导入数据 --列表
export const indexImportList = data => post('gdda-new/khda/esManage/listTableTreeJsonsingle', data);
//专责小组
//专责小组---判断用户能否访问专责小组--初始化时执行
export const canAccess = data => post('gdda-new/gdda/zzxz/canAccess', data)
//专责小组--列表
export const taskList = data => post('gdda-new/gdda/zzxz/list', data);
//专责小组--状态下拉框选项
export const typeSelect = data => post('gdda-new/gdda/zzxz/listStopUse', data);
//专责小组--联络人下拉框
export const userSelect = data => post('gdda-new/gdda/zzxz/findUser', data);
//专责小组--新增/修改--归档部门
export const allDept = data => post('gdda-new/gdda/zzxz/listAllDept', data);
//专责小组--修改--正常
export const taskNormal = data => post('gdda-new/gdda/zzxz/noStop', data);
//专责小组--修改--已终止
export const taskStop = data => postConfig('gdda-new/gdda/zzxz/stop', data);
//专责小组--修改--无变化
export const taskNoChange = data => post('gdda-new/gdda/zzxz/noChange', data);
//专责小组--新增/修改--保存
export const saveTask = data => post('gdda-new/gdda/zzxz/save', data);
//专责小组--删除
export const taskDelete = data => post('gdda-new/gdda/zzxz/delete', data);
//专责小组--取消代办
export const taskCancel = data => post('gdda-new/gdda/zzxz/cancelTodo', data);
//专责小组--发送代办
export const taskSend = data => post('gdda-new/gdda/zzxz/sendTodo', data);
//专责小组--导出选中/导出全部
export const taskExport = data => post('gdda-new/gdda/zzxz/export', data);
//归档地图
//归档地图--查询列表
export const mapList = data => post('gdda-new/gdda/archiveMap/listArchiveMapData', data);
//归档地图--检索--系统名称
export const sysSelect = data => post('gdda-new/gdda/archiveMap/listSystemName', data);
//归档地图--检索--流程名称
export const sysProcess = data => post('gdda-new/gdda/archiveMap/listProcessName', data);
//归档地图--录入
export const saveMap = data => post('gdda-new/gdda/archiveMap/saveFilingMapFile', data);
//归档地图--详情
export const detailsMap = data => post('gdda-new/gdda/archiveMap/getFilingMapFileDate', data);
//归档地图--删除
export const delMap = data => post('gdda-new/gdda/archiveMap/delFilingMapFile', data);
//归档地图--上传文件保存
export const mapUploadSave = data => post('gdda-new/gdda/archiveMap/uploadMapExcel', data);
//投行档案借阅
//投行档案借阅--获取全宗
export const getFonds = data => post('gdda-new/gdda/util/ListFonds', data);
//投行档案借阅--根据全宗查询分类
export const getAndRole = data => post('gdda-new/gdda/util/listSeriesByFondsAndRole', data);
//投行档案借阅--根据档案分类id获取下级分类
export const getIdList = data => post('gdda-new/gdda/util/listSeriesByFonds', data);
//投行档案借阅--档案列表
export const docList = data => post('gdda-new/gdda/archiveSearch/listThArchiveData', data);
//投行档案借阅--获取投行档案案卷信息/案卷层
export const listFolder = data => post('gdda-new/gdda/archiveZL/listThFolderData', data);
//投行档案借阅--项目信息检索--状态下拉
export const thStatus = data => fetch('gdda-new/gdda/archiveZL/listThStatus', data);
//投行档案借阅--项目信息检索--部门下拉
export const thDept = data => fetch('gdda-new/gdda/archiveZL/listAllDept', data);
//投行档案借阅--项目信息检索--执行检索
export const saveTh = data => post('gdda-new/gdda/archiveSearch/listThArchiveData', data);
//投行档案借阅--添加借阅车
export const addCar = data => post('gdda-new/gdda/borrowCarMng/addBorrowCarNew', data);
//投行档案借阅--文件层
export const fileTh = data => post('gdda-new/gdda/archiveZL/listTouHangFileData', data);
//投行档案借阅--文件层--借阅
export const fileAddCar = data => post('gdda-new/gdda/borrowCarMng/addBorrowCarNew', data);
//投行档案借阅--显示借阅车数量
export const carCount = data => post('gdda-new/gdda/borrowCarMng/showBorrowCarCount', data);
//客户档案--点击
export const custArch = data => fetch('gdda-new/gdda/archiveSearch/customerArchive', data);
//档案可视化--点击
export const viewArch = data => fetch('gdda-new/gdda/archiveSearch/viewableArchive', data);
//电子档案查询系统
export const elecrArch = data => fetch('gdda-new/gdda/archiveSearch/electArchiveSearch', data);
//电子档案质检系统
export const sysArch = data => fetch('gdda-new/gdda/archiveSearch/electArchiveQCSys', data);
//综合档案确认
//综合档案确认--列表
export const confirmList = data => post('gdda-new/rewirte/gdda/archiveCleanUp/listAnJianData', data);
//综合档案确认--指定承办人
export const confirmSend = data => post('gdda-new/rewirte/gdda/archiveCleanUp/sendCbrOA', data);
//综合档案确认--检索--归档部门/拟稿部门
export const conDept = data => fetch('gdda-new/rewirte/gdda/archiveCleanUp/listAllDept', data);
//综合档案确认--检索--归档人/拟稿人
export const conUser = data => post('gdda-new/rewirte/gdda/archiveCleanUp/findUser', data);
//综合档案确认--检索--文件类型
export const confile = data => fetch('gdda-new/rewirte/gdda/archiveCleanUp/listFileType', data);
//综合档案确认--检索--盖章类型
export const conSeal = data => fetch('gdda-new/rewirte/gdda/archiveCleanUp/listGzdj', data);
//综合档案确认--查看--列表
export const conDetailList = data => post('gdda-new/rewirte/gdda/archiveCleanUp/listDocumentData', data);
//综合档案确认--查看前判断
export const conCheckUser = data => fetch('gdda-new/rewirte/gdda/archiveCleanUp/checkUser', data);
//综合档案确认--查看--左侧数--如果是档案管理员或者综合员
export const conLeft = data => post('gdda-new/rewirte/gdda/archiveCleanUp/listAnJianTree', data);
//综合档案确认--查看--左侧数--其它角色
export const conLeft1 = data => post('gdda-new/rewirte/rewirte/gdda/archiveCleanUp/listFileDetailTree', data);
//综合档案确认--查看--左侧树--查看材料文件
export const seeConLeft = data => post('gdda-new/rewirte/gdda/archiveCleanUp/powerDocView', data);
//综合档案确认--确认承办人--详情接口(指定承办人)
export const getArch = data => post('gdda-new/rewirte/gdda/archiveCleanUp/getArchiveFile', data);
//综合档案确认--确认承办人--附件列表接口(指定承办人)
export const listCbr = data => post('gdda-new/rewirte/gdda/archiveCleanUp/listCbrQrData', data);
//综合档案确认--确认承办人--添加承办人--查询
export const cbrFind = data => post('gdda-new/rewirte/gdda/archiveCleanUp/findCbrAndDept', data);
//综合档案确认--确认承办人--查看前判断（非PDF）
export const findDoc = data => post('gdda-new/gdda/archiveCleanUp/findDocument', data);
//综合档案确认--确定承办人--提交
export const saveCbr = data => post('gdda-new/rewirte/gdda/archiveCleanUp/saveCbrQr', data);
//综合档案确认--确定承办人--结束
export const exitCbr = data => post('gdda-new/rewirte/gdda/archiveCleanUp/saveEndGd', data);
//综合档案确认--已确认--退回
export const confirmExit = data => post('gdda-new/rewirte/gdda/archiveCleanUp/backAnJian', data);
//综合档案确认--已确认--详情材料列表
export const confirmStuffList = data => post('gdda-new/rewirte/gdda/archiveCleanUp/listDocData', data);
//综合档案确认--待确认--详情材料列表
export const confirmDoc = data => post('gdda-new/rewirte/gdda/archiveCleanUp/listFileDocData', data);
//综合档案确认--待确认--重发归档确认代办
export const sendGdOA = data => post('gdda-new/rewirte/gdda/archiveCleanUp/againSendGdOA', data);
//综合档案确认--待确认--归档
export const gdEnd = data => post('gdda-new/rewirte/gdda/archiveCleanUp/anJianGdEnd', data);
//综合档案确认--待确认--撤销归档
export const undoGd = data => post('gdda-new/rewirte/gdda/archiveCleanUp/anJianUndoGdOA', data);
//综合档案确认--待确认--确定按钮--检查文件是否存在
export const checkFile = data => post('gdda-new/rewirte/gdda/archiveCleanUp/checkFileConfirm', data);
//综合档案确认--待确认--确定按钮--根据ID获取档案文件详情
export const getArchDetail = data => post('gdda-new/rewirte/gdda/archiveCleanUp/getArchiveFileList', data);
//综合档案确认--待确认--确定按钮--附件列表
export const listGdQrData = data => post('gdda-new/rewirte/gdda/archiveCleanUp/listGdQrData', data);
//综合档案确认--待确认--确定按钮--附件列表--查看按钮
export const findCom = data => post('gdda-new/rewirte/gdda/archiveCleanUp/findConfirmDetail', data);
//综合档案确认--待确认--确定按钮--检查PDF是否存在
export const cleanAccept = data => post('gdda-new/rewirte/gdda/archiveCleanUp/powerCondeView', data);
//综合档案确认--待确认--确定按钮--附件列表--删除按钮
export const findComDel = data => post('gdda-new/rewirte/gdda/archiveCleanUp/deleteFile', data);
//综合档案确认--待确认--确定按钮--上传按钮
export const findComUpload = data => post('gdda-new/rewirte/gdda/archiveCleanUp/saveUploadDoc', data);
//综合档案确认--待确认--确定按钮
export const saveGdQr = data => post('gdda-new/rewirte/gdda/archiveCleanUp/saveGdQr', data);
//综合档案整理--保管期限
//综合档案整理--保管期限--列表
export const sdList = data => post('gdda-new/rewrite/zl/listRetentionPeriodData', data);
//综合档案整理--添加权限--年份下拉
export const yearCodeList = data => post('gdda-new/gdda/util/yearCodeList', data);
//综合档案整理--添加权限--关键字下拉
export const fieldList = data => fetch('gdda-new/rewrite/zl/listFileType', data);
//综合档案整理--添加权限--加入条件
export const addCondition = data => post('gdda-new/rewrite/zl/addCondition', data);
//综合档案整理--添加权限--条件列表
export const listRule = data => post('gdda-new/rewrite/zl/listRuleData', data);
//综合档案整理--添加权限--删除条件
export const delCond = data => post('gdda-new/rewrite/zl/delCondition', data);
//综合档案整理--添加权限--并且操作
export const andReten = data => post('gdda-new/rewrite/zl/addAndRetentionPeriod', data);
//综合档案整理--添加权限--或许操作
export const orReten = data => post('gdda-new/rewrite/zl/addOrRetentionPeriod', data);
//综合档案整理--添加权限--加入规则
export const interReten = data => post('gdda-new/rewrite/zl/addInnerOrRetentionPeriod', data);
//综合档案整理--添加权限--保存按钮
export const saveReten = data => post('gdda-new/rewrite/zl/addOrRetentionPeriod', data);
//综合档案整理--保管期限--删除规则
export const sdDel = data => post('gdda-new/rewrite/zl/delRule', data);
//综合档案整理--保管期限--复制规则
export const copyReten = data => post('gdda-new/rewrite/zl/copyRetentionRule', data);
//综合档案整理--保管期限--执行规则
export const sdRun = data => post('gdda-new/rewrite/zl/runRetentionRule', data);
//综合档案整理--保管期限--启用规则
export const sdStart = data => post('gdda-new/rewrite/zl/startRetentionRule', data);
//综合档案整理--保管期限--禁用规则
export const sdEnd = data => post('gdda-new/rewrite/zl/endRetentionRule', data);
//综合档案整理--保管期限--筛选问题--问题文件列表
export const listArch = data => post('gdda-new/rewrite/zl/listArchiveNoRetentionPeriod', data);
//综合档案整理--保管期限--筛选问题--导入按钮
export const importExcel = data => post('gdda-new/rewrite/zl/importExcel', data);
//综合档案整理--保管期限--筛选问题--保存问题文件
export const saveProblem = data => post('gdda-new/gdda/archiveMap/saveProblemFileRp', data);
//设置电子归档章
//设置电子归档章--电子归档列表
export const listElec = data => post('gdda-new/rewrite/zl/listElectronicSealData', data);
//设置电子归档章--启用归档章
export const startElec = data => post('gdda-new/rewrite/zl/startElectronicSeal', data);
//设置电子归档章--禁用归档章
export const endElec = data => post('gdda-new/rewrite/zl/endElectronicSeal', data);
//设置电子归档章--删除归档章
export const delElec = data => post('gdda-new/rewrite/zl/delElectronicSeal', data);
//设置电子归档章--添加归档章
export const addElec = data => post('gdda-new/rewrite/zl/saveAddElectronicSeal', data);
//设置电子归档章--编辑归档章--归档章详情
export const detaiElec = data => post('gdda-new/rewrite/zl/getElectronicSeal', data);
//设置电子归档章--编辑归档章--保存归档章
export const saveElec = data => post('gdda-new/rewrite/zl/saveEditElectronicSealDlg', data);
//设置电子归档--设置归档--内容列表
export const sendListElec = data => post('gdda-new/rewrite/zl/listElectronicSealContentsData', data);
//设置电子归档--设置归档--内容添加按钮
export const addElecSend = data => post('gdda-new/rewrite/zl/addElectronicSealContents', data);
//设置电子归档--设置归档--内容删除按钮
export const delElecSend = data => post('gdda-new/rewrite/zl/delElectronicSealContents', data);
//设置电子归档--设置归档--内容保存
export const saveElecSend = data => post('gdda-new/rewrite/zl/saveSetElectronicSeal', data);
//批量挂接--文件上传确认接口
export const savePl = data => post('gdda-new/gdda/archiveZL/savePlHangingDocs', data);
//综合档案保存--管理类档案--列表
export const manageList = data => post('gdda-new/gdda/archiveSave/listArchiveSave', data);
//综合档案保存--管理类档案--入库
export const manageRk = data => post('gdda-new/store/kfManage/rkFilesave', data);
//综合档案保存--管理类档案--退回整理
export const manageBack = data => post('gdda-new/gdda/archiveSave/backAnJianFile', data);
//综合档案保存--管理类档案--去除存址号
export const manageNo = data => post('gdda-new/gdda/archiveSave/dislodgeFileAddressNo', data);
//综合档案保存--管理类档案--查看日志
export const manageKf = data => post('gdda-new/store/kfManage/listKfManageLog', data);
//综合档案保存--管理类档案--查询--年份下拉
export const listYear = data => post('gdda-new/gdda/archiveZL/listRetentionPeriod', data);
//综合档案保存--管理类档案--查询--拟稿部门获取拟稿人
export const listUserBy = data => post('gdda-new/gdda/archiveZL/listUserByDeptId', data);
//综合档案保存--管理类档案--查询--拟稿人下拉
export const listUser = data => post('gdda-new/gdda/archiveZL/findUser', data);
//综合档案保存--管理类档案--查询--文档类型下拉框
export const listType = data => post('gdda-new/gdda/archiveZL/listFileType', data);
//综合档案保存--管理类档案--查询--盖章类型下拉框
export const listGz = data => post('gdda-new/gdda/archiveZL/listGzdj', data);
//综合档案保存--管理类档案--查询--来文类型下拉框
export const listLwxt = data => post('gdda-new/gdda/archiveZL/listLwxt', data);
//综合档案保存--管理类档案--生成存址号--年份下拉
export const getYear = data => fetch('gdda-new/gdda/archiveZL/getYearCode', data);
//综合档案保存--管理类档案--生成存址号--获取档号范围
export const getScope = data => fetch('gdda-new/gdda/archiveZL/getScope', data);
//综合档案保存--管理类档案--生成存址号--获取存址联动集合
export const getStore = data => post('gdda-new/store/kfConfigManage/ListStore', data);
//综合档案保存--管理类档案--生成存址号--确认
export const saveFileAdd = data => post('gdda-new/gdda/archiveSave/saveFileAddressNo', data);
//综合档案保存--管理类档案--生成存址号--检查存址号是否存在
export const checkStore = data => post('gdda-new/store/kfConfigManage/checkStore', data);
//综合档案保存--管理类档案--查看--列表
export const archList  = data => post('gdda-new/gdda/archiveSave/listDoc', data);
//综合档案保存--管理类档案--查看--加载树
export const archTree  = data => post('gdda-new/gdda/util/listAnJianTree', data);
//综合档案保存--管理类档案--查看--加载材料
export const powerTree  = data => post('gdda-new/gdda/util/powerDocView', data);
//综合档案保存--业务档案--投资银行--底稿--列表
export const typeList  = data => post('gdda-new/gdda/archiveSave/listThArchiveSave', data);
//综合档案保存--业务档案--投资银行--底稿--案卷层列表
export const typeFolderList  = data => post('gdda-new/gdda/archiveZL/listThFolderData', data);
//综合档案保存--业务档案--投资银行--底稿--文件层列表
export const typeHangList  = data => post('gdda-new/gdda/archiveZL/listTouHangFileData', data);
//综合档案保存--业务档案--投资银行--底稿--入库
export const typeRk  = data => post('gdda-new/store/kfManage/rksave', data);
//综合档案保存--业务档案--投资银行--底稿--退回整理
export const typeBack  = data => post('gdda-new/gdda/archiveSave/backTouHang', data);
//综合档案保存--业务档案--投资银行--底稿--退回整理（入库档案） 
export const typeBackTou  = data => post('gdda-new/gdda/archiveSave/backTouHangRk', data);
//综合档案保存--业务档案--投资银行--底稿--去除存址号 
export const typeAddress  = data => post('gdda-new/gdda/archiveSave/dislodgeAddressNo', data);
//综合档案保存--业务档案--投资银行--底稿--查看--左侧树 
export const typeLeftTree  = data => post('gdda-new/gdda/archiveView/listTreeJsonByTh', data);
//综合档案保存--业务档案--投资银行--底稿--查看--右侧基本信息 
export const viewByTh  = data => fetch('gdda-new/gdda/archiveView/viewByTh', data);
//综合档案保存--业务档案--投资银行--底稿--生成存址号--检验入库
export const validateAddressNo = data => post('gdda-new/gdda/archiveSave/validateAddressNo', data);
//综合档案保存--业务档案--投资银行--底稿--生成存址号--根据年份获取档号
export const getByYear = data => post('gdda-new/gdda/archiveSave/getBoxFileNoByYear', data);
//综合档案保存--业务档案--投资银行--底稿--生成存址号--生成存址号
export const saveAddressNo = data => post('gdda-new/gdda/archiveSave/saveAddressNo', data);
//综合档案保存--业务档案--投资银行--底稿--生成存址号--获取生成存址号
export const openMakeAdd = data => post('gdda-new/gdda/archiveSave/openMakeAddressNoFrom', data);
//综合档案保存--会计档案--列表
export const listSheng = data => post('gdda-new/gdda/archiveSave/listShengxArchiveZL', data);
//综合档案保存--员工档案--列表
export const listStaff = data => post('gdda-new/gdda/archiveSave/listStaffArchiveSave', data);
//综合档案保存--员工档案--入库
export const rkStaff = data => post('gdda-new/store/kfManage/rkFoldersave', data);
//综合档案保存--员工档案--退回整理
export const backStaff = data => post('gdda-new/gdda/archiveSave/backStaffFolder', data);
//综合档案保存--员工档案--去除存址号
export const noStaff = data => post('gdda-new/gdda/archiveZL/dislodgeFolderAddressNo', data);
//综合档案保存--员工档案--生成存址号--档号范围
export const scopeStaff = data => post('gdda-new/gdda/archiveZL/getFolderScope', data);
//综合档案保存--员工档案--生成存址号--保存
export const saveStaff = data => post('gdda-new/gdda/archiveZL/saveFolderAddressNo', data);
//综合档案保存--员工档案--下方列表
export const pageStaff = data => post('gdda-new/gdda/archiveZL/listStaffFilePage', data);
//综合档案保存--员工档案--下方查看--加载树
export const treeStaff = data => post('gdda-new/gdda/util/listFileTree', data);
//综合档案保存--员工档案--下方查看--加载基本信息
export const viewStaff = data => post('gdda-new/gdda/archiveZL/getStaffFileByView', data);
//综合档案保存--员工档案--下方检索--获取公开类型
export const openStaff = data => post('gdda-new/gdda/archiveZL/listOpeningType', data);
//综合档案保存--实物档案--列表
export const entityList = data => post('gdda-new/gdda/archiveSave/listPhysicalArchiveZL', data);
//综合档案保存--声像档案--列表
export const videoList = data => post('gdda-new/gdda/archiveSave/listShengxArchiveZL', data);
//综合档案保存--基建档案--列表
export const capitalList = data => post('gdda-new/gdda/archiveSave/listJijianArchiveSave', data);
//综合档案保存--基建档案--查看--左侧树 
export const capitalTree  = data => post('gdda-new/gdda/archiveView/listTreeJsonByJj', data);
//综合档案保存--基建档案--查看--基本信息 
export const capitalInfo  = data => post('gdda-new/gdda/archiveView/viewByJj', data);
//综合档案保存--基建档案--退回整理
export const capitalBack  = data => post('gdda-new/gdda/archiveSave/backJijianPro', data);
//综合档案保存--基建档案--生成存址号--初始化回显数据
export const capitalInit  = data => post('gdda-new/gdda/archiveSave/openJiJianMakeAddressNoFrom', data);
//综合档案保存--基建档案--生成存址号--下拉年改变数据
export const capitalYear  = data => post('gdda-new/gdda/archiveSave/getJiJianBoxFileNoByYear', data);
//综合档案保存--基建档案--生成存址号--保存
export const capitalSave  = data => post('gdda-new/gdda/archiveSave/saveJiJianAddressNo', data);
//综合档案保存--基建档案--案卷层列表
export const capitalFolder  = data => post('gdda-new/gdda/archiveSave/listJjFolderData', data);
//综合档案保存--基建档案--文件层列表
export const capitalFile  = data => post('gdda-new/gdda/archiveSave/listJijianFileData', data);
//综合档案保存--业务档案--债务业务
export const debtList = data => post('gdda-new/gdda/archiveSave/listZqArchiveSave',data);
//综合档案保存--业务档案--修改存址号--页面回显
export const caseInit = data => fetch('gdda-new/gdda/archiveSave/openUpdateAddressNoFrom',data);
//综合档案保存--业务档案--修改存址号--获取盒号下拉框
export const caseList = data => post('gdda-new/gdda/archiveSave/listCaseNo',data);
//综合档案保存--业务档案--修改存址号--改变年份和盒号获取旧存址信息
export const caseChange = data => post('gdda-new/gdda/archiveSave/getUpdateAddress',data);
//综合档案保存--业务档案--修改存址号/新增存址号 --保存按钮
export const saveCase = data => post('gdda-new/gdda/archiveSave/saveAddressNo',data);
//综合档案保存--基建档案 --查看--获取所有树的显示
export const newTree = data =>post('gdda-new/gdda/archiveView/listTreeData',data);
//综合档案保存--业务档案--查看--获取所有树的显示
export const newTree1 = data =>post('gdda-new/gdda/archiveView/listTHTreeData',data);
//库房管理--库房管理--左侧列表
export const leftTree = data =>fetch('gdda-new/storeManage/listTreeJson',data);
//库房管理--库房管理--获取节点类型
export const leftJudge = data =>fetch('gdda-new/storeManage/judgeType',data);
//库房管理--库房管理--获取子节点
export const leftTreeChi = data =>fetch('gdda-new/storeManage/childrenData',data);
//库房管理--库房管理--层级--列表
export const storeList = data =>fetch('gdda-new/storeManage/listForJson',data);
//库房管理--库房管理--层级--新增
export const storeAdd = data => post('gdda-new/storeManage/save',data);
//库房管理--库房管理--层级--编辑--获取详情
export const storeDetail = data => fetch('gdda-new/storeManage/openStoreInfo',data);
//库房管理--库房管理--层级--删除
export const storeDel = data => post('gdda-new/storeManage/delete',data);
//库房管理--库房管理--层级--批量添加
export const storeAddAll = data => post('gdda-new/storeManage/adds',data);
//库房管理--查看--管理类--列表
export const storeQuery1 = data => post('gdda-new/storeManage/fileStoreList',data);
//库房管理--查看--管理类--检索--移交下拉
export const storeYj = data => fetch('gdda-new/gdda/archiveYj/listYjStatus',data);
//库房管理--查看--管理类--检索--拟稿部门下拉
export const storeDept = data => fetch('gdda-new/gdda/archiveYj/listAllDept',data);
//库房管理--查看--管理类--检索--文件类型下拉
export const storeFile = data => fetch('gdda-new/gdda/archiveYj/listFileType',data);
//库房管理--查看--管理类--检索--公章类型下拉
export const storeGz = data => fetch('gdda-new/gdda/archiveYj/listGzdj',data);
//库房管理--查看--管理类--检索--拟稿人下拉
export const storeUser = data => fetch('gdda-new/gdda/archiveYj/findUser',data);
//库房管理--查看--业务档案--投资银行--项目列表
export const proList = data => post('gdda-new/storeManage/projectStoreList',data);
//库房管理--查看--业务档案--投资银行--案卷列表
export const proListF = data => post('gdda-new/storeManage/projectFolderStoreList',data);
//库房管理--查看--业务档案--投资银行--案件列表
export const proListP = data => post('gdda-new/storeManage/projectFileStoreList',data);
//库房管理--查看--会计档案--列表
export const storeKj  = data => post('gdda-new/storeManage/fileStoreList',data);
//库房管理--查看--基建档案--项目--列表
export const conList  = data => post('gdda-new/storeManage/projectStoreList',data);
//库房管理--查看--基建档案--案卷--列表
export const conPList  = data => post('gdda-new/storeManage/projectFolderStoreList',data);
//库房管理--查看--基建档案--案件--列表
export const conFList  = data => post('gdda-new/storeManage/projectFileStoreList',data);
//库房管理--查看--员工档案--案卷--列表
export const userFList  = data => post('gdda-new/storeManage/folderStoreList',data);
//库房管理--查看--员工档案--案件--列表
export const userPList  = data => post('gdda-new/storeManage/projectFolderStoreList',data);
//库房管理--查看--实物档案 || 声像档案--列表
export const fileList1  = data => post('gdda-new/storeManage/fileStoreList',data);
//库房管理--查看--保管期限下拉
export const listRet  = data => fetch('gdda-new/rewrite/zl/listRetentionPeriod',data);
