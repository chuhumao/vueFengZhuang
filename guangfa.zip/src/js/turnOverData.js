import { DEV_HOST, fetch, post, patch, put, postConfig, get } from './http.js'
export const BASICURL = DEV_HOST
// 获取全宗
// export const getFonds = data => post('gdda-new/gdda/util/getFonds', data)
export const getFonds = data => post('gdda-new/gdda/util/ListFonds', data)
// 获取档案类型
export const listSeriesByFondsAndRole = data => post('gdda-new/gdda/util/listSeriesByFondsAndRole', data)
// 获取列表
export const listHandOverQrData = data => post('gdda-new/gdda/archiveYj/listHandOverQrData', data)
// 获取列表(下表格）
export const listHandOverDetailData = data => post('gdda-new/gdda/archiveYj/listHandOverDetailData', data)
// 查看弹框--是否有额外信息
export const checkExtendInfo = data => post('gdda-new/gdda/archiveView/checkExtendInfo', data)
// 查看弹框--是否有额外信息
export const handoverExtendInfoView = data => post('gdda-new/gdda/archiveView/handoverExtendInfoView', data)
// 获取档案类型第二级，第三级
export const listSeriesByFonds = data => post('gdda-new/gdda/util/listSeriesByFonds', data)
// 变更人查询
export const findChangeUser = data => post('gdda-new/gdda/archiveYj/findChangeUser', data)
// 移交确认
export const handOverSave = data => post('gdda-new/gdda/archiveYj/handOverSave', data)
// 查看弹框--树形菜单
export const listHandOverDocumentTree = data => post('gdda-new/gdda/util/listHandOverDocumentTree', data)
// 查看弹框--数据
export const getHandOverFile = data => post('gdda-new/gdda/archiveYj/getHandOverFile', data)
// 查看弹框--判断列表条
export const countHandOverDetailByNext = data => post('gdda-new/gdda/archiveYj/countHandOverDetailByNext', data)
// 查看弹框--下次移交
export const delHandOverFile = data => post('gdda-new/gdda/archiveYj/delHandOverFile', data)
// 查看弹框--刷新内容
export const resettingHandOverFile = data => post('gdda-new/gdda/archiveYj/resettingHandOverFile', data)
// 查看弹框--录入回显
export const findSeriesCode = data => post('gdda-new/gdda/archiveYj/findSeriesCode', data)
// 查看弹框--录入确定
export const saveMhYjFile = data => post('gdda-new/gdda/archiveYj/saveMhYjFile', data)
// 查看弹框--编辑（模糊）
export const editMhFileTitle = data => post('gdda-new/gdda/archiveYj/editMhFileTitle', data)
// 查看弹框--删除
export const deleteMhYjFile = data => post('gdda-new/gdda/archiveYj/deleteMhYjFile', data)
// 查看弹框--上传返回文件，图片分类
export const uploadPicture = data => postConfig('gdda-new/gdda/archiveYj/uploadPicture', data)
// 查看弹框--上传保存
export const saveUploadYjDoc = data => post('gdda-new/gdda/archiveYj/saveUploadYjDoc', data)
// 查看弹框--导入excel文件
export const uploadExcelH5 = data => postConfig('gdda-new/gdda/archiveZL/uploadExcelH5', data)
// 查看弹框--导入excel
export const uploadExcel = data => post('gdda-new/gdda/archiveYj/uploadExcel', data)
// 查看弹框--删除附件列表
export const listHandOverDocumentData = data => post('gdda-new/gdda/archiveYj/listHandOverDocumentData', data)
// 查看弹框--删除附件
export const deleteDoc = data => post('gdda-new/gdda/archiveYj/deleteDoc', data)
// 查看弹框--移交异常
export const saveHandoverYc = data => post('gdda-new/gdda/archiveYj/saveHandoverYc', data)
export const saveHandoverYcZq = data => post('gdda-new/gdda/archiveYj/saveHandoverYcZq', data)
export const noHandOverSave = data => post('gdda-new/gdda/archiveYj/noHandOverSave', data)
// 查看弹框--移交异常 -- 修改文件原件状态（变为非原件）
export const saveIsOriginal = data => post('gdda-new/gdda/archiveYj/saveIsOriginal', data)
// 查看弹框--模糊查询--导出excel
export const downloadExcel = data => post('gdda-new/gdda/archiveYj/downloadExcel', data)
// 查看弹框--精确查询，修改附件标题
export const editDocTitle = data => post('gdda-new/gdda/archiveYj/editDocTitle', data)
// 查看弹框--精确查询，修改附件标题
export const getQrYjList = data => post('gdda-new/gdda/archiveYj/getQrYjList', data)
// 查看弹框--精确查询，修改附件标题
export const getZqYjList = data => post('gdda-new/gdda/archiveYj/getZqYjList', data)
// 查看弹框--精确查询，修改附件标题
export const getThYjList = data => post('gdda-new/gdda/archiveYj/getThYjList', data)
// 查看弹框--精确查询，初始化材料项数据
export const listKhdaStuffCoding = data => post('gdda-new/gdda/archiveYj/listKhdaStuffCoding', data)
// 查看弹框--精确查询，关联客户
export const saveGlKhda = data => postConfig('gdda-new/gdda/archiveYj/saveGlKhda', data)
// 查看弹框--精确查询，关联客户--更新意见
export const getQrYjRemark = data => post('gdda-new/gdda/archiveYj/getQrYjRemark', data)
// 查看弹框--精确查询，合同信息
export const getBusinessType = data => post('gdda-new/gdda/archiveYj/getBusinessType', data)
// 查看弹框--精确查询，合同信息---列表数据
export const listHandoverPartnerData = data => post('gdda-new/gdda/archiveYj/listHandoverPartnerData', data)
// 查看弹框--精确查询，合同信息---确定
export const saveImformation = data => post('gdda-new/gdda/archiveYj/saveImformation', data)
// 查看弹框--精确查询，合同信息---编辑
export const handoverPartnerEditSave = data => post('gdda-new/gdda/archiveYj/handoverPartnerEditSave', data)
// 查看弹框--精确查询，合同信息---删除
export const delImformation = data => post('gdda-new/gdda/archiveYj/delImformation', data)
// 查看弹框--精确查询，获取移交情况
export const getYjInformation = data => post('gdda-new/gdda/archiveYj/getYjInformation', data)
// 查看弹框--精确查询，确认移交情况
export const saveYjInfoData = data => post('gdda-new/gdda/archiveYj/saveYjInfoData', data)
// 查看弹框--检索--当前处理人搜索
export const searchFindUser = data => post('gdda-new/gdda/statistics/findUser', data)
// 查看弹框--检索--拟稿部门
export const listAllDept = data => post('gdda-new/gdda/archiveYj/listAllDept', data)
// 查看弹框--检索--文件类型下拉框选项
export const listFileType = data => post('gdda-new/gdda/archiveYj/listFileType', data)
// 查看弹框--检索--公章
export const listGzdj = data => post('gdda-new/gdda/archiveYj/listGzdj', data)
// 查看弹框--检索--部门第二级
export const newListUserByDept = data => post('gdda-new/gdda/archiveYj/newListUserByDept', data)
// 查看弹框--保存--录入模糊移交单
export const saveMhHandOver = data => post('gdda-new/gdda/archiveYj/saveMhHandOver', data)
// 查看弹框--保存--发送代办
export const sendMhYjOa = data => post('gdda-new/gdda/archiveYj/sendMhYjOa', data)
// 查看弹框--保存--重新发送代办
export const sendYjQrDb = data => post('gdda-new/gdda/archiveYj/sendYjQrDb', data)
// 查看弹框--保存--线下移交初始化下拉框数据
export const ListArchive = data => post('gdda-new/gdda/datum/newListArchive', data)
// 查看弹框--保存--线下移交初始化数据
export const listForJson = data => post('gdda-new/gdda/datum/listForJson', data)
// 查看弹框--保存--线下移交保存期限
export const ListRetentionPeriod = data => post('gdda-new/gdda/datum/ListRetentionPeriod', data)
// 查看弹框--保存--线下移交保存
export const saveUnderLine = data => post('gdda-new/gdda/archiveYj/saveUnderLine', data)
// 查看弹框--定时设置数据
export const listTimingData = data => post('gdda-new/gdda/archiveYj/listTimingData', data)
// 查看弹框--保存--定时设置
export const saveTiming = data => post('gdda-new/gdda/archiveYj/saveTiming', data)
// 查看弹框--保存--定时设置图片上传
export const uploadPlPicture = data => postConfig('gdda-new/gdda/archiveZL/uploadPlPicture', data)
// 查看弹框--保存--定时设置确认
export const savePlHangingDocs = data => post('gdda-new/gdda/archiveYj/savePlHangingDocs', data)
// 查看弹框--投资银行弹框--确定
export const thHandOverSave = data => post('gdda-new/gdda/archiveYj/thHandOverSave', data)
// 查看弹框--投资银行弹框--导入
export const uploadThExcel = data => post('gdda-new/gdda/archiveYj/uploadThExcel', data)
// 查看弹框--投资银行弹框--导入
export const uploadZqExcel = data => post('gdda-new/gdda/archiveYj/uploadZqExcel', data)
// 查看弹框--投资银行弹框--录入
export const saveThYjFile = data => post('gdda-new/gdda/archiveYj/saveThYjFile', data)
// 查看弹框--投资银行弹框--删除
export const delHandOverDetails = data => post('gdda-new/gdda/archiveYj/delHandOverDetails', data)
// 查看弹框--实物-印章--统计移交详情
export const countHandOverDetail = data => post('gdda-new/gdda/archiveYj/countHandOverDetail', data)
// 查看弹框--实物-印章--录入
export const saveMatterYzYjFile = data => post('gdda-new/gdda/archiveYj/saveMatterYzYjFile', data)
// 查看弹框--实物-印章--编辑
export const editMatterYzYjFile = data => post('gdda-new/gdda/archiveYj/editMatterYzYjFile', data)
// 查看弹框--实物-印章--编辑回显
export const getHandoverDatailDate = data => post('gdda-new/gdda/archiveYj/getHandoverDatailDate', data)
// 查看弹框--实物-印章--录入（奖牌）
export const saveMatterQtYjFile = data => post('gdda-new/gdda/archiveYj/saveMatterQtYjFile', data)
// 查看弹框--实物-印章--编辑（奖牌）
export const editMatterQtYjFile = data => post('gdda-new/gdda/archiveYj/editMatterQtYjFile', data)
// 查看弹框--会计--录入
export const saveAccountingYjFile = data => post('gdda-new/gdda/archiveYj/saveAccountingYjFile', data)
// 查看弹框--会计--编辑
export const editAccountingYjFile = data => post('gdda-new/gdda/archiveYj/editAccountingYjFile', data)
// 查看弹框--会计--导入
export const uploadKjExcel = data => post('gdda-new/gdda/archiveYj/uploadKjExcel', data)
// 查看弹框--声像--录入
export const saveSxMhYjFile = data => post('gdda-new/gdda/archiveYj/saveSxMhYjFile', data)
// 查看弹框--声像--编辑
export const editAcousticImageYjFile = data => post('gdda-new/gdda/archiveYj/editAcousticImageYjFile', data)
// 查看弹框--左侧菜单树
export const listTreeJson = data => post('gdda-new/gdda/archiveView/listTreeJson', data)
// 查看弹框--右侧--基本信息
export const listTreeJsonView= data => post('gdda-new/gdda/archiveView/view', data)
// 查看弹框--右侧--关键档案
export const extendInfoView = data => post('gdda-new/gdda/archiveView/extendInfoView', data)
// 查看弹框--第一级左侧菜单--点击是什么文件
export const powerHandoverDocView = data => post('gdda-new/gdda/util/powerHandoverDocView', data)
// 查看弹框--第一级左侧菜单--查看PDF文件
export const viewHandoverPdf = data => post('gdda-new/gdda/util/viewHandoverPdf', data)

// 综合员审核弹框--确认
export const zhyHandOverSave = data => post('gdda-new/gdda/archiveYj/zhyHandOverSave', data)
// 综合员审核弹框--重发
export const sendZhyShDb = data => post('gdda-new/gdda/archiveYj/sendZhyShDb', data)
// 综合员审核弹框--导出合同移交登记表
export const exportHtTable = data => post('gdda-new/gdda/archiveYj/exportHtTable', data)
// 综合员审核弹框--退回
export const handOverBack = data => post('gdda-new/gdda/archiveYj/handOverBack', data)
// 综合员审核弹框--详情
export const getArchiveYjList = data => post('gdda-new/gdda/archiveYj/getArchiveYjList', data)
// 综合员审核弹框--归档
export const gdHandOverFile = data => post('gdda-new/gdda/archiveYj/gdHandOverFile', data)

// 领导审核弹框--同意
export const tyNoYj = data => post('gdda-new/gdda/archiveYj/tyNoYj', data)
// 领导审核弹框--不同意
export const btyNoYj = data => post('gdda-new/gdda/archiveYj/btyNoYj', data)
// 领导审核弹框--重发领导审核
export const sendLdShDb = data => post('gdda-new/gdda/archiveYj/sendLdShDb', data)


// 档案管理审核--重发领导审核
export const sendGlyShDb = data => post('gdda-new/gdda/archiveYj/sendGlyShDb', data)
// 档案管理审核--管理员审核通过
export const glyShPass = data => post('gdda-new/gdda/archiveYj/glyShPass', data)
// 档案管理审核--确定（投行）
export const glyThShPass = data => post('gdda-new/gdda/archiveYj/glyThShPass', data)
// 档案管理审核--确定（债券）
export const glyZqShPass = data => post('gdda-new/gdda/archiveYj/glyZqShPass', data)
// 档案管理审核--管理员审核退回
export const glyHandOverBack = data => post('gdda-new/gdda/archiveYj/glyHandOverBack', data)
// 档案管理审核--变更移交人
export const changeUserSave = data => post('gdda-new/gdda/archiveYj/changeUserSave', data)


// 档案已移交--退回
export const yyjBackSave = data => post('gdda-new/gdda/archiveYj/yyjBackSave', data)
// 档案已移交--生成移交订单
export const createYjForm = data => post('gdda-new/gdda/archiveYj/createYjForm', data)
// 档案已移交--进行整理
export const zLingThProject = data => post('gdda-new/gdda/archiveYj/zLingThProject', data)
// 档案已移交--认领--校验认领权限
export const checkRlPermissions = data => post('gdda-new/gdda/archiveYj/checkRlPermissions', data)
// 档案已移交--认领
export const handOverClaim = data => post('gdda-new/gdda/archiveYj/handOverClaim', data)
// 档案已移交--同步材料
export const syncDoc = data => post('gdda-new/gdda/archiveYj/syncDoc', data)

// 档案已移交--导出错误信息
export const exportError = data => post('gdda-new/gdda/archiveZL/exportError', data)
// 档案已移交--业务投行录入批次保存
export const saveThHandOver = data => post('gdda-new/gdda/archiveYj/saveThHandOver', data)
// 档案已移交--业务投行录入批次 移交人
export const listClientNoByDept = data => post('gdda-new/gdda/archiveYj/listClientNoByDept', data)
// 档案已移交--业务债券录入批次 移交人
export const saveZqHandOver = data => post('gdda-new/gdda/archiveYj/saveZqHandOver', data)


// 综合审核--查看合同-搜索
export const listProductName = data => post('gdda-new/gdda/archiveYj/listProductName', data)
// 综合审核--查看合同-搜索
export const getProductCodeAndTACode = data => post('gdda-new/gdda/archiveYj/getProductCodeAndTACode', data)
// 综合审核--查看合同-搜索
export const getHTInfo = data => post('gdda-new/gdda/archiveYj/getHTInfo', data)
// 综合审核--查看合同-保存
export const saveHTInfo = data => post('gdda-new/gdda/archiveYj/saveHTInfo', data)
