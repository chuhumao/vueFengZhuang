import axios from 'axios'
import qs from 'qs'
// import {DEV_HOST} from './config'
import router from '@/router'
// export const DEV_HOST = axios.defaults.baseURL = 'http://192.168.0.223:8080' // 开发地址
// export const DEV_HOST = axios.defaults.baseURL = 'http://192.168.0.26:8080' // 潘文东开发地址
// export const DEV_HOST = axios.defaults.baseURL = 'http://192.168.0.16:8081' // 杨书君开发地址
export const DEV_HOST = axios.defaults.baseURL = 'http://192.168.0.47:8081' // 打包地址npm
// export const DEV_HOST = axios.defaults.baseURL = 'http://gf.manage.pro:80' // 打包地址npm
axios.defaults.withCredentials = true

const instance = axios.create({
  // 设置默认根地址
  baseURL: DEV_HOST,
  // 设置请求超时设置
  timeout: 5000,
  // 设置请求时的header
  header: {
    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8'
    /*    'Content-Type': 'application/json' */
  },
  // 公用参数
  data: {}
})

// POST传参序列化
instance.interceptors.request.use((config) => {
  return config
}, (error) => {
  return Promise.reject(error)
})
// 返回状态判断
// http response 拦截器
axios.interceptors.response.use((response) => {
    const data = response.data
    if (data.code === 401) {
         router.push({ name: 'Login' })
    }
    return response;
})
export const fetch = (url, params = {}) => {
  return new Promise((resolve, reject) => {
    axios.get(url, {
        params: params
      })
      .then(response => {
        resolve(response.data);
      })
      .catch(err => {
        reject(err);
      });
  });
};
export const get = (url, params = {}) => {
  return new Promise((resolve, reject) => {
    axios({
        url: `${url}/${params}`,
        methods: 'get'
      })
      .then(response => {
        resolve(response.data);
      })
      .catch(err => {
        reject(err);
      });
  });
};

export const post = (url, data = {}) => {
  return new Promise((resolve, reject) => {
    axios
      .post(url, qs.stringify(data, {
        arrayFormat: 'repeat'
      }))
      .then(response => {
        resolve(response.data);
      })
      .catch(err => {
        reject(err);
      });
  });
};

export const patch = (url, data = {}) => {
  return new Promise((resolve, reject) => {
    axios
      .patch(url, qs.stringify(data, {
        arrayFormat: 'repeat'
      }))
      .then(response => {
        resolve(response.data);
      })
      .catch(err => {
        reject(err);
      });
  });
};

export const put = (url, data = {}) => {
  return new Promise((resolve, reject) => {
    axios
      .put(url, qs.stringify(data))
      .then(response => {
        resolve(response.data);
      })
      .catch(err => {
        reject(err);
      });
  });
};

export const postConfig = (url, data = {}, config) => {
  return new Promise((resolve, reject) => {
    axios
      .post(url, data, config)
      .then(response => {
        resolve(response.data);
      })
      .catch(err => {
        reject(err);
      });
  });
};
