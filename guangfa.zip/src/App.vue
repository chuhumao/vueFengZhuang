<template>
  <div id="app">
    <router-view />
  </div>
</template>
<script>
export default {
  name: 'App',
  created () {
    // console.log([
    //   '                   _ooOoo_',
    //   '                  o8888888o',
    //   '                  88" . "88',
    //   '                  (| ~|~ |)',
    //   '                  O\\ -=- /O',
    //   "               ____/`---'\\____",
    //   "             .'  \\\\|     |//  `.",
    //   '            /  \\\\|||  :  |||//  \\',
    //   '           /  _||||| -:- |||||-  \\',
    //   '           |   | \\\\\\  -  /// |   |',
    //   "           | \\_|  ''\\---/''  |   |",
    //   '           \\  .-\\__  `-`  ___/-. /',
    //   "         ___`. .'  /--.--\\  `. . __",
    //   "      .\"\" '<  `.___\\_<|>_/___.'  >'\"\".",
    //   '     | | :  `- \\`.;`\\ _ /`;.`/ - ` : | |',
    //   '     \\  \\ `-.   \\_ __\\ /__ _/   .-` /  /',
    //   "======`-.____`-.___\\_____/___.-`____.-'======",
    //   "                   `=---='",
    //   '^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^',
    //   '         佛祖保佑       永无BUG'
    // ].join('\n'))
  }
}

</script>
<style lang="less">
html,
body {
  width: 100%;
  height: 100%;
  overflow: hidden;
}

#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  width: 100%;
  height: 100%;
  background-color: #E8EDF4;
  overflow-y: auto;
/*   overflow: auto; */
  /*   text-align: center; */
  /*   color: #2c3e50; */
  /*margin-top: 60px;*/
}

* {
  margin: 0;
  padding: 0;
}
li{list-style: none;}
.clear{
  display: block;
  overflow: hidden;
  clear: both;
}
// 滚动条样式
/*::-webkit-scrollbar{width: 5px; height:9px;background-color: #ccc;}*/
/*::-webkit-scrollbar{width: 10px; height: 20px; background-color: red;}*/

.editorXin{
  >label:before{
    content: '*';
    color: #F56C6C;
    margin-right: 4px;
  }
}
/*删除弹框*/
.hurdleAll{
  >div{
    >div:first-child{
      padding: 0!important;
      >div{
        height: 30px;
        line-height: 30px;
        text-indent: 10px;
        font-size: 14px;
        color: #fff;
      }
      button{
        top: 8px;
        i{
          color:#fff;
        }
      }
    }
  }
  .dialog-title {
    background-color: #0067AD;
    padding: 0;
    height: 30px;
    line-height: 30px;
    img{
      vertical-align: middle;
    }
  }
}
.el-tooltip__popper{
  /*width: 500px!important;*/
  width: 39%!important;
}
//黑色tree选中
.black-tree {
  .el-tree-node.is-current>.el-tree-node__content {
    background-color: #999999 !important;
  }
}
.el-dialog{
  margin-top: 4vh!important;
}
.el-message--error {
  z-index: 9999;
}
</style>
