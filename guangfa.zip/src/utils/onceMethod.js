import { Message } from 'element-ui'
import axios from "axios";
import {DEV_HOST} from "../js/http";
export const onceWay = () => {
  return {
    onceTableList: function (val) {
      if (val.length <= 0) {
        Message.error('请选择一条数据')
      } else if (val.length > 1) {
        Message.error('只能选择一条数据')
      } else return 1
    },
    onceTableListTwo: function (val) {
      if (val.length <= 0) {
        Message.error('请选择一条数据')
      } else return 1
    },
    deleteId (val) {
      let item = ''
      val.forEach((itemVal, index) => {
        item += itemVal.id + ','
      })
      return item
    },
    showOpeningType: function (val) {
      if (val == 1) return '公开'
      else if (val == 2) return '内部'
      else if (val == 3) return '受控'
      else if (val == 5) return '商密二级'
      else if (val == 6) return '商密一级'
    },
    showRetentionPeriod: function (val) {
      if (val == 1) return '短期'
      else if (val == 2) return '长期'
      else if (val == 3) return '永久'
      else if (val == 4) return '3年'
      else if (val == 5) return '10年'
      else if (val == 6) return '15年'
      else if (val == 7) return '25年'
      else if (val == 8) return '30年'
      else if (val == 9) return '5年'
      else if (val == 10) return '35年'
    },
    showC59: function (val) {
      if (val == 0) return '是'
      else if (val == -1) return '否'
    },
    showC93: function (val) {
      if (val == 0) return '可见'
      else if (val == 1) return '隐藏'
    },
    wordPull: function (url, filename, params) {
      axios({
        method: 'get',
        url: DEV_HOST +'/'+ url,
        params: params,
        responseType: 'blob' // 二进制流
      }).then(res => {
        Message.success('下载成功');
        const blob = new Blob([res.data], {
          type: 'application/vnd.ms-excel;charset=utf-8'
        })
        const downloadElement = document.createElement('a');
        const href = window.URL.createObjectURL(blob);
        downloadElement.href = href;
        downloadElement.download = filename;
        document.body.appendChild(downloadElement);
        downloadElement.click();
        document.body.removeChild(downloadElement); // 下载完成移除元素
        window.URL.revokeObjectURL(href) // 释放掉blob对象
      }).catch(err => {
        console.log(err);
        Message.error("请求超时");
      })
    }
  }
}
