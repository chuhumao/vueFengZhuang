<template>
  <div>
    <el-button type="text" @click="dialogVisible = true">打开移交状态</el-button>
    <el-button type="text" @click="dialogVisible1 = true">打开通知公告</el-button>
    <el-button type="text" @click="dialogVisible2 = true">打开档案查询</el-button>
    <el-button type="text" @click="dialogVisible3 = true">打开借阅单提交</el-button>
    <el-button type="text" @click="dialogVisible4 = true">打开通知公告-阅读</el-button>
    <el-button type="text" @click="dialogVisible5 = true">打开流程指引</el-button>
    <el-button type="text" @click="dialogVisible6 = true">打开专题</el-button>

    <!-- 移交状态 -->
    <el-dialog class="give hand-over" :visible.sync="dialogVisible">
      <div slot="title" class="titl">
        <img src="./send.png" alt />
        移交状态
      </div>
      <table class="content" cellspacing="0" cellpadding="0" border="0">
        <tr>
          <td>文件号</td>
          <td>111</td>
        </tr>
        <tr>
          <td>合同号</td>
          <td>111</td>
        </tr>
        <tr>
          <td>文件标题</td>
          <td>111</td>
        </tr>
        <tr>
          <td>对方单位</td>
          <td>111</td>
        </tr>
        <tr>
          <td>文件日期</td>
          <td>111</td>
        </tr>
        <tr>
          <td>文件类型</td>
          <td>111</td>
        </tr>
        <tr>
          <td>是否原件</td>
          <td>111</td>
        </tr>
        <tr>
          <td>公章等级</td>
          <td>111</td>
        </tr>
        <tr>
          <td>移交异常</td>
          <td>111</td>
        </tr>
      </table>
    </el-dialog>

    <!-- 通知公告 -->
    <el-dialog :visible.sync="dialogVisible1" class="inform give">
      <div slot="title" class="titl">
        <img src="./inform.png" alt />
        通知公告
      </div>
      <div>
        <el-table border :data="tableData" style="width: 100%">
          <el-table-column prop="date" label="题名"></el-table-column>
          <el-table-column prop="name" label="创建时间"></el-table-column>
        </el-table>
        <div class="page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage4"
            :page-sizes="[100, 200, 300, 400]"
            :page-size="100"
            layout="sizes, prev, pager, next, jumper,total"
            :total="400"
          ></el-pagination>
        </div>
      </div>
    </el-dialog>

    <!-- 档案查询 -->
    <el-dialog :visible.sync="dialogVisible2" class="search-file give">
      <div slot="title" class="titl">
        <img src="./search.png" alt />
        档案查询
      </div>
      <div class="top">
        <div class="search">
          <el-input v-model="input" placeholder="请输入内容"></el-input>
          <el-button type="primary" class="blue">检索</el-button>
          <el-radio-group v-model="radio">
            <el-radio :label="3">附件</el-radio>
            <el-radio :label="6">目录</el-radio>
            <el-radio :label="9">案卷</el-radio>
            <el-radio :label="12">项目</el-radio>
          </el-radio-group>
        </div>

        <div class="common">
          <div class="label">
            <label for>拟稿人</label>
          </div>

          <el-select v-model="select" slot="prepend" placeholder="请输入姓名检索">
            <el-option label="餐厅名" value="1"></el-option>
            <el-option label="订单号" value="2"></el-option>
            <el-option label="用户电话" value="3"></el-option>
          </el-select>
        </div>
        <div class="common">
          <div class="label">
            <label for>拟稿部门</label>
          </div>

          <el-select v-model="select1" slot="prepend" placeholder="请输入部门检索">
            <el-option label="餐厅名" value="1"></el-option>
            <el-option label="订单号" value="2"></el-option>
            <el-option label="用户电话" value="3"></el-option>
          </el-select>
        </div>
        <div class="common">
          <div class="label">
            <label for>文件类型</label>
          </div>

          <el-select v-model="select2" slot="prepend" placeholder="请选择">
            <el-option label="餐厅名" value="1"></el-option>
            <el-option label="订单号" value="2"></el-option>
            <el-option label="用户电话" value="3"></el-option>
          </el-select>
        </div>
        <div class="common">
          <div class="label">
            <label>来源系统</label>
          </div>

          <el-select v-model="select3" slot="prepend" placeholder="请选择">
            <el-option label="餐厅名" value="1"></el-option>
            <el-option label="订单号" value="2"></el-option>
            <el-option label="用户电话" value="3"></el-option>
          </el-select>
        </div>
        <div class="common">
          <div class="label">
            <label for>年度</label>
          </div>

          <el-select v-model="select4" slot="prepend" placeholder="请选择">
            <el-option label="餐厅名" value="1"></el-option>
            <el-option label="订单号" value="2"></el-option>
            <el-option label="用户电话" value="3"></el-option>
          </el-select>
        </div>
        <el-button type="primary" class="blue">
          <img src="./reset.png" alt />
          重置
        </el-button>
        <div class="gray-button">
          <el-button type="primary" class="gray">默认排序</el-button>
          <el-button type="primary" class="gray">年度</el-button>
          <el-button type="primary" class="gray">归档部门</el-button>
          <el-button type="primary" class="gray">文件日期</el-button>
        </div>
      </div>
      <div class="bottom"></div>
    </el-dialog>

    <!-- 借阅单提交 -->
    <el-dialog :visible.sync="dialogVisible3" class="search-file borrow-submit give">
      <div slot="title" class="titl">
        <img src="./borrow.png" alt />
        借阅单提交
      </div>
      <div class="head">
        <el-button class="borrow">
          <img src="./delete.png" alt />
          删除
        </el-button>

        <el-table :data="tableData" border style="width: 100%">
          <el-table-column type="index" width="80"></el-table-column>
          <el-table-column type="selection" width="80"></el-table-column>
          <el-table-column prop="date" label="档号" width="180"></el-table-column>
          <el-table-column prop="name" label="题名" width="180"></el-table-column>
          <el-table-column prop="address" label="全宗"></el-table-column>
          <el-table-column prop="address" label="公开属性"></el-table-column>
          <el-table-column prop="address" label="归档部门"></el-table-column>
        </el-table>
        <div class="page">
          <el-pagination
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
            :current-page="currentPage4"
            :page-sizes="[100, 200, 300, 400]"
            :page-size="100"
            layout="sizes, prev, pager, next, jumper,total"
            :total="400"
          ></el-pagination>
        </div>
      </div>

      <div class="top">
        <div class="header">电子借阅单</div>

        <div class="common">
          <div class="label">
            <label for>借阅人：</label>
          </div>
          <el-input v-model="input1" placeholder="请输入内容"></el-input>
        </div>
        <div class="common">
          <div class="label">
            <label for>借阅部门：</label>
          </div>
          <el-input v-model="input2" placeholder="请输入内容"></el-input>
        </div>
        <div class="common">
          <div class="label">
            <label for>联系方式：</label>
          </div>
          <el-input v-model="input3" placeholder="请输入内容"></el-input>
        </div>
        <div class="common">
          <div class="label">
            <label for>申请日期：</label>
          </div>
          <el-input v-model="input4" placeholder="请输入内容"></el-input>
        </div>
        <div class="common">
          <div class="label">
            <label for>借阅方式：</label>
          </div>

          <el-select v-model="select5" slot="prepend" placeholder="请输入姓名检索">
            <el-option label="餐厅名" value="1"></el-option>
            <el-option label="订单号" value="2"></el-option>
            <el-option label="用户电话" value="3"></el-option>
          </el-select>
        </div>
        <div class="common">
          <div class="label">
            <label for>借阅时间(天)：</label>
          </div>

          <el-select v-model="select6" slot="prepend" placeholder="请输入部门检索">
            <el-option label="餐厅名" value="1"></el-option>
            <el-option label="订单号" value="2"></el-option>
            <el-option label="用户电话" value="3"></el-option>
          </el-select>
        </div>
        <div class="common">
          <div class="label">
            <label for>是否加水印：</label>
          </div>

          <el-select v-model="select7" slot="prepend" placeholder="请选择">
            <el-option label="餐厅名" value="1"></el-option>
            <el-option label="订单号" value="2"></el-option>
            <el-option label="用户电话" value="3"></el-option>
          </el-select>
        </div>
        <div class="common">
          <div class="label">
            <label>对内/外部使用：</label>
          </div>

          <el-select v-model="select8" slot="prepend" placeholder="请选择">
            <el-option label="餐厅名" value="1"></el-option>
            <el-option label="订单号" value="2"></el-option>
            <el-option label="用户电话" value="3"></el-option>
          </el-select>
        </div>
        <div class="area">
          <div class="label">
            <label for>借阅原因：</label>
          </div>
          <el-input
            type="textarea"
            :autosize="{ minRows: 2, maxRows: 4}"
            placeholder="请输入内容"
            v-model="textarea2"
          ></el-input>
        </div>
        <div class="gray-button">
          <el-button type="primary" class="borrow">
            <img src="./submit.png" alt />
            提交订阅
          </el-button>
          <el-button type="primary" class="borrow">
            <img src="./guanbi.png" alt />
            关闭
          </el-button>
        </div>
      </div>
    </el-dialog>

    <!-- 通知公告-阅读 -->
    <el-dialog :visible.sync="dialogVisible4" class="give read">
      <div slot="title" class="titl">
        <img src="./read.png" alt />
        通知公告
      </div>
      <div class="read-content"></div>
      <div class="gray-button">
        <el-button type="primary" class="borrow">
          <img src="./yidu.png" alt />
          已读
        </el-button>
        <el-button type="primary" class="borrow">
          <img src="./weidu.png" alt />
          未读
        </el-button>
      </div>
    </el-dialog>

    <!-- 流程指引 -->
    <el-dialog :visible.sync="dialogVisible5" class="give process">
      <div slot="title" class="titl">
        <img src="./process.png" alt />
        流程指引
      </div>
      <div class="process-content">
        <div class="left">
          <div class="headline-top">全部</div>
          <div v-for="(item,index) in data" :key="index" class="headline" @click="toContent(index)">
            <img src="./yuan.png" alt v-show="yuan" />
            <!-- <img src="./hover.png" alt="" v-show="!yuan"> -->
            替代文字
          </div>
        </div>
        <div class="right">
          <div class="content-top">
            <!-- <span class="triangle_border_right"></span> -->
            代替文字
          </div>
          <div class="content" v-show="active == 0">0</div>
          <div class="content" v-show="active == 1">1</div>
        </div>
      </div>
    </el-dialog>

    <!-- 专题 -->
    <el-dialog :visible.sync="dialogVisible6" class="give special">
      <div class="special-top">
        <el-tabs v-model="activeName" @tab-click="handleClick">
          <el-tab-pane label="专题栏" name="first">
            <div class="article">
              <div class="article-head">
                <img src="./article.png" alt />
                专题栏文章
              </div>
              <div class="article-content">
                <img src="./content.png" alt />
                <div class="word">
                  <h2>文章标题</h2>
                  <p>文章内容</p>
                  <div class="foot">
                    <span>作者姓名</span>
                    <span>昨天15:28</span>
                  </div>
                </div>
              </div>
              <div class="article-content">
                <img src="./content.png" alt />
                <div class="word">
                  <h2>文章标题</h2>
                  <p>文章内容</p>
                  <div class="foot">
                    <span>作者姓名</span>
                    <span>昨天15:28</span>
                  </div>
                </div>
              </div>
              <div class="article-content">
                <img src="./content.png" alt />
                <div class="word">
                  <h2>文章标题</h2>
                  <p>文章内容</p>
                  <div class="foot">
                    <span>作者姓名</span>
                    <span>昨天15:28</span>
                  </div>
                </div>
              </div>
              <div class="article-content">
                <img src="./content.png" alt />
                <div class="word">
                  <h2>文章标题</h2>
                  <p>文章内容</p>
                  <div class="foot">
                    <span>作者姓名</span>
                    <span>昨天15:28</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="hot">
              <div class="search-title">
                <span></span>
                专业搜索
              </div>
              <div class="search">
                <el-input v-model="input" placeholder="请输入内容"></el-input>
                <button>
                  <img src="./zhuanlan_search.png" alt />
                </button>
              </div>
              <div class="hot-topic">
                <div class="hot-head">
                  <img src="./24hour.png" alt />
                  24h热专题
                </div>
                <div class="hot-word">
                  <p>内容</p>
                </div>
                <div class="hot-word">
                  <p>内容</p>
                </div>
                <div class="hot-word">
                  <p>内容</p>
                </div>
                <div class="hot-word">
                  <p>内容</p>
                </div>
                <div class="hot-word">
                  <p>内容</p>
                </div>
                <div class="hot-word">
                  <p>内容</p>
                </div>
                <div class="hot-word">
                  <p>内容</p>
                </div>
              </div>
            </div>
          </el-tab-pane>
          <el-tab-pane label="名人堂" name="second">
            <div class="famous">
              <div class="img">
                <img src="./famous.png" alt />
              </div>
              <div class="detail">
                <p class="name">程树荣</p>
                <div class="experience">
                  <div class="experience-left">
                    <img src="./experience.png" alt />
                  </div>
                  <div class="experience-right">
                    <p>1</p>
                    <p>2</p>
                    <p>3</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="famous">
              <div class="img">
                <img src="./famous.png" alt />
              </div>
              <div class="detail">
                <p class="name">程树荣</p>
                <div class="experience">
                  <div class="experience-left">
                    <img src="./experience.png" alt />
                  </div>
                  <div class="experience-right">
                    <p>1</p>
                    <p>2</p>
                    <p>3</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="famous">
              <div class="img">
                <img src="./famous.png" alt />
              </div>
              <div class="detail">
                <p class="name">程树荣</p>
                <div class="experience">
                  <div class="experience-left">
                    <img src="./experience.png" alt />
                  </div>
                  <div class="experience-right">
                    <p>1</p>
                    <p>2</p>
                    <p>3</p>
                  </div>
                </div>
              </div>
            </div>
          </el-tab-pane>
          <el-tab-pane label="荣誉榜" name="third">
            <div class="article">
              <div class="article-head">
                <img src="./article.png" alt />
                专题栏文章
              </div>
              <div class="article-content">
                <img src="./content.png" alt />
                <div class="word">
                  <h2>文章标题</h2>
                  <p>文章内容</p>
                  <div class="foot">
                    <span>作者姓名</span>
                    <span>昨天15:28</span>
                  </div>
                </div>
              </div>
              <div class="article-content">
                <img src="./content.png" alt />
                <div class="word">
                  <h2>文章标题</h2>
                  <p>文章内容</p>
                  <div class="foot">
                    <span>作者姓名</span>
                    <span>昨天15:28</span>
                  </div>
                </div>
              </div>
              <div class="article-content">
                <img src="./content.png" alt />
                <div class="word">
                  <h2>文章标题</h2>
                  <p>文章内容</p>
                  <div class="foot">
                    <span>作者姓名</span>
                    <span>昨天15:28</span>
                  </div>
                </div>
              </div>
              <div class="article-content">
                <img src="./content.png" alt />
                <div class="word">
                  <h2>文章标题</h2>
                  <p>文章内容</p>
                  <div class="foot">
                    <span>作者姓名</span>
                    <span>昨天15:28</span>
                  </div>
                </div>
              </div>
            </div>
            <div class="hot">
              <div class="search-title">
                <span></span>
                专业搜索
              </div>
              <div class="search">
                <el-input v-model="input" placeholder="请输入内容"></el-input>
                <button>
                  <img src="./zhuanlan_search.png" alt />
                </button>
              </div>
              <div class="hot-topic">
                <div class="hot-head">
                  <img src="./24hour.png" alt />
                  24h热专题
                </div>
                <div class="hot-word">
                  <p>内容</p>
                </div>
                <div class="hot-word">
                  <p>内容</p>
                </div>
                <div class="hot-word">
                  <p>内容</p>
                </div>
                <div class="hot-word">
                  <p>内容</p>
                </div>
                <div class="hot-word">
                  <p>内容</p>
                </div>
                <div class="hot-word">
                  <p>内容</p>
                </div>
                <div class="hot-word">
                  <p>内容</p>
                </div>
              </div>
            </div>
          </el-tab-pane>
        </el-tabs>
      </div>
    </el-dialog>
  </div>
</template>

<script>
export default {
  data() {
    return {
      // 移交状态
      dialogVisible: false,
      // 通知公告
      dialogVisible1: false,
      tableData: [
        {
          date: "2016-05-02",
          name: "王小虎"
        },
        {
          date: "2016-05-04",
          name: "王小虎"
        },
        {
          date: "2016-05-01",
          name: "王小虎"
        },
        {
          date: "2016-05-03",
          name: "王小虎"
        }
      ],
      currentPage4: 4,
      // 档案查询
      dialogVisible2: false,
      radio: 3,
      input: "",
      select: "",
      select1: "",
      select2: "",
      select3: "",
      select4: "",
      // 借阅订单提交
      dialogVisible3: false,
      textarea2: "",
      input1: "",
      input2: "",
      input3: "",
      input4: "",
      select5: "",
      select6: "",
      select7: "",
      select8: "",
      tableData1: [
        {
          date: "2016-05-03",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-02",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-04",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-01",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-08",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-06",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        },
        {
          date: "2016-05-07",
          name: "王小虎",
          address: "上海市普陀区金沙江路 1518 弄"
        }
      ],
      // 通知公告-阅读
      dialogVisible4: false,
      // 流程指引
      dialogVisible5: false,
      yuan: true,
      data: [1, 1],
      active: "",
      // 专题
      dialogVisible6: false,
      activeName: "second"
    };
  },
  methods: {
    // 通知公告
    handleSizeChange(val) {
      console.log(`每页 ${val} 条`);
    },
    handleCurrentChange(val) {
      console.log(`当前页: ${val}`);
    },
    // 借阅订单提交
    toggleSelection(rows) {
      if (rows) {
        rows.forEach(row => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      } else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    // 流程流程指引
    toContent(index) {
      this.active = index;
    },
    // 专题
    handleClick(tab, event) {
      console.log(tab, event);
    }
  }
};
</script>

<style scoped lang='less'>
@import "../css/dialog.less";
</style>
