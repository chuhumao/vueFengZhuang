<template>
  <div>
    <el-table
      :data="tableData"
      style="width: 100%">
      <el-table-column
        prop="date"
        label="日期"
        width="180">
      </el-table-column>
      <el-table-column
        prop="name"
        label="姓名"
        width="180">
        <template slot-scope="scope">
          <el-input v-model="scope.row.name" placeholder="请输入内容"></el-input>
        </template>
      </el-table-column>
      <el-table-column
        prop="address"
        label="地址">
        <template slot-scope="scope">
          <el-input v-model="scope.row.address" placeholder="请输入内容"></el-input>
        </template>
      </el-table-column>
    </el-table>
    <button @click="addBtn">添加</button>
  </div>
</template>

<script>
export default {
  name: 'testSelect',
  data () {
    return {
      tableData: []
    }
  },
  methods: {
    addBtn () {
      let params = {
        date: '三生三世',
        name: null,
        address: null
      }
      this.tableData.push(params)
    }
  }
}
</script>

<style scoped lang="less">
  @import "../css/public";
</style>
