<!-- 欠交 -->
<template>
  <div style="background-color: #fff">
    <!-- 搜索 -->
    <div style="padding: 10px 0;">
      <div class="search-select">
        <label>全宗：</label>
        <el-select v-model="params.fonds" filterable placeholder="请选择" @change="yjTypeBtn">
          <el-option
            v-for="item in fullZong"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
      </div>
      <div class="search-select">
        <label>档案类型：</label>
        <el-select v-model="params.series1" filterable placeholder="请选择" @change="searchSeries">
          <el-option v-for="item in FondsAndRole" :key="item.id" :label="item.name" :value="item.id"></el-option>
        </el-select>
        <el-select v-model="params.series2" filterable placeholder="请选择" @change="searchSeriesTwo">
          <el-option v-for="item in FondsAndRoleTwo" :key="item.id" :label="item.name" :value="item.id"></el-option>
        </el-select>
        <el-select v-model="params.series3" filterable placeholder="请选择" @change="searchSeriesThree">
          <el-option v-for="item in FondsAndRoleThree" :key="item.id" :label="item.name" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="search-select">
        <label>移交类型：</label>
        <el-select v-model="params.yjType" filterable placeholder="请选择" @change="yjTypeBtnTwo">
          <el-option
            v-for="item in handoverTypeModel"
            :key="item.itemValue"
            :label="item.name"
            :value="item.itemValue">
          </el-option>
        </el-select>
      </div>
      <div class="search-select" @click="brachBtn">
        <span style="cursor: pointer;">批量挂接</span>
      </div>
      <div class="clear"></div>
    </div>
    <!-- 上操作 -->
    <div style="background-color: #F4F4F4;">
      <div class="searchBtn" @click="tureOverBtn">
        <img src="../../assets/turnOver/yj.png" alt="">
        <span>移交</span>
      </div>
      <div class="searchBtn" @click="searchContent">
        <img src="../../assets/turnOver/js.png" alt="">
        <span>检索</span>
      </div>
      <div class="searchBtn" @click="lrYjPcBtn">
        <img src="../../assets/turnOver/lr.png" alt="">
        <span v-if="params.series2 == 1388742017297">录入投行移交批次</span>
        <span v-else-if="params.series2 == 1388742017298">录入债券移交批次</span>
        <span v-else>录入模糊移交批次</span>
      </div>
      <div class="searchBtn" @click="retryBtn">
        <img src="../../assets/turnOver/cf.png" alt="">
        <span>重发移交确认代办</span>
      </div>
      <div class="searchBtn" @click="wireBtn" v-if="params.series1 != 1388742017296">
        <img src="../../assets/turnOver/yj.png" alt="">
        <span>线下移交</span>
      </div>
      <div class="searchBtn" @click="toOrderBtn" v-if="showMehod">
        <img src="../../assets/turnOver/ds.png" alt="">
        <span>定时设置</span>
      </div>
      <div class="clear"></div>
    </div>
    <!-- 上表格 -->
    <div class="all-Table">
      <el-table
        ref="multipleTable"
        :data="tableData"
        stripe
        border
        @selection-change="handleSelectionChange">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="status"
          label="移交状态"
          width="180">
          <template slot-scope="scope">
            <span v-if="scope.row.status == 1">欠交</span>
            <span v-else-if="scope.row.status == 2">综合员移交</span>
            <span v-else-if="scope.row.status == 3">领导审核</span>
            <span v-else-if="scope.row.status == 4">档案员审核</span>
            <span v-else-if="scope.row.status == 5">已移交</span>
            <span v-else-if="scope.row.status == 6">不移交</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="serialNumber"
          label="移交单号"
          width="250">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverUser"
          label="移交人姓名"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverDept"
          label="移交部门"
          width="317">
        </el-table-column>
        <el-table-column
          v-if="params.series2 == 1388742017297 || params.series2 == 1388742017298"
          show-overflow-tooltip
          prop="handoverStyle"
          label="移交类型"
          width="160">
          <template slot-scope="scope">
            <span v-if="scope.row.handoverStyle == 0">精确移交</span>
            <span v-else-if="scope.row.handoverStyle == 1">模糊移交</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverType"
          label="移交方式"
          width="160">
          <template slot-scope="scope">
            <span v-if="scope.row.handoverType == 1">邮寄</span>
            <!--<span v-else-if="scope.row.handoverType == 2">本人亲自移交</span>-->
            <span v-else>面交</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverYdh"
          label="运单号"
          width="179">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverDate"
          label="移交时间"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="tagName"
          label="档案类型"
          width="180">
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <div class="pageLayout">
      <el-pagination
        @current-change="handleCurrentChange"
        :current-page="params.page"
        :page-size="params.rows"
        layout="prev, pager, next, jumper"
        :total="params.total">
      </el-pagination>
    </div>

    <!-- 下操作 -->
    <div style="background-color: #F4F4F4;">
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="showLookBtn">
        <img src="../../assets/turnOver/ck.png" alt="">
        <span>查看</span>
      </div>
      <div class="clear"></div>
    </div>
    <!-- 下表格 -->
    <div v-if="params.series1 == 1388742017296" class="all-Table">
      <el-table
        ref="multipleTableBtomTwo"
        :data="tableDataTwo"
        stripe
        border
        @selection-change="handleSelectionChangeBtom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverThNumber"
          label="序号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverEmployer"
          label="项目单位全称"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileType"
          label="项目类型"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverHt"
          label="业务类型"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="项目名称"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          label="项目结束年度"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileCode"
          label="移交箱数"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileNum"
          label="移交册数"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="gzhangLevel"
          label="快递单号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverDate"
          label="移交时间"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverPc"
          label="移交批次"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverException"
          label="移交异常"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverNote"
          label="备注"
          width="120">
        </el-table-column>
      </el-table>
    </div>
    <div v-else-if="params.series1 == 1388742017269" class="all-Table">
      <el-table
        ref="multipleTableBtomTwo"
        :data="dialogTableBtom"
        stripe
        border
        @selection-change="handleSelectionChangeBtomTwo">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="archivalCode"
          label="档号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverEmployer"
          label="所属部门"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="serialNumber"
          label="案卷号"
          width="230">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileType"
          label="类别"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="卷（册、袋）标题"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="startDate"
          label="起始时间"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="endDate"
          label="终止时间"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverHt"
          label="凭证起始号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="gzhangLevel"
          label="保管期限"
          width="160">
          <template slot-scope="scope">
            <span v-if="scope.row.gzhangLevel == 3">永久</span>
            <span v-else-if="scope.row.gzhangLevel == 2">长期</span>
            <span v-else-if="scope.row.gzhangLevel == 1">短期</span>
            <span v-else-if="scope.row.gzhangLevel == 5">10年</span>
            <span v-else-if="scope.row.gzhangLevel == 6">15年</span>
            <span v-else-if="scope.row.gzhangLevel == 8">30年</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileNum"
          label="卷内张数"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverNote"
          label="备考"
          width="160">
        </el-table-column>
      </el-table>
    </div>
    <div v-else-if="params.series2 == 1374133285844" class="all-Table">
      <el-table
        ref="multipleTableBtomTwo"
        :data="dialogTableBtom"
        stripe
        border
        @selection-change="handleSelectionChangeBtomTwo">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="caseNo"
          label="盒号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverThNumber"
          label="件号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="印章名称"
          width="220">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverPc"
          label="刻制年度"
          width="230">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          label="刻制日期"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverEmployer"
          label="责任者"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="gzhangLevel"
          label="保管期限"
          width="160">
          <template slot-scope="scope">
            <span v-if="scope.row.retentionPeriod == 3">永久</span>
            <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
            <span v-else-if="scope.row.retentionPeriod == 1">短期</span>
            <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
            <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
            <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileType"
          label="印章种类"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverHt"
          label="印章形状"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="sealStatus"
          label="印章状态"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverNote"
          label="备注"
          width="160">
        </el-table-column>
      </el-table>
    </div>
    <div v-else-if="params.series2 == 1374133285845 || params.series2 == 1374133285846 || params.series2 == 1374133285847
          || params.series2 == 1374133285848 || params.series2 == 1374133285849" class="all-Table">
      <el-table
        ref="multipleTableBtomTwo"
        :data="dialogTableBtom"
        stripe
        border
        @selection-change="handleSelectionChangeBtomTwo">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverThNumber"
          label="件号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverPc"
          label="年度"
          width="230">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="名称"
          width="200">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          label="获奖日期"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverEmployer"
          label="对方单位"
          width="200">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileType"
          label="类别"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverNote"
          label="备注"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="belongDept"
          label="所属部门"
          width="200">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="author"
          label="责任者"
          width="160">
        </el-table-column>
      </el-table>
    </div>
    <div v-else-if="params.series1 == 1374133285828" class="all-Table">
      <el-table
        ref="multipleTableBtomTwo"
        :data="dialogTableBtom"
        stripe
        border
        @selection-change="handleSelectionChangeBtomTwo">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverThNumber"
          label="件号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="题名"
          width="230">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="theme"
          label="主题"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          label="拍摄时间"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="site"
          label="地点"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="background"
          label="背景"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="personage"
          label="人物(职务)"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="photographer"
          label="摄(录)者"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="belongDept"
          label="所属部门"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverNote"
          label="内容简介"
          width="160">
        </el-table-column>
      </el-table>
    </div>
    <div v-else class="all-Table">
      <el-table
        ref="multipleTableBtom"
        :data="tableDataTwo"
        stripe
        border
        @selection-change="handleSelectionChangeBtom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileCode"
          label="文件号"
          width="220">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverHt"
          label="合同号"
          width="180">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="文件标题"
          width="250">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverEmployer"
          label="对方单位"
          width="180">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          sortable
          label="文件日期"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileType"
          label="文件类型"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="isOriginal"
          label="是否原件"
          width="120">
          <template slot-scope="scope">
            <span v-if="scope.row.isOriginal == 0">是</span>
            <span v-else-if="scope.row.isOriginal == 1">否</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="gzhangLevel"
          label="公章等级"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverException"
          label="移交异常"
          width="159">
        </el-table-column>
      </el-table>
    </div>
    <!-- 下分页 -->
    <div class="pageLayout">
      <!--<el-pagination
        @current-change="handleCurrentChangeTwo"
        :current-page="paramsTwo.page"
        :page-size="paramsTwo.rows"
        layout="prev, pager, next, jumper"
        :total="paramsTwo.total">
      </el-pagination>-->
      <el-pagination
        @current-change="handleCurrentChangeTwo"
        :current-page.sync="paramsTwo.page"
        :page-size="paramsTwo.rows"
        layout="prev, pager, next, jumper"
        :total="paramsTwo.total">
      </el-pagination>
    </div>

    <!-- 模糊移交交单弹框 -->
    <el-dialog :visible.sync="dialogShowContent" width="1111px" class="hurdleAll" :before-close="handleClose">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/mh.png" alt="">
        模糊移交交单
      </div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li>
            <label>移交人姓名：</label>
            <el-input v-model="showEdit.handoverUser" readonly></el-input>
          </li>
          <li>
            <label>移交部门：</label>
            <el-input v-model="showEdit.handoverDept" readonly></el-input>
          </li>
          <li>
            <label>移交时间：</label>
            <el-input v-model="showEdit.handoverDate" readonly></el-input>
          </li>
          <!--<li>-->
          <!--<label>操作指引：</label>-->
          <!--<el-button type="primary">下载</el-button>-->
          <!--</li>-->
          <div class="clear"></div>
        </ul>
        <!--中-->
        <ul class="mangeShow">
          <li>
            <label>接收人：</label>
            <el-input v-model="showEdit.receiveUser" readonly></el-input>
          </li>
          <li>
            <label>接收方式：</label>
            <el-select v-model="showEdit.handoverType"  placeholder="请选择" filterable @change="receiveBtn">
              <el-option
                v-for="item in handoverTypeList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <li v-if="!showDisable">
            <label>接收地址：</label>
            <el-input v-model="showEdit.receiveAddress" placeholder="请输入接收地址"></el-input>
          </li>
          <div class="clear"></div>
        </ul>
        <ul class="mangeShow">
          <li>
            <label>变更移交人：</label>
            <el-select v-model="showEdit.userId"  placeholder="请输入移交人检索" filterable remote reserve-keyword :remote-method="orgFlag">
              <el-option
                v-for="item in sqFondsList"
                :key="item.id"
                :label="item.text"
                :value="item.id">
              </el-option>
            </el-select>
          </li>
          <li>
            <label>运单号：</label>
            <el-input v-model="showEdit.handoverYdh" :disabled="showDisable"></el-input>
          </li>
          <li>
            <label>运营商：</label>
            <el-select v-model="showEdit.handoverYys"  placeholder="请选择" filterable :disabled="showDisable">
              <el-option
                v-for="item in handoverYysList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList">
          <label>申请人意见：</label>
          <el-input
            type="textarea"
            :rows="2"
            placeholder="提醒：请在申请意见中写明需移交档案内容及数量，点击“确认”即可。
 例：申请移交历史部门印章登记表，共6册，请档案中心评估接收。"
            v-model="showEdit.applyRemarkCopy">
          </el-input>
        </div>
        <!--下-列表-->
        <div class="mangeShowList">
          <p>意见详情：</p>
          <div class="showReadOnlyContent" v-if="showEdit.isOldDate == 0">
            <div v-html="showEdit.handoverRemark"></div>
          </div>
          <!-- 表格 -->
          <div class="all-Table" v-else-if="showEdit.isOldDate == 1" style="width: 83%;max-height: 300px;overflow: auto;margin: 0 auto;">
            <el-table
              :data="dialogTable"
              stripe
              border
              style="width: 100%">
              <el-table-column
                show-overflow-tooltip
                prop="handoverRemark"
                label="意见内容">
                <template slot-scope="scope">
                  <div v-for="(item, index) in scope.row.handoverRemark" :key="index">{{ item }}</div>
                </template>
              </el-table-column>
              <el-table-column
                prop="date"
                label="时间">
              </el-table-column>
              <el-table-column
                prop="sendName"
                label="操作人">
              </el-table-column>
            </el-table>
          </div>
        </div>
        <!--合同介绍-->
        <div class="mangeShowList">
          <label>合同上传要求：</label>
          <div class="heTong">
            1,文件彩色扫描为pdf格式；<br/>
            2,命名格式：原OA流程：公司公章："年份+合同号",例：2017年第0001号001份。部门公章：合同名称-扫描件,例：房屋租赁合同-扫描件。
            <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            BPM流程：不区分公司公章与部门公章，均以流程显示的合同号为准。例：广发证券[2018]001234号合同
          </div>
        </div>
      </div>
      <!-- 下操作 -->
      <div class="maxHeight">
        <div style="background-color: #F4F4F4;">
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn"  @click="showLookBtnTwo">
            <img src="../../assets/turnOver/ck.png" alt="">
            <span>查看</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn2">
            <img src="../../assets/turnOver/yj.png" alt="">
            <span>下次移交</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="getDataViewDialog3 = true">
            <img src="../../assets/turnOver/sx.png" alt="">
            <span>刷新内容</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn4">
            <img src="../../assets/turnOver/lr.png" alt="">
            <span>录入</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn5">
            <img src="../../assets/turnOver/bj.png" alt="">
            <span>编辑</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn6">
            <img src="../../assets/turnOver/delete.png" alt="">
            <span>删除</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn7">
            <img src="../../assets/turnOver/sc.png" alt="">
            <span>上传</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <!--<div class="searchBtn" @click="clearImgDel, getDataViewDialog9 = true">-->
          <div class="searchBtn" @click="daoRuExcel">
            <img src="../../assets/turnOver/dr.png" alt="">
            <span>导入Excel</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn10">
            <img src="../../assets/turnOver/delete.png" alt="">
            <span>删除附件</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn11">
            <img src="../../assets/turnOver/tj.png" alt="">
            <span>添加异常</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn12">
            <img src="../../assets/turnOver/s5.png" alt="">
            <span>导出Excel模板</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 下表格 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtomTwo"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileCode"
              label="文件号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="文件标题"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              sortable
              label="文件日期"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverPc"
              label="年度">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="isOriginal"
              label="是否原件"
              width="100">
              <template slot-scope="scope">
                <span v-if="scope.row.isOriginal == 0">是</span>
                <span v-else-if="scope.row.isOriginal == 1">否</span>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverException"
              label="移交异常"
              width="500">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeTwo2"
            :current-page="paramsTwo1.page"
            :page-size="paramsTwo1.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo1.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="mangeBtn">确定</el-button>
        <el-button @click="dialogShowContent = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 线下移交交单弹框 -->
    <el-dialog :visible.sync="dialogShowContent2" width="1111px" class="hurdleAll" :before-close="handleClose">
      <div slot="title" class="dialog-title">线下移交交单</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li>
            <label>移交人姓名：</label>
            <el-input v-model="showEdit.handoverUser" readonly></el-input>
          </li>
          <li>
            <label>移交部门：</label>
            <el-input v-model="showEdit.handoverDept" readonly></el-input>
          </li>
          <li>
            <label>移交时间：</label>
            <el-input v-model="showEdit.handoverDate" readonly></el-input>
          </li>
          <!--<li>-->
          <!--<label>操作指引：</label>-->
          <!--<el-button type="primary">下载</el-button>-->
          <!--</li>-->
          <div class="clear"></div>
        </ul>
        <!--中-->
        <ul class="mangeShow">
          <li>
            <label>接收人：</label>
            <el-input v-model="showEdit.receiveUser" readonly></el-input>
          </li>
          <li>
            <label>接收方式：</label>
            <el-select v-model="showEdit.handoverType"  placeholder="请选择" filterable @change="receiveBtn">
              <el-option
                v-for="item in handoverTypeList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <li v-if="!showDisable">
            <label>接收地址：</label>
            <el-input v-model="showEdit.receiveAddress" placeholder="请输入接收地址"></el-input>
          </li>
          <div class="clear"></div>
        </ul>
        <ul class="mangeShow">
          <li>
            <label>变更移交人：</label>
            <el-select v-model="showEdit.userId"  placeholder="请输入移交人检索" filterable remote reserve-keyword :remote-method="orgFlag">
              <el-option
                v-for="item in sqFondsList"
                :key="item.id"
                :label="item.text"
                :value="item.id">
              </el-option>
            </el-select>
          </li>
          <li>
            <label>运单号：</label>
            <el-input v-model="showEdit.handoverYdh" :disabled="showDisable"></el-input>
          </li>
          <li>
            <label>运营商：</label>
            <el-select v-model="showEdit.handoverYys"  placeholder="请选择" filterable :disabled="showDisable">
              <el-option
                v-for="item in handoverYysList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList">
          <label>申请人意见：</label>
          <el-input
            type="textarea"
            :rows="2"
            placeholder="提醒：请在申请意见中写明需移交档案内容及数量，点击“确认”即可。
 例：申请移交历史部门印章登记表，共6册，请档案中心评估接收。"
            v-model="showEdit.applyRemarkCopy">
          </el-input>
        </div>
        <!--下-列表-->
        <div class="mangeShowList">
          <p>意见详情：</p>
          <div class="showReadOnlyContent" v-if="showEdit.isOldDate == 0">
            <div v-html="showEdit.handoverRemark"></div>
          </div>
          <!-- 表格 -->
          <div class="all-Table" v-else-if="showEdit.isOldDate == 1" style="width: 83%;max-height: 300px;overflow: auto;margin: 0 auto;">
            <el-table
              :data="dialogTable"
              stripe
              border
              style="width: 100%">
              <el-table-column
                show-overflow-tooltip
                prop="handoverRemark"
                label="意见内容">
                <template slot-scope="scope">
                  <div v-for="(item, index) in scope.row.handoverRemark" :key="index">{{ item }}</div>
                </template>
              </el-table-column>
              <el-table-column
                prop="date"
                label="时间">
              </el-table-column>
              <el-table-column
                prop="sendName"
                label="操作人">
              </el-table-column>
            </el-table>
          </div>
        </div>
        <!--合同介绍-->
        <div class="mangeShowList">
          <label>合同上传要求：</label>
          <div class="heTong">
            1,文件彩色扫描为pdf格式；<br/>
            2,命名格式：原OA流程：公司公章："年份+合同号",例：2017年第0001号001份。部门公章：合同名称-扫描件,例：房屋租赁合同-扫描件。
            <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            BPM流程：不区分公司公章与部门公章，均以流程显示的合同号为准。例：广发证券[2018]001234号合同
          </div>
        </div>
      </div>
      <div class="maxHeight">
        <!-- 下操作 -->
        <div style="background-color: #F4F4F4;">
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn"  @click="showLookBtnTwo">
            <img src="../../assets/turnOver/ck.png" alt="">
            <span>查看</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn2">
            <img src="../../assets/turnOver/yj.png" alt="">
            <span>下次移交</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="getDataViewDialog3 = true">
            <img src="../../assets/turnOver/sx.png" alt="">
            <span>刷新内容</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn4">
            <img src="../../assets/turnOver/lr.png" alt="">
            <span>录入</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn5">
            <img src="../../assets/turnOver/bj.png" alt="">
            <span>编辑</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn6">
            <img src="../../assets/turnOver/delete.png" alt="">
            <span>删除</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn7">
            <img src="../../assets/turnOver/sc.png" alt="">
            <span>上传</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <!--<div class="searchBtn" @click="clearImgDel, getDataViewDialog9 = true">-->
          <div class="searchBtn" @click="daoRuExcel">
            <img src="../../assets/turnOver/dr.png" alt="">
            <span>导入Excel</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn10">
            <img src="../../assets/turnOver/delete.png" alt="">
            <span>删除附件</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn11">
            <img src="../../assets/turnOver/tj.png" alt="">
            <span>添加异常</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn12">
            <img src="../../assets/turnOver/s5.png" alt="">
            <span>导出Excel模板</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 下表格 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtomTwo"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileCode"
              label="文件号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="文件标题"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              sortable
              label="文件日期"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverPc"
              label="年度">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="isOriginal"
              label="是否原件"
              width="100">
              <template slot-scope="scope">
                <span v-if="scope.row.isOriginal == 0">是</span>
                <span v-else-if="scope.row.isOriginal == 1">否</span>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverException"
              label="移交异常"
              width="500">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeTwo2"
            :current-page="paramsTwo1.page"
            :page-size="paramsTwo1.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo1.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="mangeBtn">确定</el-button>
        <el-button @click="dialogShowContent2 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--模糊查询--确认弹框-->
    <el-dialog :visible.sync="getDataViewDialog" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        询问
      </div>
      <div class="dia-delete">
        <!--<div>{{ paramsContent.content }}</div>-->
        <el-radio-group v-model="showEdit.radio" style="width: 100%;">
          <el-radio :label="0">电子</el-radio>
          <el-radio :label="1">纸质</el-radio>
          <el-radio :label="2">电子+纸质</el-radio>
        </el-radio-group>
        <div>
          <br/>
          <el-radio
            v-model="showEdit.radio2"
            v-if="showEdit.radio == 0 || showEdit.radio == 2 || showEdit.radio == 3"
            :label="3">确认移交电子稿件移交完整，且可以正常使用。</el-radio>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn1">确定</el-button>
        <el-button @click="getDataViewDialog = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 查看弹框 -->
    <el-dialog :visible.sync="dialogShowLook" width="1314px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">查看材料</div>
      <div class="showClearLook">
        <div class="bigDog menuShrink black-tree" style="float: left;height: 100%;min-height: unset;max-height: unset;">
          <el-tree
            :data="treTable"
            :props="defaultProps"
            :check-strictly="true"
            :default-expand-all="true"
            :expand-on-click-node="false"
            :highlight-current="true"
            accordion
            @node-click="handleNodeClick">
          </el-tree>
        </div>
        <div style="float: left;margin-left: 10px;width: 80%; max-height: 600px; overflow: auto;">
          <el-tabs v-model="activeName" class="elTabsCssMange" type="card" @tab-click="resetTable">
            <!-- 广发上市 -->
            <el-tab-pane name="contentOnce" label="基本信息">
              <div v-if="showCheckEmbed">
                <!--件号，问号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>件号：</label>
                    <el-input v-model="showEditLook.itemNo" readonly></el-input>
                  </li>
                  <li>
                    <label>文号：</label>
                    <el-input v-model="showEditLook.fileCode" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--题名-->
                <ul class="mangeShowLook">
                  <li style="width: 100%;">
                    <label>题名：</label>
                    <el-input v-model="showEditLook.titleProper" readonly style="width: 84.5%;"></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--保管期限，公开属性，文件盒号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>保管期限：</label>
                    <el-input v-model="showEditLook.retentionPeriod" readonly></el-input>
                  </li>
                  <li>
                    <label>公开属性：</label>
                    <el-input v-model="showEditLook.openingType" readonly></el-input>
                  </li>
                  <li>
                    <label>文件盒号：</label>
                    <el-input v-model="showEditLook.caseNo" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--文件日期，年度，页数-->
                <ul class="mangeShowLook">
                  <li>
                    <label>文件日期：</label>
                    <el-input v-model="showEditLook.dateOfCreation" readonly></el-input>
                  </li>
                  <li>
                    <label>年度：</label>
                    <el-input v-model="showEditLook.yearCode" readonly></el-input>
                  </li>
                  <li>
                    <label>页数：</label>
                    <el-input v-model="showEditLook.amountOfPages" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--档号，责任者，分类号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>档号：</label>
                    <el-input v-model="showEditLook.officeArchivalCode" readonly></el-input>
                  </li>
                  <li>
                    <label>责任者：</label>
                    <el-input v-model="showEditLook.c113" readonly></el-input>
                  </li>
                  <li>
                    <label>分类号：</label>
                    <el-input v-model="showEditLook.seriesCode" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--是否为原件，是否在库，可见性-->
                <ul class="mangeShowLook">
                  <li>
                    <label>是否为原件：</label>
                    <el-input v-model="showEditLook.c58" readonly></el-input>
                  </li>
                  <li>
                    <label>是否在库：</label>
                    <el-input v-model="showEditLook.c59" readonly></el-input>
                  </li>
                  <li>
                    <label>可见性：</label>
                    <el-input v-model="showEditLook.c93" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档人，归档部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档人：</label>
                    <el-input v-model="showEditLook.filingUser" readonly></el-input>
                  </li>
                  <li>
                    <label>归档部门：</label>
                    <el-input v-model="showEditLook.filingDept" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--备注-->
                <ul class="mangeShowLook">
                  <li>
                    <label>备注：</label>
                    <el-input v-model="showEditLook.c8" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--部门，全宗，合同号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>部门：</label>
                    <el-input v-model="showEditLook.c98" readonly></el-input>
                  </li>
                  <li>
                    <label>全宗：</label>
                    <el-input v-model="showEditLook.fondsCode" readonly></el-input>
                  </li>
                  <li>
                    <label>合同号：</label>
                    <el-input v-model="showEditLook.c117" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档日期，来文系统，文件类型-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档日期：</label>
                    <el-input v-model="showEditLook.filingDate" readonly></el-input>
                  </li>
                  <li>
                    <label>来文系统：</label>
                    <el-input v-model="showEditLook.c92" readonly></el-input>
                  </li>
                  <li>
                    <label>文件类型：</label>
                    <el-input v-model="showEditLook.c100" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--公章等级，拟稿人，拟稿部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>公章等级：</label>
                    <el-input v-model="showEditLook.c112" readonly></el-input>
                  </li>
                  <li>
                    <label>拟稿人：</label>
                    <el-input v-model="showEditLook.c89" readonly></el-input>
                  </li>
                  <li>
                    <label>拟稿部门：</label>
                    <el-input v-model="showEditLook.c90" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
              </div>
              <div v-else>
                <embed :src="embedOnce" type="application/pdf" width="100%" height="600px"/>
              </div>
            </el-tab-pane>
            <el-tab-pane name="contentTwoce" label="关联档案" v-if="showView == 1">
              <div style="margin: 6px;">关联目录：</div>
              <ul class="mangeShowLook" v-for="(item, index) in paramsView.tlist" :key="item.id">
                <li style="width: 25%;">
                  <label style="width: 102px;">{{index + 1}}、档案题名：</label>
                  <el-input v-model="item.titleProper" readonly style="width: 57%"></el-input>
                </li>
                <li style="width: 25%;">
                  <label style="width: 102px;">责任者：</label>
                  <el-input v-model="item.c113" readonly style="width: 57%"></el-input>
                </li>
                <li style="width: 25%;">
                  <label style="width: 102px;">拟稿人：</label>
                  <el-input v-model="item.c89" readonly style="width: 57%"></el-input>
                </li>
                <li style="width: 25%;">
                  <label style="width: 102px;">合同号：</label>
                  <el-input v-model="item.c117" readonly style="width: 57%"></el-input>
                </li>
                <li style="width: 25%;margin-top:4px;">
                  <label style="width: 102px;">档案链接：</label>
                  <span style="color: #409eff;cursor: pointer;" @click="lookFileContent('f', item)">点击查看</span>
                </li>
                <div class="clear"></div>
              </ul>
              <div style="margin: 6px;">关联案卷：</div>
              <ul class="mangeShowLook" v-for="(item, index) in paramsView.tflist" :key="item.id">
                <li style="width: 25%;">
                  <label style="width: 102px;">{{index + 1}}、档案题名：</label>
                  <el-input v-model="item.titleProper" readonly style="width: 57%"></el-input>
                </li>
                <div class="clear"></div>
                <li style="width: 25%; margin-top:4px;">
                  <label style="width: 102px;">档案链接：</label>
                  <span style="color: #409eff;cursor: pointer;" @click="lookFileContent('v', item)">点击查看</span>
                </li>
                <div class="clear"></div>
              </ul>
              <div style="margin: 6px;">关联项目：</div>
              <ul class="mangeShowLook">
                <li style="width: 25%;">
                  <label style="width: 102px;">档案题名：</label>
                  <el-input v-model="paramsView.project.titleProper" readonly style="width: 57%"></el-input>
                </li>
                <div class="clear"></div>
                <li style="width: 25%; margin-top:4px;">
                  <label style="width: 102px;">档案链接：</label>
                  <span style="color: #409eff;cursor: pointer;" @click="lookFileContent('p', paramsView.project)">点击查看</span>
                </li>
                <div class="clear"></div>
              </ul>
            </el-tab-pane>
          </el-tabs>
        </div>
        <div class="clear"></div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button @click="dialogShowLook = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 查看弹框--第二级查看资料弹框 -->
    <el-dialog :visible.sync="dialogShowLookTwo" width="1314px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">查看材料</div>
      <div class="showClearLook">
        <div class="bigDog menuShrink black-tree" style="float: left;height: 100%;min-height: unset;max-height: unset;">
          <el-tree
            :data="treTableTwo"
            :props="defaultProps"
            :check-strictly="true"
            :default-expand-all="true"
            :expand-on-click-node="false"
            :highlight-current="true"
            accordion
            @node-click="handleNodeClickTwo">
          </el-tree>
        </div>
        <div style="float: left;margin-left: 10px;width: 80%; max-height: 600px; overflow: auto;">
          <el-tabs v-model="activeName" class="elTabsCssMange"  type="card" @tab-click="resetTable">
            <!-- 广发上市 -->
            <el-tab-pane name="contentOnce" label="基本信息">
              <div v-if="attributesType == 'f'">
                <!--件号，问号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>件号：</label>
                    <el-input v-model="showEditLookTwo.itemNo" readonly></el-input>
                  </li>
                  <li>
                    <label>文号：</label>
                    <el-input v-model="showEditLookTwo.fileCode" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--题目-->
                <ul class="mangeShowLook">
                  <li style="width: 100%;">
                    <label>题名：</label>
                    <el-input v-model="showEditLookTwo.titleProper" readonly style="width: 84.5%;"></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--保管期限，公开属性，文件盒号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>保管期限：</label>
                    <el-input v-model="showEditLookTwo.retentionPeriod" readonly></el-input>
                  </li>
                  <li>
                    <label>公开属性：</label>
                    <el-input v-model="showEditLookTwo.openingType" readonly></el-input>
                  </li>
                  <li>
                    <label>文件盒号：</label>
                    <el-input v-model="showEditLookTwo.caseNo" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--文件日期，年度，页数-->
                <ul class="mangeShowLook">
                  <li>
                    <label>文件日期：</label>
                    <el-input v-model="showEditLookTwo.dateOfCreation" readonly></el-input>
                  </li>
                  <li>
                    <label>年度：</label>
                    <el-input v-model="showEditLookTwo.yearCode" readonly></el-input>
                  </li>
                  <li>
                    <label>页数：</label>
                    <el-input v-model="showEditLookTwo.amountOfPages" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--档号，责任者，分类号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>档号：</label>
                    <el-input v-model="showEditLookTwo.officeArchivalCode" readonly></el-input>
                  </li>
                  <li>
                    <label>责任者：</label>
                    <el-input v-model="showEditLookTwo.c113" readonly></el-input>
                  </li>
                  <li>
                    <label>分类号：</label>
                    <el-input v-model="showEditLookTwo.seriesCode" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--是否为原件，是否在库，可见性-->
                <ul class="mangeShowLook">
                  <li>
                    <label>是否为原件：</label>
                    <el-input v-model="showEditLookTwo.c58" readonly></el-input>
                  </li>
                  <li>
                    <label>是否在库：</label>
                    <el-input v-model="showEditLookTwo.c59" readonly></el-input>
                  </li>
                  <li>
                    <label>可见性：</label>
                    <el-input v-model="showEditLookTwo.c93" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档人，归档部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档人：</label>
                    <el-input v-model="showEditLookTwo.filingUser" readonly></el-input>
                  </li>
                  <li>
                    <label>归档部门：</label>
                    <el-input v-model="showEditLookTwo.filingDept" readonly></el-input>
                  </li>
                  <li>
                    <label>归档部门：</label>
                    <el-input v-model="showEditLookTwo.c107 == 0 ? '已盖章':'未盖章'" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--备注-->
                <ul class="mangeShowLook">
                  <li>
                    <label>备注：</label>
                    <el-input v-model="showEditLookTwo.c8" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--部门，全宗，合同号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>部门：</label>
                    <el-input v-model="showEditLookTwo.c98" readonly></el-input>
                  </li>
                  <li>
                    <label>全宗：</label>
                    <el-input v-model="showEditLookTwo.fondsCode" readonly></el-input>
                  </li>
                  <li>
                    <label>合同号：</label>
                    <el-input v-model="showEditLookTwo.c117" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档日期，来文系统，文件类型-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档日期：</label>
                    <el-input v-model="showEditLookTwo.filingDate" readonly></el-input>
                  </li>
                  <li>
                    <label>来文系统：</label>
                    <el-input v-model="showEditLookTwo.c92" readonly></el-input>
                  </li>
                  <li>
                    <label>文件类型：</label>
                    <el-input v-model="showEditLookTwo.c100" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--公章等级，拟稿人，拟稿部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>公章等级：</label>
                    <el-input v-model="showEditLookTwo.c112" readonly></el-input>
                  </li>
                  <li>
                    <label>拟稿人：</label>
                    <el-input v-model="showEditLookTwo.c89" readonly></el-input>
                  </li>
                  <li>
                    <label>拟稿部门：</label>
                    <el-input v-model="showEditLookTwo.c90" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
              </div>
              <div v-if="attributesType == 'v'">
                <!--项目名称，全宗，分类号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>项目名称：</label>
                    <el-input v-model="showEditLookTwo.c11" readonly></el-input>
                  </li>
                  <li>
                    <label>全宗：</label>
                    <el-input v-model="showEditLookTwo.fondsCode" readonly></el-input>
                  </li>
                  <li>
                    <label>分类号：</label>
                    <el-input v-model="showEditLookTwo.seriesCode" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--案卷题名-->
                <ul class="mangeShowLook">
                  <li style="width: 100%;">
                    <label>案卷题名：</label>
                    <el-input v-model="showEditLookTwo.titleProper" readonly style="width: 84.5%;"></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--案卷号，年度，可见性-->
                <ul class="mangeShowLook">
                  <li>
                    <label>案卷号：</label>
                    <el-input v-model="showEditLookTwo.folderNo" readonly></el-input>
                  </li>
                  <li>
                    <label>年度：</label>
                    <el-input v-model="showEditLookTwo.yearCode" readonly></el-input>
                  </li>
                  <li>
                    <label>可见性：</label>
                    <el-input v-model="showEditLookTwo.c93" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档人，归档日期，归档部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档人：</label>
                    <el-input v-model="showEditLookTwo.filingUser" readonly></el-input>
                  </li>
                  <li>
                    <label>归档日期：</label>
                    <el-input v-model="showEditLookTwo.filingDate" readonly></el-input>
                  </li>
                  <li>
                    <label>归档部门：</label>
                    <el-input v-model="showEditLookTwo.filingDept" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--起始日期，责任者，保管期限-->
                <ul class="mangeShowLook">
                  <li>
                    <label>起始日期：</label>
                    <el-input v-model="showEditLookTwo.dateBegun" readonly></el-input>
                  </li>
                  <li>
                    <label>终止日期：</label>
                    <el-input v-model="showEditLookTwo.dateFinished" readonly></el-input>
                  </li>
                  <li>
                    <label>保管期限：</label>
                    <el-input v-model="showEditLookTwo.retentionPeriod" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--备注-->
                <ul class="mangeShowLook">
                  <li>
                    <label>备注：</label>
                    <el-input v-model="showEditLookTwo.folderNote" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--档号，项目代号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>档号：</label>
                    <el-input v-model="showEditLookTwo.officeArchivalCode" readonly></el-input>
                  </li>
                  <li>
                    <label>项目代号：</label>
                    <el-input v-model="showEditLookTwo.c0" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
              </div>
              <div v-if="attributesType == 'p'">
                <!--项目代号，项目名称-->
                <ul class="mangeShowLook">
                  <li>
                    <label>项目代号：</label>
                    <el-input v-model="showEditLookTwo.c0" readonly></el-input>
                  </li>
                  <li>
                    <label>项目名称：</label>
                    <el-input v-model="showEditLookTwo.c11" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--工程地点-->
                <ul class="mangeShowLook">
                  <li style="width: 100%;">
                    <label>工程地点：</label>
                    <el-input v-model="showEditLookTwo.projectSite" readonly style="width: 84.5%;"></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--全宗，归档部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>全宗：</label>
                    <el-input v-model="showEditLookTwo.fondsCode" readonly></el-input>
                  </li>
                  <li>
                    <label>归档部门：</label>
                    <el-input v-model="showEditLookTwo.filingDept" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--分类号，归档人-->
                <ul class="mangeShowLook">
                  <li>
                    <label>分类号：</label>
                    <el-input v-model="showEditLookTwo.seriesCode" readonly></el-input>
                  </li>
                  <li>
                    <label>归档人：</label>
                    <el-input v-model="showEditLookTwo.filingUser" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档日期，可见性-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档日期：</label>
                    <el-input v-model="showEditLookTwo.filingDate" readonly></el-input>
                  </li>
                  <li>
                    <label>可见性：</label>
                    <el-input v-model="showEditLookTwo.c93" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
              </div>
            </el-tab-pane>
            <el-tab-pane name="contentTwoce" label="关联档案" v-if="showViewTwo == 1">
              <div v-if="paramsViewTwo.tlist">
                <div style="margin: 6px;" v-if="attributesType == 'f'">关联目录：</div>
                <ul class="mangeShowLook" v-if="attributesType == 'f'" v-for="(item, index) in paramsViewTwo.tlist" :key="item.id">
                  <li style="width: 25%;">
                    <label style="width: 102px;">{{index + 1}}、档案题名：</label>
                    <el-input v-model="item.titleProper" readonly style="width: 57%"></el-input>
                  </li>
                  <li style="width: 25%;">
                    <label style="width: 102px;">责任者：</label>
                    <el-input v-model="item.c113" readonly style="width: 57%"></el-input>
                  </li>
                  <li style="width: 25%;">
                    <label style="width: 102px;">拟稿人：</label>
                    <el-input v-model="item.c89" readonly style="width: 57%"></el-input>
                  </li>
                  <li style="width: 25%;">
                    <label style="width: 102px;">合同号：</label>
                    <el-input v-model="item.c117" readonly style="width: 57%"></el-input>
                  </li>
                  <!--<li style="width: 25%;margin-top:4px;">
                    <label style="width: 102px;">档案链接：</label>
                    <span style="color: #409eff;cursor: pointer;">点击查看</span>
                  </li>-->
                  <div class="clear"></div>
                </ul>
              </div>
              <div v-if="paramsViewTwo.tflist">
                <div style="margin: 6px;">关联案卷：</div>
                <ul class="mangeShowLook" v-for="(item, index) in paramsViewTwo.tflist" :key="item.id">
                  <li style="width: 25%;">
                    <label style="width: 102px;">{{index + 1}}、档案题名：</label>
                    <el-input v-model="item.titleProper" readonly style="width: 57%"></el-input>
                  </li>
                  <div class="clear"></div>
                  <!--<li style="width: 25%; margin-top:4px;">
                    <label style="width: 102px;">档案链接：</label>
                    <span style="color: #409eff;cursor: pointer;">点击查看</span>
                  </li>-->
                  <div class="clear"></div>
                </ul>
              </div>
              <div v-if="paramsViewTwo.project">
                <div style="margin: 6px;">关联项目：</div>
                <ul class="mangeShowLook">
                  <li style="width: 25%;">
                    <label style="width: 102px;">档案题名：</label>
                    <el-input v-model="paramsViewTwo.project.titleProper" readonly style="width: 57%"></el-input>
                  </li>
                  <div class="clear"></div>
                  <!--<li style="width: 25%; margin-top:4px;">
                    <label style="width: 102px;">档案链接：</label>
                    <span style="color: #409eff;cursor: pointer;">点击查看</span>
                  </li>-->
                  <div class="clear"></div>
                </ul>
              </div>
            </el-tab-pane>
          </el-tabs>
        </div>
        <div class="clear"></div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button @click="dialogShowLookTwo = false">取消</el-button>
      </div>
    </el-dialog>
    <!--模糊查询--移出确认（下次移出）-->
    <el-dialog :visible.sync="getDataViewDialog2" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        移出确认
      </div>
      <div class="dia-delete">
        {{ showEdit.deleteContent }}
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn2">确定</el-button>
        <el-button @click="getDataViewDialog2 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--模糊查询--刷新确认-->
    <el-dialog :visible.sync="getDataViewDialog3" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        刷新确认
      </div>
      <div class="dia-delete">
        确定要刷新移交内容吗?
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn3">确定</el-button>
        <el-button @click="getDataViewDialog3 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 模糊查询--录入 -->
    <el-dialog :visible.sync="getDataViewDialog4" width="880px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">录入</div>
      <!--文号，题名-->
      <ul class="mangeShowLook">
        <li>
          <label>文号：</label>
          <el-input v-model="showEditLook.fileCode"></el-input>
        </li>
        <li class="editorXin" style="width: 536px;">
          <label>题名：</label>
          <el-input v-model="showEditLook.titleProper" style="width: 78%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--文件日期，年度，页数-->
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label>文件日期：</label>
          <el-date-picker
            v-model="showEditLook.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <li class="editorXin">
          <label>年度：</label>
          <el-input v-model="showEditLook.yearCode"></el-input>
        </li>
        <li>
          <label>页数：</label>
          <el-input v-model="showEditLook.amountOfPage"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--责任者，公开属性，分类号-->
      <ul class="mangeShowLook">
        <li>
          <label>责任者：</label>
          <el-input v-model="showEditLook.c113"></el-input>
        </li>
        <li>
          <label>公开属性：</label>
          <el-select v-model="showEditLook.openingType" filterable placeholder="请选择" @change="searchSeries">
            <el-option
              v-for="item in openingType"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </li>
        <li class="editorXin">
          <label>分类号：</label>
          <el-input v-model="showEditLook.seriesCode" readonly></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--是否为原件，归档部门，归档人-->
      <ul class="mangeShowLook">
        <li>
          <label>是否为原件：</label>
          <el-select v-model="showEditLook.c58" filterable placeholder="请选择" @change="searchSeries">
            <el-option
              v-for="item in c58"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </li>
        <li>
          <label>归档部门：</label>
          <el-input v-model="showEditLook.filingDeptName" readonly></el-input>
        </li>
        <li>
          <label>归档人：</label>
          <el-input v-model="showEditLook.filingUserName" readonly></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--备注-->
      <ul class="mangeShowLook">
        <li style="width: 804px;">
          <label>备注：</label>
          <el-input type="textarea" v-model="showEditLook.c8" style="width: 85%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="submitBtn4">保存</el-button>
        <el-button @click="restBtn">重置</el-button>
        <el-button @click="getDataViewDialog4 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--模糊查询--修改标题-->
    <el-dialog :visible.sync="getDataViewDialog5" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        编辑文件信息
      </div>
      <div class="dia-delete">
        <ul class="mangeShowLook">
          <li class="editorXin" style="width: 410px;">
            <label>题名：</label>
            <el-input v-model="showEditLook.title" style="width: 65%;"></el-input>
          </li>
          <div class="clear"></div>
        </ul>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn5">确定</el-button>
        <el-button @click="getDataViewDialog5 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--模糊查询--修改附件确认-->
    <el-dialog :visible.sync="getDataViewDialog6" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        修改附件确认
      </div>
      <div class="dia-delete">
        确定要修改此文件的题名吗?
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn6">确定</el-button>
        <el-button @click="getDataViewDialog6 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--模糊查询--删除确认-->
    <el-dialog :visible.sync="getDataViewDialog7" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        删除确认
      </div>
      <div class="dia-delete">
        确定要删除此文件吗?
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn7">确定</el-button>
        <el-button @click="getDataViewDialog7 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--模糊查询--文件上传-->
    <el-dialog :visible.sync="getDataViewDialog8" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        文件上传
      </div>
      <div class="dia-delete">
        <label>文件上传：</label>
        <el-upload
          ref="AddBtnImgTwo"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :on-change="handleChange"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn8">确定</el-button>
        <el-button @click="getDataViewDialog8 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--模糊查询--导入Excel-->
    <el-dialog :visible.sync="getDataViewDialog9" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        导入Excel
      </div>
      <div class="dia-delete">
        <label>导入Excel：</label>
        <el-upload
          ref="AddBtnImgOne"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :limit="1"
          :on-exceed="handleExceed"
          :on-change="handleChangeTwo"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn9">确定</el-button>
        <el-button @click="getDataViewDialog9 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--模糊查询--删除附件-->
    <el-dialog :visible.sync="getDataViewDialog10" width="896px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <!--<img src="../../assets/dialog/sccl.png" alt="">-->
        <img src="../../assets/dialog/sccl.png" alt="">
        删除附件
      </div>
      <div class="">
        <!-- 删除 -->
        <div style="line-height: 35px;border: 1px solid #929292;">
          <div  class="searchBtn" style="margin-left: 4px;" @click="tableDeleteFile">
            <img src="../../assets/turnOver/delete.png" alt="">
            <span style="cursor: pointer">删除</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 下表格 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="deleteTable"
            stripe
            border
            @selection-change="handleSelectionChangeBtomThree">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="path"
              label="题名"
              width="600">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileSize"
              label="文件大小"
              width="100">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileFormat"
              label="文件格式"
              width="99">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeThree"
            :current-page="paramsDelete.page"
            :page-size="paramsDelete.rows"
            layout="prev, pager, next, jumper"
            :total="paramsDelete.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <!--<el-button type="primary" @click="submitBtn9">确定</el-button>-->
        <el-button @click="getDataViewDialog10 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--模糊查询--删除附件--删除确认-->
    <el-dialog :visible.sync="getDataViewDialog11" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        删除确认
      </div>
      <div class="dia-delete">
        确定要删除此附件吗?
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn11">确定</el-button>
        <el-button @click="getDataViewDialog11 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--模糊查询--移交异常-->
    <el-dialog :visible.sync="getDataViewDialog12" width="1111px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        移交异常
      </div>
      <div>
        <!--移交异常-->
        <div class="anomalyError">
          <div class="anomalyErrorOne">移交异常：</div>
          <div class="anomalyErrorTwo">
            <el-checkbox ref="hException1" v-model="checkParams.hException1" true-label="广发未办理盖章" label="广发未办理盖章" :disabled="disYj" @change="selectDis"></el-checkbox>
            <el-checkbox ref="hException2" v-model="checkParams.hException2" true-label="未打印签署" label="未打印签署" :disabled="disYj" @change="selectDis"></el-checkbox>
          </div>
          <div class="anomalyErrorThree ErrorCenter">达标措施</div>
          <div class="anomalyErrorThree ErrorCenter">补救措施</div>
          <span class="clear"></span>
        </div>
        <!--合同遗失-A类-->
        <div class="anomalyErrorOnceTwo">
          <div class="anomalyErrorOne">合同遗失-A类：</div>
          <!--1-->
          <div>
            <div class="anomalyErrorTwo">
              <el-checkbox ref="hException3" @change="selectDis" v-model="checkParams.hException3" true-label="(A1)合同各方已盖章，且已履行完毕" label="(A1)合同各方已盖章，且已履行完毕" :disabled="disHtOne"></el-checkbox>
            </div>
            <div class="anomalyErrorThree">
              <el-checkbox ref="checkBosOne" @change="selectDis" v-model="checkParams.upStandard2" true-label="已补签" label="已补签" :disabled="disHtOneTwo"></el-checkbox>
            </div>
            <div class="anomalyErrorThree">
              <!--<el-checkbox ref="checkBosTwo" @change="selectDis" v-model="checkParams.remedial2" true-label="复印件等附件归档" label="复印件等附件归档" :disabled="disHtOneTwo"></el-checkbox>-->
              <el-checkbox ref="checkBosTwo" @change="selectDis" v-model="checkParams.remedial2" true-label="复印件等附件归档" label="复印件等附件归档" :disabled="disHtThreeTwoFy"></el-checkbox>
            </div>
          </div>
          <!--2-->
          <div style="height: 79px;">
            <div class="anomalyErrorTwo">
              <el-checkbox ref="hException4" @change="selectDis" v-model="checkParams.hException4" true-label="(A2)合同各方已盖章，且正在履行" label="(A2)合同各方已盖章，且正在履行" :disabled="disHtTwo"></el-checkbox>
              <el-checkbox ref="zlhDateOne" @change="selectDisTwo" v-model="checkParams.hException4" true-label="自留函" label="自留函" :disabled="disHtTwoOnce"></el-checkbox>
              <el-date-picker
                class="pickerSelect"
                v-show="disHtTwoDate"
                v-model="checkParams.zlhDate"
                :picker-options="timeChange"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="yyyy-MM-dd"
                placeholder="选择时间">
              </el-date-picker>
            </div>
            <div class="anomalyErrorThree" style="line-height: 79px;">
              <el-checkbox ref="checkBosThree" @change="selectDis" v-model="checkParams.upStandard3" true-label="已补签" label="已补签" :disabled="disHtTwoTwo"></el-checkbox>
            </div>
            <div class="anomalyErrorThree ErrorCenter"  style="line-height: 79px;">——</div>
          </div>
          <!--3-->
          <div>
            <div class="anomalyErrorTwo">
              <el-checkbox ref="hException5" @change="selectDis" v-model="checkParams.hException5" true-label="(A3)合同各方已盖章，合同不再履行" label="(A3)合同各方已盖章，合同不再履行"  :disabled="disHtThree"></el-checkbox>
            </div>
            <div class="anomalyErrorThree">
              <el-checkbox ref="checkBosFour" @change="selectDis" v-model="checkParams.upStandard5" true-label="已变更、解除、终止" label="已变更、解除、终止"  :disabled="disHtThreeTwo"></el-checkbox>
            </div>
            <div class="anomalyErrorThree ErrorCenter">——</div>
          </div>
          <!--4-->
          <div>
            <div class="anomalyErrorTwo">
              <el-checkbox ref="hException6" @change="selectDis" v-model="checkParams.hException6" true-label="(A4)合同仅有我方盖章" label="(A4)合同仅有我方盖章" :disabled="disHtFour"></el-checkbox>
            </div>
            <div class="anomalyErrorThree">
              <el-checkbox ref="checkBosFive" @change="selectDis" v-model="checkParams.upStandard6" true-label="已全部回收" label="已全部回收" :disabled="disHtFourTwo"></el-checkbox>
            </div>
            <div class="anomalyErrorThree">
              <el-checkbox ref="checkBosSix" @change="selectDis" v-model="checkParams.remedial6" true-label="已有遗失说明" label="已有遗失说明" :disabled="disHtFourTwo"></el-checkbox>
            </div>
          </div>
          <span class="clear"></span>
        </div>
        <!--合同不完整-B类-->
        <div class="anomalyErrorOnceTwo">
          <div class="anomalyErrorOnceFour">合同不完整-B类：</div>
          <div>
            <div class="anomalyErrorOnceThree">
              <el-checkbox ref="contentOne"  v-model="checkParams.contentOne" true-label="原件不完整（对方未盖章）" label="原件不完整（对方未盖章）" :disabled="disHtBOne" @change="selectDis"></el-checkbox>
            </div>
            <div class="anomalyErrorOnceThree">
              <el-checkbox ref="contentTwo"  v-model="checkParams.contentTwo" true-label="原件不完整（无签署时间）" label="原件不完整（无签署时间）" :disabled="disHtBTwo" @change="selectDis"></el-checkbox>
            </div>
            <div class="anomalyErrorOnceThree">
              <el-checkbox ref="contentThree"  v-model="checkParams.contentThree" true-label="原件不完整（缺失授权书）" label="原件不完整（缺失授权书）" :disabled="disHtBThree" @change="selectDis"></el-checkbox>
            </div>
            <div class="anomalyErrorOnceThree">
              <el-checkbox ref="contentFour"  v-model="checkParams.contentFour" true-label="原件不完整（对方未签名）" label="原件不完整（对方未签名）" :disabled="disHtBFour" @change="selectDis"></el-checkbox>
            </div>
            <div class="anomalyErrorOnceThree">
              <el-checkbox ref="contentFive"  v-model="checkParams.contentFive" true-label="原件不完整（缺失部分页）" label="原件不完整（缺失部分页）" :disabled="disHtBFive" @change="selectDis"></el-checkbox>
            </div>
          </div>
          <div class="anomalyErrorOnceFour" style="width: 234px; text-align: left; text-indent: 2px;">
            <el-checkbox ref="checkBosSeven" v-model="checkParams.upStandard7" true-label="补充整改完成后原件归档" label="补充整改完成后原件归档" :disabled="disHtBOnceTwo" @change="selectDis"></el-checkbox>
          </div>
          <div class="anomalyErrorThree ErrorCenter"  style="height: 204px;line-height: 204px;">——</div>
          <span class="clear"></span>
        </div>
        <!--考核标准-->
        <div class="showContentDownload">
          根据《关于加强合同归档管理与考核的通知》相关要求，自2018年起，异常合同归档率超过考核指标的，办公室将报合规与法律事务部出具风险提示函或风险警示函，
          <span @click="getDataViewDialog13 = true">考核标准。</span>
        </div>
        <!--合同异常归档操作说明（点击下载）-->
        <div class="showContentDownload">
          注：选择广发未办理盖章或未打印签署的，不计入移交异常考核。已达标或有补救措施的不计入移交异常考核。
          <br/>
          <span @click="wordPullBtn">合同异常归档操作说明（点击下载）。</span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="errorCheckBtn">确定</el-button>
        <el-button @click="getDataViewDialog12 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--模糊查询--移交异常--考核标准-->
    <el-dialog :visible.sync="getDataViewDialog13" width="800px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        考核标准
      </div>
      <div>
        <!--异常种类-->
        <div class="anomalyError" style="width: 756px;">
          <div class="anomalyErrorOne ErrorCenter" style="text-align: center;font-size: 18px;">异常种类</div>
          <div class="anomalyErrorTwo ErrorCenter" style="font-size: 18px;">
            考核指标=异常合同数/合同总数
          </div>
          <div class="anomalyErrorThree ErrorCenter" style="font-size: 18px;">建议处理措施</div>
          <span class="clear"></span>
        </div>
        <!--A1不达标-->
        <div class="anomalyErrorOnceTwo"  style="width: 757px;">
          <div class="anomalyErrorOne ErrorCenter" style="height: 82px;line-height: 82px;text-align: center;">A1不达标</div>
          <!--1-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A1≥5%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <!--2-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A1≥10%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <span class="clear"></span>
        </div>
        <!--A2不达标-->
        <div class="anomalyErrorOnceTwo"  style="width: 757px;">
          <div class="anomalyErrorOne ErrorCenter" style="height: 82px;line-height: 82px;text-align: center;">A2不达标</div>
          <!--1-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A2≥4%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <!--2-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A2≥8%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <span class="clear"></span>
        </div>
        <!--A3不达标-->
        <div class="anomalyErrorOnceTwo"  style="width: 757px;">
          <div class="anomalyErrorOne ErrorCenter" style="height: 82px;line-height: 82px;text-align: center;">A3不达标</div>
          <!--1-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A3≥2%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <!--2-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A3≥4%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <span class="clear"></span>
        </div>
        <!--A4不达标-->
        <div class="anomalyErrorOnceTwo"  style="width: 757px;">
          <div class="anomalyErrorOne ErrorCenter" style="height: 82px;line-height: 82px;text-align: center;">A4不达标</div>
          <!--1-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A4≥2%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <!--2-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A4≥4%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <span class="clear"></span>
        </div>
        <!--B不达标-->
        <div class="anomalyErrorOnceTwo"  style="width: 757px;">
          <div class="anomalyErrorOne ErrorCenter" style="height: 82px;line-height: 82px;text-align: center;">B不达标</div>
          <!--1-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              B≥8%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <!--2-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              B≥15%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <span class="clear"></span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button @click="getDataViewDialog13 = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 精确移交交单弹框 -->
    <el-dialog :visible.sync="dialogShowContentFan" width="1111px" class="hurdleAll" :before-close="handleClose">
      <div slot="title" class="dialog-title">精确移交交单</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li>
            <label>移交人姓名：</label>
            <el-input v-model="showEdit.handoverUser" readonly></el-input>
          </li>
          <li>
            <label>移交部门：</label>
            <el-input v-model="showEdit.handoverDept" readonly></el-input>
          </li>
          <li>
            <label>移交时间：</label>
            <el-input v-model="showEdit.handoverDate" readonly></el-input>
          </li>
          <!--<li>-->
          <!--<label>操作指引：</label>-->
          <!--<el-button type="primary">下载</el-button>-->
          <!--</li>-->
          <div class="clear"></div>
        </ul>
        <!--中-->
        <ul class="mangeShow">
          <li>
            <label>接收人：</label>
            <el-input v-model="showEdit.receiveUser" readonly></el-input>
          </li>
          <li class="editorXin">
            <label>接收方式：</label>
            <el-select v-model="showEdit.handoverType"  placeholder="请选择" filterable @change="receiveBtn">
              <el-option
                v-for="item in handoverTypeList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <li v-if="!showDisable">
            <label>接收地址：</label>
            <el-input v-model="showEdit.receiveAddress" placeholder="请输入接收地址"></el-input>
          </li>
          <div class="clear"></div>
        </ul>
        <ul class="mangeShow">
          <li>
            <label>变更移交人：</label>
            <el-select v-model="showEdit.userId"  placeholder="请输入移交人检索" filterable remote reserve-keyword :remote-method="orgFlag">
              <el-option
                v-for="item in sqFondsList"
                :key="item.id"
                :label="item.text"
                :value="item.id">
              </el-option>
            </el-select>
          </li>
          <li>
            <label>运单号：</label>
            <el-input v-model="showEdit.handoverYdh" :disabled="showDisable"></el-input>
          </li>
          <li class="editorXin">
            <label>运营商：</label>
            <el-select v-model="showEdit.handoverYys"  placeholder="请选择" filterable :disabled="showDisable">
              <el-option
                v-for="item in handoverYysList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList editorXin">
          <label>移交人意见：</label>
          <el-input
            type="textarea"
            :rows="2"
            placeholder="提醒：请在申请意见中写明需移交档案内容及数量，点击“确认”即可。
 例：申请移交历史部门印章登记表，共6册，请档案中心评估接收。"
            v-model="showEdit.applyRemarkCopy">
          </el-input>
        </div>
        <div class="downloadBtn">
          <span @click="zjBtnDownload">证券金融业务合同归档操作指引(点击下载)</span>
        </div>
        <!--下-列表-->
        <div class="mangeShowList">
          <p>意见详情：</p>
          <div class="showReadOnlyContent" v-if="showEdit.isOldDate == 0">
            <div v-html="showEdit.handoverRemark"></div>
          </div>
          <!-- 表格 -->
          <div class="all-Table" v-else-if="showEdit.isOldDate == 1" style="width: 83%;max-height: 300px;overflow: auto;margin: 0 auto;">
            <el-table
              :data="dialogTable"
              stripe
              border
              style="width: 100%">
              <el-table-column
                show-overflow-tooltip
                prop="handoverRemark"
                label="意见内容">
                <template slot-scope="scope">
                  <div v-for="(item, key) in scope.row.handoverRemark " :key="key">{{ item }}</div>
                </template>
              </el-table-column>
              <el-table-column
                prop="date"
                label="时间">
              </el-table-column>
              <el-table-column
                prop="sendName"
                label="操作人">
              </el-table-column>
            </el-table>
          </div>
        </div>
        <!--合同介绍-->
        <div class="mangeShowList">
          <label>合同上传要求：</label>
          <div class="heTong">
            1,文件彩色扫描为pdf格式；<br/>
            2,命名格式：原OA流程：公司公章："年份+合同号",例：2017年第0001号001份。部门公章：合同名称-扫描件,例：房屋租赁合同-扫描件。
            <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
             BPM流程：不区分公司公章与部门公章，均以流程显示的合同号为准。例：广发证券[2018]001234号合同
          </div>
        </div>
      </div>
      <!--操作-->
      <div class="maxHeight">
        <!-- 下操作 -->
        <div style="background-color: #F4F4F4;">
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtnTwo">
            <img src="../../assets/turnOver/ck.png" alt="">
            <span>查看</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn2">
            <img src="../../assets/turnOver/yj.png" alt="">
            <span>下次移交</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="getDataViewDialog3 = true">
            <img src="../../assets/turnOver/sx.png" alt="">
            <span>刷新内容</span>
          </div>
          <!--<div class="searchBtn search-selectOnce" v-show="showEditIsFinance"></div>-->
          <!--<div class="searchBtn" v-show="showEditIsFinance">-->
            <!--<span @click="showLookBtn14">关联客户档案</span>-->
          <!--</div>-->
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn14">
            <img src="../../assets/turnOver/gl.png" alt="">
            <span>关联客户档案</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn7">
            <img src="../../assets/turnOver/sc.png" alt="">
            <span>上传</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn11">
            <span>添加异常</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn10">
            <img src="../../assets/turnOver/gl.png" alt="">
            <span>删除附件</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn13">
            <img src="../../assets/turnOver/xg.png" alt="">
            <span>修改附件题名</span>
          </div>
          <div class="searchBtn search-selectOnce" v-show="showEditIsSpecilly"></div>
          <div class="searchBtn" v-show="showEditIsSpecilly" @click="showLookBtn15">
            <img src="../../assets/turnOver/xg.png" alt="">
            <span>合同信息补充</span>
          </div>
          <div class="searchBtn search-selectOnce" v-show="showEditIsZctg"></div>
          <div class="searchBtn" v-show="showEditIsZctg" @click="showLookBtn16">
            <img src="../../assets/turnOver/yj.png" alt="">
            <span>移交详情</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn">
            <span style="display: block;line-height: 22px;color: red;cursor: auto">系统底色为蓝者本部门归档，</span>
            <span style="display: block;line-height: 22px;color: red;cursor: auto">底色为白者移交档案中心</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 下表格 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtomTwo"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileCode"
              label="文件号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverHt"
              label="合同号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="文件标题"
              width="230">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverEmployer"
              label="对方单位"
              width="200">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              sortable
              label="文件日期"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileType"
              label="文件类型"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="gzhangLevel"
              label="公章等级"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="signDate"
              sortable
              label="签署日期"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="businessType"
              label="业务类型"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="isOriginal"
              label="是否原件"
              width="160">
              <template slot-scope="scope">
                <span v-if="scope.row.isOriginal == 0">是</span>
                <span v-else-if="scope.row.isOriginal == 1">否</span>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverException"
              label="移交异常"
              width="160">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeTwo2"
            :current-page="paramsTwo1.page"
            :page-size="paramsTwo1.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo1.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="mangeBtn">确定</el-button>
        <el-button @click="dialogShowContentFan = false">取消</el-button>
      </div>
    </el-dialog>
    <!--精确查询--确认弹框-->
    <el-dialog :visible.sync="getDataViewDialogFan" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        询问
      </div>
      <div class="dia-delete">
        <!--<div>{{ paramsContent.content }}</div>-->
        <el-radio-group v-model="showEdit.radio" style="width: 100%;">
          <el-radio :label="0">电子</el-radio>
          <el-radio :label="1">纸质</el-radio>
          <el-radio :label="2">电子+纸质</el-radio>
        </el-radio-group>
        <div>
          <br/>
          <el-radio
            v-model="showEdit.radio2"
            v-if="showEdit.radio == 0 || showEdit.radio == 2 || showEdit.radio == 3"
            :label="3">确认移交电子稿件移交完整，且可以正常使用。</el-radio>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn1">确定</el-button>
        <el-button @click="getDataViewDialog = false">取消</el-button>
      </div>
    </el-dialog>
    <!--精确查询--修改附件提名-->
    <el-dialog :visible.sync="getDataViewDialog14" width="896px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        附件
      </div>
      <div class="">
        <!-- 修改 -->
        <div @click="tableDeleteFileTwo" style="line-height: 35px;border: 1px solid #929292;">
          <img src="../../assets/turnOver/xg.png" alt="">
          <span style="cursor: pointer">修改</span>
        </div>
        <!-- 下表格 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="deleteTable"
            stripe
            border
            @selection-change="handleSelectionChangeBtomThree">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="titleProper"
              label="文件标题"
              width="600">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileSize"
              label="文件大小"
              width="100">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileFormat"
              label="文件格式"
              width="99">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeThree"
            :current-page="paramsDelete.page"
            :page-size="paramsDelete.rows"
            layout="prev, pager, next, jumper"
            :total="paramsDelete.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button @click="getDataViewDialog14 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--精确查询--修改标题-->
    <el-dialog :visible.sync="getDataViewDialog15" width="444px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">
        附件信息
      </div>
      <div class="dia-delete">
        <ul class="mangeShowLook">
          <li class="editorXin" style="width: 410px;">
            <label>题名：</label>
            <el-input v-model="showEditLookTitle" style="width: 65%;"></el-input>
          </li>
          <div class="clear"></div>
        </ul>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn14">确定</el-button>
        <el-button @click="getDataViewDialog15 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--精确查询--关联客户档案-->
    <el-dialog :visible.sync="getDataViewDialog16" width="896px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        关联客户档案
      </div>
      <div class="">
        <!--添加材料项-->
        <div class="anomalyError" style="width: 854px;">
          <div class="anomalyErrorOne editorXin">
            <label>客户编号：</label>
          </div>
          <div class="anomalyErrorTwo clientAdd" style="width: 431px;">
            <el-input v-model="paramsClient.clientNo" placeholder="请输入内容" @blur="clientContent"></el-input>
          </div>
          <div class="anomalyErrorThree ErrorCenter" @click="addMaterials">添加材料项</div>
          <span class="clear"></span>
        </div>
        <!-- 下表格 -->
        <div class="all-Table" style="max-height: 460px;overflow: auto">
          <el-table
            ref="multipleTableBtomTwo"
            :data="clientTable"
            stripe
            border
            @selection-change="handleSelectionChangeBtomFour">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="stuffName"
              label="材料名称"
              width="239">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="boxNo"
              label="箱"
              width="160">
              <template slot-scope="scope">
                <el-input v-model="scope.row.boxNo" placeholder="请输入箱内容"></el-input>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="packageNo"
              label="盒"
              width="160">
              <template slot-scope="scope">
                <el-input v-model="scope.row.packageNo" placeholder="请输入盒内容"></el-input>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="itemNo"
              label="件"
              width="160">
              <template slot-scope="scope">
                <el-input v-model="scope.row.itemNo" placeholder="请输入件内容"></el-input>
              </template>
            </el-table-column>
            <el-table-column
              label="操作"
              width="80">
              <template slot-scope="scope">
                <span style="cursor: pointer" @click="deleteClient(scope.row)">删除</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn15">确定</el-button>
        <el-button @click="getDataViewDialog16 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--精确查询--关联客户档案--添加弹框-->
    <el-dialog :visible.sync="getDataViewDialog17" width="600px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">
        材料项
      </div>
      <div class="">
        <!--添加材料项-->
        <div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="searchContentAddBtn">
            <img src="../../assets/turnOver/tj.png" alt="">
            <span>添加：</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn">
            <el-input v-model="paramsClientTwo.stuffName" placeholder="请输入内容"></el-input>
          </div>
          <div class="searchBtn" style="margin-left: 20px;" @click="searchContentBtn">
            <img src="../../assets/turnOver/js.png" alt="">
            <span>检索</span>
          </div>
        </div>
        <div class="all-Table">
          <el-table
            ref="multipleTableBtomFour"
            :data="clientTableTwo"
            stripe
            border
            @selection-change="handleSelectionChangeBtomFour">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="stuffName"
              label="材料名称">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeFour"
            :current-page="paramsClientTwo.page"
            :page-size="paramsClientTwo.rows"
            layout="prev, pager, next, jumper"
            :total="paramsClientTwo.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button @click="getDataViewDialog17 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--精确查询--合同信息补充-->
    <el-dialog :visible.sync="getDataViewDialog18" width="896px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/turnOver/htong.png" alt="">
        合同信息补充
      </div>
      <!--输入框-->
      <div class="editorXin" style="margin-bottom: 8px;">
        <label style="display:inline-block;width: 120px; text-align: right">签署日期：</label>
        <el-date-picker
          v-model="paramsAddContent.signDate"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div class="editorXin" style="margin-bottom: 8px;">
        <label style="display:inline-block;width: 120px; text-align: right">是否业务合同：</label>
        <el-select v-model="paramsAddContent.isBusinessType"  placeholder="请选择" filterable @change="disBusType">
          <el-option
            v-for="item in isBusinessType"
            :key="item.itemValue"
            :label="item.name"
            :value="item.itemValue">
          </el-option>
        </el-select>
      </div>
      <div class="editorXin" style="margin-bottom: 8px;">
        <label style="display:inline-block;width: 120px; text-align: right">业务类型：</label>
        <el-select v-model="paramsAddContent.businessType"  placeholder="请选择" filterable :disabled="showDisableTwo">
          <el-option
            v-for="item in businessType"
            :key="item.businessCode"
            :label="item.businessName"
            :value="item.businessCode">
          </el-option>
        </el-select>
      </div>
      <!--操作-->
      <div class="maxHeight">
        <!-- 下操作 -->
        <div style="background-color: #F4F4F4;">
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn"  @click="showLookBtnThree">
            <img src="../../assets/turnOver/bj.png" alt="">
            <span>编辑</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtnDelete">
            <img src="../../assets/turnOver/delete.png" alt="">
            <span>删除</span>
          </div>
        </div>
        <!-- 下表格 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="htTable"
            stripe
            border
            @selection-change="handleSelectionChangeBtomFour">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="partner"
              label="对方单位"
              width="260">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="creditCode"
              label="统一社会信用代码"
              width="201">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="registerNo"
              label="工商注册号"
              width="169">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="orgNo"
              label="组织机构代码"
              width="169">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeFive"
            :current-page="paramsHt.page"
            :page-size="paramsHt.rows"
            layout="prev, pager, next, jumper"
            :total="paramsHt.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="htBtn">确定</el-button>
        <el-button @click="getDataViewDialog18 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--精确查询--合同信息补充--编辑-->
    <el-dialog :visible.sync="getDataViewDialog19" width="444px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">
        对方单位信息编辑
      </div>
      <div class="editorXin" style="margin-bottom: 6px;">
        <label style="width: 140px;display: inline-block;text-align: right">统一社会信用代码：</label>
        <el-input v-model="paramsEditContent.creditCode" style="width: 60%;"></el-input>
      </div>
      <div class="editorXin" style="margin-bottom: 6px;">
        <label style="width: 140px;display: inline-block;text-align: right">工商注册码：</label>
        <el-input v-model="paramsEditContent.registerNo" style="width: 60%;"></el-input>
      </div>
      <div class="editorXin" style="margin-bottom: 6px;">
        <label style="width: 140px;display: inline-block;text-align: right">组织机构代码：</label>
        <el-input v-model="paramsEditContent.orgNo" style="width: 60%;"></el-input>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn16">确定</el-button>
        <el-button @click="getDataViewDialog19 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--精确查询--移交详情-->
    <el-dialog :visible.sync="getDataViewDialog20" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        对方单位信息编辑
      </div>
      <div style="text-align: center">
        <el-radio-group v-model="paramsEditContent.completes" @change="radioCompletes">
          <el-radio label="1">已移交齐全</el-radio>
          <el-radio label="0">未移交齐全</el-radio>
        </el-radio-group>
        <!--<div>-->
          <!--<el-radio v-model="paramsEditContent.completes" label="1">已移交齐全</el-radio>-->
        <!--</div>-->
        <!--<div>-->
          <!--<el-radio v-model="paramsEditContent.completes" label="0">未移交齐全</el-radio>-->
        <!--</div>-->
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitBtn17">确定</el-button>
        <el-button @click="getDataViewDialog20 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--检索--按件-->
    <el-dialog :visible.sync="getDataViewDialog21" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        检索
      </div>
      <div class="editorXinTwo">
        <label>题名：</label>
        <el-input v-model="params.yjTitleProper" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>年度：</label>
        <el-input v-model="params.yjYearCode" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>文号：</label>
        <el-input v-model="params.yjFileCode" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>合同号：</label>
        <el-input v-model="params.yjC117" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>责任者：</label>
        <el-input v-model="params.yjAuthor" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>移交状态：</label>
        <el-select v-model="params.yjStatus" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option v-for="item in yjStatusArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>移交单号：</label>
        <el-input v-model="params.yjSerialNumber" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>拟稿部门：</label>
        <el-select v-model="params.yjc90" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option v-for="item in yjc90Arr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>拟稿人：</label>
        <el-select v-model="params.yjc89" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword
                   :remote-method="remoteMethodMan">
          <el-option v-for="item in yjc89Arr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>当前处理人：</label>
        <el-select v-model="params.yjcurrentuser" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword
                   :remote-method="remoteMethodUser">
          <el-option v-for="item in yjcurrentuserArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>文件类型：</label>
        <el-select v-model="params.fileType" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option v-for="item in fileTypeArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>公章类型：</label>
        <el-select v-model="params.yjc112" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option v-for="item in yjc112Arr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>文件日期：</label>
        <el-date-picker
          v-model="params.dataOfCreate"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div class="editorXinTwo">
        <label>移交类型：</label>
        <el-select v-model="params.type" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option
            v-for="item in handoverTypeModel"
            :key="item.itemValue"
            :label="item.name"
            :value="item.itemValue">
          </el-option>
        </el-select>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitBtn18">确定</el-button>
        <el-button @click="reset">重置</el-button>
        <el-button @click="getDataViewDialog21 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--检索--业务-->
    <el-dialog :visible.sync="getDataViewDialog211" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        检索
      </div>
      <div class="editorXinTwo">
        <label>项目单位全称：</label>
        <el-input v-model="params.thHandoverEmployer" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>项目类型：</label>
        <el-input v-model="params.thFileType" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>业务类型：</label>
        <el-input v-model="params.thHandoverHt" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>项目名称：</label>
        <el-input v-model="params.thTitle" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>项目结束年度：</label>
        <el-input v-model="params.thFileDate" placeholder="请输入内容"></el-input>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitBtn18">确定</el-button>
        <el-button @click="reset">重置</el-button>
        <el-button @click="getDataViewDialog211 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--检索--会计-->
    <el-dialog :visible.sync="getDataViewDialog212" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        检索
      </div>
      <div class="editorXinTwo">
        <label>案卷号：</label>
        <el-input v-model="params.kjc220" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>类别：</label>
        <el-input v-model="params.kjc15" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>卷(册、袋)标题：</label>
        <el-input v-model="params.kjtitleProper" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>起始时间：</label>
        <el-date-picker
          v-model="params.kjdateOfCreation"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div class="editorXinTwo">
        <label>终止时间：</label>
        <el-date-picker
          v-model="params.kjdateOfEnd"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div class="editorXinTwo">
        <label>凭证起始号：</label>
        <el-input v-model="params.kjc160" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>凭证终止号：</label>
        <el-input v-model="params.kjc162" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>移交类型：</label>
        <el-select v-model="params.type" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option
            v-for="item in handoverTypeModel"
            :key="item.itemValue"
            :label="item.name"
            :value="item.itemValue">
          </el-option>
        </el-select>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitBtn18">确定</el-button>
        <el-button @click="reset">重置</el-button>
        <el-button @click="getDataViewDialog212 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--检索--实物档案--印章-->
    <el-dialog :visible.sync="getDataViewDialog213" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        检索
      </div>
      <div class="editorXinTwo">
        <label>印章名称：</label>
        <el-input v-model="params.yzTitleProper" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>刻制年度：</label>
        <el-input v-model="params.yzYearCode" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>印章种类：</label>
        <el-input v-model="params.yzFileType" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>印章形状：</label>
        <el-input v-model="params.yzHandoverHt" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>责任者：</label>
        <el-input v-model="params.yzHandoverEmployer" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>印章状态：</label>
        <el-input v-model="params.yzSealStatus" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>刻制日期：</label>
        <el-date-picker
          v-model="params.yzFileDate"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div class="editorXinTwo">
        <label>移交类型：</label>
        <el-select v-model="params.type" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option
            v-for="item in handoverTypeModel"
            :key="item.itemValue"
            :label="item.name"
            :value="item.itemValue">
          </el-option>
        </el-select>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitBtn18">确定</el-button>
        <el-button @click="reset">重置</el-button>
        <el-button @click="getDataViewDialog213 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--检索--实物档案--非印章-->
    <el-dialog :visible.sync="getDataViewDialog214" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        检索
      </div>
      <div class="editorXinTwo">
        <label>名称：</label>
        <el-input v-model="params.qtTitleProper" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>年度：</label>
        <el-input v-model="params.qtYearCode" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>对方单位：</label>
        <el-input v-model="params.qtC161" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>类别：</label>
        <el-input v-model="params.qtC15" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>责任者：</label>
        <el-input v-model="params.qtC113" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>所属部门：</label>
        <el-input v-model="params.qtC68" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>日期：</label>
        <el-date-picker
          v-model="params.qtDataOfCreate"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div class="editorXinTwo">
        <label>移交类型：</label>
        <el-select v-model="params.type" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option
            v-for="item in handoverTypeModel"
            :key="item.itemValue"
            :label="item.name"
            :value="item.itemValue">
          </el-option>
        </el-select>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitBtn18">确定</el-button>
        <el-button @click="reset">重置</el-button>
        <el-button @click="getDataViewDialog214 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--检索--声像-->
    <el-dialog :visible.sync="getDataViewDialog215" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        检索
      </div>
      <div class="editorXinTwo">
        <label>题名：</label>
        <el-input v-model="params.sxtitleProper" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>地点：</label>
        <el-input v-model="params.sxtakePhotoPlace" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>背景：</label>
        <el-input v-model="params.sxc64" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>人物(职务)：</label>
        <el-input v-model="params.sxc65" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>摄(录)者：</label>
        <el-input v-model="params.sxtakePhotoPerson" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>所属部门：</label>
        <el-input v-model="params.sxc68" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>主题：</label>
        <el-input v-model="params.sxc69" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>日期：</label>
        <el-date-picker
          v-model="params.sxtakePhotoDate"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitBtn18">确定</el-button>
        <el-button @click="reset">重置</el-button>
        <el-button @click="getDataViewDialog215 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 录入模糊移交批次 -->
    <!--<el-dialog :visible.sync="getDataViewDialog22" width="1111px" class="hurdleAll" :before-close="handleCloseTwo">-->
    <el-dialog :visible.sync="getDataViewDialog22" width="1111px" class="hurdleAll" :before-close="handleClose">
      <div slot="title" class="dialog-title">录入模糊移交批次</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li class="editorXin" style="width: 50%;">
            <label>移交部门：</label>
            <el-select v-model="paramsYj.handoverDept" placeholder="请选择" filterable @change="yjUserChange" :disabled="showBtnLook">
              <!--<el-option v-for="item in handoverDeptArr" :key="item.organizeId" :label="item.organizeId + ' ' + item.organizeName" :value="item.organizeId"></el-option>-->
              <el-option v-for="(item, index) in handoverDeptArr" :key="index" :label="item.flag1 + ' ' + item.organizeName" :value="item.flag1"></el-option>
            </el-select>
          </li>
          <li class="editorXin" style="width: 50%;">
            <label>移交人姓名：</label>
            <el-select v-model="paramsYj.handoverUser" placeholder="请选择" filterable :disabled="showBtnLook">
              <el-option v-for="item in handoverUserArr" :key="item.userId" :label="item.userName" :value="item.userId"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList editorXin">
          <label>移交意见：</label>
          <el-input type="textarea" :rows="2" v-model="paramsYj.handoverRemark" :disabled="showBtnLook">
          </el-input>
        </div>
        <!--下-->
        <ul class="mangeShow">
          <li class="editorXin" style="width: 50%;">
            <label>全宗：</label>
            <el-select v-model="paramsYj.fonds" placeholder="请选择" filterable @change="fullZongBtnTwo" :disabled="showBtnLook">
              <el-option v-for="item in fullZongArrTwo" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </li>
          <li class="editorXin" style="width: 50%;">
            <label>档案类型：</label>
            <el-select v-model="paramsYj.series" placeholder="请选择" filterable :disabled="showBtnLook" @change="FondsAndRoleArrChange">
              <el-option v-for="item in FondsAndRoleArrTwo" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
      </div>
      <!--操作-->
      <div class="maxHeight">
        <!-- 下表格 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtomTwo"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileCode"
              label="文件号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="文件标题"
              width="230">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              sortable
              prop="fileDate"
              label="文件日期">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverPc"
              label="年度">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="isOriginal"
              label="是否原件">
              <template slot-scope="scope">
                <span v-if="scope.row.isOriginal == 0">是</span>
                <span v-else-if="scope.row.isOriginal == 1">否</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeTwo2"
            :current-page="paramsTwo1.page"
            :page-size="paramsTwo1.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo1.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="yjBtn" v-if="!showBtnLook">保存</el-button>
        <el-button  v-if="!showBtnLook" @click="paramsYj = {}">重置</el-button>
        <el-button type="primary" v-if="showBtnLook" @click="showLookBtn44">录入</el-button>
        <!--<el-button type="primary" v-if="showBtnLook" @click="showLookBtn55">发送代办</el-button>-->
        <el-button type="primary" v-if="showBtnLook" @click="getDataViewDialog49 = true">发送代办</el-button>
        <el-button @click="getDataViewDialog22 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--模糊查询--重新发送代办-->
    <el-dialog :visible.sync="getDataViewDialog23" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        代办发送确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/home/deleteGan.png" alt="">
        <div>确定要重新发送该移交确认代办给移交人吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn19">确定</el-button>
        <el-button @click="getDataViewDialog23 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 线下移交 -->
    <el-dialog :visible.sync="getDataViewDialog24" width="1256px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
        线下移交
      </div>
      <!-- 下拉框 -->
      <div>
        <ul class="mangeShow">
          <li class="editorXin">
            <label style="width: 110px">特殊档案类型：</label>
            <el-select v-model="specialListOnce" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       @change="specialChange"
            >
              <el-option v-for="item in specialList" :key="item.id" :label="item.archiveTypeName" :value="item.id"></el-option>
            </el-select>
          </li>
          <li class="editorXin">
            <label style="width: 110px">载体类型：</label>
            <el-select v-model="carrierListOnce" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       @change="carrierChange"
            >
              <el-option v-for="item in carrierList" :key="item.carrierId" :label="item.carrier" :value="item.carrierId"></el-option>
            </el-select>
          </li>
          <li class="editorXin">
            <label style="width: 110px">部门：</label>
            <el-select v-model="departListOnce" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       @change="departChange"
            >
              <!--@change="departChange"-->
              <el-option v-for="item in departList" :key="item.deptId" :label="item.dept" :value="item.deptId"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
      </div>
      <!--左侧栏表格-->
      <div class="dialogAddList">
        <div class="all-Table addTableList">
          <el-table
            :data="userListTable"
            stripe
            border
            style="width: 100%">
            <el-table-column
              prop="typeCode"
              label="材料编号"
              width="130">
            </el-table-column>
            <el-table-column
              prop="archiveTypeName"
              label="材料名称"
              width="180">
            </el-table-column>
            <el-table-column
              prop="createUserName"
              label="创建人"
              width="160">
            </el-table-column>
            <el-table-column
              prop="effectiveData"
              label="有效期限"
              width="180">
            </el-table-column>
            <el-table-column
              prop="createTime"
              label="创建时间"
              width="180">
            </el-table-column>
            <el-table-column
              label="操作"
              width="100">
              <template slot-scope="scope">
                <span style="cursor: pointer;color: #0067AD" @click="userAddBtn(scope.row)">添加</span>
              </template>
            </el-table-column>
          </el-table>
          <!-- 分页 -->
          <div class="pageLayout">
            <el-pagination
              @current-change="handleCurrentChangeUser"
              :current-page="paramsUser.page"
              :page-size="paramsUser.rows"
              layout="prev, pager, next, jumper"
              :total="paramsUser.total">
            </el-pagination>
          </div>
        </div>
      </div>
      <!--右侧栏表格-->
      <div class="dialogAddList">
        <!--<div class="all-Table" style="overflow-x: auto;border: 1px solid #929292;">
          <table border="0" cellspacing="0" style="width: 1056px;">
            <tr class="addTableList">
              <th style="width: 200px">移交部门</th>
              <th style="width: 200px">移交人</th>
              <th style="width: 200px">保管期限</th>
              <th style="width: 200px">意见</th>
              <th style="width: 160px">材料编号</th>
              <th style="width: 160px">材料名称</th>
              <th style="width: 130px">创建人</th>
              <th style="width: 160px">有效期限</th>
              <th style="width: 160px">创建时间</th>
              <th style="width: 100px">操作</th>
            </tr>
            &lt;!&ndash;<tr v-if="roleListTable.length >= 1"  class="addTableList">&ndash;&gt;
            <tr class="addTableList" v-for="(item, index) in roleListTable" :key="index">
              <td>
                &lt;!&ndash;移交部门&ndash;&gt;
                <el-select v-model="item.userBranch" placeholder="请选择"
                           filterable
                           remote
                           reserve-keyword
                >
                  <el-option v-for="item in handoverDeptArr" :key="item.organizeId" :label="item.organizeName" :value="item.organizeId"></el-option>
                </el-select>
              </td>
              <td>
                &lt;!&ndash;移交人&ndash;&gt;
                <el-select v-model="item.userId" placeholder="请选择"
                           filterable
                           remote
                           reserve-keyword
                >
                  <el-option v-for="item in handoverUserArrList" :key="item.userId" :label="item.userName" :value="item.userId"></el-option>
                </el-select>
              </td>
            </tr>
          </table>
          &lt;!&ndash;<div v-if="roleListTable.length < 1" style="min-height: 63px; line-height: 63px;text-indent: 333px; color:#909399;">暂无数据</div>&ndash;&gt;
        </div>-->
        <div class="all-Table addTableList">
          <el-table
            :data="roleListTable"
            stripe
            border
            style="width: 100%">
            <el-table-column
              prop="userBranch"
              label="移交部门"
              width="180">
              <template slot-scope="scope">
                <el-select v-model="scope.row.userBranch" placeholder="请选择"
                           filterable
                           remote
                           reserve-keyword
                >
                  <!--<el-option v-for="item in handoverDeptArr" :key="item.organizeId" :label="item.organizeName" :value="item.organizeId"></el-option>-->
                  <el-option v-for="(item, index) in handoverDeptArr" :key="index" :label="item.flag1 + ' ' + item.organizeName" :value="item.flag1"></el-option>
                </el-select>
              </template>
            </el-table-column>

            <el-table-column
              prop="userId"
              label="移交人"
              width="130">
              <template slot-scope="scope">
                <el-select v-model="scope.row.userId" placeholder="请选择"
                           filterable
                           remote
                           reserve-keyword
                >
                  <el-option v-for="item in handoverUserArrList" :key="item.userId" :label="item.userName" :value="item.userId"></el-option>
                </el-select>
              </template>
            </el-table-column>

            <el-table-column
              prop="itemValue"
              label="保管期限"
              width="130">
              <template slot-scope="scope">
                <el-select v-model="scope.row.itemValue" placeholder="请选择"
                           filterable
                           remote
                           reserve-keyword
                >
                  <el-option v-for="item in handoverPeriodArrList" :key="item.id" :label="item.name" :value="item.id"></el-option>
                </el-select>
              </template>
            </el-table-column>
            <el-table-column
              prop="idea"
              label="意见"
              width="160">
              <template slot-scope="scope">
                <el-input v-model="scope.row.idea" placeholder="请输入意见内容"></el-input>
              </template>
            </el-table-column>
            <el-table-column
              prop="typeCode"
              label="材料编号"
              width="130">
            </el-table-column>
            <el-table-column
              prop="archiveTypeName"
              label="材料名称"
              width="180">
            </el-table-column>
            <el-table-column
              prop="createUserName"
              label="创建人"
              width="160">
            </el-table-column>
            <el-table-column
              prop="effectiveData"
              label="有效期限"
              width="180">
            </el-table-column>
            <el-table-column
              prop="createTime"
              label="创建时间"
              width="180">
            </el-table-column>
            <el-table-column
              label="操作"
              width="100">
              <template slot-scope="scope">
                <span style="cursor: pointer;color: #0067AD" @click="deleteUserBtn(scope.row)">删除</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <!--<div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeRole"
            :current-page="paramsRole.page"
            :page-size="paramsRole.rows"
            layout="prev, pager, next, jumper"
            :total="paramsRole.total">
          </el-pagination>
        </div>-->
      </div>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn20">保存</el-button>
        <el-button @click="submitBtn21">重置</el-button>
        <el-button @click="getDataViewDialog24 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 定时设置 -->
    <el-dialog :visible.sync="getDataViewDialog25" width="1256px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/ds.png" alt="">
        定时设置
      </div>
      <!-- 下拉框 -->
      <div>
        <ul class="mangeShow">
          <li class="editorXin">
            <label style="width: 110px">发送类型：</label>
            <el-select v-model="paramsData.sendType" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       @change="sendTypeListChange"
            >
              <el-option v-for="item in sendTypeList" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </li>
          <li class="editorXin" v-show="statusShow">
            <label style="width: 110px">是否完成：</label>
            <el-select v-model="paramsData.status" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       @change="statusListChange"
            >
              <el-option v-for="item in statusList" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </li>
          <li class="editorXin">
            <label style="width: 110px">时间时长：</label>
            <el-select v-model="paramsData.matureDate" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       @change="matureDateChange"
            >
              <el-option v-for="item in matureDateList" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
      </div>
      <!--表格-->
      <div class="all-Table">
        <el-table
          :data="dataListTableOnce"
          stripe
          border
          style="width: 100%"
          @selection-change="handleSelectionChangeBtomData">
          <el-table-column
            type="selection"
            align="center"
            width="60">
          </el-table-column>
          <el-table-column
            prop="status"
            label="移交状态"
            width="130">
            <template slot-scope="scope">
              <span v-if="scope.row.status == 1">欠交</span>
              <span v-else-if="scope.row.status == 2">综合员审核</span>
              <span v-else-if="scope.row.status == 3">领导审核</span>
              <span v-else-if="scope.row.status == 4">档案员审核</span>
              <span v-else-if="scope.row.status == 5">已移交</span>
              <span v-else-if="scope.row.status == 6">不移交</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="serialNumber"
            label="移交单号"
            width="180">
          </el-table-column>
          <el-table-column
            prop="handoverUser"
            label="移交人姓名"
            width="160">
          </el-table-column>
          <el-table-column
            prop="handoverDept"
            label="移交部门"
            width="180">
          </el-table-column>
          <el-table-column
            prop="handoverDate"
            label="移交时间"
            width="180">
          </el-table-column>
          <el-table-column
            prop="tagName"
            label="档案类型"
            width="180">
          </el-table-column>
          <el-table-column
            prop="sendType"
            label="发送类型"
            width="180">
            <template slot-scope="scope">
              <span v-if="scope.row.sendType == 0">失败重发</span>
              <span v-else-if="scope.row.sendType == 1">定时发送</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="timing"
            label="时间过长"
            width="180">
            <template slot-scope="scope">
              <span v-if="scope.row.timing == 0">3月</span>
              <span v-else-if="scope.row.timing == 1">6月</span>
              <span v-else-if="scope.row.timing == 2">9月</span>
              <span v-else-if="scope.row.timing == 3">1年</span>
              <span v-else-if="scope.row.timing == 4">3年</span>
              <span v-else-if="scope.row.timing == 5">1天</span>
            </template>
          </el-table-column>
          <el-table-column
            prop="matureDate"
            sortable
            label="重发日期"
            width="180">
          </el-table-column>
        </el-table>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeUser"
            :current-page="paramsData.page"
            :page-size="paramsData.rows"
            layout="prev, pager, next, jumper"
            :total="paramsData.total">
          </el-pagination>
        </div>
      </div>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn22">保存</el-button>
        <el-button @click="getDataViewDialog25 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 批量挂接材料 -->
    <el-dialog :visible.sync="getDataViewDialog26" width="1111px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
        批量挂接材料
      </div>
      <!-- 下拉框 -->
      <div>
        <ul class="mangeShow">
          <li class="editorXin">
            <label>全宗：</label>
            <el-select v-model="paramsBatch.fonds" placeholder="请选择" filterable @change="fullZongBtnThree">
              <el-option v-for="item in fullZongArrTwo" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </li>
          <li class="editorXin">
            <label>档案类型：</label>
            <el-select v-model="paramsBatch.series" placeholder="请选择" filterable @change="newChange">
              <el-option v-for="item in FondsAndRoleArrTwo" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </li>
          <li class="editorXin">
            <label>匹配方式：</label>
            <el-select v-model="paramsBatch.matchingData" placeholder="请选择" filterable @change="matchingDataChange">
              <el-option v-for="item in matchingData" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
      </div>
      <!--上传图片-->
      <div style="width: 90%;margin: 0 auto;">
        <el-upload
          ref="AddBtnImgTwo"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          list-type="picture"
          :on-change="handleChangeThree"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
      </div>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn23">确定</el-button>
        <el-button @click="getDataViewDialog26 = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 投行移交单 -->
    <el-dialog :visible.sync="getDataViewDialog27" width="1111px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">投行移交单</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li>
            <label>移交人姓名：</label>
            <el-input v-model="showEdit.handoverUser" readonly></el-input>
          </li>
          <li>
            <label>移交部门：</label>
            <el-input v-model="showEdit.handoverDept" readonly></el-input>
          </li>
          <li>
            <label>移交时间：</label>
            <el-input v-model="showEdit.handoverDate" readonly></el-input>
          </li>
          <!--<li>-->
          <!--<label>操作指引：</label>-->
          <!--<el-button type="primary">下载</el-button>-->
          <!--</li>-->
          <div class="clear"></div>
        </ul>
        <!--中-->
        <ul class="mangeShow">
          <li>
            <label>接收人：</label>
            <el-input v-model="showEdit.receiveUser" readonly></el-input>
          </li>
          <li>
            <label>接收方式：</label>
            <el-select v-model="showEdit.handoverType"  placeholder="请选择" filterable @change="receiveBtn">
              <el-option
                v-for="item in handoverTypeList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <li v-if="!showDisable">
            <label>接收地址：</label>
            <el-input v-model="showEdit.receiveAddress" placeholder="请输入接收地址"></el-input>
          </li>
          <div class="clear"></div>
        </ul>
        <ul class="mangeShow">
          <li>
            <label>变更移交人：</label>
            <el-select v-model="showEdit.userId"  placeholder="请输入移交人检索" filterable remote reserve-keyword :remote-method="orgFlag">
              <el-option
                v-for="item in sqFondsList"
                :key="item.id"
                :label="item.text"
                :value="item.id">
              </el-option>
            </el-select>
          </li>
          <li>
            <label>运单号：</label>
            <el-input v-model="showEdit.handoverYdh" :disabled="showDisable"></el-input>
          </li>
          <li>
            <label>运营商：</label>
            <el-select v-model="showEdit.handoverYys"  placeholder="请选择" filterable :disabled="showDisable">
              <el-option
                v-for="item in handoverYysList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList">
          <label>申请人意见：</label>
          <el-input
            type="textarea"
            :rows="2"
            placeholder="提醒：请在申请意见中写明需移交档案内容及数量，点击“确认”即可。
 例：申请移交历史部门印章登记表，共6册，请档案中心评估接收。"
            v-model="showEdit.applyRemarkCopy">
          </el-input>
        </div>
        <!--下-列表-->
        <div class="mangeShowList">
          <p>意见详情：</p>
          <div class="showReadOnlyContent" v-if="showEdit.isOldDate == 0">
            <div v-html="showEdit.handoverRemark"></div>
          </div>
          <!-- 表格 -->
          <div class="all-Table" v-else-if="showEdit.isOldDate == 1" style="width: 83%;max-height: 300px;overflow: auto;margin: 0 auto;">
            <el-table
              :data="dialogTable"
              stripe
              border
              style="width: 100%">
              <el-table-column
                show-overflow-tooltip
                prop="handoverRemark"
                label="意见内容">
                <template slot-scope="scope">
                  <div v-for="(item, index) in scope.row.handoverRemark" :key="index">{{ item }}</div>
                </template>
              </el-table-column>
              <el-table-column
                prop="date"
                label="时间">
              </el-table-column>
              <el-table-column
                prop="sendName"
                label="操作人">
              </el-table-column>
            </el-table>
          </div>
        </div>
        <!--合同介绍-->
        <div class="mangeShowList">
          <label>合同上传要求：</label>
          <div class="heTong">
            1,文件彩色扫描为pdf格式；<br/>
            2,命名格式：原OA流程：公司公章："年份+合同号",例：2017年第0001号001份。部门公章：合同名称-扫描件,例：房屋租赁合同-扫描件。
            <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            BPM流程：不区分公司公章与部门公章，均以流程显示的合同号为准。例：广发证券[2018]001234号合同
          </div>
        </div>
      </div>
      <div class="maxHeight">
        <!-- 下操作 -->
        <div style="background-color: #F4F4F4;">
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn4">
            <img src="../../assets/turnOver/lr.png" alt="">
            <span>录入</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn27">
            <img src="../../assets/turnOver/delete.png" alt="">
            <!--<span @click="showLookBtn6">删除</span>-->
            <span>删除</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <!--<div class="searchBtn" @click="clearImgDel, getDataViewDialog9 = true">-->
          <div class="searchBtn" @click="daoRuExcel">
            <img src="../../assets/turnOver/dr.png" alt="">
            <span>导入Excel</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn32">
            <img src="../../assets/turnOver/yj.png" alt="">
            <span>添加异常</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn12">
            <img src="../../assets/turnOver/s5.png" alt="">
            <span>导出Excel模板</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 下表格 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtomTwo"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverThNumber"
              label="序号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverEmployer"
              label="项目单位全称"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileType"
              label="项目类型"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverHt"
              label="业务类型"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="项目名称"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              label="项目结束年度"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileCode"
              label="移交箱数"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileNum"
              label="移交册数"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="gzhangLevel"
              label="快递单号"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverDate"
              label="移交时间"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverPc"
              label="移交批次"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverException"
              label="移交异常"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverNote"
              label="备注"
              width="120">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <!--<el-pagination
            @current-change="handleCurrentChangeTwo2"
            :current-page="paramsTwo1.page"
            :page-size="paramsTwo1.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo1.total">
          </el-pagination>-->

          <el-pagination
            @current-change="handleCurrentChangeTwo2"
            :current-page.sync="paramsTwo1.page"
            :page-size="paramsTwo1.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo1.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="mangeBtnThree">确定</el-button>
        <el-button @click="getDataViewDialog27 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--投行移交单--确认-->
    <el-dialog :visible.sync="getDataViewDialog28" width="444px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">
        投行移交单确认
      </div>
      <div class="dia-delete">
        请尽快将实体档案移交至档案中心
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn28">确定</el-button>
        <el-button @click="getDataViewDialog28 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--线下移交--确定-->
    <el-dialog :visible.sync="getDataViewDialog29" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        移交确认（线下）
      </div>
      <div class="dia-delete">
        请同时将档案移交给部门综合员。
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn29">确定</el-button>
        <el-button @click="getDataViewDialog29 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 投行移交单--录入 -->
    <el-dialog :visible.sync="getDataViewDialog30" width="880px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">录入信息</div>
      <!--项目名称-->
      <ul class="mangeShowLook">
        <li class="editorXin" style="width: 100%;">
          <label>项目名称：</label>
          <el-input v-model="showEditLook.title" style="width: 82%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--项目单位全称-->
      <ul class="mangeShowLook">
        <li class="editorXin" style="width: 100%;">
          <label>项目单位全称：</label>
          <el-input v-model="showEditLook.handoverEmployer" style="width: 82%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--项目类型，业务类型，项目结束年度-->
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label>项目类型：</label>
          <el-input v-model="showEditLook.fileType"></el-input>
        </li>
        <li class="editorXin">
          <label>业务类型：</label>
          <el-input v-model="showEditLook.handoverHt"></el-input>
        </li>
        <li>
          <label>项目结束年度：</label>
          <el-input v-model="showEditLook.fileDate"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--移交箱数，移交册数，快递单号-->
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label>移交箱数：</label>
          <el-input v-model="showEditLook.fileCode"></el-input>
        </li>
        <li>
          <label>移交册数：</label>
          <el-input v-model="showEditLook.fileNum"></el-input>
        </li>
        <li class="editorXin">
          <label>快递单号：</label>
          <el-input v-model="showEditLook.gzhangLevel"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="submitBtn30">保存</el-button>
        <el-button @click="showEditLook = {}">重置</el-button>
        <el-button @click="getDataViewDialog30 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 投行移交单--录入 -->
    <el-dialog :visible.sync="getDataViewDialog31" width="880px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">移交详情单</div>
      <!-- 下操作 -->
      <div style="background-color: #F4F4F4;">
        <div class="searchBtn search-selectOnce"></div>
        <div class="searchBtn" @click="showLookBtn31">
          <img src="../../assets/turnOver/delete.png" alt="">
          <span>删除</span>
        </div>
      </div>
      <!-- 下表格 -->
      <div class="all-Table">
        <el-table
          ref="multipleTableBtomTwo"
          :data="dialogTableBtom27"
          stripe
          border
          @selection-change="handleSelectionChangeBtomTwo31">
          <el-table-column
            type="selection"
            align="center"
            width="55">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="handoverThNumber"
            label="序号"
            width="160">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="handoverEmployer"
            label="项目单位全称"
            width="160">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="fileType"
            label="项目类型"
            width="160">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="handoverHt"
            label="业务类型"
            width="120">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="title"
            label="项目名称"
            width="120">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="fileDate"
            label="项目结束年度"
            width="120">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="fileCode"
            label="移交箱数"
            width="120">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="fileNum"
            label="移交册数"
            width="120">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="gzhangLevel"
            label="快递单号"
            width="120">
          </el-table-column>
          <!--<el-table-column
            show-overflow-tooltip
            prop="handoverDate"
            label="移交时间"
            width="120">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="handoverPc"
            label="移交批次"
            width="120">
          </el-table-column>-->
          <el-table-column
            show-overflow-tooltip
            prop="handoverException"
            label="移交异常"
            width="120">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="handoverNote"
            label="备注"
            width="120">
          </el-table-column>
        </el-table>
      </div>
      <!-- 下分页 -->
      <div class="pageLayout">
        <el-pagination
          @current-change="handleCurrentChangeTwo27"
          :current-page="delete27.page"
          :page-size="delete27.rows"
          layout="prev, pager, next, jumper"
          :total="delete27.total">
        </el-pagination>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button @click="getDataViewDialog31 = false, showListBtom">关闭</el-button>
      </div>
    </el-dialog>
    <!--债券--确认-->
    <el-dialog :visible.sync="getDataViewDialog311" width="444px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">
        删除
      </div>
      <div class="dia-delete">
        确定删除此数据吗？
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="showLookBtn31Two">确定</el-button>
        <el-button @click="getDataViewDialog311 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 债券 -->
    <el-dialog :visible.sync="getDataViewDialog32" width="1111px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">债券移交单</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li>
            <label>移交人姓名：</label>
            <el-input v-model="showEdit.handoverUser" readonly></el-input>
          </li>
          <li>
            <label>移交部门：</label>
            <el-input v-model="showEdit.handoverDept" readonly></el-input>
          </li>
          <li>
            <label>移交时间：</label>
            <el-input v-model="showEdit.handoverDate" readonly></el-input>
          </li>
          <!--<li>-->
          <!--<label>操作指引：</label>-->
          <!--<el-button type="primary">下载</el-button>-->
          <!--</li>-->
          <div class="clear"></div>
        </ul>
        <!--中-->
        <ul class="mangeShow">
          <li>
            <label>接收人：</label>
            <el-input v-model="showEdit.receiveUser" readonly></el-input>
          </li>
          <li>
            <label>接收方式：</label>
            <el-select v-model="showEdit.handoverType"  placeholder="请选择" filterable @change="receiveBtn">
              <el-option
                v-for="item in handoverTypeList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <li v-if="!showDisable">
            <label>接收地址：</label>
            <el-input v-model="showEdit.receiveAddress" placeholder="请输入接收地址"></el-input>
          </li>
          <div class="clear"></div>
        </ul>
        <ul class="mangeShow">
          <li>
            <label>变更移交人：</label>
            <el-select v-model="showEdit.userId"  placeholder="请输入移交人检索" filterable remote reserve-keyword :remote-method="orgFlag">
              <el-option
                v-for="item in sqFondsList"
                :key="item.id"
                :label="item.text"
                :value="item.id">
              </el-option>
            </el-select>
          </li>
          <li>
            <label>运单号：</label>
            <el-input v-model="showEdit.handoverYdh" :disabled="showDisable"></el-input>
          </li>
          <li>
            <label>运营商：</label>
            <el-select v-model="showEdit.handoverYys"  placeholder="请选择" filterable :disabled="showDisable">
              <el-option
                v-for="item in handoverYysList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList">
          <label>申请人意见：</label>
          <el-input
            type="textarea"
            :rows="2"
            placeholder="提醒：请在申请意见中写明需移交档案内容及数量，点击“确认”即可。
 例：申请移交历史部门印章登记表，共6册，请档案中心评估接收。"
            v-model="showEdit.applyRemarkCopy">
          </el-input>
        </div>
        <!--下-列表-->
        <div class="mangeShowList">
          <p>意见详情：</p>
          <div class="showReadOnlyContent" v-if="showEdit.isOldDate == 0">
            <div v-html="showEdit.handoverRemark"></div>
          </div>
          <!-- 表格 -->
          <div class="all-Table" v-else-if="showEdit.isOldDate == 1" style="width: 83%;max-height: 300px;overflow: auto;margin: 0 auto;">
            <el-table
              :data="dialogTable"
              stripe
              border
              style="width: 100%">
              <el-table-column
                show-overflow-tooltip
                prop="handoverRemark"
                label="意见内容">
                <template slot-scope="scope">
                  <div v-for="(item, index) in scope.row.handoverRemark" :key="index">{{ item }}</div>
                </template>
              </el-table-column>
              <el-table-column
                prop="date"
                label="时间">
              </el-table-column>
              <el-table-column
                prop="sendName"
                label="操作人">
              </el-table-column>
            </el-table>
          </div>
        </div>
        <!--合同介绍-->
        <div class="mangeShowList">
          <label>合同上传要求：</label>
          <div class="heTong">
            1,文件彩色扫描为pdf格式；<br/>
            2,命名格式：原OA流程：公司公章："年份+合同号",例：2017年第0001号001份。部门公章：合同名称-扫描件,例：房屋租赁合同-扫描件。
            <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            BPM流程：不区分公司公章与部门公章，均以流程显示的合同号为准。例：广发证券[2018]001234号合同
          </div>
        </div>
      </div>
      <div class="maxHeight">
        <!-- 下操作 -->
        <div style="background-color: #F4F4F4;">
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtnTwo">
            <img src="../../assets/turnOver/ck.png" alt="">
            <span>查看</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn4">
            <img src="../../assets/turnOver/lr.png" alt="">
            <span>录入</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn27">
            <img src="../../assets/turnOver/delete.png" alt="">
            <!--<span @click="showLookBtn6">删除</span>-->
            <span>删除</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <!--<div class="searchBtn" @click="clearImgDel, getDataViewDialog9 = true">-->
          <div class="searchBtn" @click="daoRuExcel">
            <img src="../../assets/turnOver/dr.png" alt="">
            <span>导入Excel</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn32">
            <img src="../../assets/turnOver/tj.png" alt="">
            <span>添加异常</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn12">
            <img src="../../assets/turnOver/s5.png" alt="">
            <span>导出Excel模板</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn7">
            <img src="../../assets/turnOver/sc.png" alt="">
            <span>上传</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn10">
            <img src="../../assets/turnOver/gl.png" alt="">
            <span>删除附件</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 下表格 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtomTwo"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverThNumber"
              label="序号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverEmployer"
              label="项目单位全称"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileType"
              label="项目类型"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverHt"
              label="业务类型"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="项目名称"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              label="项目结束年度"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileCode"
              label="移交箱数"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileNum"
              label="移交册数"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="gzhangLevel"
              label="快递单号"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverDate"
              label="移交时间"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverPc"
              label="移交批次"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverException"
              label="移交异常"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverNote"
              label="备注"
              width="120">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeTwo2"
            :current-page="paramsTwo1.page"
            :page-size="paramsTwo1.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo1.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="mangeBtnThree">确定</el-button>
        <el-button @click="getDataViewDialog32 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--债券--确认-->
    <el-dialog :visible.sync="getDataViewDialog33" width="444px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">
        债券移交单确认
      </div>
      <div class="dia-delete">
        请尽快将实体档案移交至档案中心
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn28">确定</el-button>
        <el-button @click="getDataViewDialog33 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--投资和债券，移交异常-->
    <el-dialog :visible.sync="getDataViewDialog34" width="880px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">
        移交异常
      </div>
      <div>
        <span style="font-size: 20px;">移交异常A类：</span>
        <div class="zqCheck">
          <el-checkbox :disabled="yiChangDisOne" ref="checkBossOne" v-model="thZqDate.oneData" true-label="原件丢失或损毁" @change="yiChangDisChange">原件丢失或损毁</el-checkbox>
          <el-checkbox :disabled="yiChangDisTwo" ref="checkBossTwo" v-model="thZqDate.twoData" true-label="无原件且无复印件" @change="yiChangDisChange">无原件且无复印件</el-checkbox>
        </div>
      </div>
      <br>
      <div>
        <span style="font-size: 20px;">移交异常B类：</span>
        <div class="zqCheck">
          <el-checkbox :disabled="yiChangDisThree" ref="checkBossThree" v-model="thZqDate.threeData" true-label="原件不完整（对方未盖章）" @change="yiChangDisChangeTwo">原件不完整（对方未盖章）</el-checkbox>
          <el-checkbox :disabled="yiChangDisFour" ref="checkBossFour" v-model="thZqDate.fourData" true-label="原件不完整（无签署时间）" @change="yiChangDisChangeTwo">原件不完整（无签署时间）</el-checkbox>
          <el-checkbox :disabled="yiChangDisFive" ref="checkBossFive" v-model="thZqDate.fiveData" true-label="无原件有复印件" @change="yiChangDisChangeTwo">无原件有复印件</el-checkbox>
          <el-checkbox :disabled="yiChangDisSix" ref="checkBossSix" v-model="thZqDate.sixData" true-label="原件不完整（对方未签名）" @change="yiChangDisChangeTwo">原件不完整（对方未签名）</el-checkbox>
          <el-checkbox :disabled="yiChangDisSevem" ref="checkBossSeven" v-model="thZqDate.seveData" true-label="原件不完整（缺失部分页）" @change="yiChangDisChangeTwo">原件不完整（缺失部分页）</el-checkbox>
          <el-checkbox :disabled="yiChangDisEight" ref="checkBossEight" v-model="thZqDate.eightData" true-label="合同（已盖章）作废" @change="yiChangDisChangeTwo">合同（已盖章）作废</el-checkbox>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn34">确定</el-button>
        <el-button @click="getDataViewDialog34 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 实物印章移交单 -->
    <el-dialog :visible.sync="getDataViewDialog35" width="1111px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">{{ paramsTwo.titleOnce}}</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li>
            <label>移交人姓名：</label>
            <el-input v-model="showEdit.handoverUser" readonly></el-input>
          </li>
          <li>
            <label>移交部门：</label>
            <el-input v-model="showEdit.handoverDept" readonly></el-input>
          </li>
          <li>
            <label>移交时间：</label>
            <el-input v-model="showEdit.handoverDate" readonly></el-input>
          </li>
          <!--<li>-->
          <!--<label>操作指引：</label>-->
          <!--<el-button type="primary">下载</el-button>-->
          <!--</li>-->
          <div class="clear"></div>
        </ul>
        <!--中-->
        <ul class="mangeShow">
          <li>
            <label>接收人：</label>
            <el-input v-model="showEdit.receiveUser" readonly></el-input>
          </li>
          <li>
            <label>接收方式：</label>
            <el-select v-model="showEdit.handoverType"  placeholder="请选择" filterable @change="receiveBtn">
              <el-option
                v-for="item in handoverTypeList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <li v-if="!showDisable">
            <label>接收地址：</label>
            <el-input v-model="showEdit.receiveAddress" placeholder="请输入接收地址"></el-input>
          </li>
          <div class="clear"></div>
        </ul>
        <ul class="mangeShow">
          <li>
            <label>变更移交人：</label>
            <el-select v-model="showEdit.userId"  placeholder="请输入移交人检索" filterable remote reserve-keyword :remote-method="orgFlag">
              <el-option
                v-for="item in sqFondsList"
                :key="item.id"
                :label="item.text"
                :value="item.id">
              </el-option>
            </el-select>
          </li>
          <li>
            <label>运单号：</label>
            <el-input v-model="showEdit.handoverYdh" :disabled="showDisable"></el-input>
          </li>
          <li>
            <label>运营商：</label>
            <el-select v-model="showEdit.handoverYys"  placeholder="请选择" filterable :disabled="showDisable">
              <el-option
                v-for="item in handoverYysList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList">
          <label>申请人意见：</label>
          <el-input
            type="textarea"
            :rows="2"
            placeholder="提醒：请在申请意见中写明需移交档案内容及数量，点击“确认”即可。
 例：申请移交历史部门印章登记表，共6册，请档案中心评估接收。"
            v-model="showEdit.applyRemarkCopy">
          </el-input>
        </div>
        <!--下-列表-->
        <div class="mangeShowList">
          <p>意见详情：</p>
          <div class="showReadOnlyContent" v-if="showEdit.isOldDate == 0">
            <div v-html="showEdit.handoverRemark"></div>
          </div>
          <!-- 表格 -->
          <div class="all-Table" v-else-if="showEdit.isOldDate == 1" style="width: 83%;max-height: 300px;overflow: auto;margin: 0 auto;">
            <el-table
              :data="dialogTable"
              stripe
              border
              style="width: 100%">
              <el-table-column
                show-overflow-tooltip
                prop="handoverRemark"
                label="意见内容">
                <template slot-scope="scope">
                  <div v-for="(item, index) in scope.row.handoverRemark" :key="index">{{ item }}</div>
                </template>
              </el-table-column>
              <el-table-column
                prop="date"
                label="时间">
              </el-table-column>
              <el-table-column
                prop="sendName"
                label="操作人">
              </el-table-column>
            </el-table>
          </div>
        </div>
        <!--合同介绍-->
        <div class="mangeShowList">
          <label>合同上传要求：</label>
          <div class="heTong">
            1,文件彩色扫描为pdf格式；<br/>
            2,命名格式：原OA流程：公司公章："年份+合同号",例：2017年第0001号001份。部门公章：合同名称-扫描件,例：房屋租赁合同-扫描件。
            <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            BPM流程：不区分公司公章与部门公章，均以流程显示的合同号为准。例：广发证券[2018]001234号合同
          </div>
        </div>
      </div>
      <div class="maxHeight">
        <!-- 下操作 -->
        <div style="background-color: #F4F4F4;">
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtnTwo">
            <img src="../../assets/turnOver/ck.png" alt="">
            <span>查看</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn35">
            <img src="../../assets/turnOver/lr.png" alt="">
            <span>录入</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn">
            <img src="../../assets/turnOver/bj.png" alt="">
            <span v-if="params.series2 == 1374133285844" @click="showLookBtn38">编辑</span>
            <span v-else @click="showLookBtn40">编辑</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn6">
            <img src="../../assets/turnOver/delete.png" alt="">
            <span>删除</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn7">
            <img src="../../assets/turnOver/sc.png" alt="">
            <span>上传</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <!--<div class="searchBtn" @click="clearImgDel, getDataViewDialog9 = true">-->
          <div class="searchBtn" @click="daoRuExcel">
            <img src="../../assets/turnOver/dr.png" alt="">
            <span>导入Excel</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn10">
            <img src="../../assets/turnOver/gl.png" alt="">
            <span>删除附件</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn12">
            <img src="../../assets/turnOver/s5.png" alt="">
            <span>导出Excel模板</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 下表格 -->
        <div v-if="params.series2 == 1374133285844" class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtomTwo"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="caseNo"
              label="盒号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverThNumber"
              label="件号"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="印章名称"
              width="220">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverPc"
              label="刻制年度"
              width="230">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              label="刻制日期"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverEmployer"
              label="责任者"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="gzhangLevel"
              label="保管期限"
              width="160">
              <template slot-scope="scope">
                <span v-if="scope.row.retentionPeriod == 3">永久</span>
                <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
                <span v-else-if="scope.row.retentionPeriod == 1">短期</span>
                <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
                <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
                <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileType"
              label="印章种类"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverHt"
              label="印章形状"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="sealStatus"
              label="印章状态"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverNote"
              label="备注"
              width="160">
            </el-table-column>
          </el-table>
        </div>
        <div v-else-if="params.series2 == 1374133285845 || params.series2 == 1374133285846 || params.series2 == 1374133285847
          || params.series2 == 1374133285848 || params.series2 == 1374133285849" class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtomTwo"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverThNumber"
              label="件号"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverPc"
              label="年度"
              width="230">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="名称"
              width="200">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              label="获奖日期"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverEmployer"
              label="对方单位"
              width="200">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileType"
              label="类别"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverNote"
              label="备注"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="belongDept"
              label="所属部门"
              width="200">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="author"
              label="责任者"
              width="160">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeTwo2"
            :current-page="paramsTwo1.page"
            :page-size="paramsTwo1.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo1.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="mangeBtn35">确定</el-button>
        <el-button @click="getDataViewDialog35 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--实物印章移交单--确认-->
    <el-dialog :visible.sync="getDataViewDialog36" width="444px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">
        移交单确认
      </div>
      <div class="dia-delete">
        请同时将档案移交给部门综合员。
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn35">确定</el-button>
        <el-button @click="getDataViewDialog36 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 实物印章移交单--录入（印章） -->
    <el-dialog :visible.sync="getDataViewDialog37" width="880px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">录入</div>
      <!--文号，题名-->
      <ul class="mangeShowLook">
        <li>
          <label>盒号：</label>
          <el-input v-model="showEditLook.caseNo"></el-input>
        </li>
        <li>
          <label>件号：</label>
          <el-input v-model="showEditLook.itemNo"></el-input>
        </li>
        <li class="editorXin">
          <label>印章名称：</label>
          <el-input v-model="showEditLook.titleProper"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--文件日期，年度，页数-->
      <ul class="mangeShowLook">
        <li>
          <label>刻制日期：</label>
          <el-date-picker
            v-model="showEditLook.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <li class="editorXin">
          <label>保管期限：</label>
          <el-select v-model="showEditLook.retentionPeriod" filterable placeholder="请选择">
            <el-option
              v-for="item in retentionPeriod"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </li>
        <li>
          <label>公开属性：</label>
          <el-select v-model="showEditLook.openingType" filterable placeholder="请选择">
            <el-option
              v-for="item in openingTypeTwo"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </li>
        <div class="clear"></div>
      </ul>
      <!--责任者，公开属性，分类号-->
      <ul class="mangeShowLook">
        <li>
          <label>印章种类：</label>
          <el-input v-model="showEditLook.c164"></el-input>
        </li>
        <li>
          <label>印章形状：</label>
          <el-input v-model="showEditLook.c73"></el-input>
        </li>
        <li>
          <label>印章状态：</label>
          <el-input v-model="showEditLook.c66"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--是否为原件，归档部门，归档人-->
      <ul class="mangeShowLook">
        <li>
          <label>责任者：</label>
          <el-input v-model="showEditLook.c113"></el-input>
        </li>
        <li class="editorXin">
          <label>分类号：</label>
          <el-input v-model="showEditLook.seriesCode"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--备注-->
      <ul class="mangeShowLook">
        <li style="width: 804px;">
          <label>备注：</label>
          <el-input type="textarea" v-model="showEditLook.c8" style="width: 85%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="submitBtn37">保存</el-button>
        <el-button @click="showEditLook = {}">重置</el-button>
        <el-button @click="getDataViewDialog37 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 实物印章移交单--编辑 -->
    <el-dialog :visible.sync="getDataViewDialog38" width="880px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">编辑文件信息</div>
      <!--文号，题名-->
      <ul class="mangeShowLook">
        <li>
          <label>盒号：</label>
          <el-input v-model="showEditLook.caseNo"></el-input>
        </li>
        <li>
          <label>件号：</label>
          <el-input v-model="showEditLook.itemNo"></el-input>
        </li>
        <li class="editorXin">
          <label>印章名称：</label>
          <el-input v-model="showEditLook.titleProper"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--文件日期，年度，页数-->
      <ul class="mangeShowLook">
        <li>
          <label>刻制日期：</label>
          <el-date-picker
            v-model="showEditLook.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <li class="editorXin">
          <label>保管期限：</label>
          <el-select v-model="showEditLook.retentionPeriod" filterable placeholder="请选择">
            <el-option
              v-for="item in retentionPeriod"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </li>
        <li>
          <label>公开属性：</label>
          <el-select v-model="showEditLook.openingType" filterable placeholder="请选择">
            <el-option
              v-for="item in openingTypeTwo"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </li>
        <div class="clear"></div>
      </ul>
      <!--责任者，公开属性，分类号-->
      <ul class="mangeShowLook">
        <li>
          <label>印章种类：</label>
          <el-input v-model="showEditLook.c164"></el-input>
        </li>
        <li>
          <label>印章形状：</label>
          <el-input v-model="showEditLook.c73"></el-input>
        </li>
        <li>
          <label>印章状态：</label>
          <el-input v-model="showEditLook.c66"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--是否为原件，归档部门，归档人-->
      <ul class="mangeShowLook">
        <li>
          <label>责任者：</label>
          <el-input v-model="showEditLook.c113"></el-input>
        </li>
        <li class="editorXin">
          <label>分类号：</label>
          <el-input v-model="showEditLook.seriesCode"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--备注-->
      <ul class="mangeShowLook">
        <li style="width: 804px;">
          <label>备注：</label>
          <el-input type="textarea" v-model="showEditLook.c8" style="width: 85%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="submitBtn38">保存</el-button>
        <el-button @click="showLookBtn38">重置</el-button>
        <el-button @click="getDataViewDialog38 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 实物印章移交单--录入（奖牌） -->
    <el-dialog :visible.sync="getDataViewDialog39" width="880px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">录入</div>
      <!--件号，名称，对面单位-->
      <ul class="mangeShowLook">
        <li>
          <label>件号：</label>
          <el-input v-model="showEditLook.itemNo"></el-input>
        </li>
        <li class="editorXin">
          <label>名称：</label>
          <el-input v-model="showEditLook.titleProper"></el-input>
        </li>
        <li class="editorXin">
          <label>对方单位：</label>
          <el-input v-model="showEditLook.c161"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--日期，类别-->
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label>日期：</label>
          <el-date-picker
            v-model="showEditLook.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <li>
          <label>类别：</label>
          <el-input v-model="showEditLook.c15"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--所属部门，责任者，分类号-->
      <ul class="mangeShowLook">
        <li>
          <label>所属部门：</label>
          <el-input v-model="showEditLook.c68"></el-input>
        </li>
        <li>
          <label>责任者：</label>
          <el-input v-model="showEditLook.c113"></el-input>
        </li>
        <li class="editorXin">
          <label>分类号：</label>
          <el-input v-model="showEditLook.seriesCode"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--备注-->
      <ul class="mangeShowLook">
        <li style="width: 804px;">
          <label>备注：</label>
          <el-input type="textarea" v-model="showEditLook.c8" style="width: 85%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="submitBtn39">保存</el-button>
        <el-button @click="showEditLook = {}">重置</el-button>
        <el-button @click="getDataViewDialog39 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 实物印章移交单--编辑（奖牌） -->
    <el-dialog :visible.sync="getDataViewDialog40" width="880px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">编辑</div>
      <!--件号，名称，对面单位-->
      <ul class="mangeShowLook">
        <li>
          <label>件号：</label>
          <el-input v-model="showEditLook.itemNo"></el-input>
        </li>
        <li class="editorXin">
          <label>名称：</label>
          <el-input v-model="showEditLook.titleProper"></el-input>
        </li>
        <li class="editorXin">
          <label>对方单位：</label>
          <el-input v-model="showEditLook.c161"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--日期，类别-->
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label>日期：</label>
          <el-date-picker
            v-model="showEditLook.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <li>
          <label>类别：</label>
          <el-input v-model="showEditLook.c15"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--所属部门，责任者，分类号-->
      <ul class="mangeShowLook">
        <li>
          <label>所属部门：</label>
          <el-input v-model="showEditLook.c68"></el-input>
        </li>
        <li>
          <label>责任者：</label>
          <el-input v-model="showEditLook.c113"></el-input>
        </li>
        <li class="editorXin">
          <label>分类号：</label>
          <el-input v-model="showEditLook.seriesCode"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--备注-->
      <ul class="mangeShowLook">
        <li style="width: 804px;">
          <label>备注：</label>
          <el-input type="textarea" v-model="showEditLook.c8" style="width: 85%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="submitBtn40">保存</el-button>
        <el-button @click="showLookBtn40">重置</el-button>
        <el-button @click="getDataViewDialog40 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--下载整理Excel -->
    <el-dialog :visible.sync="getDataViewDialog88" width="444px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">
        系统提示
      </div>
      <div class="dia-delete">
        确定要下载该模板吗?
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajFileDownload88">确定</el-button>
        <el-button @click="getDataViewDialog88 = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 会计--移交弹框 -->
    <el-dialog :visible.sync="getDataViewDialog41" width="1111px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">会计移交交单</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li>
            <label>移交人姓名：</label>
            <el-input v-model="showEdit.handoverUser" readonly></el-input>
          </li>
          <li>
            <label>移交部门：</label>
            <el-input v-model="showEdit.handoverDept" readonly></el-input>
          </li>
          <li>
            <label>移交时间：</label>
            <el-input v-model="showEdit.handoverDate" readonly></el-input>
          </li>
          <!--<li>-->
          <!--<label>操作指引：</label>-->
          <!--<el-button type="primary">下载</el-button>-->
          <!--</li>-->
          <div class="clear"></div>
        </ul>
        <!--中-->
        <ul class="mangeShow">
          <li>
            <label>接收人：</label>
            <el-input v-model="showEdit.receiveUser" readonly></el-input>
          </li>
          <li>
            <label>接收方式：</label>
            <el-select v-model="showEdit.handoverType"  placeholder="请选择" filterable @change="receiveBtn">
              <el-option
                v-for="item in handoverTypeList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <li v-if="!showDisable">
            <label>接收地址：</label>
            <el-input v-model="showEdit.receiveAddress" placeholder="请输入接收地址"></el-input>
          </li>
          <div class="clear"></div>
        </ul>
        <ul class="mangeShow">
          <li>
            <label>变更移交人：</label>
            <el-select v-model="showEdit.userId"  placeholder="请输入移交人检索" filterable remote reserve-keyword :remote-method="orgFlag">
              <el-option
                v-for="item in sqFondsList"
                :key="item.id"
                :label="item.text"
                :value="item.id">
              </el-option>
            </el-select>
          </li>
          <li>
            <label>运单号：</label>
            <el-input v-model="showEdit.handoverYdh" :disabled="showDisable"></el-input>
          </li>
          <li>
            <label>运营商：</label>
            <el-select v-model="showEdit.handoverYys"  placeholder="请选择" filterable :disabled="showDisable">
              <el-option
                v-for="item in handoverYysList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList">
          <label>申请人意见：</label>
          <el-input
            type="textarea"
            :rows="2"
            v-model="showEdit.applyRemarkCopy">
          </el-input>
        </div>
        <!--下-列表-->
        <div class="mangeShowList">
          <p>意见详情：</p>
          <div class="showReadOnlyContent" v-if="showEdit.isOldDate == 0">
            <div v-html="showEdit.handoverRemark"></div>
          </div>
          <!-- 表格 -->
          <div class="all-Table" v-else-if="showEdit.isOldDate == 1" style="width: 83%;max-height: 300px;overflow: auto;margin: 0 auto;">
            <el-table
              :data="dialogTable"
              stripe
              border
              style="width: 100%">
              <el-table-column
                show-overflow-tooltip
                prop="handoverRemark"
                label="意见内容">
                <template slot-scope="scope">
                  <div v-for="(item, index) in scope.row.handoverRemark" :key="index">{{ item }}</div>
                </template>
              </el-table-column>
              <el-table-column
                prop="date"
                label="时间">
              </el-table-column>
              <el-table-column
                prop="sendName"
                label="操作人">
              </el-table-column>
            </el-table>
          </div>
        </div>
        <!--合同介绍-->
        <div class="mangeShowList">
          <label>合同上传要求：</label>
          <div class="heTong">
            1,文件彩色扫描为pdf格式；<br/>
            2,命名格式：原OA流程：公司公章："年份+合同号",例：2017年第0001号001份。部门公章：合同名称-扫描件,例：房屋租赁合同-扫描件。
            <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            BPM流程：不区分公司公章与部门公章，均以流程显示的合同号为准。例：广发证券[2018]001234号合同
          </div>
        </div>
      </div>
      <div class="maxHeight">
        <!-- 下操作 -->
        <div style="background-color: #F4F4F4;">
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtnTwo">
            <img src="../../assets/turnOver/ck.png" alt="">
            <span>查看</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn41">
            <img src="../../assets/turnOver/lr.png" alt="">
            <span>录入</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn42">
            <img src="../../assets/turnOver/bj.png" alt="">
            <span>编辑</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn6">
            <img src="../../assets/turnOver/delete.png" alt="">
            <span>删除</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn7">
            <img src="../../assets/turnOver/sc.png" alt="">
            <span>上传</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <!--<div class="searchBtn" @click="clearImgDel, getDataViewDialog9 = true">-->
          <div class="searchBtn" @click="daoRuExcel">
            <img src="../../assets/turnOver/dr.png" alt="">
            <span>导入Excel</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn10">
            <img src="../../assets/turnOver/gl.png" alt="">
            <span>删除附件</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn12">
            <img src="../../assets/turnOver/s5.png" alt="">
            <span>导出Excel模板</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 下表格 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtomTwo"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileCode"
              label="文件号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="文件标题"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              sortable
              label="文件日期"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverPc"
              label="年度">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="isOriginal"
              label="是否原件"
              width="100">
              <template slot-scope="scope">
                <span v-if="scope.row.isOriginal == 0">是</span>
                <span v-else-if="scope.row.isOriginal == 1">否</span>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverException"
              label="移交异常"
              width="500">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeTwo2"
            :current-page="paramsTwo1.page"
            :page-size="paramsTwo1.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo1.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="mangeBtn35">确定</el-button>
        <el-button @click="getDataViewDialog41 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 会计--录入 -->
    <el-dialog :visible.sync="getDataViewDialog42" width="1111px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">会计信息录入</div>
      <!--案卷号，类别，卷(册、袋)标题-->
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label style="width: 124px;">案卷号：</label>
          <el-input v-model="showEditLook.c220"></el-input>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">类别：</label>
          <el-input v-model="showEditLook.c15"></el-input>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">卷(册、袋)标题：</label>
          <el-input v-model="showEditLook.titleProper"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--保管期限，类别，凭证止号-->
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label style="width: 124px;">保管期限：</label>
          <el-select v-model="showEditLook.retentionPeriod" filterable placeholder="请选择">
            <el-option
              v-for="item in retentionPeriod"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">凭证起号：</label>
          <el-input v-model="showEditLook.c160"></el-input>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">凭证止号：</label>
          <el-input v-model="showEditLook.c162"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--所属部门，责任者，分类号-->
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label style="width: 124px;">起止日期（起）：</label>
          <el-date-picker
            v-model="showEditLook.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">起止日期（止）：</label>
          <el-date-picker
            v-model="showEditLook.dateOfEnd"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">年度：</label>
          <el-input v-model="showEditLook.yearCode"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <ul class="mangeShowLook">
        <li>
          <label style="width: 124px;">卷内张数：</label>
          <el-input v-model="showEditLook.amountOfPages"></el-input>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">所属部门：</label>
          <el-input v-model="showEditLook.c113"></el-input>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">分类号：</label>
          <el-input v-model="showEditLook.c163"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--备注-->
      <ul class="mangeShowLook">
        <li style="width: 99.5%;">
          <label style="width: 124px;">备注：</label>
          <el-input type="textarea" v-model="showEditLook.c8" style="width: 85%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="submitBtn42">保存</el-button>
        <el-button @click="showEditLook = {}">重置</el-button>
        <el-button @click="getDataViewDialog42 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 会计--编辑 -->
    <el-dialog :visible.sync="getDataViewDialog43" width="1111px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">会计信息编辑</div>
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label style="width: 124px;">案卷号：</label>
          <el-input v-model="showEditLook.c220"></el-input>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">类别：</label>
          <el-input v-model="showEditLook.c15"></el-input>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">卷(册、袋)标题：</label>
          <el-input v-model="showEditLook.titleProper"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label style="width: 124px;">保管期限：</label>
          <el-select v-model="showEditLook.retentionPeriod" filterable placeholder="请选择">
            <el-option
              v-for="item in retentionPeriod"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">凭证起号：</label>
          <el-input v-model="showEditLook.c160"></el-input>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">凭证止号：</label>
          <el-input v-model="showEditLook.c162"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label style="width: 124px;">起止日期（起）：</label>
          <el-date-picker
            v-model="showEditLook.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">起止日期（止）：</label>
          <el-date-picker
            v-model="showEditLook.dateOfEnd"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">年度：</label>
          <el-input v-model="showEditLook.yearCode"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <ul class="mangeShowLook">
        <li>
          <label style="width: 124px;">卷内张数：</label>
          <el-input v-model="showEditLook.amountOfPages"></el-input>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">所属部门：</label>
          <el-input v-model="showEditLook.c113"></el-input>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">分类号：</label>
          <el-input v-model="showEditLook.c163"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--备注-->
      <ul class="mangeShowLook">
        <li style="width: 99.5%;">
          <label style="width: 124px;">备注：</label>
          <el-input type="textarea" v-model="showEditLook.c8" style="width: 85%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="submitBtn43">保存</el-button>
        <el-button @click="showLookBtn42">重置</el-button>
        <el-button @click="getDataViewDialog43 = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 声像--移交弹框 -->
    <el-dialog :visible.sync="getDataViewDialog44" width="1111px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">声像移交交单</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li>
            <label>移交人姓名：</label>
            <el-input v-model="showEdit.handoverUser" readonly></el-input>
          </li>
          <li>
            <label>移交部门：</label>
            <el-input v-model="showEdit.handoverDept" readonly></el-input>
          </li>
          <li>
            <label>移交时间：</label>
            <el-input v-model="showEdit.handoverDate" readonly></el-input>
          </li>
          <!--<li>-->
          <!--<label>操作指引：</label>-->
          <!--<el-button type="primary">下载</el-button>-->
          <!--</li>-->
          <div class="clear"></div>
        </ul>
        <!--中-->
        <ul class="mangeShow">
          <li>
            <label>接收人：</label>
            <el-input v-model="showEdit.receiveUser" readonly></el-input>
          </li>
          <li>
            <label>接收方式：</label>
            <el-select v-model="showEdit.handoverType"  placeholder="请选择" filterable @change="receiveBtn">
              <el-option
                v-for="item in handoverTypeList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <li v-if="!showDisable">
            <label>接收地址：</label>
            <el-input v-model="showEdit.receiveAddress" placeholder="请输入接收地址"></el-input>
          </li>
          <div class="clear"></div>
        </ul>
        <ul class="mangeShow">
          <li>
            <label>变更移交人：</label>
            <el-select v-model="showEdit.userId"  placeholder="请输入移交人检索" filterable remote reserve-keyword :remote-method="orgFlag">
              <el-option
                v-for="item in sqFondsList"
                :key="item.id"
                :label="item.text"
                :value="item.id">
              </el-option>
            </el-select>
          </li>
          <li>
            <label>运单号：</label>
            <el-input v-model="showEdit.handoverYdh" :disabled="showDisable"></el-input>
          </li>
          <li>
            <label>运营商：</label>
            <el-select v-model="showEdit.handoverYys"  placeholder="请选择" filterable :disabled="showDisable">
              <el-option
                v-for="item in handoverYysList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList">
          <label>申请人意见：</label>
          <el-input
            type="textarea"
            :rows="2"
            placeholder="提醒：请在申请意见中写明需移交档案内容及数量，点击“确认”即可。
 例：申请移交历史部门印章登记表，共6册，请档案中心评估接收。"
            v-model="showEdit.applyRemarkCopy">
          </el-input>
        </div>
        <!--下-列表-->
        <div class="mangeShowList">
          <p>意见详情：</p>
          <div class="showReadOnlyContent" v-if="showEdit.isOldDate == 0">
            <div v-html="showEdit.handoverRemark"></div>
          </div>
          <!-- 表格 -->
          <div class="all-Table" v-else-if="showEdit.isOldDate == 1" style="width: 83%;max-height: 300px;overflow: auto;margin: 0 auto;">
            <el-table
              :data="dialogTable"
              stripe
              border
              style="width: 100%">
              <el-table-column
                show-overflow-tooltip
                prop="handoverRemark"
                label="意见内容">
                <template slot-scope="scope">
                  <div v-for="(item, index) in scope.row.handoverRemark" :key="index">{{ item }}</div>
                </template>
              </el-table-column>
              <el-table-column
                prop="date"
                label="时间">
              </el-table-column>
              <el-table-column
                prop="sendName"
                label="操作人">
              </el-table-column>
            </el-table>
          </div>
        </div>
        <!--合同介绍-->
        <div class="mangeShowList">
          <label>合同上传要求：</label>
          <div class="heTong">
            1,文件彩色扫描为pdf格式；<br/>
            2,命名格式：原OA流程：公司公章："年份+合同号",例：2017年第0001号001份。部门公章：合同名称-扫描件,例：房屋租赁合同-扫描件。
            <br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            BPM流程：不区分公司公章与部门公章，均以流程显示的合同号为准。例：广发证券[2018]001234号合同
          </div>
        </div>
      </div>
      <div class="maxHeight">
        <!-- 下操作 -->
        <div style="background-color: #F4F4F4;">
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtnTwo">
            <img src="../../assets/turnOver/ck.png" alt="">
            <span>查看</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn45">
            <img src="../../assets/turnOver/lr.png" alt="">
            <span>录入</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn46">
            <img src="../../assets/turnOver/bj.png" alt="">
            <span>编辑</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn6">
            <img src="../../assets/turnOver/delete.png" alt="">
            <span>删除</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn7">
            <img src="../../assets/turnOver/sc.png" alt="">
            <span>上传</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <!--<div class="searchBtn" @click="clearImgDel, getDataViewDialog9 = true">-->
          <div class="searchBtn" @click="daoRuExcel">
            <img src="../../assets/turnOver/dr.png" alt="">
            <span>导入Excel</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn10">
            <img src="../../assets/turnOver/gl.png" alt="">
            <span>删除附件</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn12">
            <img src="../../assets/turnOver/s5.png" alt="">
            <span>导出Excel模板</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 下表格 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtomTwo"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverThNumber"
              label="件号"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="题名"
              width="230">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="theme"
              label="主题"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              label="拍摄时间"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="site"
              label="地点"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="background"
              label="背景"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="personage"
              label="人物(职务)"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="photographer"
              label="摄(录)者"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="belongDept"
              label="所属部门"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverNote"
              label="内容简介"
              width="160">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeTwo2"
            :current-page="paramsTwo1.page"
            :page-size="paramsTwo1.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo1.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="mangeBtn35">确定</el-button>
        <el-button @click="getDataViewDialog44 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 声像--录入 -->
    <el-dialog :visible.sync="getDataViewDialog45" width="1111px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">声像信息录入</div>
      <ul class="mangeShowLook">
        <li>
          <label style="width: 124px;">件号：</label>
          <el-input v-model="showEditLook.itemNo"></el-input>
        </li>
        <li class="editorXin" style="width: 63.7%;">
          <label style="width: 124px;">题名：</label>
          <el-input v-model="showEditLook.titleProper" style="width: 81%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label style="width: 124px;">主题：</label>
          <el-input v-model="showEditLook.c69"></el-input>
        </li>
        <li>
          <label style="width: 124px;">拍摄时间：</label>
          <el-date-picker
            v-model="showEditLook.takePhotoDate"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <div class="clear"></div>
      </ul>
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label style="width: 124px;">地点：</label>
          <el-input v-model="showEditLook.takePhotoPlace"></el-input>
        </li>
        <li class="">
          <label style="width: 124px;">背景：</label>
          <el-input v-model="showEditLook.c64"></el-input>
        </li>
        <li>
          <label style="width: 124px;">人物(职务)：</label>
          <el-input v-model="showEditLook.c65"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <ul class="mangeShowLook">
        <li class="">
          <label style="width: 124px;">摄(录)者：</label>
          <el-input v-model="showEditLook.takePhotoPerson"></el-input>
        </li>
        <li class="">
          <label style="width: 124px;">所属部门：</label>
          <el-input v-model="showEditLook.c68"></el-input>
        </li>
        <li>
          <label style="width: 124px;">分类号：</label>
          <el-input v-model="showEditLook.seriesCode"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--备注-->
      <ul class="mangeShowLook">
        <li style="width: 99.5%;">
          <label style="width: 124px;">备注：</label>
          <el-input type="textarea" v-model="showEditLook.c8" style="width: 85%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="submitBtn45">保存</el-button>
        <el-button @click="showEditLook = {}">重置</el-button>
        <el-button @click="getDataViewDialog45 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 声像--编辑 -->
    <el-dialog :visible.sync="getDataViewDialog46" width="1111px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">声像信息编辑</div>
      <ul class="mangeShowLook">
        <li>
          <label style="width: 124px;">件号：</label>
          <el-input v-model="showEditLook.itemNo"></el-input>
        </li>
        <li class="editorXin" style="width: 63.7%;">
          <label style="width: 124px;">题名：</label>
          <el-input v-model="showEditLook.titleProper" style="width: 81%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label style="width: 124px;">主题：</label>
          <el-input v-model="showEditLook.c69"></el-input>
        </li>
        <li>
          <label style="width: 124px;">拍摄时间：</label>
          <el-date-picker
            v-model="showEditLook.takePhotoDate"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <div class="clear"></div>
      </ul>
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label style="width: 124px;">地点：</label>
          <el-input v-model="showEditLook.takePhotoPlace"></el-input>
        </li>
        <li class="">
          <label style="width: 124px;">背景：</label>
          <el-input v-model="showEditLook.c64"></el-input>
        </li>
        <li>
          <label style="width: 124px;">人物(职务)：</label>
          <el-input v-model="showEditLook.c65"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <ul class="mangeShowLook">
        <li class="">
          <label style="width: 124px;">摄(录)者：</label>
          <el-input v-model="showEditLook.takePhotoPerson"></el-input>
        </li>
        <li class="">
          <label style="width: 124px;">所属部门：</label>
          <el-input v-model="showEditLook.c68"></el-input>
        </li>
        <li>
          <label style="width: 124px;">分类号：</label>
          <el-input v-model="showEditLook.seriesCode"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--备注-->
      <ul class="mangeShowLook">
        <li style="width: 99.5%;">
          <label style="width: 124px;">备注：</label>
          <el-input type="textarea" v-model="showEditLook.c8" style="width: 85%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="submitBtn46">保存</el-button>
        <el-button @click="showLookBtn46">重置</el-button>
        <el-button @click="getDataViewDialog46 = false">取消</el-button>
      </div>
    </el-dialog>

    <!--下载非PDF文件-->
    <el-dialog :visible.sync="getDataViewDialog47" width="444px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">
        系统提示
      </div>
      <div class="dia-delete">
        该电子全文暂不提供在线浏览，您是否要离线下载此文件？
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn47">确定</el-button>
        <el-button @click="getDataViewDialog47 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--下载  导入Excel文件错误信息-->
    <el-dialog :visible.sync="getDataViewDialog48" width="444px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">
        系统提示
      </div>
      <div class="dia-delete">
        是否要导出错误信息？
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn48">确定</el-button>
        <el-button @click="getDataViewDialog48 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--代办发送确认-->
    <el-dialog :visible.sync="getDataViewDialog49" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        代办发送确认
      </div>
      <div class="dia-delete">
        确定要发送移交确认代办给移交人吗？
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="showLookBtn55">确定</el-button>
        <el-button @click="getDataViewDialog49 = false">取消</el-button>
      </div>
    </el-dialog>

    <!--投资银行录入移交批次-->
    <el-dialog :visible.sync="getDataViewDialog50" width="1111px" class="hurdleAll" :before-close="handleClose">
      <div slot="title" class="dialog-title">录入投行移交批次</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li class="editorXin" style="width: 50%;">
            <label>移交部门：</label>
            <el-select v-model="paramsYj.handoverDept" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       @change="yjUserChange"
                       :disabled="showBtnLook"
            >
              <!--<el-option v-for="item in handoverDeptArr" :key="item.organizeId" :label="item.organizeId + ' ' + item.organizeName" :value="item.organizeId"></el-option>-->
              <el-option v-for="(item, index) in handoverDeptArr" :key="index" :label="item.flag1 + ' ' + item.organizeName" :value="item.flag1"></el-option>
            </el-select>
          </li>
          <li class="editorXin" style="width: 50%;">
            <label>移交人姓名：</label>
            <el-select v-model="paramsYj.handoverUser" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       :disabled="showBtnLook"
            >
              <el-option v-for="item in handoverUserArr" :key="item.userId" :label="item.userName" :value="item.userId"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList editorXin">
          <label>移交意见：</label>
          <el-input
            type="textarea"
            :rows="2"
            v-model="paramsYj.handoverRemark"
            :disabled="showBtnLook"
          >
          </el-input>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <!--<el-button type="primary" @click="showLookBtn44">录入</el-button>-->
        <el-button type="primary" @click="showLookBtn50">录入</el-button>
        <!--<el-button type="primary" @click="yjBtn">保存</el-button>-->
        <el-button type="primary" @click="paramsYj = {}">重置</el-button>
        <el-button @click="getDataViewDialog50 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--债券录入移交批次-->
    <el-dialog :visible.sync="getDataViewDialog51" width="1111px" class="hurdleAll" :before-close="handleClose">
      <div slot="title" class="dialog-title">录入债券移交批次</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li class="editorXin" style="width: 50%;">
            <label>移交部门：</label>
            <el-select v-model="paramsYj.handoverDept" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       @change="yjUserChange"
                       :disabled="showBtnLook"
            >
              <!--<el-option v-for="item in handoverDeptArr" :key="item.organizeId" :label="item.organizeId + ' ' + item.organizeName" :value="item.organizeId"></el-option>-->
              <el-option v-for="(item, index) in handoverDeptArr" :key="index" :label="item.flag1 + ' ' + item.organizeName" :value="item.flag1"></el-option>
            </el-select>
          </li>
          <li class="editorXin" style="width: 50%;">
            <label>移交人姓名：</label>
            <el-select v-model="paramsYj.handoverUser" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       :disabled="showBtnLook"
            >
              <el-option v-for="item in handoverUserArr" :key="item.userId" :label="item.userName" :value="item.userId"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList editorXin">
          <label>移交意见：</label>
          <el-input
            type="textarea"
            :rows="2"
            v-model="paramsYj.handoverRemark"
            :disabled="showBtnLook"
          >
          </el-input>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <!--<el-button type="primary" @click="showLookBtn44">录入</el-button>-->
        <el-button type="primary" @click="showLookBtn50">录入</el-button>
        <!--<el-button type="primary" @click="yjBtn">保存</el-button>-->
        <el-button type="primary" @click="paramsYj = {}">重置</el-button>
        <el-button @click="getDataViewDialog51 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--会计录入移交批次-->
    <el-dialog :visible.sync="getDataViewDialog52" width="1111px" class="hurdleAll" :before-close="handleClose">
      <div slot="title" class="dialog-title">录入模糊移交批次</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li class="editorXin" style="width: 50%;">
            <label>移交部门：</label>
            <el-select v-model="paramsYj.handoverDept" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       @change="yjUserChange"
                       :disabled="showBtnLook"
            >
              <!--<el-option v-for="item in handoverDeptArr" :key="item.organizeId" :label="item.organizeId + ' ' + item.organizeName" :value="item.organizeId"></el-option>-->
              <el-option v-for="(item, index) in handoverDeptArr" :key="index" :label="item.flag1 + ' ' + item.organizeName" :value="item.flag1"></el-option>
            </el-select>
          </li>
          <li class="editorXin" style="width: 50%;">
            <label>移交人姓名：</label>
            <el-select v-model="paramsYj.handoverUser" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       :disabled="showBtnLook"
            >
              <el-option v-for="item in handoverUserArr" :key="item.userId" :label="item.userName" :value="item.userId"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList editorXin">
          <label>移交意见：</label>
          <el-input
            type="textarea"
            :rows="2"
            v-model="paramsYj.handoverRemark"
            :disabled="showBtnLook"
          >
          </el-input>
        </div>
        <!--下-->
        <ul class="mangeShow">
          <li class="editorXin" style="width: 50%;">
            <label>全宗：</label>
            <el-select v-model="paramsYj.fonds" placeholder="请选择" filterable @change="fullZongBtnTwo" :disabled="showBtnLook">
              <el-option v-for="item in fullZongArrTwo" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </li>
          <li class="editorXin" style="width: 50%;">
            <label>档案类型：</label>
            <!-- <el-select v-model="paramsYj.series" placeholder="请选择" filterable :disabled="showBtnLook">
               <el-option v-for="item in FondsAndRoleArr" :key="item.id" :label="item.name" :value="item.id"></el-option>
             </el-select>-->
            <el-select v-model="paramsYj.series" filterable placeholder="请选择" @change="searchSeriesOnceTwo" :disabled="showBtnLook" style="width: 31%;">
              <el-option v-for="item in FondsAndRoleArrTwo" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
            <el-select v-model="paramsYj.series1" filterable placeholder="请选择" :disabled="showBtnLook" style="width: 30%;">
              <el-option v-for="item in FondsAndRoleTwoOnce" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--操作-->
        <div class="maxHeight">
          <!-- 下表格 -->
          <div class="all-Table">
            <el-table
              ref="multipleTableBtomTwo"
              :data="dialogTableBtomTwo"
              stripe
              border
              @selection-change="handleSelectionChangeBtomTwo">
              <el-table-column
                type="selection"
                align="center"
                width="55">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="serialNumber"
                label="案卷号"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="fileType"
                label="类别"
                width="120">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="title"
                label="卷（册、袋）标题"
                width="230">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                sortable
                prop="startDate"
                label="起始时间"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                sortable
                prop="endDate"
                label="终止时间"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="handoverHt"
                label="凭证起始号"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="handoverPc"
                label="凭证终止号"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="gzhangLevel"
                label="保管期限"
                width="160">
                <template slot-scope="scope">
                  <span v-if="scope.row.gzhangLevel == 3">永久</span>
                  <span v-else-if="scope.row.gzhangLevel == 2">长期</span>
                  <span v-else-if="scope.row.gzhangLevel == 1">短期</span>
                  <span v-else-if="scope.row.gzhangLevel == 5">10年</span>
                  <span v-else-if="scope.row.gzhangLevel == 6">15年</span>
                  <span v-else-if="scope.row.gzhangLevel == 8">30年</span>
                </template>
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="fileNum"
                label="卷内张数"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="handoverNote"
                label="备考"
                width="160">
              </el-table-column>
            </el-table>
          </div>
          <!-- 下分页 -->
          <div class="pageLayout">
            <el-pagination
              @current-change="handleCurrentChangeTwo2"
              :current-page="paramsTwo1.page"
              :page-size="paramsTwo1.rows"
              layout="prev, pager, next, jumper"
              :total="paramsTwo1.total">
            </el-pagination>
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="yjBtn" v-if="!showBtnLook">保存</el-button>
        <el-button  v-if="!showBtnLook" @click="paramsYj = {}">重置</el-button>
        <el-button type="primary" v-if="showBtnLook" @click="showLookBtn44">录入</el-button>
        <!--<el-button type="primary" v-if="showBtnLook" @click="showLookBtn55">发送代办</el-button>-->
        <el-button type="primary" v-if="showBtnLook" @click="getDataViewDialog49 = true">发送代办</el-button>
        <el-button @click="getDataViewDialog52 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 会计--录入 -->
    <el-dialog :visible.sync="getDataViewDialog522" width="1111px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">会计信息录入</div>
      <!--案卷号，类别，卷(册、袋)标题-->
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label style="width: 124px;">案卷号：</label>
          <el-input v-model="showEditLook.c220"></el-input>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">类别：</label>
          <el-input v-model="showEditLook.c15"></el-input>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">卷(册、袋)标题：</label>
          <el-input v-model="showEditLook.titleProper"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--保管期限，类别，凭证止号-->
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label style="width: 124px;">保管期限：</label>
          <el-select v-model="showEditLook.retentionPeriod" filterable placeholder="请选择">
            <el-option
              v-for="item in retentionPeriod"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">凭证起号：</label>
          <el-input v-model="showEditLook.c160"></el-input>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">凭证止号：</label>
          <el-input v-model="showEditLook.c162"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--所属部门，责任者，分类号-->
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label style="width: 124px;">起止日期（起）：</label>
          <el-date-picker
            v-model="showEditLook.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">起止日期（止）：</label>
          <el-date-picker
            v-model="showEditLook.dateOfEnd"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">年度：</label>
          <el-input v-model="showEditLook.yearCode"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <ul class="mangeShowLook">
        <li>
          <label style="width: 124px;">卷内张数：</label>
          <el-input v-model="showEditLook.amountOfPages"></el-input>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">所属部门：</label>
          <el-input v-model="showEditLook.c113"></el-input>
        </li>
        <li class="editorXin">
          <label style="width: 124px;">分类号：</label>
          <el-input v-model="showEditLook.c163"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--备注-->
      <ul class="mangeShowLook">
        <li style="width: 99.5%;">
          <label style="width: 124px;">备注：</label>
          <el-input type="textarea" v-model="showEditLook.c8" style="width: 85%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="submitBtn52">保存</el-button>
        <el-button @click="showEditLook = {}">重置</el-button>
        <el-button @click="getDataViewDialog522 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--实物录入移交批次(印章）-->
    <el-dialog :visible.sync="getDataViewDialog53" width="1111px" class="hurdleAll" :before-close="handleClose">
      <div slot="title" class="dialog-title">录入模糊移交批次</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li class="editorXin" style="width: 50%;">
            <label>移交部门：</label>
            <el-select v-model="paramsYj.handoverDept" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       @change="yjUserChange"
                       :disabled="showBtnLook"
            >
              <!--<el-option v-for="item in handoverDeptArr" :key="item.organizeId" :label="item.organizeId + ' ' + item.organizeName" :value="item.organizeId"></el-option>-->
              <el-option v-for="(item, index) in handoverDeptArr" :key="index" :label="item.flag1 + ' ' + item.organizeName" :value="item.flag1"></el-option>
            </el-select>
          </li>
          <li class="editorXin" style="width: 50%;">
            <label>移交人姓名：</label>
            <el-select v-model="paramsYj.handoverUser" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       :disabled="showBtnLook"
            >
              <el-option v-for="item in handoverUserArr" :key="item.userId" :label="item.userName" :value="item.userId"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList editorXin">
          <label>移交意见：</label>
          <el-input
            type="textarea"
            :rows="2"
            v-model="paramsYj.handoverRemark"
            :disabled="showBtnLook"
          >
          </el-input>
        </div>
        <!--下-->
        <ul class="mangeShow">
          <li class="editorXin" style="width: 50%;">
            <label>全宗：</label>
            <el-select v-model="paramsYj.fonds" placeholder="请选择" filterable @change="fullZongBtnTwo" :disabled="showBtnLook">
              <el-option v-for="item in fullZongArrTwo" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </li>
          <li class="editorXin" style="width: 50%;">
            <label>档案类型：</label>
            <!-- <el-select v-model="paramsYj.series" placeholder="请选择"
                        filterable
                        remote
                        reserve-keyword
                        :disabled="showBtnLook"
             >
               <el-option v-for="item in FondsAndRoleArr" :key="item.id" :label="item.name" :value="item.id"></el-option>
             </el-select>-->
            <el-select v-model="paramsYj.series" filterable placeholder="请选择" @change="searchSeriesOnceTwo" :disabled="showBtnLook" style="width: 31%;">
              <el-option v-for="item in FondsAndRoleArrTwo" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
            <el-select v-model="paramsYj.series1" filterable placeholder="请选择" :disabled="showBtnLook" style="width: 30%;">
              <el-option v-for="item in FondsAndRoleTwoOnce" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--操作-->
        <div class="maxHeight">
          <!-- 下表格 -->
          <div class="all-Table">
            <el-table
              ref="multipleTableBtomTwo"
              :data="dialogTableBtomTwo"
              stripe
              border
              @selection-change="handleSelectionChangeBtomTwo">
              <el-table-column
                type="selection"
                align="center"
                width="55">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="caseNo"
                label="盒号"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="handoverThNumber"
                label="件号"
                width="120">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="handoverPc"
                label="刻制年度"
                width="230">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="fileDate"
                label="刻制日期"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="handoverEmployer"
                label="责任者"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="gzhangLevel"
                label="保管期限"
                width="160">
                  <template slot-scope="scope">
                    <span v-if="scope.row.retentionPeriod == 3">永久</span>
                    <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
                    <span v-else-if="scope.row.retentionPeriod == 1">短期</span>
                    <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
                    <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
                    <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
                  </template>
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="fileType"
                label="印章种类"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="handoverHt"
                label="印章形状"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="sealStatus"
                label="印章状态"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="handoverNote"
                label="备注"
                width="160">
              </el-table-column>
            </el-table>
          </div>
          <!-- 下分页 -->
          <div class="pageLayout">
            <el-pagination
              @current-change="handleCurrentChangeTwo2"
              :current-page="paramsTwo1.page"
              :page-size="paramsTwo1.rows"
              layout="prev, pager, next, jumper"
              :total="paramsTwo1.total">
            </el-pagination>
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="yjBtn" v-if="!showBtnLook">保存</el-button>
        <el-button  v-if="!showBtnLook" @click="paramsYj = {}">重置</el-button>
        <el-button type="primary" v-if="showBtnLook" @click="showLookBtn44">录入</el-button>
        <!--<el-button type="primary" v-if="showBtnLook" @click="showLookBtn55">发送代办</el-button>-->
        <el-button type="primary" v-if="showBtnLook" @click="getDataViewDialog49 = true">发送代办</el-button>
        <el-button @click="getDataViewDialog53 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 实物印章移交单--录入（印章） -->
    <el-dialog :visible.sync="getDataViewDialog533" width="880px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">录入</div>
      <!--文号，题名-->
      <ul class="mangeShowLook">
        <li>
          <label>盒号：</label>
          <el-input v-model="showEditLook.caseNo"></el-input>
        </li>
        <li>
          <label>件号：</label>
          <el-input v-model="showEditLook.itemNo"></el-input>
        </li>
        <li class="editorXin">
          <label>印章名称：</label>
          <el-input v-model="showEditLook.titleProper"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--文件日期，年度，页数-->
      <ul class="mangeShowLook">
        <li>
          <label>刻制日期：</label>
          <el-date-picker
            v-model="showEditLook.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <li class="editorXin">
          <label>保管期限：</label>
          <el-select v-model="showEditLook.retentionPeriod" filterable placeholder="请选择">
            <el-option
              v-for="item in retentionPeriod"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </li>
        <li>
          <label>公开属性：</label>
          <el-select v-model="showEditLook.openingType" filterable placeholder="请选择">
            <el-option
              v-for="item in openingTypeTwo"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </li>
        <div class="clear"></div>
      </ul>
      <!--责任者，公开属性，分类号-->
      <ul class="mangeShowLook">
        <li>
          <label>印章种类：</label>
          <el-input v-model="showEditLook.c164"></el-input>
        </li>
        <li>
          <label>印章形状：</label>
          <el-input v-model="showEditLook.c73"></el-input>
        </li>
        <li>
          <label>印章状态：</label>
          <el-input v-model="showEditLook.c66"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--是否为原件，归档部门，归档人-->
      <ul class="mangeShowLook">
        <li>
          <label>责任者：</label>
          <el-input v-model="showEditLook.c113"></el-input>
        </li>
        <li class="editorXin">
          <label>分类号：</label>
          <el-input v-model="showEditLook.seriesCode"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--备注-->
      <ul class="mangeShowLook">
        <li style="width: 804px;">
          <label>备注：</label>
          <el-input type="textarea" v-model="showEditLook.c8" style="width: 85%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="submitBtn533">保存</el-button>
        <el-button @click="showEditLook = {}">重置</el-button>
        <el-button @click="getDataViewDialog533 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--实物录入移交批次(奖杯）-->
    <el-dialog :visible.sync="getDataViewDialog54" width="1111px" class="hurdleAll" :before-close="handleClose">
      <div slot="title" class="dialog-title">录入模糊移交批次</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li class="editorXin" style="width: 50%;">
            <label>移交部门：</label>
            <el-select v-model="paramsYj.handoverDept" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       @change="yjUserChange"
                       :disabled="showBtnLook"
            >
              <!--<el-option v-for="item in handoverDeptArr" :key="item.organizeId" :label="item.organizeId + ' ' + item.organizeName" :value="item.organizeId"></el-option>-->
              <el-option v-for="(item, index) in handoverDeptArr" :key="index" :label="item.flag1 + ' ' + item.organizeName" :value="item.flag1"></el-option>
            </el-select>
          </li>
          <li class="editorXin" style="width: 50%;">
            <label>移交人姓名：</label>
            <el-select v-model="paramsYj.handoverUser" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       :disabled="showBtnLook"
            >
              <el-option v-for="item in handoverUserArr" :key="item.userId" :label="item.userName" :value="item.userId"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList editorXin">
          <label>移交意见：</label>
          <el-input
            type="textarea"
            :rows="2"
            v-model="paramsYj.handoverRemark"
            :disabled="showBtnLook"
          >
          </el-input>
        </div>
        <!--下-->
        <ul class="mangeShow">
          <li class="editorXin" style="width: 50%;">
            <label>全宗：</label>
            <el-select v-model="paramsYj.fonds" placeholder="请选择" filterable @change="fullZongBtnTwo" :disabled="showBtnLook">
              <el-option v-for="item in fullZongArrTwo" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </li>
          <li class="editorXin" style="width: 50%;">
            <label>档案类型：</label>
            <!-- <el-select v-model="paramsYj.series" placeholder="请选择"
                        filterable
                        remote
                        reserve-keyword
                        :disabled="showBtnLook"
             >
               <el-option v-for="item in FondsAndRoleArr" :key="item.id" :label="item.name" :value="item.id"></el-option>
             </el-select>-->
            <el-select v-model="paramsYj.series" filterable placeholder="请选择" @change="searchSeriesOnceTwo" :disabled="showBtnLook" style="width: 31%;">
              <el-option v-for="item in FondsAndRoleArrTwo" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
            <el-select v-model="paramsYj.series1" filterable placeholder="请选择" :disabled="showBtnLook" style="width: 30%;">
              <el-option v-for="item in FondsAndRoleTwoOnce" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--操作-->
        <div class="maxHeight">
          <!-- 下表格 -->
          <div class="all-Table">
            <el-table
              ref="multipleTableBtomTwo"
              :data="dialogTableBtomTwo"
              stripe
              border
              @selection-change="handleSelectionChangeBtomTwo">
              <el-table-column
                type="selection"
                align="center"
                width="55">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="handoverThNumber"
                label="件号"
                width="120">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="handoverPc"
                label="年度"
                width="230">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="title"
                label="名称"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="fileDate"
                label="获奖日期"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="handoverEmployer"
                label="对方单位"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="fileType"
                label="类别"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="handoverNote"
                label="备注"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="belongDept"
                label="所属部门"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="author"
                label="责任者"
                width="160">
              </el-table-column>
            </el-table>
          </div>
          <!-- 下分页 -->
          <div class="pageLayout">
            <el-pagination
              @current-change="handleCurrentChangeTwo2"
              :current-page="paramsTwo1.page"
              :page-size="paramsTwo1.rows"
              layout="prev, pager, next, jumper"
              :total="paramsTwo1.total">
            </el-pagination>
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="yjBtn" v-if="!showBtnLook">保存</el-button>
        <el-button  v-if="!showBtnLook" @click="paramsYj = {}">重置</el-button>
        <el-button type="primary" v-if="showBtnLook" @click="showLookBtn44">录入</el-button>
        <!--<el-button type="primary" v-if="showBtnLook" @click="showLookBtn55">发送代办</el-button>-->
        <el-button type="primary" v-if="showBtnLook" @click="getDataViewDialog49 = true">发送代办</el-button>
        <el-button @click="getDataViewDialog54 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 实物印章移交单--录入（奖牌） -->
    <el-dialog :visible.sync="getDataViewDialog544" width="880px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">录入</div>
      <!--件号，名称，对面单位-->
      <ul class="mangeShowLook">
        <li>
          <label>件号：</label>
          <el-input v-model="showEditLook.itemNo"></el-input>
        </li>
        <li class="editorXin">
          <label>名称：</label>
          <el-input v-model="showEditLook.titleProper"></el-input>
        </li>
        <li class="editorXin">
          <label>对方单位：</label>
          <el-input v-model="showEditLook.c161"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--日期，类别-->
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label>日期：</label>
          <el-date-picker
            v-model="showEditLook.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <li>
          <label>类别：</label>
          <el-input v-model="showEditLook.c15"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--所属部门，责任者，分类号-->
      <ul class="mangeShowLook">
        <li>
          <label>所属部门：</label>
          <el-input v-model="showEditLook.c68"></el-input>
        </li>
        <li>
          <label>责任者：</label>
          <el-input v-model="showEditLook.c113"></el-input>
        </li>
        <li class="editorXin">
          <label>分类号：</label>
          <el-input v-model="showEditLook.seriesCode"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--备注-->
      <ul class="mangeShowLook">
        <li style="width: 804px;">
          <label>备注：</label>
          <el-input type="textarea" v-model="showEditLook.c8" style="width: 85%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <!--<el-button type="primary" @click="submitBtn39">保存</el-button>-->
        <el-button type="primary" @click="submitBtn544">保存</el-button>
        <el-button @click="showEditLook = {}">重置</el-button>
        <el-button @click="getDataViewDialog544 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--实物录入移交批次(声像）-->
    <el-dialog :visible.sync="getDataViewDialog55" width="1111px" class="hurdleAll" :before-close="handleClose">
      <div slot="title" class="dialog-title">录入模糊移交批次</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li class="editorXin" style="width: 50%;">
            <label>移交部门：</label>
            <el-select v-model="paramsYj.handoverDept" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       @change="yjUserChange"
                       :disabled="showBtnLook"
            >
              <!--<el-option v-for="item in handoverDeptArr" :key="item.organizeId" :label="item.organizeId + ' ' + item.organizeName" :value="item.organizeId"></el-option>-->
              <el-option v-for="(item, index) in handoverDeptArr" :key="index" :label="item.flag1 + ' ' + item.organizeName" :value="item.flag1"></el-option>
            </el-select>
          </li>
          <li class="editorXin" style="width: 50%;">
            <label>移交人姓名：</label>
            <el-select v-model="paramsYj.handoverUser" placeholder="请选择"
                       filterable
                       remote
                       reserve-keyword
                       :disabled="showBtnLook"
            >
              <el-option v-for="item in handoverUserArr" :key="item.userId" :label="item.userName" :value="item.userId"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList editorXin">
          <label>移交意见：</label>
          <el-input
            type="textarea"
            :rows="2"
            v-model="paramsYj.handoverRemark"
            :disabled="showBtnLook"
          >
          </el-input>
        </div>
        <!--下-->
        <ul class="mangeShow">
          <li class="editorXin" style="width: 50%;">
            <label>全宗：</label>
            <el-select v-model="paramsYj.fonds" placeholder="请选择" filterable @change="fullZongBtnTwo" :disabled="showBtnLook">
              <el-option v-for="item in fullZongArrTwo" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </li>
          <li class="editorXin" style="width: 50%;">
            <label>档案类型：</label>
            <!-- <el-select v-model="paramsYj.series" placeholder="请选择"
                        filterable
                        remote
                        reserve-keyword
                        :disabled="showBtnLook"
             >
               <el-option v-for="item in FondsAndRoleArr" :key="item.id" :label="item.name" :value="item.id"></el-option>
             </el-select>-->
            <el-select v-model="paramsYj.series" filterable placeholder="请选择" @change="searchSeriesOnceTwo" :disabled="showBtnLook" style="width: 31%;">
              <el-option v-for="item in FondsAndRoleArrTwo" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
            <el-select v-model="paramsYj.series1" filterable placeholder="请选择" :disabled="showBtnLook" style="width: 30%;">
              <el-option v-for="item in FondsAndRoleTwoOnce" :key="item.id" :label="item.name" :value="item.id"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--操作-->
        <div class="maxHeight">
          <!-- 下表格 -->
          <div class="all-Table">
            <el-table
              ref="multipleTableBtomTwo"
              :data="dialogTableBtomTwo"
              stripe
              border
              @selection-change="handleSelectionChangeBtomTwo">
              <el-table-column
                type="selection"
                align="center"
                width="55">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="handoverThNumber"
                label="件号"
                width="120">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="title"
                label="题名"
                width="230">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="theme"
                label="主题"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="fileDate"
                label="拍摄时间"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="site"
                label="地点"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="background"
                label="背景"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="personage"
                label="人物(职务)"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="photographer"
                label="摄(录)者"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="belongDept"
                label="所属部门"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="handoverNote"
                label="内容简介"
                width="160">
              </el-table-column>
            </el-table>
          </div>
          <!-- 下分页 -->
          <div class="pageLayout">
            <el-pagination
              @current-change="handleCurrentChangeTwo2"
              :current-page="paramsTwo1.page"
              :page-size="paramsTwo1.rows"
              layout="prev, pager, next, jumper"
              :total="paramsTwo1.total">
            </el-pagination>
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="yjBtn" v-if="!showBtnLook">保存</el-button>
        <el-button  v-if="!showBtnLook" @click="paramsYj = {}">重置</el-button>
        <el-button type="primary" v-if="showBtnLook" @click="showLookBtn44">录入</el-button>
        <!--<el-button type="primary" v-if="showBtnLook" @click="showLookBtn55">发送代办</el-button>-->
        <el-button type="primary" v-if="showBtnLook" @click="getDataViewDialog49 = true">发送代办</el-button>
        <el-button @click="getDataViewDialog55 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 声像--录入 -->
    <el-dialog :visible.sync="getDataViewDialog555" width="1111px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">声像信息录入</div>
      <ul class="mangeShowLook">
        <li>
          <label style="width: 124px;">件号：</label>
          <el-input v-model="showEditLook.itemNo"></el-input>
        </li>
        <li class="editorXin" style="width: 63.7%;">
          <label style="width: 124px;">题名：</label>
          <el-input v-model="showEditLook.titleProper" style="width: 81%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label style="width: 124px;">主题：</label>
          <el-input v-model="showEditLook.c69"></el-input>
        </li>
        <li>
          <label style="width: 124px;">拍摄时间：</label>
          <el-date-picker
            v-model="showEditLook.takePhotoDate"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <div class="clear"></div>
      </ul>
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label style="width: 124px;">地点：</label>
          <el-input v-model="showEditLook.takePhotoPlace"></el-input>
        </li>
        <li class="">
          <label style="width: 124px;">背景：</label>
          <el-input v-model="showEditLook.c64"></el-input>
        </li>
        <li>
          <label style="width: 124px;">人物(职务)：</label>
          <el-input v-model="showEditLook.c65"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <ul class="mangeShowLook">
        <li class="">
          <label style="width: 124px;">摄(录)者：</label>
          <el-input v-model="showEditLook.takePhotoPerson"></el-input>
        </li>
        <li class="">
          <label style="width: 124px;">所属部门：</label>
          <el-input v-model="showEditLook.c68"></el-input>
        </li>
        <li>
          <label style="width: 124px;">分类号：</label>
          <el-input v-model="showEditLook.seriesCode"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--备注-->
      <ul class="mangeShowLook">
        <li style="width: 99.5%;">
          <label style="width: 124px;">备注：</label>
          <el-input type="textarea" v-model="showEditLook.c8" style="width: 85%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <!--<el-button type="primary" @click="submitBtn45">保存</el-button>-->
        <el-button type="primary" @click="submitBtn555">保存</el-button>
        <el-button @click="showEditLook = {}">重置</el-button>
        <el-button @click="getDataViewDialog555 = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getFonds, listSeriesByFondsAndRole, listHandOverQrData, listHandOverDetailData, listSeriesByFonds, findChangeUser,
  handOverSave, listHandOverDocumentTree, getHandOverFile, countHandOverDetailByNext, delHandOverFile, resettingHandOverFile,
  findSeriesCode, saveMhYjFile, editMhFileTitle, deleteMhYjFile, uploadPicture, saveUploadYjDoc, uploadExcelH5, uploadExcel,
  listHandOverDocumentData, deleteDoc, saveHandoverYc, saveIsOriginal, downloadExcel, editDocTitle, getQrYjList,
  listKhdaStuffCoding, saveGlKhda, getQrYjRemark, getBusinessType, listHandoverPartnerData, saveImformation, handoverPartnerEditSave,
  delImformation, getYjInformation, saveYjInfoData, searchFindUser, listAllDept, listFileType, listGzdj, newListUserByDept,
  saveMhHandOver, sendMhYjOa, sendYjQrDb, ListArchive, listForJson, ListRetentionPeriod, saveUnderLine, listTimingData,
  saveTiming, uploadPlPicture, savePlHangingDocs, thHandOverSave, uploadThExcel, saveThYjFile, delHandOverDetails, saveHandoverYcZq,
  countHandOverDetail, saveMatterYzYjFile, getHandoverDatailDate, editMatterYzYjFile, saveMatterQtYjFile, editMatterQtYjFile,
  saveAccountingYjFile, editAccountingYjFile, uploadKjExcel, saveSxMhYjFile, editAcousticImageYjFile, checkExtendInfo, handoverExtendInfoView,
  listTreeJson, listTreeJsonView, extendInfoView, powerHandoverDocView, viewHandoverPdf, BASICURL, exportError, saveThHandOver,
  listClientNoByDept, saveZqHandOver, uploadZqExcel, getZqYjList, getThYjList} from '@/js/turnOverData'
import { wordPull } from '../../js/wordDerive'
import { valueIndex } from '@/js/transitionText'
import { branchListOrg, branchListTUser, ListSeriesList } from '@/js/getData'
import axios from 'axios'
export default {
  name: 'arrearsMange',
  data () {
    return {
      fullZongArrTwo: [],
      dialogTableBtomTwo: [],
      FondsAndRoleArrTwo: [],
      FondsAndRoleTwoOnce: [],
      activeName: 'contentOnce',
      showCheckEmbed: true,
      embedOnce: '',
      attributesType: '',
      errorMsg: '',
      thZqDate: {},
      showEditLookTwo: {},
      paramsView: {
        project: {titleProper: null}
      },
      paramsViewTwo: {
        project: {titleProper: null}
      },
      delete27: {page: 1, rows: 10},
      paramsBatch: {},
      matchingData: [{name: '合同号', itemValue: '1'}, {name: '档号', itemValue: '2'}],
      retentionPeriod: [
        {name: '短期', itemValue: '1'},
        {name: '长期', itemValue: '2'},
        {name: '永久', itemValue: '3'},
        {name: '10年', itemValue: '5'},
        {name: '15年', itemValue: '6'},
        {name: '30年', itemValue: '8'},
      ],
      dataListTableOnce: [],
      dialogTableBtom27: [],
      matureDateList: [
        {id: ' ', name: '请选择'},
        {id: '0', name: '3月'},
        {id: '1', name: '6月'},
        {id: '2', name: '9月'},
        {id: '3', name: '1年'},
        {id: '4', name: '3年'},
        {id: '5', name: '1天'}
      ],
      sendTypeList: [
        {id: '-100', name: '请选择'},
        {id: '0', name: '失败重发'},
        {id: '1', name: '定时发送'}
      ],
      statusList: [
        {id: ' ', name: '请选择'},
        {id: '1,2,3,4', name: '否'},
        {id: '5', name: '是'}
      ],
      statusShow: true,
      paramsData: {
        page: 1,
        rows: 10
      },
      userListTable: [],
      roleListTable: [],
      carrierList: [],
      departList: [],
      specialList: [],
      specialListOnce: null,
      carrierListOnce: null,
      departListOnce: null,
      paramsRole: {page: 1, rows: 10},
      // paramsTwo1: {page: 1, rows: 5,bs: 'th', flag: 0},
      paramsTwo1: {page: 1, rows: 5},
      paramsUser: {page: 1, rows: 10},
      showEditLookTitle: '',
      showBtnLook: false,
      treTable: [],
      treTableTwo: [],
      htTable: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      /* 移交 */
      dialogShowContent: false,
      dialogShowContent2: false,
      getDataViewDialog: false,
      getDataViewDialog2: false,
      getDataViewDialog3: false,
      getDataViewDialog4: false,
      getDataViewDialog5: false,
      getDataViewDialog6: false,
      getDataViewDialog7: false,
      getDataViewDialog8: false,
      getDataViewDialog9: false,
      getDataViewDialog10: false,
      getDataViewDialog11: false,
      getDataViewDialog12: false,
      getDataViewDialog13: false,
      getDataViewDialog14: false,
      getDataViewDialog15: false,
      getDataViewDialog16: false,
      getDataViewDialog17: false,
      getDataViewDialog18: false,
      getDataViewDialog19: false,
      getDataViewDialog20: false,
      getDataViewDialog21: false,
      getDataViewDialog211: false,
      getDataViewDialog212: false,
      getDataViewDialog213: false,
      getDataViewDialog214: false,
      getDataViewDialog215: false,
      getDataViewDialog22: false,
      getDataViewDialog23: false,
      getDataViewDialog24: false,
      getDataViewDialog25: false,
      getDataViewDialog26: false,
      getDataViewDialog27: false,
      getDataViewDialog28: false,
      getDataViewDialog29: false,
      getDataViewDialog30: false,
      getDataViewDialog31: false,
      getDataViewDialog32: false,
      getDataViewDialog33: false,
      getDataViewDialog34: false,
      getDataViewDialog35: false,
      getDataViewDialog36: false,
      getDataViewDialog37: false,
      getDataViewDialog38: false,
      getDataViewDialog39: false,
      getDataViewDialog40: false,
      getDataViewDialog41: false,
      getDataViewDialog42: false,
      getDataViewDialog43: false,
      getDataViewDialog44: false,
      getDataViewDialog45: false,
      getDataViewDialog46: false,
      getDataViewDialog47: false,
      getDataViewDialog48: false,
      getDataViewDialog49: false,
      getDataViewDialog50: false,
      getDataViewDialog51: false,
      getDataViewDialog52: false,
      getDataViewDialog88: false,
      getDataViewDialog522: false,
      getDataViewDialog53: false,
      getDataViewDialog533: false,
      getDataViewDialog54: false,
      getDataViewDialog544: false,
      getDataViewDialog55: false,
      getDataViewDialog555: false,
      getDataViewDialog311: false,
      dialogShowLook: false,
      dialogShowLookTwo: false,
      showEditIsSpecilly: false,
      showEditIsFinance: false,
      showEditIsZctg: false,
      showMehod: true,
      yiChangDisOne: false,
      yiChangDisTwo: false,
      yiChangDisThree: false,
      yiChangDisFour: false,
      yiChangDisFive: false,
      yiChangDisSix: false,
      yiChangDisSevem: false,
      yiChangDisEight: false,
      // 精确移交
      dialogShowContentFan: false,
      getDataViewDialogFan: false,
      showEdit: {},
      showEditLook: {},
      paramsYj: {},
      paramsClient: {
        page: 1,
        rows: 10
      },
      paramsClientTwo: {
        page: 1,
        rows: 10
      },
      paramsHt: {
        page: 1,
        rows: 10
      },
      clientTable: [],
      clientTableTwo: [],
      dialogTable: [],
      dialogTableBtom: [],
      deleteTable: [],
      handoverDeptArr: [],
      handoverUserArr: [],
      fullZongArr: [],
      params: {
        page: 1,
        rows: 10,
        status: 1,
        fonds: 1374133141812,
        series1: 1379482316593
      },
      paramsTwo: {page: 1, rows: 3, total: 0},
      paramsDelete: {
        page: 1,
        rows: 10,
        total: 0
      },
      paramsAddContent: {},
      paramsEditContent: {},
      tableData: [],
      tableDataTwo: [],
      onceTable: [],
      onceTableBtom: [],
      onceTableBtomTwo: [],
      onceTableBtomThree: [],
      onceTableBtomFour: [],
      onceTableData: [],
      // 全宗类型
      fullZong: [],
      // 档案类型
      FondsAndRole: [],
      FondsAndRoleTwo: [],
      FondsAndRoleThree: [],
      FondsAndRoleArr: [],
      yjcurrentuserArr: [],
      yjStatusArr: [
        {id: 0, text: '全部', value: ''},
        {id: 1, text: '欠交', value: ''},
        {id: 2, text: '综合员审核', value: ''},
        {id: 3, text: '部门领导审核', value: ''},
        {id: 4, text: '档案管理员审核', value: ''},
        {id: 5, text: '已移交', value: ''}
      ],
      yjc89Arr: [],
      yjc90Arr: [],
      fileTypeArr: [],
      yjc112Arr: [],
      // 移交类型
      handoverTypeModel: [
        {name: '精确移交', itemValue: '0'},
        {name: '模糊移交', itemValue: '1'},
        {name: '线下移交', itemValue: '3'},
        {name: '全部', itemValue: '2'}
      ],
      // 移交类型(弹框移交类型）
      handoverYysList: [
        {name: '顺丰快递', itemValue: '0,顺丰快递'},
        {name: '圆通快递', itemValue: '1,圆通快递'},
        {name: '中通快递', itemValue: '2,中通快递'},
        {name: '韵达快递', itemValue: '3,韵达快递'},
        {name: '百世汇通', itemValue: '4,百世汇通'},
        {name: 'EMS', itemValue: '5,EMS'},
        {name: '申通快递', itemValue: '6,申通快递'}
      ],
      // 接收方式
      handoverTypeList: [
        {name: '邮寄', itemValue: '1'},
        {name: '面交', itemValue: '2'}
      ],
      // 是否业务合同
      isBusinessType: [
        {name: '是', itemValue: '1'},
        {name: '否', itemValue: '2'}
      ],
      // 业务类型
      businessType: [],
      // 公开类型
      openingType: [
        {name: '公开', itemValue: '1'},
        {name: '内部', itemValue: '2'},
        {name: '受控', itemValue: '3'},
        {name: '商密二级', itemValue: '5'},
        {name: '商密一级', itemValue: '6'}
      ],
      openingTypeTwo: [
        {name: '公开', itemValue: '1'},
        {name: '内部', itemValue: '2'},
        {name: '受控', itemValue: '3'},
        {name: '广发商密三级', itemValue: '4'},
        {name: '广发商密二级', itemValue: '5'},
        {name: '广发商密一级', itemValue: '6'}
      ],
      // 是否公开
      c58: [
        {name: '是', itemValue: '0'},
        {name: '否', itemValue: '1'}
      ],
      // 变更人
      sqFondsList: [],
      showDisable: false,
      showDisableTwo: false,
      disHtThreeTwoFy: true,
      showEditLookSubId: '',
      // 文件上传
      imgVal: [],
      checkList: [],
      checkedOne: '',
      checkParams: {},
      disYj: false,
      disHtOne: false,
      disHtOneTwo: true,
      disHtTwo: false,
      disHtTwoOnce: false,
      disHtTwoDate: false,
      disHtTwoTwo: true,
      disHtThree: false,
      disHtThreeTwo: true,
      disHtFour: false,
      disHtFourTwo: true,

      disHtBOne: false,
      disHtBTwo: false,
      disHtBThree: false,
      disHtBFour: false,
      disHtBFive: false,
      disHtBOnceTwo: true,
      timeChange: {
        disabledDate (time) {
          return time.getTime() < (Date.now() - 3600 * 1000 * 24 * 183) || time.getTime() > Date.now() // 选择时间范围
        }
      },
      showView: '',
      showViewTwo: '',
      showViewTwoId: '',
    }
  },
  methods: {
    submitBtn47 () {
      let params = {id: this.showEditLook.textContentIds}
      valueIndex().exportFiles('/gdda-new/gdda/util/downLoadHandoverFile', params, this.showEditLook.textContents, 'post')
      this.getDataViewDialog47 = false
    },
    handleNodeClick (val) {
      powerHandoverDocView({id: val.id}).then(res => {
        this.showCheckEmbed = true
        if (res.optFlag == -1) {
          this.$message.error('此文件不存在')
        } else if (res.optFlag == 0) {
          this.showCheckEmbed = false
          this.embedOnce = `${BASICURL}/gdda-new/gdda/util/viewHandoverPdf?docId=${val.id}`
          this.$forceUpdate()
        } else if (res.optFlag == 2) {
          this.getDataViewDialog47 = true
          this.showEditLook.textContents = val.text
          this.showEditLook.textContentIds = val.id
        }
      })
    },
    handleNodeClickTwo (val) {
      console.log(val)
      let types = val.attributes.type
      let ids = val.id
      let rids = this.showViewTwoId.id
      val.children = []
      // 左侧树
      listTreeJson({id: rids, type: types,resourceParentId: ids}).then(res => {
        if (res.data.data.message) {
          this.$message.info(res.data.data.message)
        } else {
          val.children = res.data.data
        }
      })
      // 右侧基本信息
      listTreeJsonView({id: ids, type: types}).then(res => {
        if (types == 'f') {
          this.showEditLookTwo = res.data.file
        } else if (types == 'v') {
          this.showEditLookTwo = res.data.folder
        } else if (types == 'p') {
          this.showEditLookTwo = res.data.project
        }
      })
      // 判断右侧是否有关键档案
      checkExtendInfo().then(res => {
        this.showViewTwo = res.data.optFlag
      })
      // 右侧关键档案
      extendInfoView({id: ids, type: types}).then(res => {
        this.paramsViewTwo = res.data
      })
    },
    lookFileContent (val, item) {
      this.activeName = 'contentOnce'
      this.showEditLookTwo = {}
      let types = val
      let ids = item.id
      this.showViewTwoId = item
      this.showCheckEmbed = true
      // 左侧树
      listTreeJson({id: ids, type: types}).then(res => {
        this.treTableTwo = res.data.data
        this.attributesType = this.treTableTwo[0].attributes.type
      })
      // 右侧基本信息
      listTreeJsonView({id: ids, type: types}).then(res => {
        if (types == 'f') {
          this.showEditLookTwo = res.data.file
        } else if (types == 'v') {
          this.showEditLookTwo = res.data.folder
        } else if (types == 'p') {
          this.showEditLookTwo = res.data.project
        }
      })
      // 判断右侧是否有关键档案
      checkExtendInfo().then(res => {
        this.showViewTwo = res.data.optFlag
      })
      // 右侧关键档案
      extendInfoView({id: ids, type: types}).then(res => {
        this.paramsViewTwo = res.data
      })
      this.dialogShowLookTwo = true
    },
    showLookBtn32 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        console.log(this.onceTableBtomTwo[0].handoverException);
        this.getDataViewDialog34 = true
        this.clearRefs()
        if (this.onceTableBtomTwo[0].handoverException) {
          if (this.onceTableBtomTwo[0].handoverException.split(',').length >= 2) {
            let a = this.onceTableBtomTwo[0].handoverException.split(',')
            a.forEach((item, index) => {
              // if (item == '原件不完整（对方未盖章）') this.checkParams.contentOne = '原件不完整（对方未盖章）'
              if (item == '原件丢失或损毁') {
                this.$nextTick(() => {
                  this.$refs.checkBosOne.model = '原件丢失或损毁'
                })
              }
              if (item == '无原件且无复印件') {
                this.$nextTick(() => {
                  this.$refs.checkBosTwo.model = '无原件且无复印件'
                })
              }
              if (item == '原件不完整（对方未盖章）') {
                this.$nextTick(() => {
                  this.$refs.checkBosThree.model = '原件不完整（对方未盖章）'
                })
              }
              if (item == '原件不完整（无签署时间）') {
                this.$nextTick(() => {
                  this.$refs.checkBosFour.model = '原件不完整（无签署时间）'
                })
              }
              if (item == '无原件有复印件') {
                this.$nextTick(() => {
                  this.$refs.checkBosFive.model = '无原件有复印件'
                })
              }
              if (item == '原件不完整（对方未签名）') {
                this.$nextTick(() => {
                  this.$refs.checkBosSix.model = '原件不完整（对方未签名）'
                })
              }
              if (item == '原件不完整（缺失部分页）') {
                this.$nextTick(() => {
                  this.$refs.checkBosSeven.model = '原件不完整（缺失部分页）'
                })
              }
              if (item == '合同（已盖章）作废') {
                this.$nextTick(() => {
                  this.$refs.checkBosEight.model = '合同（已盖章）作废'
                })
              }
            })
          }
        }
      }
    },
    submitBtn34 () {
      let one = []
      let two = ''
      let three = []
      let five = ''
      // 异常A
      three.push(this.thZqDate.oneData)
      three.push(this.thZqDate.twoData)
      // 异常B
      one.push(this.thZqDate.threeData)
      one.push(this.thZqDate.fourData)
      one.push(this.thZqDate.fiveData)
      one.push(this.thZqDate.sixData)
      one.push(this.thZqDate.seveData)
      one.push(this.thZqDate.eightData)
      one.forEach(item => {
        if (item) {
          two += item + ','
        }
      })
      three.forEach(item => {
        if (item) {
          five += item + ','
        }
      })
      let params = {
        subId: this.onceTableBtomTwo[0].id,
        handoverException1: five,
        handoverException2: two,
      }
      if (this.getDataViewDialog34) {
        saveHandoverYcZq(params).then(res => {
          console.log(res);
          if (res.data.optFlag == 1) {
            this.$message.success('保存成功')
            this.getDataViewDialog34 = false
            this.showListBtom2()
          } else {
            this.$message.error('保存失败')
            this.getDataViewDialog34 = false
          }
        })
      } else {
        saveHandoverYc(params).then(res => {
          console.log(res);
          if (res.data.optFlag == 1) {
            this.$message.success('保存成功')
            this.getDataViewDialog34 = false
            this.showListBtom2()
          } else {
            this.$message.error('保存失败')
            this.getDataViewDialog34 = false
          }
        })
      }
    },
    showLookBtn27 () {
      this.getDataViewDialog31 = true
      this.dialogTableBtom27 = []
      this.delete27.subId = this.onceTable[0].gid
      listHandOverDetailData(this.delete27).then(res => {
        this.dialogTableBtom27 = res.data.rows
        this.delete27.total = res.data.total
        this.showListBtom2()
      })
    },
    handleSelectionChangeBtomTwo31 (val) {
      this.onceTableBtomThree = val
    },
    handleCurrentChangeTwo27 (val) {
      this.delete27.page = val
      this.showLookBtn27()
    },
    showLookBtn31 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomThree)
      if (item == 1) {
        this.getDataViewDialog311 = true
      }
    },
    showLookBtn31Two () {
      let params = {
        // type: this.onceTableBtomThree[0].handoverType == 0 ? 'jqyj' : 'mhyj',
        ids: this.onceTableBtomThree[0].id
      }
      delHandOverDetails(params).then(res => {
        if (res.data.optFlag == 1) {
          this.$message.success('删除成功')
          this.getDataViewDialog311 = false
          // this.$message.success(res.message)
          this.showLookBtn27()
        } else {
          // this.$message.success('删除')
          this.$message.error('删除失败')
          this.getDataViewDialog311 = false
          this.showLookBtn27()
        }
      })
    },
    showList () {
      listSeriesByFondsAndRole({id: this.params.fonds}).then(res => {
        // console.log(res)
        this.FondsAndRole = res.data
        if (this.params.fonds == 1374133141812) {
          listHandOverQrData(this.params).then(resVal => {
            this.tableData = resVal.data.rows
            this.tableData.forEach(item => {
              res.data.forEach(itemVal => {
                if (item.tag == itemVal.tag) {
                  item.tagName = itemVal.name
                }
              })
            })
            this.params.total = resVal.data.total
          })
        }
      })
    },
    showListBtom (val) {
      // this.dialogTableBtom = []
      this.paramsTwo.total = 0
      this.paramsTwo.subId = this.onceTable[0].gid
      listHandOverDetailData(this.paramsTwo).then(res => {
        // if (this.dialogShowContent || this.dialogShowContentFan || this.getDataViewDialog27 || this.getDataViewDialog32 || this.getDataViewDialog35 ||
        //   this.getDataViewDialog41 || this.getDataViewDialog44 || this.dialogShowContent2) {
        //   // this.dialogTableBtom = res.data.rows
        //   this.dialogTableBtomTwo = res.data.rows
        // } else {
        // }
        this.tableDataTwo = res.data.rows
        this.paramsTwo.total = res.data.total
        // this.paramsTwo1.total = res.data.total
      })
    },
    showListBtom2 (val) {
      // this.dialogTableBtom = []
      this.paramsTwo1.total = 0
      this.paramsTwo1.subId = this.onceTable[0].gid
      listHandOverDetailData(this.paramsTwo1).then(res => {
        this.dialogTableBtomTwo = res.data.rows
        this.paramsTwo1.total = res.data.total
      })
      console.log(2);
    },
    showListHt () {
      listHandoverPartnerData(this.paramsHt).then(res => {
        this.htTable = res.data.rows
        this.paramsHt.total = res.data.total
      })
    },
    showListDelete () {
      this.paramsDelete.subId = this.onceTableBtomTwo[0].id
      listHandOverDocumentData(this.paramsDelete).then(res => {
        console.log(res)
        this.deleteTable = res.data.rows
        this.paramsDelete.total = res.data.total
      })
    },
    // 上表格的多选
    handleSelectionChange (val) {
      this.onceTable = val
      if (this.onceTable.length == 1) {
        this.paramsTwo.page = 1
        this.paramsTwo.total = 0
        this.showListBtom()
      } else if (this.onceTable.length == 0) {
        this.tableDataTwo = []
        this.paramsTwo.page = 1
        this.paramsTwo.total = 0
        // this.params.total = null
      } else if (this.onceTable.length > 1 && this.onceTable.length <= 2) {
        this.$refs.multipleTable.toggleRowSelection(this.onceTable[0])
      }
    },
    // 下表格表格的多选
    handleSelectionChangeBtom (val) {
      this.onceTableBtom = val
      if (this.onceTableBtom.length > 1 && this.onceTableBtom.length <= 2) {
        this.$refs.multipleTableBtom.toggleRowSelection(this.onceTableBtom[0])
      }
    },
    // 弹框里下表格表格的多选
    handleSelectionChangeBtomTwo (val) {
      this.onceTableBtomTwo = val
      // if (this.onceTableBtomTwo.length > 1) {
      //   this.$refs.multipleTableBtomTwo.toggleRowSelection(this.onceTableBtomTwo[0])
      // }
    },
    handleSelectionChangeBtomThree (val) {
      this.onceTableBtomThree = val
    },
    handleSelectionChangeBtomFour (val) {
      this.onceTableBtomFour = val
      if (this.onceTableBtomFour.length > 1 && this.onceTableBtomFour.length <= 2) {
        this.$refs.multipleTableBtomFour.toggleRowSelection(this.onceTableBtomFour[0])
      }
    },
    // 单页选择
    handleCurrentChange (val) {
      this.params.page = val
      this.showList()
    },
    // 页面最下方单页选择
    handleCurrentChangeTwo (val) {
      // this.tableDataTwo = []
      // this.paramsTwo.total = 0
      this.paramsTwo.subId = this.onceTable[0].gid
      this.paramsTwo.page = val
      listHandOverDetailData(this.paramsTwo).then(res => {
        this.tableDataTwo = res.data.rows
        this.paramsTwo.total = res.data.total
      })
    },
    // 页面最下方单页选择
    handleCurrentChangeThree (val) {
      this.paramsThree.page = val
      this.showListDelete()
    },
    // 页面最下方单页选择
    handleCurrentChangeFour (val) {
      this.paramsClientTwo.page = val
      listKhdaStuffCoding(this.paramsClientTwo).then(res => {
        this.clientTableTwo = res.data.rows
        this.paramsClientTwo.total = res.data.total
      })
    },
    // 页面最下方单页选择
    handleCurrentChangeFive (val) {
      this.paramsHt.page = val
      this.paramsHt.subId = this.onceTableBtomTwo[0].id
      this.showListHt()
      // listHandoverPartnerData(this.paramsHt).then(res => {
      //   this.htTable = res.data.rows
      //   this.paramsHt.total = res.data.total
      // })
    },
    // 获取全宗 档案类型第一级
    showSearchData () {
      getFonds().then(res => {
        this.fullZong = res.data
      })
      // listSeriesByFondsAndRole({id: 1374133141812}).then(res => {
      listSeriesByFondsAndRole({id: this.params.fonds}).then(res => {
        this.FondsAndRole = res.data
        listSeriesByFonds({id: this.params.series1}).then(res => {
          this.FondsAndRoleTwo = res.data
        })
        // this.searchSeries(1379482316593)
      })
    },
    // 档案类型第1级
    searchSeries (val) {
      this.FondsAndRoleThree = []
      listSeriesByFonds({id: val}).then(res => {
        this.FondsAndRoleTwo = res.data
      })
      this.params.page = 1
      this.params.rows = 10
      this.params.total = 0
      this.params.series2 = ''
      this.params.series3 = ''
      if (this.params.series1 == 1388742017296 || this.params.series1 == 1379398885203 || this.params.series1 == 1374133285843) {
        this.tableData = []
      } else {
        this.showList()
      }
      if (this.params.series1 == 1388742017296 || this.params.series1 == 1374133285828) {
        this.showMehod = false
      } else {
        this.showMehod = true
      }
      /*else if (this.params.series1 == 1374133285843) {
        console.log('不渲染')
        this.tableData = []
      } else if (this.params.series1 == 1379398885203) {
        console.log('不渲染')
        this.tableData = []
      }*/
    },
    // 第2级
    searchSeriesTwo (val) {
      this.FondsAndRoleThree = []
      listSeriesByFonds({id: val}).then(res => {
        this.FondsAndRoleThree = res.data
      })
      this.params.page = 1
      this.params.rows = 10
      this.params.total = 0
      this.params.series3 = null
      this.showList()
    },
    // 档案类型第三级获取数据
    searchSeriesThree (val) {
      this.params.page = 1
      this.params.rows = 10
      this.params.total = 0
      this.showList()
      this.$forceUpdate()
    },
    // 移交类型
    yjTypeBtn (val) {
      this.params.series1 = null
      this.params.series2 = null
      this.params.series3 = null
      this.FondsAndRole = []
      this.FondsAndRoleTwo = []
      this.FondsAndRoleThree = []
      this.tableData = []
      this.tableDataTwo = []
      listSeriesByFondsAndRole({id: val}).then(res => {
        this.FondsAndRole = res.data
      })
      this.params.page = 1
      this.params.rows = 10
      this.params.total = 0
      this.showList()
    },
    yjTypeBtnTwo (val) {
      // this.showSearchData()
      listSeriesByFondsAndRole({id: val}).then(res => {
        this.FondsAndRole = res.data
      })
      this.params.page = 1
      this.params.rows = 10
      this.params.total = 0
      this.showList()
    },
    /* 模糊移交按钮 */
    mangeBtn () {
      if (this.showEdit.handoverUser == null || this.showEdit.handoverUser == '') {
        this.$message.error('移交人不能为空')
      } else if (this.showEdit.handoverType == null || this.showEdit.handoverType == '') {
        this.$message.error('请选择邮寄方式')
      } else if (this.showEdit.handoverType == 1) {
        if (this.showEdit.receiveAddress == null || this.showEdit.receiveAddress == '') {
          this.$message.error('请填写邮寄地址')
        } else if (this.showEdit.handoverYys == null || this.showEdit.handoverYys == '') {
          this.$message.error('请选择运营商')
        } else if (this.showEdit.handoverYdh == null || this.showEdit.handoverYdh == '') {
          this.$message.error('请输入运单号')
        } else {
          this.mangeBtnTwo()
        }
      } else if (this.showEdit.applyRemarkCopy == null || this.showEdit.applyRemarkCopy == '') {
        this.$message.error('请填写意见')
      } else {
        this.mangeBtnTwo()
      }
    },
    mangeBtnTwo () {
      this.isHander()
      this.showEdit.subId = this.onceTable[0].cid
      this.showEdit.bs = 'yz'
      this.showEdit.handoverRemark = this.showEdit.applyRemarkCopy
      if (this.dialogShowContent2) {
        this.getDataViewDialog29 = true
      } else {
        this.getDataViewDialog = true
      }
    },
    // 投资银行
    mangeBtnThree () {
      if (this.showEdit.handoverUser == null || this.showEdit.handoverUser == '') {
        this.$message.error('移交人不能为空')
      } else if (this.showEdit.handoverType == null || this.showEdit.handoverType == '') {
        this.$message.error('请选择邮寄方式')
      } else if (this.showEdit.handoverType == 1) {
        if (this.showEdit.receiveAddress == null || this.showEdit.receiveAddress == '') {
          this.$message.error('请填写邮寄地址')
        } else if (this.showEdit.handoverYys == null || this.showEdit.handoverYys == '') {
          this.$message.error('请选择运营商')
        } else {
          this.isHander()
          this.getDataViewDialog28 = true
        }
      } else if (this.showEdit.applyRemarkCopy == null || this.showEdit.applyRemarkCopy == '') {
        this.$message.error('请填写意见')
      } else {
        this.isHander()
        this.getDataViewDialog28 = true
      }
    },
    mangeBtn35 () {
      if (this.showEdit.handoverUser == null || this.showEdit.handoverUser == '') {
        this.$message.error('移交人不能为空')
      } else if (this.showEdit.handoverType == null || this.showEdit.handoverType == '') {
        this.$message.error('请选择邮寄方式')
      } else if (this.showEdit.handoverType == 1) {
        if (this.showEdit.receiveAddress == null || this.showEdit.receiveAddress == '') {
          this.$message.error('请填写邮寄地址')
        } else if (this.showEdit.handoverYys == null || this.showEdit.handoverYys == '') {
          this.$message.error('请选择运营商')
        } else {
          this.isHander()
          this.getDataViewDialog28 = true
        }
      } else if (this.showEdit.applyRemarkCopy == null || this.showEdit.applyRemarkCopy == '') {
        this.$message.error('请填写意见')
      } else {
        this.isHander()
        this.getDataViewDialog36 = true
      }
    },
    // 判断是否有异常
    isHander () {
      for (let i in this.dialogTableBtom) {
        if (this.dialogTableBtom[i].handoverException != '' && this.dialogTableBtom[i].handoverException != null && this.dialogTableBtom[i].handoverException != '广发未办理盖章') {
          this.showEdit.isHandover = '1'
          break
        } else {
          this.showEdit.isHandover = '0'
        }
      }
      if (this.onceTable[0].handoverUser != '' && this.onceTable[0].handoverUser != null) {
        this.showEdit.isHandover = '1'
      }
    },
    // 关闭弹框
    handleClose () {
      this.dialogShowContent = false
      this.dialogShowContentFan = false
      this.dialogShowContent2 = false
      this.getDataViewDialog22 = false
      this.getDataViewDialog50 = false
      this.getDataViewDialog51 = false
      this.getDataViewDialog52 = false
      this.getDataViewDialog53 = false
      this.getDataViewDialog54 = false
      this.getDataViewDialog55 = false
    },
    // 关闭弹框--第二级
    handleCloseTwo () {
      this.dialogShowLook = false
      this.getDataViewDialog = false
      this.getDataViewDialog2 = false
      this.getDataViewDialog3 = false
      this.getDataViewDialog4 = false
      this.getDataViewDialog5 = false
      this.getDataViewDialog6 = false
      this.getDataViewDialog7 = false
      this.getDataViewDialog8 = false
      this.getDataViewDialog9 = false
      this.getDataViewDialog10 = false
      this.getDataViewDialog11 = false
      this.getDataViewDialog12 = false
      this.getDataViewDialog13 = false
      this.getDataViewDialog14 = false
      this.getDataViewDialog16 = false
      this.getDataViewDialog18 = false
      this.getDataViewDialog20 = false
      this.getDataViewDialog21 = false
      this.getDataViewDialog211 = false
      this.getDataViewDialog212 = false
      this.getDataViewDialog213 = false
      this.getDataViewDialog214 = false
      this.getDataViewDialog215 = false
      // this.getDataViewDialog22 = false
      this.getDataViewDialog23 = false
      this.getDataViewDialog24 = false
      this.getDataViewDialog25 = false
      this.getDataViewDialog26 = false
      this.getDataViewDialog27 = false
      this.getDataViewDialog29 = false
      this.getDataViewDialog30 = false
      this.getDataViewDialog32 = false
      this.getDataViewDialog35 = false
      this.getDataViewDialog41 = false
      this.getDataViewDialog44 = false
      this.getDataViewDialog49 = false
    },
    // 关闭弹框--第三级
    handleCloseThree () {
      this.dialogShowLookTwo = false
      // this.getDataViewDialog4 = false
      this.getDataViewDialog15 = false
      this.getDataViewDialog17 = false
      this.getDataViewDialog19 = false
      this.getDataViewDialog28 = false
      this.getDataViewDialog31 = false
      this.getDataViewDialog33 = false
      this.getDataViewDialog34 = false
      this.getDataViewDialog36 = false
      this.getDataViewDialog37 = false
      this.getDataViewDialog38 = false
      this.getDataViewDialog39 = false
      this.getDataViewDialog40 = false
      this.getDataViewDialog42 = false
      this.getDataViewDialog43 = false
      this.getDataViewDialog45 = false
      this.getDataViewDialog46 = false
      this.getDataViewDialog47 = false
      this.getDataViewDialog48 = false
      this.getDataViewDialog88 = false
      this.getDataViewDialog522 = false
      this.getDataViewDialog533 = false
      this.getDataViewDialog544 = false
      this.getDataViewDialog555 = false
      this.getDataViewDialog311 = false
    },
    // 移交按钮
    tureOverBtn () {
      let item = this.$onceWay().onceTableList(this.onceTable)
      if (item == 1) {
        if (this.params.series1 == 1388742017296) {
          if (this.params.series2 == 1388742017298) {
            getZqYjList({cid: this.onceTable[0].cid}).then(res => {
              this.showEdit = res.data
              this.showEdit.handoverType = JSON.parse(JSON.stringify('2'))
              if (this.showEdit.isSpecially == 'true' || this.showEdit.isSpecially == true) { this.showEditIsSpecilly = true } else { this.showEditIsSpecilly = false }
              if (this.showEdit.isFinance == 'true' || this.showEdit.isFinance == true) { this.showEditIsFinance = true } else { this.showEditIsFinance = false }
              if (this.showEdit.isZctg == 'true' || this.showEdit.isZctg == true) { this.showEditIsZctg = true } else { this.showEditIsZctg = false }
              this.dialogTable = JSON.parse(res.data.handoverRemark)
              if (this.dialogTable) {
                this.dialogTable.forEach((item, index) => {
                  item.handoverRemark = item.handoverRemark.split('<br>')
                })
              }
              this.receiveBtn()
            })
          } else if (this.params.series2 == 1388742017297) {
            getThYjList({cid: this.onceTable[0].cid}).then(res => {
              this.showEdit = res.data
              this.showEdit.handoverType = JSON.parse(JSON.stringify('2'))
              if (this.showEdit.isSpecially == 'true' || this.showEdit.isSpecially == true) { this.showEditIsSpecilly = true } else { this.showEditIsSpecilly = false }
              if (this.showEdit.isFinance == 'true' || this.showEdit.isFinance == true) { this.showEditIsFinance = true } else { this.showEditIsFinance = false }
              if (this.showEdit.isZctg == 'true' || this.showEdit.isZctg == true) { this.showEditIsZctg = true } else { this.showEditIsZctg = false }
              this.dialogTable = JSON.parse(res.data.handoverRemark)
              if (this.dialogTable) {
                this.dialogTable.forEach((item, index) => {
                  item.handoverRemark = item.handoverRemark.split('<br>')
                })
              }
              this.receiveBtn()
            })
          } else {
            getQrYjList({cid: this.onceTable[0].cid}).then(res => {
              this.showEdit = res.data
              this.showEdit.handoverType = JSON.parse(JSON.stringify('2'))
              if (this.showEdit.isSpecially == 'true' || this.showEdit.isSpecially == true) { this.showEditIsSpecilly = true } else { this.showEditIsSpecilly = false }
              if (this.showEdit.isFinance == 'true' || this.showEdit.isFinance == true) { this.showEditIsFinance = true } else { this.showEditIsFinance = false }
              if (this.showEdit.isZctg == 'true' || this.showEdit.isZctg == true) { this.showEditIsZctg = true } else { this.showEditIsZctg = false }
              this.dialogTable = JSON.parse(res.data.handoverRemark)
              if (this.dialogTable) {
                this.dialogTable.forEach((item, index) => {
                  item.handoverRemark = item.handoverRemark.split('<br>')
                })
              }
              this.receiveBtn()
            })
          }
        } else {
          getQrYjList({cid: this.onceTable[0].cid}).then(res => {
            this.showEdit = res.data
            this.showEdit.handoverType = JSON.parse(JSON.stringify('2'))
            if (this.showEdit.isSpecially == 'true' || this.showEdit.isSpecially == true) { this.showEditIsSpecilly = true } else { this.showEditIsSpecilly = false }
            if (this.showEdit.isFinance == 'true' || this.showEdit.isFinance == true) { this.showEditIsFinance = true } else { this.showEditIsFinance = false }
            if (this.showEdit.isZctg == 'true' || this.showEdit.isZctg == true) { this.showEditIsZctg = true } else { this.showEditIsZctg = false }
            this.dialogTable = JSON.parse(res.data.handoverRemark)
            if (this.dialogTable) {
              this.dialogTable.forEach((item, index) => {
                item.handoverRemark = item.handoverRemark.split('<br>')
              })
            }
            this.receiveBtn()
          })
        }
        if (this.params.series1 == 1379482316593) {
          if (this.onceTable[0].handoverStyle == 1) {
            this.dialogShowContent = true
            // this.showEdit = JSON.parse(JSON.stringify(this.onceTable[0]))
            this.showListBtom2()
          } else if (this.onceTable[0].handoverStyle == 0) {
            this.dialogShowContentFan = true
            // this.showEdit = JSON.parse(JSON.stringify(this.onceTable[0]))
            this.showListBtom2()
          } else if (this.onceTable[0].handoverStyle == 2) {
            this.dialogShowContent2 = true
            this.showListBtom2()
          }
        } else if (this.params.series1 == 1388742017296) {
          if (this.params.series2 == 1388742017297) {
            this.getDataViewDialog27 = true
            this.showListBtom2()
          } else if (this.params.series2 == 1388742017298) {
            this.getDataViewDialog32 = true
            this.showListBtom2()
          }
        } else if (this.params.series1 == 1374133285843) {
          this.getDataViewDialog35 = true
          if (this.params.series2 == 1374133285844) this.paramsTwo.titleOnce = '实物印章移交单'
          if (this.params.series2 == 1374133285845) this.paramsTwo.titleOnce = '实物奖杯奖牌移交单'
          if (this.params.series2 == 1374133285846) this.paramsTwo.titleOnce = '实物外事礼品移交单'
          if (this.params.series2 == 1374133285847) this.paramsTwo.titleOnce = '实物其他移交单'
          if (this.params.series2 == 1374133285848) this.paramsTwo.titleOnce = '实物证书移交单'
          if (this.params.series2 == 1547110001600) this.paramsTwo.titleOnce = '实物证照移交单'
          this.showListBtom2()
          //
        } else if (this.params.series1 == 1388742017269) {
          this.getDataViewDialog41 = true
          this.showListBtom2()
        } else if (this.params.series1 == 1374133285828) {
          this.getDataViewDialog44 = true
          this.showListBtom2()
        }
        /* else if (this.onceTable[0].handoverStyle == 2) {
          this.dialogShowContent2 = true
          // this.showEdit = JSON.parse(JSON.stringify(this.onceTable[0]))
          this.showListBtom()
        } */
      }
    },
    // 邮寄方式选择
    receiveBtn () {
      if (this.showEdit.handoverType == 2) {
        this.showDisable = true
        this.showEdit.handoverYys = null
        this.showEdit.handoverYdh = null
        this.showEdit.receiveAddress = null
      } else if (this.showEdit.handoverType == 1) {
        this.showDisable = false
        this.showEdit.handoverYys = '0,顺丰快递'

      }
    },
    // 变更移交人查询
    orgFlag (val) {
      let params = {
        q: val,
        orgFlag1: -10000
      }
      findChangeUser(params).then(res => {
        this.sqFondsList = res.data
      })
    },
    // 模糊查询确定按钮
    submitBtn1 () {
      if (this.showEdit.radio == undefined || this.showEdit.radio == null) {
        this.$message.error('请选择档案载体格式')
      } else if (this.showEdit.receiveUser == undefined || this.showEdit.receiveUser == null) {
        this.$message.error('当前接收人为空，不能进行移交！')
      } else if (this.showEdit.radio == 0 || this.showEdit.radio == 2) {
        if (this.showEdit.radio2 == '' || this.showEdit.radio2 == undefined) {
          this.$message.error('请做出相关承诺')
        } else {
          handOverSave(this.showEdit).then(res => {
            if (res.data.optFlag == '2') {
              this.$message.error('系统提示, "确认失败，当前移交状态的移交单已被其他用户处理了"')
            } else if (res.data.optFlag == 1) {
              this.$message.success('成功')
              this.handleClose()
              this.handleCloseTwo()
              this.showList()
            } else {
              this.$message.error('失败')
            }
          })
        }
      } else {
        handOverSave(this.showEdit).then(res => {
          if (res.data.optFlag == 2) {
            this.$message.error('系统提示, "确认失败，当前移交状态的移交单已被其他用户处理了"')
          } else if (res.data.optFlag == 1) {
            this.$message.success('成功')
            this.handleClose()
            this.handleCloseTwo()
            this.showList()
          } else {
            this.$message.error('失败')
          }
        })
      }
    },
    // 查看
    showLookBtn () {
      let item = this.$onceWay().onceTableList(this.onceTableBtom)
      if (item == 1) {
        this.showEditLook = {}
        this.activeName = 'contentOnce'
        this.showCheckEmbed = true
        this.treTable = []
        this.dialogShowLook = true
        let params = {
          id: this.onceTableBtom[0].fileId,
          gid: this.onceTableBtom[0].handoverId
        }
        listHandOverDocumentTree(params).then(res => {
          this.treTable = res.data
        })
        checkExtendInfo(
          {
            id: this.onceTableBtom[0].fileId,
            type: 'f'
          }).then(res => {
          this.showView = res.data.optFlag
        })
        getHandOverFile({fileId: this.onceTableBtom[0].fileId}).then(res => {
          console.log(res);
          if (res.code == 0) {
            this.showEditLook = res.data
            this.showEditLook.openingType = this.$onceWay().showOpeningType(this.showEditLook.openingType)
            this.showEditLook.retentionPeriod = this.$onceWay().showRetentionPeriod(this.showEditLook.retentionPeriod)
            this.showEditLook.c58 = this.$onceWay().showC59(this.showEditLook.c58)
            this.showEditLook.c59 = this.$onceWay().showC59(this.showEditLook.c59)
            this.showEditLook.c93 = this.$onceWay().showC93(this.showEditLook.c93)
          } else {
            this.$message.error('接口出错！')
          }
        })
        handoverExtendInfoView({
          id: this.onceTableBtom[0].fileId,
          type: 'f'
        }).then(res => {
          this.paramsView = res.data
        })
      }
    },
    // 弹框查看
    showLookBtnTwo () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.showEditLook = {}
        this.activeName = 'contentOnce'
        this.showCheckEmbed = true
        this.treTable = []
        let params = {
          id: this.onceTableBtomTwo[0].fileId,
          gid: this.onceTableBtomTwo[0].handoverId
        }
        getHandOverFile({fileId: this.onceTableBtomTwo[0].fileId}).then(res => {
          if (res.code == 0) {
            this.showEditLook = res.data
            this.showEditLook.openingType = this.$onceWay().showOpeningType(this.showEditLook.openingType)
            this.showEditLook.retentionPeriod = this.$onceWay().showRetentionPeriod(this.showEditLook.retentionPeriod)
            this.showEditLook.c58 = this.$onceWay().showC59(this.showEditLook.c58)
            this.showEditLook.c59 = this.$onceWay().showC59(this.showEditLook.c59)
            this.showEditLook.c93 = this.$onceWay().showC93(this.showEditLook.c93)
            this.dialogShowLook = true
          } else {
            this.$message.error('接口出错')
            this.dialogShowLook = false
          }
        })
        listHandOverDocumentTree(params).then(res => {
          if (res.code == 500) {
            this.$message.error('接口出错')
            this.dialogShowLook = false
          } else {
            this.treTable = res.data
          }
        })
        checkExtendInfo(
          {
            id: this.onceTableBtomTwo[0].fileId,
            type: 'f'
          }).then(res => {
          this.showView = res.data.optFlag
        })
        handoverExtendInfoView({
          id: this.onceTableBtomTwo[0].fileId,
          type: 'f'
        }).then(res => {
          this.paramsView = res.data
        })
      }
    },
    // table标签页切换
    resetTable (val) {
      console.log('table标签页切换')
      this.activeName = val.name
    },
    // 下次移交
    showLookBtn2 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        countHandOverDetailByNext({id: this.onceTableBtomTwo[0].id}).then(res => {
          if (res.optFlag == 1) {
            this.showEdit.deleteContent = '此档案为移交单最后一条档案，移除后移交单下无档案显示，确定吗？'
          } else {
            this.showEdit.deleteContent = '确定要移除并下次移交该档案吗?'
          }
          this.getDataViewDialog2 = true
        })
      }
    },
    submitBtn2 () {
      let params = {
        fileId: this.onceTableBtomTwo[0].fileId,
        subId: this.onceTableBtomTwo[0].handoverId,
        hdid: this.onceTableBtomTwo[0].id,
        bs: this.onceTableBtomTwo[0].handoverType == 0 ? 'jqyj' : 'mhyj'
      }
      delHandOverFile(params).then(res => {
        if (res.optFlag == 1) {
          // this.$message.success('移交成功')
          this.$message.success('移除成功')
          this.getDataViewDialog2 = false
          this.showListBtom2()
        } else {
          this.$message.error('移交失败')
          // this.$message.error(res.message)
          this.getDataViewDialog2 = false
          this.showListBtom2()
        }
      })
    },
    // 刷新内容--弹框
    submitBtn3 () {
      let params = {
        subId: this.onceTable[0].gid,
        type: this.onceTable[0].handoverType == 0 ? 'jqyj' : 'mhyj'
      }
      resettingHandOverFile(params).then(res => {
        if (res.data.optFlag == 1) {
          this.getDataViewDialog3 = false
          this.$message.success('刷新成功')
          // this.$message.success(res.message)
          this.showListBtom2()
        } else {
          this.getDataViewDialog3 = false
          this.$message.success('刷新失败')
          // this.$message.success(res.message)
        }
      })
    },
    // 录入
    showLookBtn4 () {
      this.showEditLook = {}
      this.showBtnLook = false
      if (this.getDataViewDialog27 || this.getDataViewDialog32) {
        this.getDataViewDialog30 = true
      } else {
        findSeriesCode({id: this.onceTable[0].gid}).then(res => {
          if (res.data) {
            this.showEditLook = res.data
            this.getDataViewDialog4 = true
          } else {
            this.$message.error('无法录入')
          }
        })
      }
    },
    submitBtn4 () {
      let reg = /^[0-9]*$/
      if (this.showEditLook.titleProper == undefined) {
        this.$message.error('请填写题名')
      } else if (this.showEditLook.dateOfCreation == undefined) {
        this.$message.error('请选择时间')
      } else if (this.showEditLook.yearCode == undefined || this.showEditLook.yearCode.length < 4 || this.showEditLook.yearCode.length > 4) {
        this.$message.error('请填写年度(输入长度为4）')
      } else if (!reg.test(this.showEditLook.yearCode)) {
        this.$message.error('年度只能填写数字')
      } else {
        if (this.showBtnLook) {
          this.showEditLook.subId = this.showEditLookSubId
          this.showEditLook.bs = 'qjym'
        } else {
          this.showEditLook.subId = this.onceTable[0].gid
          this.showEditLook.bs = this.onceTable[0].handoverType == 0 ? 'jqyj' : 'mhyj'
        }
        saveMhYjFile(this.showEditLook).then(res => {
          if (res.data.optFlag == 1) {
            this.$message.success('录入成功')
            // this.$message.success(res.message)
            this.getDataViewDialog4 = false
            if (this.showBtnLook) {
              this.showLookBtn44List()
            } else {
              this.showListBtom2()
            }
          } else {
            this.$message.error('录入失败')
            // this.$message.error(res.message)
            this.getDataViewDialog4 = false
          }
        })
      }
    },
    restBtn () {
      this.showEditLook = {}
      if (this.showBtnLook) {
        findSeriesCode({id: this.showEditLookSubId}).then(res => {
          this.showEditLook = res.data
        })
      } else {
        this.showEditLookSubId = ''
        findSeriesCode({id: this.onceTable[0].gid}).then(res => {
          this.showEditLook = res.data
        })
      }
    },
    // 编辑
    showLookBtn5 () {
      this.showEditLook = {}
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.getDataViewDialog5 = true
        this.showEditLook = JSON.parse(JSON.stringify(this.onceTableBtomTwo[0]))
      }
    },
    submitBtn5 () {
      if (this.showEditLook.title == this.onceTableBtomTwo[0].title) {
        this.$message.error('题名未进行修改，无需保存!')
      } else if (this.showEditLook.title == '' || this.showEditLook.title == null || this.showEditLook.title == undefined) {
        this.$message.error('题名不能为空')
      } else {
        this.getDataViewDialog6 = true
      }
    },
    submitBtn6 () {
      let params = {
        subId: this.onceTableBtomTwo[0].id,
        id: this.onceTableBtomTwo[0].id,
        title: this.showEditLook.title
      }
      editMhFileTitle(params).then(res => {
        if (res.data.optFlag == 1) {
          this.$message.success('修改成功')
          // this.$message.success(res.message)
          this.getDataViewDialog5 = false
          this.getDataViewDialog6 = false
          this.showListBtom2()
        } else {
          this.$message.error('修改失败')
          // this.$message.error(res.message)
        }
      })
    },
    // 删除
    showLookBtn6 () {
      let item = this.$onceWay().onceTableListTwo(this.onceTableBtomTwo)
      if (item == 1) {
        this.getDataViewDialog7 = true
      }
    },
    submitBtn7 () {
      let item = this.$onceWay().deleteId(this.onceTableBtomTwo)
      let params = {
        type: this.onceTableBtomTwo[0].handoverType == 0 ? 'jqyj' : 'mhyj',
        ids: item
      }
      deleteMhYjFile(params).then(res => {
        this.paramsTwo.page = 1
        this.paramsTwo.rows = 3
        if (res.data.optFlag == 1) {
          this.$message.success('删除成功')
          // this.$message.success(res.message)
          this.getDataViewDialog7 = false
          this.showListBtom2()
        } else {
          this.$message.error('删除失败')
          // this.$message.error(res.message)
          this.getDataViewDialog7 = false
          this.showListBtom2()
        }
      })
    },
    // 上传
    showLookBtn7 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.clearImgDel()
        this.getDataViewDialog8 = true
      }
    },
    handleChange (file, fileList) {
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('type', 'yj')
      formData.append('name', 'file')
      uploadPicture(formData).then(res => {
        if (res.code == 0) {
          this.imgVal.push(res.data.pathAndMD5)
        } else {
          this.$message.error(res.message)
        }
      })
    },
    // 删除上传
    handleRemove (val) {
      this.imgVal.splice(val, 1)
    },
    submitBtn8 () {
      /*if (this.getDataViewDialog27) {
        let params = {
          subId: this.onceTable[0].gid,
          imgVal: this.imgVal,
        }
        uploadThExcel(params).then(res => {
          console.log(res);
        })
      } else {
      }*/
      if (this.imgVal.length > 0) {
        let params = {
          subId: this.onceTableBtomTwo[0].fileId,
          detailId: this.onceTableBtomTwo[0].id,
          gid: this.onceTableBtomTwo[0].handoverId,
          imgVal: JSON.stringify(this.imgVal),
          bs: this.onceTableBtomTwo[0].handoverType == 0 ? 'jqyj' : 'mhyj'
        }
        saveUploadYjDoc(params).then(res => {
          if (res.code == 500) {
            this.$message.error('重复文件:' + res.message)
          }
          if (res.data.optFlag == 0) {
            this.$message.success('上传成功')
            this.getDataViewDialog8 = false
            this.showListBtom2()
          } else if (res.data.optFlag == 1) {
            this.$message.error('上传失败，' + res.data.msg)
          } else if (res.data.optFlag == -1) {
            this.$message.error('上传失败，因为文件' + res.data.msg + '已上传过了，请重新选择上传文件')
          }
        })
      } else {
        this.$message.error('请选择上传文件')
      }
    },
    clearImgDel () {
      this.imgVal = []
      if (this.$refs.AddBtnImgTwo) {
        this.$nextTick(() => {
          this.$refs.AddBtnImgTwo.clearFiles()
        })
      }
      if (this.$refs.AddBtnImgOne) {
        this.$nextTick(() => {
          this.$refs.AddBtnImgOne.clearFiles()
        })
      }
    },
    // 导入excel
    handleChangeTwo (file, fileList) {
      let item = this.onceTable[0].handoverStype == 0 ? 'jqyj' : 'mhyj'
      let formData = new FormData()
      if (this.getDataViewDialog27) {
        item = 'thYj'
      }
      formData.append('picture', file.raw)
      formData.append('type', item)
      formData.append('name', 'file')
      uploadExcelH5(formData).then(res => {
        if (res.data.flag == -1) {
          this.$message.error(res.data.msg)
        } else {
          this.imgVal.push(res.data.msg)
          // this.getDataViewDialog9 = false
        }
      })
    },
    // 文件超过1个时提示
    handleExceed (file, fileList) {
      this.$message.warning(`当前只能选择 1 个文件，本次已选择了 ${file.length} 个文件`)
    },
    submitBtn9 () {
      if (this.imgVal.length < 1) {
        this.$message.error('请选择文件')
      } else {
        let params = {
          subId: this.onceTable[0].gid,
          imgVal: this.imgVal
        }
        if (this.getDataViewDialog41) {
          uploadKjExcel(params).then(res => {
            if (res.data.optFlag == 0) {
              // this.$message.success(res.msg)
              this.$message.success(res.data.msg)
              this.getDataViewDialog9 = false
              this.showListBtom2()
            } else {
              this.$message.error(res.data.msg)
              this.errorMsg = res.msg
              this.getDataViewDialog48 = true
              this.showListBtom2()
            }
          })
        } else if (this.getDataViewDialog27) {
          uploadThExcel(params).then(res => {
            if (res.data.optFlag == 0) {
              // this.$message.success(res.msg)
              this.$message.success(res.data.msg)
              this.getDataViewDialog9 = false
              this.showListBtom2()
            } else {
              this.$message.error(res.data.msg)
              this.errorMsg = res.msg
              this.getDataViewDialog48 = true
              this.showListBtom2()
            }
          })
        } else if (this.getDataViewDialog32) {
          uploadZqExcel(params).then(res => {
            if (res.data.optFlag == 0) {
              // this.$message.success(res.msg)
              this.$message.success(res.data.msg)
              this.getDataViewDialog9 = false
              this.showListBtom2()
            } else {
              this.$message.error(res.data.msg)
              this.errorMsg = res.msg
              this.getDataViewDialog48 = true
              this.showListBtom2()
            }
          })
        } else {
          uploadExcel(params).then(res => {
            if (res.data.optFlag == 0) {
              this.$message.success(res.data.msg)
              this.getDataViewDialog9 = false
              this.showListBtom2()
            } else {
              // this.$message.error(res.msg)
              this.errorMsg = res.data.msg
              this.getDataViewDialog48 = true
              this.getDataViewDialog9 = false
              this.showListBtom2()
            }
          })
        }
      }
    },
    // 删除附件
    showLookBtn10 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.getDataViewDialog10 = true
        this.showListDelete()
      }
    },
    tableDeleteFile () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomThree)
      if (item == 1) {
        this.getDataViewDialog11 = true
      }
    },
    submitBtn11 () {
      let item = this.$onceWay().deleteId(this.onceTableBtomThree)
      let params = {
        ids: item,
        bs: this.onceTableBtomTwo[0].handoverType == 0 ? 'jqyj' : 'mhyj'
      }
      deleteDoc(params).then(res => {
        if (res.data.optFlag == 0) {
          this.$message.success('删除成功')
          this.getDataViewDialog11 = false
          this.showListDelete()
        } else {
          this.$message.error('删除失败')
          this.getDataViewDialog11 = false
          this.showListDelete()
        }
      })
    },
    // 异常
    showLookBtn11 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.getDataViewDialog12 = true
        this.clearRefs()
        if (this.onceTableBtomTwo[0].handoverException) {
          if (this.onceTableBtomTwo[0].handoverException.split(',').length >= 2) {
            let a = this.onceTableBtomTwo[0].handoverException.split(',')
            a.forEach((item, index) => {
              console.log(item);
              // if (item == '原件不完整（对方未盖章）') this.checkParams.contentOne = '原件不完整（对方未盖章）'
              if (item == '原件不完整（对方未盖章）') {
                this.$nextTick(() => {
                  this.$refs.contentOne.model = '原件不完整（对方未盖章）'
                })
              }
              if (item == '原件不完整（无签署时间）') {
                this.$nextTick(() => {
                  this.$refs.contentTwo.model = '原件不完整（无签署时间）'
                })
              }
              if (item == '原件不完整（缺失授权书）') {
                this.$nextTick(() => {
                  this.$refs.contentThree.model = '原件不完整（缺失授权书）'
                })
              }
              if (item == '原件不完整（对方未签名）') {
                this.$nextTick(() => {
                  this.$refs.contentFour.model = '原件不完整（对方未签名）'
                })
              }
              if (item == '原件不完整（缺失部分页）') {
                this.$nextTick(() => {
                  this.$refs.contentFive.model = '原件不完整（缺失部分页）'
                })
              }
              if (item == '广发未办理盖章') {
                this.$nextTick(() => {
                  this.$refs.hException1.model = '广发未办理盖章'
                })
              }
              if (item == '未打印签署') {
                this.$nextTick(() => {
                  this.$refs.hException2.model = '未打印签署'
                })
              }
            })
          } else {
            if (this.onceTableBtomTwo[0].handoverException == '(A1)合同各方已盖章，且已履行完毕') {
              this.$nextTick(() => {
                this.$refs.hException3.model = '(A1)合同各方已盖章，且已履行完毕'
              })
            }
            if (this.onceTableBtomTwo[0].handoverException == '(A2)合同各方已盖章，且正在履行') {
              this.$nextTick(() => {
                this.$refs.hException4.model = '(A2)合同各方已盖章，且正在履行'
              })
            }
            if (this.onceTableBtomTwo[0].handoverException == '自留函') {
              this.$nextTick(() => {
                this.$refs.hException4.model = '自留函'
                this.checkParams.zlhDate = this.onceTableBtomTwo[0].handoverDate
                this.selectDisTwo()
              })
            }
            if (this.onceTableBtomTwo[0].handoverException == '(A3)合同各方已盖章，合同不再履行') {
              this.$nextTick(() => {
                this.$refs.hException5.model = '(A3)合同各方已盖章，合同不再履行'
              })
            }
            if (this.onceTableBtomTwo[0].handoverException == '(A4)合同仅有我方盖章') {
              this.$nextTick(() => {
                this.$refs.hException6.model = '(A4)合同仅有我方盖章'
              })
            }
          }
        }
        // 达标措施
        console.log(this.onceTableBtomTwo[0])
        if (this.onceTableBtomTwo[0].upStandard) {
          if (this.onceTableBtomTwo[0].upStandard.split(')').length >= 2) {
            let a = this.onceTableBtomTwo[0].upStandard.split(')')
            a.forEach(item => {
              if (item == '补充整改完成后原件归档') {
                this.$nextTick(() => {
                  this.$refs.checkBosSeven.model = '补充整改完成后原件归档'
                })
              }
            })
          } else {
            if (this.onceTableBtomTwo[0].upStandard == '补充整改完成后原件归档') {
              this.$nextTick(() => {
                this.$refs.checkBosSeven.model = '补充整改完成后原件归档'
              })
            }
            if (this.onceTableBtomTwo[0].upStandard == '已补签') {
              if (this.onceTableBtomTwo[0].handoverException == '(A1)合同各方已盖章，且已履行完毕') {
                this.$nextTick(() => {
                  this.$refs.checkBosOne.model = '已补签'
                })
              }
              if (this.onceTableBtomTwo[0].handoverException == '(A2)合同各方已盖章，且正在履行' || this.onceTableBtomTwo[0].handoverException == '自留函') {
                this.$nextTick(() => {
                  this.$refs.checkBosThree.model = '已补签'
                })
              }
            }
            if (this.onceTableBtomTwo[0].upStandard == '已变更、解除、终止') {
              this.$nextTick(() => {
                this.$refs.checkBosFour.model = '已变更、解除、终止'
              })
            }
            if (this.onceTableBtomTwo[0].upStandard == '已全部回收') {
              this.$nextTick(() => {
                this.$refs.checkBosFive.model = '已全部回收'
              })
            }
            if (this.onceTableBtomTwo[0].upStandard == '补充整改完成后原件归档') {
              this.$nextTick(() => {
                this.$refs.checkBosSeven.model = '补充整改完成后原件归档'
              })
            }
          }
        }
        // 补救措施
        if (this.onceTableBtomTwo[0].remedial) {
          if (this.onceTableBtomTwo[0].remedial == '复印件等附件归档') {
            this.$nextTick(() => {
              this.$refs.checkBosTwo.model = '复印件等附件归档'
            })
          }
          if (this.onceTableBtomTwo[0].remedial == '已有遗失说明') {
            this.$nextTick(() => {
              this.$refs.checkBosSix.model = '已有遗失说明'
            })
          }
        }
        this.$nextTick(() => {
          this.selectDis()
        })
      }
    },
    selectDis (val) {
      if (this.checkParams.hException1 == '广发未办理盖章' || this.checkParams.hException2 == '未打印签署') {
        this.disYj = false
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (this.checkParams.hException3 == '(A1)合同各方已盖章，且已履行完毕') {
        this.disYj = true
        this.disHtOne = false
        this.disHtOneTwo = false
        this.disHtThreeTwoFy = false
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (this.checkParams.hException4 == '(A2)合同各方已盖章，且正在履行') {
        this.disYj = true
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = false
        this.disHtTwoOnce = true
        this.disHtTwoTwo = false
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (this.checkParams.hException5 == '(A3)合同各方已盖章，合同不再履行') {
        this.disYj = true
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = false
        this.disHtThreeTwo = false
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (this.checkParams.hException6 == '(A4)合同仅有我方盖章') {
        this.disYj = true
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = false
        this.disHtFourTwo = false
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (
        this.checkParams.contentOne == '原件不完整（对方未盖章）' ||
          this.checkParams.contentTwo == '原件不完整（无签署时间）' ||
          this.checkParams.contentThree == '原件不完整（缺失授权书）' ||
          this.checkParams.contentFour == '原件不完整（对方未签名）' ||
          this.checkParams.contentFive == '原件不完整（缺失部分页）'
      ) {
        this.disYj = true
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = false
        this.disHtBTwo = false
        this.disHtBThree = false
        this.disHtBFour = false
        this.disHtBFive = false
        this.disHtBOnceTwo = false
      } else if (
        this.checkParams.hException1 == undefined &&
          this.checkParams.hException2 == undefined &&
          this.checkParams.hException3 == undefined &&
          this.checkParams.hException4 == undefined &&
          this.checkParams.zlhDateOne == undefined
      ) {
        this.$refs.checkBosOne.model = false
        this.$refs.checkBosTwo.model = false
        this.$refs.checkBosThree.model = false
        this.$refs.checkBosFour.model = false
        this.$refs.checkBosFive.model = false
        this.$refs.checkBosSix.model = false
        this.$refs.checkBosSeven.model = false
        this.disCheckAbel()
      }
      // else if (this.checkParams.hException3 == undefined && this.checkParams.remedial2 == undefined && this.checkParams.upStandard2 == undefined) {
      //   console.log(22);
      //   this.disCheckAbel()
      // }
      else if (
        this.checkParams.hException4 == undefined &&
          this.checkParams.upStandard3 == undefined &&
          this.checkParams.zlhDateOne == undefined &&
          this.checkParams.zlhDate == undefined) {
        this.disCheckAbel()
      }
      if (this.checkParams.upStandard2 == '已补签') {
        console.log(1);
        this.disYj = true
        this.disHtOne = false
        this.disHtOneTwo = false
        this.disHtThreeTwoFy = true
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (this.checkParams.remedial2 == '复印件等附件归档') {
        console.log(2);
        this.disYj = true
        this.disHtOne = false
        this.disHtOneTwo = true
        this.disHtThreeTwoFy = false
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      }
    },
    selectDisTwo (val) {
      if (this.checkParams.hException4 == '自留函') {
        this.$message.info('请于出具自留函之日起6个月内完成全部合同归档，到期未完成将纳入合同异常归档考核！')
        this.disYj = true
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = true
        this.disHtTwoOnce = false
        this.disHtTwoTwo = false

        this.disHtTwoDate = true

        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (
        this.checkParams.hException1 == undefined &&
          this.checkParams.hException2 == undefined &&
          this.checkParams.hException3 == undefined &&
          this.checkParams.hException4 == undefined &&
          this.checkParams.zlhDateOne == undefined
      ) {
        this.$refs.checkBosOne.model = false
        this.$refs.checkBosTwo.model = false
        this.$refs.checkBosThree.model = false
        this.$refs.checkBosFour.model = false
        this.$refs.checkBosFive.model = false
        this.$refs.checkBosSix.model = false
        this.$refs.checkBosSeven.model = false
        this.disCheckAbel()
      }
      /* else {
          this.disYj = false
          this.disHtOne = false
          this.disHtOneTwo = false
          this.disHtTwo = false
          this.disHtTwoTwo = false
          this.disHtThree = false
          this.disHtThreeTwo = false
          this.disHtFour = false
          this.disHtFourTwo = false
          this.disHtBOne = false
          this.disHtBTwo = false
          this.disHtBThree = false
          this.disHtBFour = false
          this.disHtBFive = false
          this.disHtBOnceTwo = false
          this.disHtTwoDate = false
        } */
    },
    disCheckAbel () {
      this.disYj = false
      this.disHtOne = false
      this.disHtOneTwo = true
      this.disHtTwo = false
      this.disHtTwoOnce = false
      this.disHtTwoDate = false
      this.disHtTwoTwo = true
      this.disHtThree = false
      this.disHtThreeTwo = true
      this.disHtFour = false
      this.disHtFourTwo = true
      this.disHtBOne = false
      this.disHtBTwo = false
      this.disHtBThree = false
      this.disHtBFour = false
      this.disHtBFive = false
      this.disHtBOnceTwo = true
      this.checkParams = {}
    },
    errorCheckBtn () {
      this.checkParams.subId = this.onceTableBtomTwo[0].id
      this.checkParams.bs = this.onceTableBtomTwo[0].handoverType == 0 ? 'jqyj' : 'mhyj'
      let one = []
      let two = ''
      one.push(this.checkParams.contentOne)
      one.push(this.checkParams.contentTwo)
      one.push(this.checkParams.contentThree)
      one.push(this.checkParams.contentFour)
      one.push(this.checkParams.contentFive)
      one.forEach((item, index) => {
        if (item) {
          two += item + ','
        }
      })
      if (this.checkParams.hException1 && this.checkParams.hException2) {
        this.checkParams.hException1 = this.checkParams.hException1 + ',' + this.checkParams.hException2
      }
      this.checkParams.hException7 = two
      saveHandoverYc(this.checkParams).then(res => {
        if (res.data.optFlag == 1) {
          let params = {
            id: this.onceTableBtomTwo[0].id,
            subId: this.onceTableBtomTwo[0].fileId,
            isOriginal: this.onceTableBtomTwo[0].isOriginal
          }
          saveIsOriginal(params).then(res => {
            if (res.data.optFlag == 0) {
              this.$message.success('处理结果：成功')
              this.getDataViewDialog12 = false
              this.showListBtom2()
            } else if (res.data.optFlag == -1) {
              this.$message.error('处理结果：失败')
              this.getDataViewDialog12 = false
              this.showListBtom2()
            }
          })
        } else if (res.data.optFlag == -1) {
          this.$message.error('处理结果：失败')
          this.getDataViewDialog12 = false
          this.showListBtom2()
        }
      })
    },
    clearRefs () {
      this.$nextTick(() => {
        if (this.$refs.hException1) this.$refs.hException1.model = false
        if (this.$refs.hException2) this.$refs.hException2.model = false
        if (this.$refs.hException3) this.$refs.hException3.model = false
        if (this.$refs.checkBosOne) this.$refs.checkBosOne.model = false
        if (this.$refs.checkBosTwo) this.$refs.checkBosTwo.model = false
        if (this.$refs.hException4) this.$refs.hException4.model = false
        if (this.$refs.checkBosThree) this.$refs.checkBosThree.model = false
        if (this.$refs.hException5) this.$refs.hException5.model = false
        if (this.$refs.checkBosFour) this.$refs.checkBosFour.model = false
        if (this.$refs.hException5) this.$refs.hException5.model = false
        if (this.$refs.hException6) this.$refs.hException6.model = false
        if (this.$refs.checkBosFive) this.$refs.checkBosFive.model = false
        if (this.$refs.checkBosSix) this.$refs.checkBosSix.model = false
        if (this.$refs.checkBosSeven) this.$refs.checkBosSeven.model = false
        if (this.$refs.contentOne) this.$refs.contentOne.model = false
        if (this.$refs.contentTwo) this.$refs.contentTwo.model = false
        if (this.$refs.contentThree) this.$refs.contentThree.model = false
        if (this.$refs.contentFour) this.$refs.contentFour.model = false
        if (this.$refs.contentFive) this.$refs.contentFive.model = false
        if (this.$refs.checkBosEight) this.$refs.checkBosEight.model = false

        // this.$refs.hException2.model = false
        // this.$refs.hException3.model = false
        // this.$refs.checkBosOne.model = false
        // this.$refs.checkBosTwo.model = false
        // this.$refs.hException4.model = false
        // this.$refs.checkBosThree.model = false
        // this.$refs.hException5.model = false
        // this.$refs.checkBosFour.model = false
        // this.$refs.hException5.model = false
        // this.$refs.hException6.model = false
        // this.$refs.checkBosFive.model = false
        // this.$refs.checkBosSix.model = false
        // this.$refs.checkBosSeven.model = false
        // this.$refs.contentOne.model = false
        // this.$refs.contentTwo.model = false
        // this.$refs.contentThree.model = false
        // this.$refs.contentFour.model = false
        // this.$refs.contentFive.model = false
        // this.$refs.checkBosEight.model = false
        this.checkParams = {}
        this.thZqDate = {}
      })
    },
    // 合同异常归档下载
    wordPullBtn () {
      wordPull(`gdda-new/gdda/archiveYj/downLoadCzExplain`, '合同异常归档操作说明')
    },
    // 证券合同下载
    zjBtnDownload () {
      wordPull(`gdda-new/gdda/archiveYj/downLoadZjCzZy`, '证券金融业务合同归档通知+指引')
    },
    // 导出Excel
    showLookBtn12 () {
      this.getDataViewDialog88 = true
    },
    ajFileDownload88 () {
      if (this.getDataViewDialog27) {
        let params = {
          subId: this.onceTable[0].gid
        }
        valueIndex().exportFiles('/gdda-new/gdda/archiveYj/downloadThExcel', params, '投行录入模板.xls', 'get')
      } else if (this.getDataViewDialog32) {
        let params = {
          subId: this.onceTable[0].gid
        }
        valueIndex().exportFiles('/gdda-new/gdda/archiveYj/downloadZqExcel', params, '债券档案模板.xls', 'get')
      } else if (this.params.series2 == 1374133285844) {
        let params = {
          bs: 'yz',
        }
        valueIndex().exportFiles('/gdda-new/gdda/archiveYj/downloadExcel', params, '实物印章移交模板.xls', 'get')
      } else if (this.params.series2 == 1374133285845) {
        let params = {
          bs: 'qt',
          tag: '奖杯奖牌'
        }
        valueIndex().exportFiles('/gdda-new/gdda/archiveYj/downloadExcel', params, '实物奖杯奖牌移交模板.xls', 'get')
      } else if (this.params.series2 == 1374133285846) {
        let params = {
          bs: 'qt',
          tag: '外事礼品'
        }
        valueIndex().exportFiles('/gdda-new/gdda/archiveYj/downloadExcel', params, '实物外事礼品移交.xls', 'get')
      } else if (this.getDataViewDialog41) {
        let params = {
          bs: 'kj',
        }
        valueIndex().exportFiles('/gdda-newgdda/archiveYj/downloadZqExcel', params, '会计移交模板.xls', 'get')
      } else {
        this.$onceWay().wordPull('gdda-new/gdda/archiveYj/downloadExcel', '模糊移交模板.xls')
      }
      this.getDataViewDialog88 = false
    },
    // 修改附件
    showLookBtn13 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.getDataViewDialog14 = true
        this.showListDelete()
      }
    },
    tableDeleteFileTwo () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomThree)
      if (item == 1) {
        this.getDataViewDialog15 = true
        this.showEditLookTitle = JSON.parse(JSON.stringify(this.onceTableBtomThree[0].titleProper))
      }
    },
    submitBtn14 () {
      let params = {
        titleProper: this.showEditLookTitle,
        subId: this.onceTableBtomThree[0].id,
        id: this.onceTableBtomThree[0].id
      }
      editDocTitle(params).then(res => {
        if (res.data.optFlag == 1) {
          this.$message.success('修改成功')
          this.showListDelete()
          this.getDataViewDialog15 = false
        } else {
          this.$message.error('修改失败')
          this.showListDelete()
          this.getDataViewDialog15 = false
        }
      })
    },
    // 关联客户档案
    showLookBtn14 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item) {
        this.getDataViewDialog16 = true
      }
    },
    addMaterials () {
      listKhdaStuffCoding(this.paramsClientTwo).then(res => {
        this.clientTableTwo = res.data.rows
        this.paramsClientTwo.total = res.data.total
        this.getDataViewDialog17 = true
      })
    },
    searchContentAddBtn () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomFour)
      if (item == 1) {
        let params = {}
        params = {
          stuffName: this.onceTableBtomFour[0].stuffName,
          boxNo: null,
          packageNo: null,
          itemNo: null
        }
        this.clientTable.push(params)
      }
    },
    searchContentBtn () {
      this.paramsClientTwo.page = 1
      this.paramsClientTwo.rows = 10
      listKhdaStuffCoding(this.paramsClientTwo).then(res => {
        this.clientTableTwo = res.data.rows
        this.paramsClientTwo.total = res.data.total
      })
    },
    submitBtn15 () {
      if (this.clientTable.length < 1) {
        this.$message.error('请添加材料项')
      } else {
        let val = this.clientContent()
        let itemVal
        let formData = new FormData()
        if (val == 1) {
          this.clientTable.forEach((item, index) => {
            if (item.boxNo == null || item.packageNo == null || item.itemNo == null) {
              this.$message.error('请添加材料项')
            } else if (item.boxNo == '' || item.packageNo == '' || item.itemNo == '') {
              this.$message.error('请添加材料项')
            } else {
              itemVal = 1
              formData.append('subId', this.onceTableBtomTwo[0].id)
              formData.append('clientNo', this.paramsClient.clientNo)
              formData.append('stuffName', item.stuffName)
              formData.append('boxNo', item.boxNo)
              formData.append('packageNo', item.packageNo)
              formData.append('itemNo', item.itemNo)
            }
          })
          if (itemVal == 1) {
            saveGlKhda(formData).then(res => {
              if (res.data.optFlag == -1) {
                this.$message.error('系统提示, 关联失败，系统出错')
              } else if (res.data.optFlag == 0) {
                getQrYjRemark({hid: this.onceTableBtomTwo[0].id}).then(res => {
                  this.dialogTable = JSON.parse(res.data.handoverRemark)
                  if (this.dialogTable) {
                    this.dialogTable.forEach((item, index) => {
                      item.handoverRemark = item.handoverRemark.split('<br>')
                    })
                  }
                })
              } else if (res.data.optFlag == 4) {
                this.$message.error('系统提示, 未添加材料项，无法关联')
              } else {
                let title = res.data.optFlag.split(',')
                if (title[0] == 0) {
                  this.$message.error(`系统提示, 您已关联了${title[1]}，如需重新上传请先删除关联附件。`)
                } else if (title[0] == 2) {
                  this.$message.error(`系统提示, 您已关联了${title[1]}，关联失败，请确认是否已移交并且扫描。`)
                } else if (title[0] == 3) {
                  this.$message.error(`系统提示, 您已关联了${title[1]}，关联失败，客户档案未完成扫描挂接，请确认完成扫描后再进行关联。`)
                }
              }
            })
          }
        }
      }
    },
    clientContent () {
      let reg = /^[0-9]*$/
      if (this.paramsClient.clientNo == '' || this.paramsClient.clientNo == null) {
        this.$message.error('客户编号不得为空，请注意填写')
      } else if (!reg.test(this.paramsClient.clientNo)) {
        this.$message.error('请输入数字')
      } else if (this.paramsClient.clientNo.length < 12 || this.paramsClient.clientNo.length > 12) {
        this.$message.error('输入长度不得低于12与不得大于12长度')
      } else {
        return 1
      }
    },
    deleteClient (val) {
      this.clientTable.splice(val, 1)
    },
    // 合同信息补充
    showLookBtn15 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.getDataViewDialog18 = true
        let params = {
          detailId: this.onceTableBtomTwo[0].id,
          gid: this.onceTableBtomTwo[0].handoverId
        }
        getBusinessType(params).then(res => {
          this.paramsAddContent = res.data
          this.businessType = res.data.orgBusinessType
          if (this.paramsAddContent.isBusinessType == 2) {
            this.showDisableTwo = true
          } else {
            this.showDisableTwo = false
          }
        })
        this.paramsHt.subId = this.onceTableBtomTwo[0].id
        this.showListHt()
      }
    },
    htBtn () {
      console.log(this.paramsAddContent)
      let params = {
        signDate: this.paramsAddContent.signDate,
        businessType: this.paramsAddContent.businessType,
        isBusinessType: this.paramsAddContent.isBusinessType,
        detailId: this.paramsAddContent.detailId
      }
      if (this.paramsAddContent.isBusinessType == null || this.paramsAddContent.isBusinessType == '') {
        this.$message.error('请选择是否业务合同')
      } else if (this.paramsAddContent.isBusinessType == 1) {
        if (this.paramsAddContent.businessType == null || this.paramsAddContent.businessType == '') {
          this.$message.error('请选择业务类型')
        } else {
          saveImformation(params).then(res => {
            console.log(res)
            if (res.optFlag == 0) {
              this.$message.success('保存成功')
              this.getDataViewDialog18 = false
              this.showListBtom2()
            } else if (res.optFlag == -1) {
              this.$message.error('系统错误')
            } else if (res.optFlag == 1) {
              this.$message.error('保存失败，签署日期不合法')
            }
          })
        }
      } else if (this.paramsAddContent.signDate == null || this.paramsAddContent.signDate == '') {
        this.$message.error('请选择签署日期')
      } else {
        saveImformation(params).then(res => {
          if (res.optFlag == 0) {
            this.$message.success('保存成功')
            this.getDataViewDialog18 = false
            this.showListBtom2()
          } else if (res.optFlag == -1) {
            this.$message.error('系统错误')
          } else if (res.optFlag == 1) {
            this.$message.error('保存失败，签署日期不合法')
          }
        })
      }
    },
    // 合同dis
    disBusType (val) {
      if (val == 2) {
        this.showDisableTwo = true
      } else {
        this.showDisableTwo = false
      }
    },
    showLookBtnThree () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomFour)
      if (item == 1) {
        this.paramsEditContent = JSON.parse(JSON.stringify(this.onceTableBtomFour[0]))
        this.getDataViewDialog19 = true
      }
    },
    submitBtn16 () {
      if (this.paramsEditContent.creditCode == null || this.paramsEditContent.creditCode == '') {
        this.$message.error('请填写社会信用代码')
      } else if (this.paramsEditContent.registerNo == null || this.paramsEditContent.registerNo == '') {
        this.$message.error('请填写工商注册码')
      } else if (this.paramsEditContent.orgNo == null || this.paramsEditContent.orgNo == '') {
        this.$message.error('请填写组织机构代码')
      } else {
        this.paramsEditContent.partnerId = this.onceTableBtomFour[0].id
        this.paramsEditContent.subId = this.onceTableBtomTwo[0].id
        handoverPartnerEditSave(this.paramsEditContent).then(res => {
          if (res.optFlag == 1) {
            this.$message.success('修改成功')
            this.getDataViewDialog19 = false
            this.showListHt()
          } else {
            this.$message.error('修改失败')
            this.getDataViewDialog19 = false
          }
        })
      }
    },
    showLookBtnDelete () {
      delImformation({partnerId: this.onceTableBtomFour[0].id}).then(res => {
        if (res.optFlag == 1) {
          this.$message.success('删除成功')
          this.showListHt()
        } else {
          this.$message.error('删除失败')
          // this.showListHt()
        }
      })
    },
    // 移交情况
    showLookBtn16 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        getYjInformation({subId: this.onceTableBtomTwo[0].id}).then(res => {
          this.paramsEditContent = res.data
          this.getDataViewDialog20 = true
        })
      }
    },
    submitBtn17 () {
      let params = {
        subId: this.onceTableBtomTwo[0].id,
        completes: this.paramsEditContent.completes
      }
      saveYjInfoData(params).then(res => {
        if (res.data.optFlag == 0) {
          this.$message.success('修改成功')
          this.getDataViewDialog20 = false
          this.showListBtom2()
        } else {
          this.$message.error('修改失败')
          this.getDataViewDialog20 = false
        }
      })
    },
    radioCompletes (val) {
      this.paramsEditContent.completes = val
      this.$forceUpdate()
    },
    searchContent () {
      let fk = null
      if (this.params.series1 == 1379482316593 || this.params.series1 == 1383033168454) {
        fk = 1
      } else if (this.params.series1 == 1388742017296) {
        if (this.params.series2 == 1388742017297 || this.params.series2 == 1388742017298) {
          fk = 2
        } else {
          fk = 1
        }
      } else if (this.params.series1 == 1388742017269) {
        fk = 3
      } else if (this.params.series1 == 1374133285843) {
        if (this.params.series2 == 1374133285844) {
          fk = 4
        } else if (this.params.series2 == 1374133285845) {
          fk = 5
        }
      } else if (this.params.series1 == 1374133285828) {
        fk = 6
      }
      this.params = {
        page: 1,
        rows: 10,
        status: this.params.status,
        fonds: this.params.fonds,
        yjType: this.params.yjType,
        series1: this.params.series1,
        series2: this.params.series2,
        series3: this.params.series3,
        searchType: fk,
        total: this.params.total
      }
      if (this.params.series1 == 1388742017296) {
        this.getDataViewDialog211 = true
      } else if (this.params.series1 == 1388742017269) {
        this.getDataViewDialog212 = true
      } else if (this.params.series1 == 1374133285843) {
        if (this.params.series2 == 1374133285844) {
          this.getDataViewDialog213 = true
        } else {
          this.getDataViewDialog214 = true
        }
      } else if (this.params.series1 == 1374133285828) {
        this.getDataViewDialog215 = true
      } else {
        this.getDataViewDialog21 = true
      }
    },
    // 检索
    submitBtn18 () {
      this.showList()
      this.getDataViewDialog21 = false
      this.getDataViewDialog211 = false
      this.getDataViewDialog212 = false
      this.getDataViewDialog213 = false
      this.getDataViewDialog214 = false
      this.getDataViewDialog215 = false
    },
    reset () {
      this.params = {
        page: 1,
        rows: 10,
        status: 1,
        fonds: 1374133141812,
        series1: 1379482316593,
        searchType: 1,
        total: this.params.total
      }
    },
    // 监所内的搜索
    remoteMethodUser (val) {
      let params = {
        orgFlag1: -10000,
        q: val
      }
      searchFindUser(params).then(res => {
        this.yjcurrentuserArr = res
      })
    },
    // 监所内的搜索
    remoteMethodMan (val) {
      let params = {
        orgFlag1: -10000,
        q: val
      }
      searchFindUser(params).then(res => {
        this.yjc89Arr = res
      })
    },
    // 录入模糊移交
    lrYjPcBtn () {
      this.paramsYj = {}
      this.showEditLookSubId = ''
      this.showBtnLook = false
      this.dialogTableBtom = []
      this.dialogTableBtomTwo = []
      this.paramsTwo1.total = 0
      this.fullZongArrTwo = []
      this.FondsAndRoleArrTwo = []
      this.FondsAndRoleTwoOnce = []
      branchListOrg().then(res => {
        this.handoverDeptArr = res.data
      })
      getFonds().then(res => {
        // this.fullZongArr = res.data
        this.fullZongArrTwo = res.data
      })
      if (this.params.series1 == 1374133285828) { // 声像
        this.getDataViewDialog55 = true
      } else {
        if (this.showMehod) {
          if (this.params.series1 == 1388742017269) {
            this.getDataViewDialog52 = true // 会计
          } else if (this.params.series1 == 1374133285843) { // 实物
            if (this.params.series2 == 1374133285844) { // 印章
              this.getDataViewDialog53 = true
            } else {
              this.getDataViewDialog54 = true
            }
          } else {
            this.getDataViewDialog22 = true
          }
        } else {
          if (this.params.series2 == 1388742017298) {
            this.getDataViewDialog51 = true
          } else {
            this.getDataViewDialog50 = true
            this.paramsYj.handoverDept = '8021'
          }
          // 8021
        }
      }
    },
    yjUserChange (val) {
      // newListUserByDept({id: val}).then(res => {
      //   this.handoverUserArr = res.data
      // })
      if (this.params.series2 == 1388742017298) {
        saveZqHandOver({flag1: val}).then(res => {
          this.handoverUserArr = res.data
        })
      } else {
        listClientNoByDept({flag1: val}).then(res => {
          this.handoverUserArr = res.data
        })
      }
    },
    fullZongBtn (val) {
      listSeriesByFonds({id: val}).then(res => {
        this.FondsAndRoleArr = res.data
      })
    },
    yjBtn () {
      if (this.paramsYj.handoverDept == null || this.paramsYj.handoverDept == '') {
        this.$message.error('请选择移交部门')
      } else if (this.paramsYj.handoverUser == null || this.paramsYj.handoverUser == '') {
        this.$message.error('请选择移交人')
      } else if (this.paramsYj.handoverRemark == null || this.paramsYj.handoverRemark == '') {
        this.$message.error('请填写意见')
      } else if (this.paramsYj.fonds == null || this.paramsYj.fonds == '') {
        this.$message.error('请选择全宗')
      } else if (this.paramsYj.series == null || this.paramsYj.series == '') {
        this.$message.error('请选择档案分类')
      } else {
        if (this.params.series1 == 1388742017269 || this.params.series1 == 1374133285843) {
          if (this.paramsYj.series1 == null || this.paramsYj.series1 == '') {
            this.$message.error('请选择档案分类')
          } else {
            this.handoverDeptArr.forEach(item => {
              if (this.paramsYj.handoverDept == item.flag1) {
                this.paramsYj.handoverDept = item.organizeId
              }
            })
            saveMhHandOver(this.paramsYj).then(res => {
              if (res.data.optFlag == 0) {
                this.$message.success('保存成功')
                this.showBtnLook = true
                this.showEditLookSubId = res.data.msg
                findSeriesCode({id: res.data.msg}).then(res => {
                  this.showEditLook = res.data
                })
              } else {
                this.$message.error('保存失败')
                this.showBtnLook = false
              }
            })
          }
        } else {
          this.handoverDeptArr.forEach(item => {
            if (this.paramsYj.handoverDept == item.flag1) {
              this.paramsYj.handoverDept = item.organizeId
            }
          })
          saveMhHandOver(this.paramsYj).then(res => {
            if (res.data.optFlag == 0) {
              this.$message.success('保存成功')
              this.showBtnLook = true
              this.showEditLookSubId = res.data.msg
              findSeriesCode({id: res.data.msg}).then(res => {
                this.showEditLook = res.data
              })
            } else {
              this.$message.error('保存失败')
              this.showBtnLook = false
            }
          })
        }
      }
    },
    showLookBtn44 () {
      // findSeriesCode({id: this.onceTable[0].gid}).then(res => {
      findSeriesCode({id: this.showEditLookSubId}).then(res => {
        if (this.params.series1 == 1388742017269) {
          this.getDataViewDialog522 = true
        } else if (this.params.series1 == 1374133285828) {
          this.getDataViewDialog555 = true
        } else if (this.params.series2 == 1374133285844) {
          this.getDataViewDialog533 = true
        } else if (this.params.series2 == 1374133285845 || this.params.series2 == 1374133285846 || this.params.series2 == 1374133285847
          || this.params.series2 == 1374133285848 || this.params.series2 == 1374133285849) {
          this.getDataViewDialog544 = true
        } else {
          this.getDataViewDialog4 = true
        }
        this.showEditLook = res.data
      })
      // this.showEditLook.filingUser = JSON.parse(JSON.stringify(this.paramsYj))
      // this.showLookBtn44List()
    },
    searchSeriesOnceTwo (val) {
      listSeriesByFonds({id: val}).then(res => {
        this.FondsAndRoleTwoOnce = res.data
      })
    },
    showLookBtn50 () {
      if (this.paramsYj.handoverDept == '' || this.paramsYj.handoverDept == undefined) {
        this.$message.error('请选择移交部门')
      } else if (this.paramsYj.handoverUser == '' || this.paramsYj.handoverUser == undefined) {
        this.$message.error('请选择移交人')
      } else if (this.paramsYj.handoverRemark == '' || this.paramsYj.handoverRemark == undefined) {
        this.$message.error('请填写移交意见')
      } else {
        this.paramsYj.series = this.params.series2
        saveThHandOver(this.paramsYj).then(res => {
          if (res.data.optFlag == 1) {
            this.$message.success('录入成功')
            this.getDataViewDialog50 = false
            this.paramsYj = {}
            this.showList()
          } else {
            this.$message.error(res.data.msg)
          }
        })
      }
    },
    showLookBtn44List () {
      // this.paramsTwo = {}
      this.paramsTwo.page = 1
      this.paramsTwo.rows = 3
      this.paramsTwo.subId = this.showEditLookSubId
      listHandOverDetailData(this.paramsTwo).then(res => {
        this.dialogTableBtomTwo = res.data.rows
        this.paramsTwo.total = res.data.total
      })
    },
    // 发送代办
    showLookBtn55 () {
      sendMhYjOa({id: this.showEditLookSubId}).then(res => {
        if (res.data.optFlag == 1) {
          this.$message.success('成功发送代办')
          this.getDataViewDialog22 = false
          this.getDataViewDialog49 = false
          this.handleCloseThree()
          this.handleCloseTwo()
          this.handleClose()
        } else {
          this.$message.error(res.data.msg)
          this.getDataViewDialog22 = false
          this.getDataViewDialog49 = false
          this.handleCloseThree()
          this.handleCloseTwo()
          this.handleClose()
        }
      })
    },
    // 重新发送代办
    retryBtn () {
      let item = this.$onceWay().onceTableList(this.onceTable)
      if (item == 1) {
        this.getDataViewDialog23 = true
      }
    },
    submitBtn19 () {
      sendYjQrDb({id: this.onceTable[0].cid}).then(res => {
        console.log(res)
        if (res.data.optFlag == 1) {
          this.$message.success('发送成功')
          this.getDataViewDialog23 = false
          this.showList()
        } else {
          this.$message.error(res.data.msg)
          this.getDataViewDialog23 = false
        }
      })
    },
    // 线下移交
    wireBtn () {
      this.getDataViewDialog24 = true
      this.roleListTable = []
      this.userListTable = []
      this.carrierListOnce = null // 载体类型
      this.departListOnce = null // 部门
      this.specialListOnce = null // 特殊档案类型
      ListArchive({id: 0}).then(res => {
        this.specialList = res.data
      })
      branchListOrg().then(res => {
        this.handoverDeptArr = res.data
      })
      branchListTUser().then(res => {
        this.handoverUserArrList = res.data
      })
      ListRetentionPeriod().then(res => {
        this.handoverPeriodArrList = res.data
      })
    },
    submitBtn20 () {
      let val = ''
      this.roleListTable.forEach((item, index) => {
        if (item.userBranch == '' || item.userBranch == null) {
          this.$message.error('移交部门不能为空')
        } else if (item.userId == '' || item.userId == null) {
          this.$message.error('移交人不能为空')
        } else if (item.itemValue == '' || item.itemValue == null) {
          this.$message.error('保管期限不能为空')
        } else if (item.idea == '' || item.idea == null) {
          this.$message.error('意见不能为空')
        } else {
          val += `${item.id};${item.itemValue};${item.userBranch};${item.userId};${item.idea},`
        }
      })
      let archive = null
      if (this.params.series1 != null || this.params.series1 != '') archive = this.params.series1
      else if (this.params.series2 != null || this.params.series2 != '') archive = this.params.series1
      if (this.userListTable.length < 1) {
        this.$message.error('材料不能为空')
      } else {
        let params = {
          archive: archive,
          data: val
        }
        saveUnderLine(params).then(res => {
          if (res.data.optFlag.split(';')[0] == 0) {
            this.$message.success(res.data.optFlag.split(';')[1] + '---成功')
            this.getDataViewDialog24 = false
          } else {
            this.$message.error('失败')
          }
        })
      }
    },
    submitBtn21 () {
      this.roleListTable = []
      this.userListTable = []
      this.carrierListOnce = null // 载体类型
      this.departListOnce = null // 部门
      this.specialListOnce = null // 特殊档案类型
    },
    handleCurrentChangeUser (val) {
      this.paramsUser = val
    },
    specialChange (val) {
      this.carrierList = []
      this.departList = []
      this.userListTable = []
      this.roleListTable = []
      this.carrierListOnce = null
      this.departListOnce = null
      this.specialList.forEach((item, index) => {
        if (item.id == val) {
          this.carrierList = item.carrierList
        }
      })
    },
    carrierChange (val) {
      this.userListTable = []
      this.roleListTable = []
      this.departList = []
      this.departListOnce = null
      this.carrierList.forEach((item, index) => {
        if (item.carrierId == val) {
          this.departList = item.deptList
        }
      })
    },
    departChange (val) {
      this.userListTable = []
      this.roleListTable = []
      this.paramsUser.parentId = val
      listForJson(this.paramsUser).then(res => {
        this.userListTable = res.data.rows
        this.paramsUser.total = res.data.total
      })
    },
    userAddBtn (val) {
      let params = {
        userBranch: val.userBranch,
        userId: val.userId,
        itemValue: val.itemValue,
        idea: val.idea,
        id: val.id,
        typeCode: val.typeCode,
        type: val.type,
        parentId: val.parentId,
        archiveTypeId: val.archiveTypeId,
        archiveTypeName: val.archiveTypeName,
        createUserName: val.createUserName,
        effectiveData: val.effectiveData,
        createTime: val.createTime
      }
      this.roleListTable.push(params)
      this.paramsRole.total = this.roleListTable.length
    },
    deleteUserBtn (val) {
      this.roleListTable.splice(val, 1)
    },
    // 定时设置
    toOrderBtn () {
      this.paramsData = {}
      this.dataListTableOnce = []
      this.getDataViewDialog25 = true
      this.paramsData.page = 1
      this.paramsData.rows = 10
      this.sendTypeListChange()
      this.dataListTable()
    },
    dataListTable () {
      let archive = ''
      if (this.params.series1 != null || this.params.series1 != '') archive = this.params.series1
      else if (this.params.series2 != null || this.params.series2 != '') archive = this.params.series1
      this.paramsData.archive = archive
      ListSeriesList().then(resVal => {
        listTimingData(this.paramsData).then(res => {
          this.dataListTableOnce = res.data.rows
          this.paramsData.total = res.data.total
          this.dataListTableOnce.forEach(item => {
            resVal.data.forEach(itemVal => {
              if (item.tag == itemVal.tag) {
                item.tagName = itemVal.name
              }
            })
          })
        })
      })
    },
    submitBtn22 () {
      let itemVal = this.$onceWay().onceTableListTwo(this.onceTableData)
      if (itemVal == 1) {
        this.paramsData.valueList = ''
        if (this.paramsData.sendType == null || this.paramsData.sendType == '') {
          this.$message.error('请选择发送类型')
        } else if (this.paramsData.sendType == 1) {
          if (this.paramsData.status == null || this.paramsData.status == '') {
            this.$message.error('请选择发送类型')
          } else {
            let ids = ''
            this.onceTableData.forEach(item => {
              ids += item.gid + ','
            })
            this.paramsData.ids = ids
            saveTiming(this.paramsData).then(res => {
              if (res.data.optFlag == 0) {
                this.$message.success('处理成功')
                this.dataListTable()
                this.getDataViewDialog25 = false
              } else {
                this.$message.error('处理失败')
              }
            })
          }
        } else if (this.paramsData.matureDate == null || this.paramsData.matureDate == '') {
          this.$message.error('请选择期限时间')
        } else {
          if (this.paramsData.sendType == 0) {
            this.paramsData.status = null
          }
          let ids = ''
          this.onceTableData.forEach(item => {
            ids += item.gid + ','
          })
          this.paramsData.ids = ids
          saveTiming(this.paramsData).then(res => {
            if (res.data.optFlag == 0) {
              this.$message.success('处理成功')
              this.dataListTable()
              this.getDataViewDialog25 = false
            } else {
              this.$message.error('处理失败')
            }
          })
        }
      }
    },
    sendTypeListChange (val) {
      if (val == 0) {
        this.statusShow = false
      } else {
        this.statusShow = true
      }
      this.dataListTable()
    },
    statusListChange (val) {
      console.log(val)
      this.dataListTable()
    },
    matureDateChange (val) {
      this.paramsData.timing = val
      if (val == ' ' || val == undefined || val == ''){
        console.log(val);
      } else {
        let date = new Date()
        let dateYear = date.getFullYear()
        let dateMonth = date.getMonth() + 1
        // let dateDay = date.getDay() + 1
        let dateDay = date.getDate()
        if (val == 0) {
          dateMonth = dateMonth + 3
          if (dateMonth > 12) {
            dateYear = dateYear + 1
            dateMonth = dateMonth - 12
          }
          this.paramsData.matureDate = `${dateYear}-${dateMonth}-${dateDay}`
        } else if (val == 1) {
          dateMonth = dateMonth + 6
          if (dateMonth > 12) {
            dateYear = dateYear + 1
            dateMonth = dateMonth - 12
          }
          this.paramsData.matureDate = `${dateYear}-${dateMonth}-${dateDay}`
        } else if (val == 2) {
          dateMonth = dateMonth + 9
          if (dateMonth > 12) {
            dateYear = dateYear + 1
            dateMonth = dateMonth - 12
          }
          this.paramsData.matureDate = `${dateYear}-${dateMonth}-${dateDay}`
        } else if (val == 3) {
          this.paramsData.matureDate = `${dateYear + 1}-${dateMonth}-${dateDay}`
        } else if (val == 4) {
          this.paramsData.matureDate = `${dateYear + 3}-${dateMonth}-${dateDay}`
        } else if (val == 5) {
          dateDay = dateDay + 1
          if (dateDay > 31) {
            if (dateMonth > 12) {
              dateYear = dateYear + 1
              dateMonth = dateMonth - 12
            }
          }
          this.paramsData.matureDate = `${dateYear}-${dateMonth}-${dateDay}`
        }
      }
      this.$forceUpdate()
    },
    handleSelectionChangeBtomData (val) {
      this.onceTableData = []
      this.onceTableData = val
    },
    // 批量链接
    brachBtn () {
      this.getDataViewDialog26 = true
      this.imgVal = []
      this.paramsBatch = {}
      this.paramsBatch.series = null
      this.paramsBatch.matchingData = null
      // this.matchingData = []
      this.FondsAndRoleArrTwo = []
      getFonds().then(res => {
        this.fullZongArrTwo = res.data
      })
      this.clearImgDel()
    },
    fullZongBtnTwo (val) {
      this.paramsYj.series = null
      this.paramsBatch.series = null
      this.paramsBatch.matchingData = null
      this.FondsAndRoleArrTwo = []
      this.matchingData = []
      // this.matchingData = []
      listSeriesByFonds({id: val}).then(res => {
        this.FondsAndRoleArrTwo = res.data
      })
    },
    fullZongBtnThree (val) {
      this.paramsYj.series = null
      this.paramsBatch.series = null
      this.paramsBatch.matchingData = null
      this.FondsAndRoleArrTwo = []
      // this.matchingData = []
      // this.matchingData = []
      listSeriesByFonds({id: val}).then(res => {
        this.FondsAndRoleArrTwo = res.data
      })
    },
    FondsAndRoleArrChange (val) {
      this.paramsBatch.matchingData = null
      // this.matchingData = []
      this.paramsBatch.series = val
      listSeriesByFonds({id: val}).then(res => {
        this.matchingData = res.data
      })
      this.$forceUpdate()
    },
    matchingDataChange (val) {
      this.paramsBatch.matchingData = val
      this.$forceUpdate()
    },
    // 上传图片
    handleChangeThree (file, fileList) {
      let formData = new FormData()
      this.paramsBatch.batchId = new Date().getTime()
      formData.append('picture', file.raw)
      formData.append('type', 'plHanging')
      formData.append('name', 'file')
      formData.append('batchId', this.paramsBatch.batchId)
      uploadPlPicture(formData).then(res => {
        if (res.code == 0) {
          this.imgVal.push(res.data.pathAndMD5)
        } else {
          this.$message.error(res.message)
        }
      })
    },
    submitBtn23 () {
      if (this.paramsBatch.fonds == null || this.paramsBatch.fonds == '') {
        this.$message.error('请选择全宗')
      } else if (this.paramsBatch.series == null || this.paramsBatch.series == '') {
        this.$message.error('请选择档案类型')
      } else if (this.paramsBatch.matchingData == null || this.paramsBatch.matchingData == '') {
        this.$message.error('请选择匹配方式')
      } else if (this.imgVal.length <= 0) {
        this.$message.error('请选择要上传的文件')
      } else {
        this.paramsBatch.imgVal = JSON.stringify(this.imgVal)
        savePlHangingDocs(this.paramsBatch).then(res => {
          // console.log(res);
          if (res.data.optFlag == 0) {
            this.$message.success('上传成功')
            this.getDataViewDialog26 = false
          } else if (res.data.optFlag == 1) {
            this.$message.error(`上传至服务器的文件获取失败，此时，mgs为：${res.data.msg}请重新上传文件`)
          } else {
            this.$message.error('失败')
          }
        })
      }
    },
    // 投资银行
    submitBtn28 () {
      if (this.showEdit.receiveUser == undefined || this.showEdit.receiveUser == null) {
        this.$message.error('当前接收人为空，不能进行移交！')
      } else {
        countHandOverDetail({gid: this.onceTable[0].gid}).then(res => {
          if (res.data.optFlag == -1) {
            this.$message.error('系统提示, "移交失败，系统出错')
          } else if (res.data.optFlag == 2) {
            this.$message.error('系统提示, "确认失败，当前移交状态的移交单已被其他用户处理了')
          } else {
            this.showEdit.gid = this.onceTable[0].gid
            this.showEdit.subId = this.onceTable[0].cid
            this.showEdit.handoverRemark = this.showEdit.applyRemarkCopy
            this.isHander()
            thHandOverSave(this.showEdit).then(res => {
              if (res.data.optFlag == 1) {
                this.$message.success('保存成功')
                this.getDataViewDialog27 = false
                this.getDataViewDialog28 = false
                this.getDataViewDialog32 = false
                this.getDataViewDialog33 = false
                this.showListBtom2()
              } else {
                this.$message.error(res.data.msg)
                this.getDataViewDialog27 = false
                this.getDataViewDialog28 = false
                this.getDataViewDialog32 = false
                this.getDataViewDialog33 = false
                this.showListBtom2()
              }
            })
          }
        })
      }
    },
    // 线下移交确认
    submitBtn29 () {
      handOverSave(this.showEdit).then(res => {
        if (res.data.optFlag == '2') {
          this.$message.error('系统提示, "确认失败，当前移交状态的移交单已被其他用户处理了"')
        } else if (res.data.optFlag == 1) {
          this.$message.success('成功')
          this.handleClose()
          this.handleCloseTwo()
          this.showList()
        } else {
          this.$message.error('失败')
        }
      })
    },
    // 投资银行录入
    submitBtn30 () {
      if (this.showEditLook.title == '' || this.showEditLook.title == null) {
        this.$message.error('请填写项目名称')
      } else if (this.showEditLook.handoverEmployer == '' || this.showEditLook.handoverEmployer == null) {
        this.$message.error('请填写项目单位全称')
      } else if (this.showEditLook.fileType == '' || this.showEditLook.fileType == null) {
        this.$message.error('请填写项目类型')
      } else if (this.showEditLook.handoverHt == '' || this.showEditLook.handoverHt == null) {
        this.$message.error('请填写业务类型')
      } else if (this.showEditLook.gzhangLevel == '' || this.showEditLook.gzhangLevel == null) {
        this.$message.error('请填写快递单号')
      } else if (this.showEditLook.fileCode == '' || this.showEditLook.fileCode == null) {
        this.$message.error('请填写移交箱数')
      } else {
        this.showEditLook.subId = this.onceTable[0].gid
        saveThYjFile(this.showEditLook).then(res => {
          if (res.data.optFlag == 1) {
            this.$message.success('录入成功')
            this.getDataViewDialog30 = false
            this.showListBtom2()
          } else {
            this.$message.error('录入失败')
            this.getDataViewDialog30 = false
          }
        })
      }
    },
    // 实物，会计，声像弹框确认
    submitBtn35 () {
      if (this.showEdit.receiveUser == undefined || this.showEdit.receiveUser == null) {
        this.$message.error('当前接收人为空，不能进行移交！')
      } else {
        countHandOverDetail({gid: this.onceTable[0].gid}).then(res => {
          if (res.data.optFlag == -1) {
            this.$message.error('系统提示, "移交失败，系统出错')
          } else if (res.data.optFlag == 2) {
            this.$message.error('系统提示, "确认失败，当前移交状态的移交单已被其他用户处理了')
          } else {
            this.showEdit.gid = this.onceTable[0].gid
            this.showEdit.subId = this.onceTable[0].cid
            this.showEdit.handoverRemark = this.showEdit.applyRemarkCopy
            if (this.params.series1 == 1374133285843) {
              this.showEdit.bs = 'qt'
            }
            this.isHander()
            handOverSave(this.showEdit).then(res => {
              if (res.data.optFlag == 1) {
                this.$message.success('保存成功')
                this.handleCloseThree()
                this.handleCloseTwo()
                this.showList()
              } else {
                this.$message.error(res.data.msg)
                this.handleCloseThree()
                this.handleCloseTwo()
                this.showList()
              }
            })
          }
        })
      }
    },
    // 录入
    showLookBtn35 () {
      this.showEditLook = {}
      findSeriesCode({id: this.onceTable[0].gid}).then(res => {
        if (res.data) {
          this.showEditLook = res.data
          this.showEditLook.subId = this.onceTable[0].gid
          if (this.params.series2 == 1374133285844) {
            this.getDataViewDialog37 = true
          // } else if (this.params.series2 == 1374133285845) {
          } else {
            this.getDataViewDialog39 = true
          }
        } else {
          this.$message.error('无法录入')
        }
      })
    },
    submitBtn37 () {
      if (this.showEditLook.titleProper == undefined || this.showEditLook.titleProper == '') {
        this.$message.error('请填写印章名称')
      } else if (this.showEditLook.retentionPeriod == undefined || this.showEditLook.retentionPeriod == '') {
        this.$message.error('请选择保管期限')
      } else if (this.showEditLook.seriesCode == undefined || this.showEditLook.seriesCode == '') {
        this.$message.error('请填写分类号）')
      } else {
        saveMatterYzYjFile(this.showEditLook).then(res => {
          if (res.data.optFlag == 1) {
            this.$message.success('录入成功')
            // this.$message.success(res.message)
            this.getDataViewDialog37 = false
            this.showListBtom2()
          } else {
            this.$message.error('录入失败')
            // this.$message.error(res.message)
            this.getDataViewDialog37 = false
            this.showListBtom2()
          }
        })
      }
    },
    submitBtn39 () {
      if (this.showEditLook.titleProper == undefined || this.showEditLook.titleProper == '') {
        this.$message.error('请填写名称')
      } else if (this.showEditLook.dateOfCreation == undefined || this.showEditLook.dateOfCreation == '') {
        this.$message.error('请选择日期')
      } else if (this.showEditLook.seriesCode == undefined || this.showEditLook.seriesCode == '') {
        this.$message.error('请填写分类号）')
      } else {
        saveMatterQtYjFile(this.showEditLook).then(res => {
          if (res.data.optFlag == 1) {
            this.$message.success('录入成功')
            this.getDataViewDialog39 = false
            this.showListBtom2()
          } else {
            this.$message.error('录入失败')
            this.getDataViewDialog39 = false
            this.showListBtom2()
          }
        })
      }
    },
    // 编辑 回显
    showLookBtn38 () {
      let params = {}
      this.showEditLook = {
        caseNo: '',
        itemNo: '',
        titleProper: '',
        dateOfCreation: '',
        retentionPeriod: '',
        openingType: '',
        c164: '',
        c73: '',
        c66: '',
        c113: '',
        seriesCode: '',
        c8: '',
      }
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        getHandoverDatailDate({id: this.onceTableBtomTwo[0].id}).then(res => {
          this.getDataViewDialog38 = true
          params = res.data
          // 盒号
          this.showEditLook.caseNo = params.caseNo
          // 件号
          this.showEditLook.itemNo = params.handoverThNumber
          // 印章名称
          this.showEditLook.titleProper = params.title
          // 刻制日期
          this.showEditLook.dateOfCreation = params.fileDate
          // 保管期限
          this.showEditLook.retentionPeriod = params.gzhangLevel
          // 公开属性
          this.showEditLook.openingType = params.openingType
          // 印章种类
          this.showEditLook.c164 = params.fileType
          // 印章形状
          this.showEditLook.c73 = params.handoverHt
          // 印章状态
          this.showEditLook.c66 = params.sealStatus
          // 责任者
          this.showEditLook.c113 = params.handoverEmployer
          // 分类号
          this.showEditLook.seriesCode = params.seriesCode
          // 备注
          this.showEditLook.c8 = params.handoverNote
        })
      }
    },
    submitBtn38 () {
      if (this.showEditLook.titleProper == '') {
        this.$message.error('请填写印章名称')
      } else if (this.showEditLook.retentionPeriod == '') {
        this.$message.error('请选择保管期限')
      } else if (this.showEditLook.seriesCode == '') {
        this.$message.error('请选择分类号')
      } else {
        this.showEditLook.subId = this.onceTableBtomTwo[0].id
        editMatterYzYjFile(this.showEditLook).then(res => {
          console.log(res);
          if (res.data.optFlag == 1) {
            this.$message.success('编辑成功')
            this.getDataViewDialog38 = false
            this.showListBtom2()
          } else {
            this.$message.error('编辑失败')
            this.getDataViewDialog38 = false
            this.showListBtom2()
          }
        })
      }
    },
    // 编辑 回显
    showLookBtn40 () {
      let params = {}
      this.showEditLook = {
        itemNo: '',
        titleProper: '',
        dateOfCreation: '',
        c161: '',
        c15: '',
        c68: '',
        c113: '',
        seriesCode: '',
        c8: '',
      }
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        getHandoverDatailDate({id: this.onceTableBtomTwo[0].id}).then(res => {
          this.getDataViewDialog40 = true
          params = res.data
          this.showEditLook.itemNo = params.handoverThNumber
          this.showEditLook.titleProper = params.title
          this.showEditLook.dateOfCreation = params.fileDate
          this.showEditLook.c161 = params.handoverEmployer
          this.showEditLook.c15 = params.fileType
          this.showEditLook.c68 = params.belongDept
          this.showEditLook.c113 = params.author
          this.showEditLook.seriesCode = params.seriesCode
          this.showEditLook.c8 = params.handoverNote
        })
      }
    },
    submitBtn40 () {
      if (this.showEditLook.titleProper == '') {
        this.$message.error('请填写印章名称')
      } else if (this.showEditLook.retentionPeriod == '') {
        this.$message.error('请选择保管期限')
      } else if (this.showEditLook.seriesCode == '') {
        this.$message.error('请选择分类号')
      } else {
        this.showEditLook.subId = this.onceTableBtomTwo[0].id
        editMatterQtYjFile(this.showEditLook).then(res => {
          if (res.data.optFlag == 1) {
            this.$message.success('编辑成功')
            this.getDataViewDialog40 = false
            this.showListBtom2()
          } else {
            this.$message.error('编辑失败')
            this.getDataViewDialog40 = false
            this.showListBtom2()
          }
        })
      }
    },
    // 会计 录入
    showLookBtn41 () {
      this.showEditLook = {}
      this.getDataViewDialog42 = true
    },
    submitBtn42 () {
      let reg = /^[0-9]*$/
      if (this.showEditLook.c220 == undefined || this.showEditLook.c220 == '') {
        this.$message.error('请填写案卷号')
      } else if (!reg.test(this.showEditLook.c220)) {
        this.$message.error('请填写正确的案卷号')
      } else if (this.showEditLook.c15 == undefined || this.showEditLook.c15 == '') {
        this.$message.error('请填写类别')
      } else if (this.showEditLook.titleProper == undefined || this.showEditLook.titleProper == '') {
        this.$message.error('请填写卷(册、袋)标题')
      } else if (this.showEditLook.retentionPeriod == undefined || this.showEditLook.retentionPeriod == '') {
        this.$message.error('请选择保管期限')
      } else if (this.showEditLook.c160 == undefined || this.showEditLook.c160 == '') {
        this.$message.error('请填写凭证起号')
      } else if (this.showEditLook.c162 == undefined || this.showEditLook.c162 == '') {
        this.$message.error('请填写凭证止号')
      } else if (this.showEditLook.dateOfCreation == undefined || this.showEditLook.dateOfCreation == '') {
        this.$message.error('请填写起止日期')
      } else if (this.showEditLook.dateOfEnd == undefined || this.showEditLook.dateOfEnd == '') {
        this.$message.error('请填写起止日期')
      } else if (this.showEditLook.yearCode == undefined || this.showEditLook.yearCode.length < 4 || this.showEditLook.yearCode.length > 4) {
        this.$message.error('请填写年度(输入长度为4）')
      } else if (!reg.test(this.showEditLook.yearCode)) {
        this.$message.error('请填写正确的年度')
      } else if (this.showEditLook.c113 == undefined || this.showEditLook.c113 == '') {
        this.$message.error('请填写所属部门')
      } else if (this.showEditLook.c163 == undefined || this.showEditLook.c163 == '') {
        this.$message.error('请填写分类号')
      } else {
        this.showEditLook.subId = this.onceTable[0].gid
        saveAccountingYjFile(this.showEditLook).then(res => {
          if (res.data.optFlag == 1) {
            this.$message.success('录入成功')
            this.getDataViewDialog42 = false
            this.showListBtom2()
          } else {
            this.$message.error('录入失败')
            this.getDataViewDialog42 = false
            this.showListBtom2()
          }
        })
      }
    },
    submitBtn52 () {
      let reg = /^[0-9]*$/
      if (this.showEditLook.c220 == undefined || this.showEditLook.c220 == '') {
        this.$message.error('请填写案卷号')
      } else if (!reg.test(this.showEditLook.c220)) {
        this.$message.error('请填写正确的案卷号')
      } else if (this.showEditLook.c15 == undefined || this.showEditLook.c15 == '') {
        this.$message.error('请填写类别')
      } else if (this.showEditLook.titleProper == undefined || this.showEditLook.titleProper == '') {
        this.$message.error('请填写卷(册、袋)标题')
      } else if (this.showEditLook.retentionPeriod == undefined || this.showEditLook.retentionPeriod == '') {
        this.$message.error('请选择保管期限')
      } else if (this.showEditLook.c160 == undefined || this.showEditLook.c160 == '') {
        this.$message.error('请填写凭证起号')
      } else if (this.showEditLook.c162 == undefined || this.showEditLook.c162 == '') {
        this.$message.error('请填写凭证止号')
      } else if (this.showEditLook.dateOfCreation == undefined || this.showEditLook.dateOfCreation == '') {
        this.$message.error('请填写起止日期')
      } else if (this.showEditLook.dateOfEnd == undefined || this.showEditLook.dateOfEnd == '') {
        this.$message.error('请填写起止日期')
      } else if (this.showEditLook.yearCode == undefined || this.showEditLook.yearCode.length < 4 || this.showEditLook.yearCode.length > 4) {
        this.$message.error('请填写年度(输入长度为4）')
      } else if (!reg.test(this.showEditLook.yearCode)) {
        this.$message.error('请填写正确的年度')
      } else if (this.showEditLook.c113 == undefined || this.showEditLook.c113 == '') {
        this.$message.error('请填写所属部门')
      } else if (this.showEditLook.c163 == undefined || this.showEditLook.c163 == '') {
        this.$message.error('请填写分类号')
      } else {
        this.showEditLook.subId = this.showEditLookSubId
        this.showEditLook.bs = 'qjym'
        saveMhYjFile(this.showEditLook).then(res => {
          if (res.data.optFlag == 1) {
            this.$message.success('录入成功')
            this.getDataViewDialog522 = false
            this.showLookBtn44List()
          } else {
            this.$message.error('录入失败')
            this.getDataViewDialog522 = false
            this.showLookBtn44List()
          }
        })
      }
    },
    newChange (val) {
      this.paramsBatch.series = val
      this.$forceUpdate()
    },
    // 编辑 回显
    showLookBtn42 () {
      let params = {}
      this.showEditLook = {
        id: '',
        c220: '',
        c15: '',
        titleProper: '',
        retentionPeriod: '',
        c160: '',
        c162: '',
        dateOfCreation: '',
        dateOfEnd: '',
        yearCode: '',
        amountOfPages: '',
        c113: '',
        c163: '',
        c8: ''
      }
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        getHandoverDatailDate({id: this.onceTableBtomTwo[0].id}).then(res => {
          this.getDataViewDialog43 = true
          params = res.data
          // 案卷号
          this.showEditLook.c220 = params.serialNumber
          // 类别
          this.showEditLook.c15 = params.fileType
          // 卷(册、袋)标题
          this.showEditLook.titleProper = params.title
          // 保管期限
          this.showEditLook.retentionPeriod = params.gzhangLevel
          // 凭证起号
          this.showEditLook.c160 = params.handoverHt
          // 凭证止号
          this.showEditLook.c162 = params.handoverPc
          // 起止日期：开始日期
          this.showEditLook.dateOfCreation = params.startDate
          // 起止日期：结束日期
          this.showEditLook.dateOfEnd = params.endDate
          // 年度
          this.showEditLook.yearCode = params.fileDate
          // 卷内张数
          this.showEditLook.amountOfPages = params.fileNum == null || params.fileNum == 'null' ? '' : params.fileNum
          // 所属部门
          this.showEditLook.c113 = params.handoverEmployer
          // 分类号
          this.showEditLook.c163 = params.fileCode
          // 分类号
          // this.showEditLook.seriesCode = params.seriesCode
          // 备注
          this.showEditLook.c8 = params.handoverNote
        })
      }
    },
    submitBtn43 () {
      let reg = /^[0-9]*$/
      if (this.showEditLook.c220 == undefined || this.showEditLook.c220 == '') {
        this.$message.error('请填写案卷号')
      } else if (!reg.test(this.showEditLook.c220)) {
        this.$message.error('请填写正确的案卷号')
      } else if (this.showEditLook.c15 == undefined || this.showEditLook.c15 == '') {
        this.$message.error('请填写类别')
      } else if (this.showEditLook.titleProper == undefined || this.showEditLook.titleProper == '') {
        this.$message.error('请填写卷(册、袋)标题')
      } else if (this.showEditLook.retentionPeriod == undefined || this.showEditLook.retentionPeriod == '') {
        this.$message.error('请选择保管期限')
      } else if (this.showEditLook.c160 == undefined || this.showEditLook.c160 == '') {
        this.$message.error('请填写凭证起号')
      } else if (this.showEditLook.c162 == undefined || this.showEditLook.c162 == '') {
        this.$message.error('请填写凭证止号')
      } else if (this.showEditLook.dateOfCreation == undefined || this.showEditLook.dateOfCreation == '') {
        this.$message.error('请填写起止日期')
      } else if (this.showEditLook.dateOfEnd == undefined || this.showEditLook.dateOfEnd == '') {
        this.$message.error('请填写起止日期')
      } else if (this.showEditLook.yearCode == undefined || this.showEditLook.yearCode.length < 4 || this.showEditLook.yearCode.length > 4) {
        this.$message.error('请填写年度(输入长度为4）')
      } else if (!reg.test(this.showEditLook.yearCode)) {
        this.$message.error('请填写正确的年度')
      } else if (!reg.test(this.showEditLook.amountOfPages)) {
        this.$message.error('请填写正确的卷内张数')
      } else if (this.showEditLook.c113 == undefined || this.showEditLook.c113 == '') {
        this.$message.error('请填写所属部门')
      } else if (this.showEditLook.c163 == undefined || this.showEditLook.c163 == '') {
        this.$message.error('请填写分类号')
      } else {
        this.showEditLook.subId = this.onceTableBtomTwo[0].id
        editAccountingYjFile(this.showEditLook).then(res => {
          if (res.data.optFlag == 1) {
            this.$message.success('编辑成功')
            this.getDataViewDialog43 = false
            this.showListBtom2()
          } else {
            this.$message.error('编辑失败')
            this.getDataViewDialog43 = false
            this.showListBtom2()
          }
        })
      }
    },

    // 声像--录入
    showLookBtn45 () {
      this.showEditLook = {}
      this.getDataViewDialog45 = true
    },
    submitBtn45 () {
      let reg = /^[0-9]*$/
      if (this.showEditLook.titleProper == undefined || this.showEditLook.titleProper == '') {
        this.$message.error('请填写题名')
      } else if (this.showEditLook.c69 == undefined || this.showEditLook.c69 == '') {
        this.$message.error('请填写主题')
      } else if (this.showEditLook.takePhotoPlace == undefined || this.showEditLook.takePhotoPlace == '') {
        this.$message.error('请填写地点')
      } else {
        this.showEditLook.subId = this.onceTable[0].gid
        saveSxMhYjFile(this.showEditLook).then(res => {
          if (res.data.optFlag == 1) {
            this.$message.success('录入成功')
            this.getDataViewDialog45 = false
            this.showListBtom2()
          } else {
            this.$message.error('录入失败')
            this.getDataViewDialog45 = false
            this.showListBtom2()
          }
        })
      }
    },
    yiChangDisChange () {
      if (this.thZqDate.oneData == '原件丢失或损毁') {
        this.yiChangDisOne = false
        this.yiChangDisTwo = false
        this.yiChangDisThree = true
        this.yiChangDisFour = true
        this.yiChangDisFive = true
        this.yiChangDisSix = true
        this.yiChangDisSevem = true
        this.yiChangDisEight = true
      } else if (this.thZqDate.twoData == '无原件且无复印件') {
        this.yiChangDisOne = false
        this.yiChangDisTwo = false
        this.yiChangDisThree = true
        this.yiChangDisFour = true
        this.yiChangDisFive = true
        this.yiChangDisSix = true
        this.yiChangDisSevem = true
        this.yiChangDisEight = true
      } else {
        this.yiChangDisOne = false
        this.yiChangDisTwo = false
        this.yiChangDisThree = false
        this.yiChangDisFour = false
        this.yiChangDisFive = false
        this.yiChangDisSix = false
        this.yiChangDisSevem = false
        this.yiChangDisEight = false
      }
    },
    yiChangDisChangeTwo () {
      if (this.thZqDate.threeData == '原件不完整（对方未盖章）') {
        this.yiChangDisOne = true
        this.yiChangDisTwo = true
        this.yiChangDisThree = false
        this.yiChangDisFour = false
        this.yiChangDisFive = false
        this.yiChangDisSix = false
        this.yiChangDisSevem = false
        this.yiChangDisEight = false
      } else if (this.thZqDate.fourData == '原件不完整（无签署时间）') {
        this.yiChangDisOne = true
        this.yiChangDisTwo = true
        this.yiChangDisThree = false
        this.yiChangDisFour = false
        this.yiChangDisFive = false
        this.yiChangDisSix = false
        this.yiChangDisSevem = false
        this.yiChangDisEight = false
      } else if (this.thZqDate.fiveData == '无原件有复印件') {
        this.yiChangDisOne = true
        this.yiChangDisTwo = true
        this.yiChangDisThree = false
        this.yiChangDisFour = false
        this.yiChangDisFive = false
        this.yiChangDisSix = false
        this.yiChangDisSevem = false
        this.yiChangDisEight = false
      } else if (this.thZqDate.sixData == '原件不完整（对方未签名）') {
        this.yiChangDisOne = true
        this.yiChangDisTwo = true
        this.yiChangDisThree = false
        this.yiChangDisFour = false
        this.yiChangDisFive = false
        this.yiChangDisSix = false
        this.yiChangDisSevem = false
        this.yiChangDisEight = false
      } else if (this.thZqDate.seveData == '原件不完整（缺失部分页）') {
        this.yiChangDisOne = true
        this.yiChangDisTwo = true
        this.yiChangDisThree = false
        this.yiChangDisFour = false
        this.yiChangDisFive = false
        this.yiChangDisSix = false
        this.yiChangDisSevem = false
        this.yiChangDisEight = false
      } else if (this.thZqDate.eightData == '合同（已盖章）作废') {
        this.yiChangDisOne = true
        this.yiChangDisTwo = true
        this.yiChangDisThree = false
        this.yiChangDisFour = false
        this.yiChangDisFive = false
        this.yiChangDisSix = false
        this.yiChangDisSevem = false
        this.yiChangDisEight = false
      } else {
        this.yiChangDisOne = false
        this.yiChangDisTwo = false
        this.yiChangDisThree = false
        this.yiChangDisFour = false
        this.yiChangDisFive = false
        this.yiChangDisSix = false
        this.yiChangDisSevem = false
        this.yiChangDisEight = false
      }
    },

    // 编辑 回显
    showLookBtn46 () {
      let params = {}
      this.showEditLook = {
        itemNo: '',
        titleProper: '',
        c69: '',
        takePhotoDate: '',
        takePhotoPlace: '',
        c64: '',
        c65: '',
        takePhotoPerson: '',
        c68: '',
        seriesCode: '',
        c8: ''
      }
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        getHandoverDatailDate({id: this.onceTableBtomTwo[0].id}).then(res => {
          this.getDataViewDialog46 = true
          params = res.data
          // 件号
          this.showEditLook.itemNo = params.handoverThNumber
          // 题名
          this.showEditLook.titleProper = params.title
          // 主题
          this.showEditLook.c69 = params.theme
          // 拍摄时间
          this.showEditLook.takePhotoDate = params.fileDate
          // 地点
          this.showEditLook.takePhotoPlace = params.site
          // 背景
          this.showEditLook.c64 = params.background
          // 人物(职务)
          this.showEditLook.c65 = params.personage
          // 摄(录)者
          this.showEditLook.takePhotoPerson = params.photographer
          // 所属部门
          this.showEditLook.c68 = params.belongDept
          // 分类号
          this.showEditLook.seriesCode = params.seriesCode
          // 备注
          this.showEditLook.c8 = params.handoverNote
        })
      }
    },
    submitBtn46 () {
      let reg = /^[0-9]*$/
      if (this.showEditLook.titleProper == undefined || this.showEditLook.titleProper == '') {
        this.$message.error('请填写题名')
      } else if (this.showEditLook.c69 == undefined || this.showEditLook.c69 == '') {
        this.$message.error('请填写主题')
      } else if (this.showEditLook.takePhotoPlace == undefined || this.showEditLook.takePhotoPlace == '') {
        this.$message.error('请填写地点')
      } else if (this.showEditLook.seriesCode == undefined || this.showEditLook.seriesCode == '') {
        this.$message.error('请填写分类号')
      } else {
        this.showEditLook.subId = this.onceTableBtomTwo[0].id
        editAcousticImageYjFile(this.showEditLook).then(res => {
          if (res.data.optFlag == 1) {
            this.$message.success('编辑成功')
            this.getDataViewDialog46 = false
            this.showListBtom2()
          } else {
            this.$message.error('编辑失败')
            this.getDataViewDialog46 = false
            this.showListBtom2()
          }
        })
      }
    },
    daoRuExcel () {
      this.getDataViewDialog9 = true
      this.clearImgDel()
    },
    // 导入excel表 错误信息
    submitBtn48 () {
      // valueIndex().exportFiles(`/${exportError}`, {excelId: this.errorMsg}, '错误信息模板.xls', 'get')
      valueIndex().exportFiles(`/gdda-new/gdda/archiveZL/exportError`, {excelId: this.errorMsg}, '错误信息模板.xls', 'get')
      this.getDataViewDialog48 = false
      this.getDataViewDialog9 = false
    },

    submitBtn533 () {
      if (this.showEditLook.titleProper == undefined || this.showEditLook.titleProper == '') {
        this.$message.error('请填写印章名称')
      } else if (this.showEditLook.retentionPeriod == undefined || this.showEditLook.retentionPeriod == '') {
        this.$message.error('请选择保管期限')
      } else if (this.showEditLook.seriesCode == undefined || this.showEditLook.seriesCode == '') {
        this.$message.error('请填写分类号）')
      } else {
        this.showEditLook.subId = this.showEditLookSubId
        this.showEditLook.bs = 'qjym'
        saveMatterYzYjFile(this.showEditLook).then(res => {
          if (res.data.optFlag == 1) {
            this.$message.success('录入成功')
            // this.$message.success(res.message)
            this.getDataViewDialog533 = false
            this.showLookBtn44List()
          } else {
            this.$message.error('录入失败')
            // this.$message.error(res.message)
            this.getDataViewDialog533 = false
            this.showLookBtn44List()
          }
        })
      }
    },
    submitBtn544 () {
      if (this.showEditLook.titleProper == undefined || this.showEditLook.titleProper == '') {
        this.$message.error('请填写名称')
      } else if (this.showEditLook.dateOfCreation == undefined || this.showEditLook.dateOfCreation == '') {
        this.$message.error('请选择日期')
      } else if (this.showEditLook.seriesCode == undefined || this.showEditLook.seriesCode == '') {
        this.$message.error('请填写分类号')
      } else if (this.showEditLook.c161 == undefined || this.showEditLook.c161 == '') {
        this.$message.error('请填写对方单位')
      } else {
        this.showEditLook.subId = this.showEditLookSubId
        this.showEditLook.bs = 'qjym'
        saveMatterQtYjFile(this.showEditLook).then(res => {
          if (res.data.optFlag == 1) {
            this.$message.success('录入成功')
            this.getDataViewDialog544 = false
            this.showLookBtn44List()
          } else {
            this.$message.error('录入失败')
            this.getDataViewDialog544 = false
            this.showLookBtn44List()
          }
        })
      }
    },
    submitBtn555 () {
      let reg = /^[0-9]*$/
      if (this.showEditLook.titleProper == undefined || this.showEditLook.titleProper == '') {
        this.$message.error('请填写题名')
      } else if (this.showEditLook.c69 == undefined || this.showEditLook.c69 == '') {
        this.$message.error('请填写主题')
      } else if (this.showEditLook.takePhotoPlace == undefined || this.showEditLook.takePhotoPlace == '') {
        this.$message.error('请填写地点')
      } else {
        this.showEditLook.subId = this.showEditLookSubId
        this.showEditLook.bs = 'qjym'
        saveSxMhYjFile(this.showEditLook).then(res => {
          if (res.data.optFlag == 1) {
            this.$message.success('录入成功')
            this.getDataViewDialog555 = false
            this.showLookBtn44List()
          } else {
            this.$message.error('录入失败')
            this.getDataViewDialog555 = false
            this.showLookBtn44List()
          }
        })
      }
    },
    handleCurrentChangeTwo2 (val) {
      // this.dialogTableBtomTwo = []
      this.paramsTwo1.page = val
      // this.paramsTwo1.total = 0
      this.paramsTwo1.subId = this.onceTable[0].gid
      listHandOverDetailData(this.paramsTwo1).then(res => {
        this.dialogTableBtomTwo = res.data.rows
        this.paramsTwo1.total = res.data.total
        // this.$forceUpdate()
      })
    }
  },
  created () {
    this.showSearchData()
    this.showList()
    listAllDept().then(res => {
      this.yjc90Arr = res.data
    })
    listFileType().then(res => {
      this.fileTypeArr = res.data
    })
    listGzdj().then(res => {
      this.yjc112Arr = res.data
    })
  }
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  .dialogAddList{
    width:49%;
    float: left;
    margin-right: 10px;
    overflow-x: auto;
  }
  .editorXinTwo {
    margin-bottom: 6px;
    label{
      display: inline-block;
      width: 108px;
      text-align: right;
    }
    .el-input, .el-select{
      width: 70%;
    }
  }
  .downloadBtn{
    width: 95%;
    /*margin-top: 16px;*/
    color: #4A90E2;
    text-align: right;
    span{
      cursor: pointer;
    }
  }
  .showClearLook{
    height: 600px;
    overflow: auto;
  }
  .search-select {
    float: left;
    margin: 4px 0;
    vertical-align: middle;
    line-height: 40px;
    margin: 0 8px;
    label {
      font-size: 14px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 143px;
    }
  }
  .searchBtn{
    float: left;
    line-height: 47px;
    font-size: 13px;
    cursor: pointer;
    margin: 0 8px;
    img{
      vertical-align: middle;
      margin-right: 4px;
    }
  }
  .search-selectOnce{
    margin: 5px 6px;
    height: 35px;
    border:1px solid #DEDEDE;
    cursor: auto;
  }

  .mangeShow{
    margin-bottom: 10px;
    li{
      float: left;
      width: 350px;
      .el-input, .el-select{
        width: 62%;
      }
      label{
        display: inline-block;
        width: 96px;
        text-align: right;
      }
      /deep/.el-input.is-disabled .el-input__inner{
        background-color: #fff!important;
        color: #606266!important;
      }
    }
  }
  .mangeShowList{
    margin-bottom: 10px;
    >p{
      width: 99px;
      text-align: right;
    }
    >label{
      display: inline-block;
      width: 99px;
      text-align: right;
      vertical-align: top;
    }
    .heTong {
      display: inline-block;
      width: 86%;
      color: red;
    }
    .el-textarea{
      width: 86%;
    }
  }
  .showReadOnlyContent {
    width: 82%;
    margin: 0 auto;
    border: 1px solid #E4E7ED;
    min-height: 200px;
    padding: 6px;
    max-height: 200px;
    overflow: auto;
  }
  .maxHeight{
    max-height: 300px;
    overflow: auto;
  }
  .mangeShowLook{
    margin-bottom: 10px;
    li{
      float: left;
      /*width: 268px;*/
      width: 33%;
      .el-input, .el-select{
        width: 56%;
      }
      label{
        display: inline-block;
        width: 110px;
        text-align: right;
      }
      /deep/.el-input.is-disabled .el-input__inner{
        background-color: #fff!important;
        color: #606266!important;
      }
    }
  }
  .anomalyError{
    width: 993px;
    border: 1px solid;
    >div{
      float:left;
      border:1px solid;
      height: 40px;
      line-height: 40px;
    }
    .anomalyErrorOne{
      width: 182px;
      text-align: left;
    }
    .anomalyErrorTwo{
      text-indent: 2px;
      width: 333px;
      /deep/.el-checkbox__label{
        padding-top: 2px;
        font-size: 16px;
      }
    }
    .anomalyErrorThree{
      width: 235px;
      text-indent: 2px;
      /deep/.el-checkbox__label{
        padding-top: 2px;
        font-size: 16px;
      }
    }
  }
  .ErrorCenter{
    /*text-align: center;*/
    text-align: left;
  }
  .anomalyErrorOnceTwo{
    width: 993px;
    font-size: 20px;
    border: 1px solid;
    >div{
      float:left;
      border:1px solid;
      height: 40px;
    }
    .anomalyErrorOne{
      width: 182px;
      height: 205px;
      line-height: 205px;
      text-align: left;
    }
    .anomalyErrorTwo{
      float: left;
      width: 333px;
      height: 100%;
      text-indent: 2px;
      line-height: 40px;
      border: 1px solid;
      /deep/.el-checkbox__label{
        padding-top: 2px;
        font-size: 16px;
      }
    }
    .anomalyErrorThree{
      float: left;
      width: 234px;
      height: 100%;
      text-indent: 2px;
      line-height: 40px;
      border: 1px solid;
      /deep/.el-checkbox__label{
        padding-top: 2px;
        font-size: 16px;
      }
    }
    .anomalyErrorOnceThree{
      width: 333px;
      height: 39px;
      text-indent: 2px;
      line-height: 40px;
      border: 1px solid;
      /deep/.el-checkbox__label{
        padding-top: 2px;
        font-size: 16px;
      }
    }
    .anomalyErrorOnceFour{
      width: 182px;
      height: 204px;
      line-height: 204px;
      text-align: left;
    }
    .pickerSelect{
      width: 190px;
      /deep/.el-input__inner{
        height: 28px;
      }
    }
  }
  .showContentDownload{
    width: 993px;
    margin-top: 10px;
    font-size: 16px;
    span{
      color: #01ABE7;
      cursor: pointer;
    }
  }
  .clientAdd{
    /deep/.el-input__inner{
      height: 30px;
      width: 88%;
    }
  }
</style>
<style lang="less">
  .elTabsCssMange{
    >.el-tabs__header{
      .el-tabs__item{
        width: 150px;
        margin: 0;
        border-radius: 10px 10px 0 0;
        background-color: #EEF2F7;
        border: 1px solid #EEF2F7;
        text-align: center;
      }
      .el-tabs__item.is-active{
        color: #454545;
        background-color: #fff;
      }
    }
  }
</style>
<style scoped lang="less">
  .addTableList{
    /deep/.el-table__body-wrapper {
      max-height: 456px;
      overflow: auto;
    }
  }
  .zqCheck{
    width: 80%;
    display: inline-block;
    /deep/.el-checkbox__label{
      font-size: 16px;
      margin-bottom: 10px;
    }
  }
</style>
