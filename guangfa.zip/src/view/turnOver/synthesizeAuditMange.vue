<!-- 综合员审核 -->
<template>
  <div class="" style="background-color: #fff">
    <!-- 搜索 -->
    <div style="padding: 10px 0;">
      <!--<div class="search-select search-selectOnce"></div>-->
      <div class="search-select">
        <label>全宗：</label>
        <el-select v-model="params.fonds" filterable placeholder="请选择" @change="yjTypeBtn">
          <el-option
            v-for="item in fullZong"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
      </div>
      <!--<div class="search-select search-selectOnce"></div>-->
      <div class="search-select">
        <label>档案类型：</label>
        <el-select v-model="params.series1" filterable placeholder="请选择" @change="searchSeries">
          <el-option
            v-for="item in FondsAndRole"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
        <el-select v-model="params.series2" filterable placeholder="请选择" @change="searchSeriesTwo">
          <el-option
            v-for="item in FondsAndRoleTwo"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
        <el-select v-model="params.series3" filterable placeholder="请选择" @change="searchSeriesThree">
          <el-option
            v-for="item in FondsAndRoleThree"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
      </div>
      <!--<div class="search-select search-selectOnce"></div>-->
      <div class="search-select">
        <label>移交类型：</label>
        <el-select v-model="params.yjType" filterable placeholder="请选择" @change="yjTypeBtnTwo">
          <el-option
            v-for="item in handoverTypeModel"
            :key="item.itemValue"
            :label="item.name"
            :value="item.itemValue">
          </el-option>
        </el-select>
      </div>
      <div class="clear"></div>
    </div>
    <!-- 上操作 -->
    <!--<div style="background-color: #F4F4F4;">-->
    <div>
      <div class="searchBtn" @click="tureOverBtn">
        <img src="../../assets/turnOver/yj.png" alt="">
        <!--<img src="../../assets/turnOver/sh.png" alt="">-->
        <span>综合员审核</span>
      </div>
      <div class="searchBtn" @click="searchContent">
        <img src="../../assets/turnOver/js.png" alt="">
        <span>检索</span>
      </div>
      <div class="searchBtn" @click="retryBtn">
        <img src="../../assets/turnOver/cf.png" alt="">
        <span>重发移交确认代办</span>
      </div>
      <div v-if="params.series1 == 1379482316593" class="searchBtn" @click="getDataViewDialog27 = true, paramsDownload = {}">
        <img src="../../assets/turnOver/dr.png" alt="">
        <span>导出合同移交登记表</span>
      </div>
      <!-- 没有功能，放这 -->
      <!--<div v-if="params.series1 == 1379482316593" class="searchBtn">-->
        <!--<span>扫一扫</span>-->
      <!--</div>-->
      <div class="clear"></div>
    </div>
    <!-- 上表格 -->
    <div class="all-Table">
      <el-table
        ref="multipleTable"
        :data="tableData"
        stripe
        border
        @selection-change="handleSelectionChange">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="status"
          label="移交状态"
          width="160">
          <template slot-scope="scope">
            <span v-if="scope.row.status == 1">欠交</span>
            <span v-else-if="scope.row.status == 2">综合员审核</span>
            <span v-else-if="scope.row.status == 3">领导审核</span>
            <span v-else-if="scope.row.status == 4">档案员审核</span>
            <span v-else-if="scope.row.status == 5">已移交</span>
            <span v-else-if="scope.row.status == 6">不移交</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="serialNumber"
          label="移交单号"
          width="250">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverUser"
          label="移交人姓名"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverDept"
          label="移交部门"
          width="320">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverType"
          label="移交方式"
          width="160">
          <template slot-scope="scope">
            <span v-if="scope.row.handoverType == 1">邮寄</span>
            <!--<span v-else-if="scope.row.handoverType == 2">本人亲自移交</span>-->
            <span v-else>面交</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverYdh"
          label="运单号"
          width="179">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverDate"
          label="移交时间"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="tagName"
          label="档案类型"
          width="200">
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <div class="pageLayout">
      <el-pagination
        @current-change="handleCurrentChange"
        :current-page="params.page"
        :page-size="params.rows"
        layout="prev, pager, next, jumper"
        :total="params.total">
      </el-pagination>
    </div>

    <!-- 下操作 -->
    <div>
      <div class="searchBtn" @click="showLookBtn">
        <img src="../../assets/turnOver/ck.png" alt="">
        <span>查看</span>
      </div>
      <div class="clear"></div>
    </div>
    <!-- 下表格 -->
    <div v-if="params.series1 == 1388742017269" class="all-Table">
      <el-table
        ref="multipleTableBtomTwo"
        :data="tableDataTwo"
        stripe
        border
        @selection-change="handleSelectionChangeBtom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="archivalCode"
          label="档号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverEmployer"
          label="所属部门"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="serialNumber"
          label="案卷号"
          width="230">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileType"
          label="类别"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="卷（册、袋）标题"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="startDate"
          label="起始时间"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="endDate"
          label="终止时间"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverHt"
          label="凭证起始号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="gzhangLevel"
          label="保管期限"
          width="160">
          <template slot-scope="scope">
            <span v-if="scope.row.gzhangLevel == 3">永久</span>
            <span v-else-if="scope.row.gzhangLevel == 2">长期</span>
            <span v-else-if="scope.row.gzhangLevel == 1">短期</span>
            <span v-else-if="scope.row.gzhangLevel == 5">10年</span>
            <span v-else-if="scope.row.gzhangLevel == 6">15年</span>
            <span v-else-if="scope.row.gzhangLevel == 8">30年</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileNum"
          label="卷内张数"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverNote"
          label="备考"
          width="160">
        </el-table-column>
      </el-table>
    </div>
    <div v-else-if="params.series2 == 1374133285844" class="all-Table">
      <el-table
        ref="multipleTableBtomTwo"
        :data="tableDataTwo"
        stripe
        border
        @selection-change="handleSelectionChangeBtom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="caseNo"
          label="盒号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverThNumber"
          label="件号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverPc"
          label="刻制年度"
          width="230">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          label="刻制日期"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverEmployer"
          label="责任者"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop=""
          width="1">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="gzhangLevel"
          label="保管期限"
          width="160">
          <template slot-scope="scope">
            <span v-if="scope.row.gzhangLevel == 1">短期</span>
            <span v-else-if="scope.row.gzhangLevel == 2">长期</span>
            <span v-else-if="scope.row.gzhangLevel == 3">永久</span>
            <span v-else-if="scope.row.gzhangLevel == 5">10年</span>
            <span v-else-if="scope.row.gzhangLevel == 6">15年</span>
            <span v-else-if="scope.row.gzhangLevel == 8">30年</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileType"
          label="印章种类"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverHt"
          label="印章形状"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="sealStatus"
          label="印章状态"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverNote"
          label="备注"
          width="160">
        </el-table-column>
      </el-table>
    </div>
    <div v-else-if="params.series2 == 1374133285845 || params.series2 == 1374133285846 || params.series2 == 1374133285847
          || params.series2 == 1374133285848 || params.series2 == 1374133285849" class="all-Table">
      <el-table
        ref="multipleTableBtomTwo"
        :data="tableDataTwo"
        stripe
        border
        @selection-change="handleSelectionChangeBtom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverThNumber"
          label="件号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverPc"
          label="年度"
          width="230">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="名称"
          width="200">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          label="获奖日期"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverEmployer"
          label="对方单位"
          width="200">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileType"
          label="类别"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverNote"
          label="备注"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="belongDept"
          label="所属部门"
          width="200">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="author"
          label="责任者"
          width="160">
        </el-table-column>
      </el-table>
    </div>
    <div v-else-if="params.series1 == 1374133285828" class="all-Table">
      <el-table
        ref="multipleTableBtomTwo"
        :data="tableDataTwo"
        stripe
        border
        @selection-change="handleSelectionChangeBtom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverThNumber"
          label="件号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="题名"
          width="230">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="theme"
          label="主题"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          label="拍摄时间"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="site"
          label="地点"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="background"
          label="背景"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="personage"
          label="人物(职务)"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="photographer"
          label="摄(录)者"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="belongDept"
          label="所属部门"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverNote"
          label="内容简介"
          width="160">
        </el-table-column>
      </el-table>
    </div>
    <div v-else class="all-Table">
      <el-table
        ref="multipleTableBtom"
        :data="tableDataTwo"
        stripe
        border
        @selection-change="handleSelectionChangeBtom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileCode"
          label="文件号"
          width="220">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverHt"
          label="合同号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="文件标题"
          width="250">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverEmployer"
          label="对方单位"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          label="文件日期"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileType"
          label="文件类型"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="isOriginal"
          label="是否原件"
          width="140">
          <template slot-scope="scope">
            <span v-if="scope.row.isOriginal == 0">是</span>
            <span v-else-if="scope.row.isOriginal == 1">否</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="gzhangLevel"
          label="公章等级"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverException"
          label="移交异常"
          width="179">
        </el-table-column>
      </el-table>
    </div>
    <!-- 下分页 -->
    <div class="pageLayout">
      <el-pagination
        @current-change="handleCurrentChangeTwo"
        :current-page="paramsTwo.page"
        :page-size="paramsTwo.rows"
        layout="prev, pager, next, jumper"
        :total="paramsTwo.total">
      </el-pagination>
    </div>
    <!-- 查看弹框 -->
    <el-dialog :visible.sync="dialogShowLook" width="1314px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">查看材料</div>
      <div class="showClearLook">
        <div class="bigDog menuShrink black-tree" style="float: left;height: 100%;min-height: unset;max-height: unset;">
          <el-tree
            :data="treTable"
            :props="defaultProps"
            :check-strictly="true"
            :default-expand-all="true"
            :expand-on-click-node="false"
            :highlight-current="true"
            accordion
            @node-click="handleNodeClick">
          </el-tree>
        </div>
        <div style="float: left;margin-left: 10px;width: 80%; max-height: 600px; overflow: auto;">
          <el-tabs v-model="activeName" class="elTabsCssMange"  type="card" @tab-click="resetTable">
            <!-- 广发上市 -->
            <el-tab-pane label="基本信息" name="contentOnce">
              <div v-if="showCheckEmbed">
                <!--件号，问号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>件号：</label>
                    <el-input v-model="showEditLook.itemNo" readonly></el-input>
                  </li>
                  <li>
                    <label>文号：</label>
                    <el-input v-model="showEditLook.fileCode" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--题名-->
                <ul class="mangeShowLook">
                  <li style="width: 100%;">
                    <label>题名：</label>
                    <el-input v-model="showEditLook.titleProper" readonly style="width: 84.5%;"></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--保管期限，公开属性，文件盒号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>保管期限：</label>
                    <el-input v-model="showEditLook.retentionPeriod" readonly></el-input>
                  </li>
                  <li>
                    <label>公开属性：</label>
                    <el-input v-model="showEditLook.openingType" readonly></el-input>
                  </li>
                  <li>
                    <label>文件盒号：</label>
                    <el-input v-model="showEditLook.caseNo" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--文件日期，年度，页数-->
                <ul class="mangeShowLook">
                  <li>
                    <label>文件日期：</label>
                    <el-input v-model="showEditLook.dateOfCreation" readonly></el-input>
                  </li>
                  <li>
                    <label>年度：</label>
                    <el-input v-model="showEditLook.yearCode" readonly></el-input>
                  </li>
                  <li>
                    <label>页数：</label>
                    <el-input v-model="showEditLook.amountOfPages" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--档号，责任者，分类号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>档号：</label>
                    <el-input v-model="showEditLook.officeArchivalCode" readonly></el-input>
                  </li>
                  <li>
                    <label>责任者：</label>
                    <el-input v-model="showEditLook.c113" readonly></el-input>
                  </li>
                  <li>
                    <label>分类号：</label>
                    <el-input v-model="showEditLook.seriesCode" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--是否为原件，是否在库，可见性-->
                <ul class="mangeShowLook">
                  <li>
                    <label>是否为原件：</label>
                    <el-input v-model="showEditLook.c58" readonly></el-input>
                  </li>
                  <li>
                    <label>是否在库：</label>
                    <el-input v-model="showEditLook.c59" readonly></el-input>
                  </li>
                  <li>
                    <label>可见性：</label>
                    <el-input v-model="showEditLook.c93" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档人，归档部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档人：</label>
                    <el-input v-model="showEditLook.filingUser" readonly></el-input>
                  </li>
                  <li>
                    <label>归档部门：</label>
                    <el-input v-model="showEditLook.filingDept" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--备注-->
                <ul class="mangeShowLook">
                  <li>
                    <label>备注：</label>
                    <el-input v-model="showEditLook.c8" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--部门，全宗，合同号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>部门：</label>
                    <el-input v-model="showEditLook.c98" readonly></el-input>
                  </li>
                  <li>
                    <label>全宗：</label>
                    <el-input v-model="showEditLook.fondsCode" readonly></el-input>
                  </li>
                  <li>
                    <label>合同号：</label>
                    <el-input v-model="showEditLook.c117" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档日期，来文系统，文件类型-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档日期：</label>
                    <el-input v-model="showEditLook.filingDate" readonly></el-input>
                  </li>
                  <li>
                    <label>来文系统：</label>
                    <el-input v-model="showEditLook.c92" readonly></el-input>
                  </li>
                  <li>
                    <label>文件类型：</label>
                    <el-input v-model="showEditLook.c100" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--公章等级，拟稿人，拟稿部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>公章等级：</label>
                    <el-input v-model="showEditLook.c112" readonly></el-input>
                  </li>
                  <li>
                    <label>拟稿人：</label>
                    <el-input v-model="showEditLook.c89" readonly></el-input>
                  </li>
                  <li>
                    <label>拟稿部门：</label>
                    <el-input v-model="showEditLook.c90" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
              </div>
              <div v-else>
                <embed :src="embedOnce" type="application/pdf" width="100%" height="600px"/>
              </div>
            </el-tab-pane>
            <el-tab-pane label="关联档案" name="contentTwoce" v-if="showView == 1">
              <div style="margin: 6px;">关联目录：</div>
              <ul class="mangeShowLook" v-for="(item, index) in paramsView.tlist" :key="item.id">
                <li style="width: 25%;">
                  <label style="width: 102px;">{{index + 1}}、档案题名：</label>
                  <el-input v-model="item.titleProper" readonly style="width: 57%"></el-input>
                </li>
                <li style="width: 25%;">
                  <label style="width: 102px;">责任者：</label>
                  <el-input v-model="item.c113" readonly style="width: 57%"></el-input>
                </li>
                <li style="width: 25%;">
                  <label style="width: 102px;">拟稿人：</label>
                  <el-input v-model="item.c89" readonly style="width: 57%"></el-input>
                </li>
                <li style="width: 25%;">
                  <label style="width: 102px;">合同号：</label>
                  <el-input v-model="item.c117" readonly style="width: 57%"></el-input>
                </li>
                <li style="width: 25%;margin-top:4px;">
                  <label style="width: 102px;">档案链接：</label>
                  <span style="color: #409eff;cursor: pointer;" @click="lookFileContent('f', item)">点击查看</span>
                </li>
                <div class="clear"></div>
              </ul>
              <div style="margin: 6px;">关联案卷：</div>
              <ul class="mangeShowLook" v-for="(item, index) in paramsView.tflist" :key="item.id">
                <li style="width: 25%;">
                  <label style="width: 102px;">{{index + 1}}、档案题名：</label>
                  <el-input v-model="item.titleProper" readonly style="width: 57%"></el-input>
                </li>
                <div class="clear"></div>
                <li style="width: 25%; margin-top:4px;">
                  <label style="width: 102px;">档案链接：</label>
                  <span style="color: #409eff;cursor: pointer;" @click="lookFileContent('v', item)">点击查看</span>
                </li>
                <div class="clear"></div>
              </ul>
              <div style="margin: 6px;">关联项目：</div>
              <ul class="mangeShowLook">
                <li style="width: 25%;">
                  <label style="width: 102px;">档案题名：</label>
                  <el-input v-model="paramsView.project.titleProper" readonly style="width: 57%"></el-input>
                </li>
                <div class="clear"></div>
                <li style="width: 25%; margin-top:4px;">
                  <label style="width: 102px;">档案链接：</label>
                  <span style="color: #409eff;cursor: pointer;" @click="lookFileContent('p', paramsView.project)">点击查看</span>
                </li>
                <div class="clear"></div>
              </ul>
            </el-tab-pane>
          </el-tabs>
        </div>
        <div class="clear"></div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button @click="dialogShowLook = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 查看弹框--第二级查看资料弹框 -->
    <el-dialog :visible.sync="dialogShowLookTwo" width="1314px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">查看材料</div>
      <div class="showClearLook">
        <div class="bigDog menuShrink black-tree" style="float: left;height: 100%;min-height: unset;max-height: unset;">
          <el-tree
            :data="treTableTwo"
            :props="defaultProps"
            :check-strictly="true"
            :default-expand-all="true"
            :expand-on-click-node="false"
            :highlight-current="true"
            accordion
            @node-click="handleNodeClickTwo">
          </el-tree>
        </div>
        <div style="float: left;margin-left: 10px;width: 80%; max-height: 600px; overflow: auto;">
          <el-tabs v-model="activeName" class="elTabsCssMange"  type="card" @tab-click="resetTable">
            <!-- 广发上市 -->
            <el-tab-pane label="基本信息" name="contentOnce">
              <div v-if="attributesType == 'f'">
                <!--件号，问号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>件号：</label>
                    <el-input v-model="showEditLookTwo.itemNo" readonly></el-input>
                  </li>
                  <li>
                    <label>文号：</label>
                    <el-input v-model="showEditLookTwo.fileCode" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--题目-->
                <ul class="mangeShowLook">
                  <li style="width: 100%;">
                    <label>题名：</label>
                    <el-input v-model="showEditLookTwo.titleProper" readonly style="width: 84.5%;"></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--保管期限，公开属性，文件盒号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>保管期限：</label>
                    <el-input v-model="showEditLookTwo.retentionPeriod" readonly></el-input>
                  </li>
                  <li>
                    <label>公开属性：</label>
                    <el-input v-model="showEditLookTwo.openingType" readonly></el-input>
                  </li>
                  <li>
                    <label>文件盒号：</label>
                    <el-input v-model="showEditLookTwo.caseNo" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--文件日期，年度，页数-->
                <ul class="mangeShowLook">
                  <li>
                    <label>文件日期：</label>
                    <el-input v-model="showEditLookTwo.dateOfCreation" readonly></el-input>
                  </li>
                  <li>
                    <label>年度：</label>
                    <el-input v-model="showEditLookTwo.yearCode" readonly></el-input>
                  </li>
                  <li>
                    <label>页数：</label>
                    <el-input v-model="showEditLookTwo.amountOfPages" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--档号，责任者，分类号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>档号：</label>
                    <el-input v-model="showEditLookTwo.officeArchivalCode" readonly></el-input>
                  </li>
                  <li>
                    <label>责任者：</label>
                    <el-input v-model="showEditLookTwo.c113" readonly></el-input>
                  </li>
                  <li>
                    <label>分类号：</label>
                    <el-input v-model="showEditLookTwo.seriesCode" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--是否为原件，是否在库，可见性-->
                <ul class="mangeShowLook">
                  <li>
                    <label>是否为原件：</label>
                    <el-input v-model="showEditLookTwo.c58" readonly></el-input>
                  </li>
                  <li>
                    <label>是否在库：</label>
                    <el-input v-model="showEditLookTwo.c59" readonly></el-input>
                  </li>
                  <li>
                    <label>可见性：</label>
                    <el-input v-model="showEditLookTwo.c93" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档人，归档部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档人：</label>
                    <el-input v-model="showEditLookTwo.filingUser" readonly></el-input>
                  </li>
                  <li>
                    <label>归档部门：</label>
                    <el-input v-model="showEditLookTwo.filingDept" readonly></el-input>
                  </li>
                  <li>
                    <label>归档部门：</label>
                    <el-input v-model="showEditLookTwo.c107 == 0 ? '已盖章':'未盖章'" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--备注-->
                <ul class="mangeShowLook">
                  <li>
                    <label>备注：</label>
                    <el-input v-model="showEditLookTwo.c8" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--部门，全宗，合同号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>部门：</label>
                    <el-input v-model="showEditLookTwo.c98" readonly></el-input>
                  </li>
                  <li>
                    <label>全宗：</label>
                    <el-input v-model="showEditLookTwo.fondsCode" readonly></el-input>
                  </li>
                  <li>
                    <label>合同号：</label>
                    <el-input v-model="showEditLookTwo.c117" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档日期，来文系统，文件类型-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档日期：</label>
                    <el-input v-model="showEditLookTwo.filingDate" readonly></el-input>
                  </li>
                  <li>
                    <label>来文系统：</label>
                    <el-input v-model="showEditLookTwo.c92" readonly></el-input>
                  </li>
                  <li>
                    <label>文件类型：</label>
                    <el-input v-model="showEditLookTwo.c100" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--公章等级，拟稿人，拟稿部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>公章等级：</label>
                    <el-input v-model="showEditLookTwo.c112" readonly></el-input>
                  </li>
                  <li>
                    <label>拟稿人：</label>
                    <el-input v-model="showEditLookTwo.c89" readonly></el-input>
                  </li>
                  <li>
                    <label>拟稿部门：</label>
                    <el-input v-model="showEditLookTwo.c90" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
              </div>
              <div v-if="attributesType == 'v'">
                <!--项目名称，全宗，分类号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>项目名称：</label>
                    <el-input v-model="showEditLookTwo.c11" readonly></el-input>
                  </li>
                  <li>
                    <label>全宗：</label>
                    <el-input v-model="showEditLookTwo.fondsCode" readonly></el-input>
                  </li>
                  <li>
                    <label>分类号：</label>
                    <el-input v-model="showEditLookTwo.seriesCode" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--案卷题名-->
                <ul class="mangeShowLook">
                  <li style="width: 100%;">
                    <label>案卷题名：</label>
                    <el-input v-model="showEditLookTwo.titleProper" readonly style="width: 84.5%;"></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--案卷号，年度，可见性-->
                <ul class="mangeShowLook">
                  <li>
                    <label>案卷号：</label>
                    <el-input v-model="showEditLookTwo.folderNo" readonly></el-input>
                  </li>
                  <li>
                    <label>年度：</label>
                    <el-input v-model="showEditLookTwo.yearCode" readonly></el-input>
                  </li>
                  <li>
                    <label>可见性：</label>
                    <el-input v-model="showEditLookTwo.c93" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档人，归档日期，归档部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档人：</label>
                    <el-input v-model="showEditLookTwo.filingUser" readonly></el-input>
                  </li>
                  <li>
                    <label>归档日期：</label>
                    <el-input v-model="showEditLookTwo.filingDate" readonly></el-input>
                  </li>
                  <li>
                    <label>归档部门：</label>
                    <el-input v-model="showEditLookTwo.filingDept" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--起始日期，责任者，保管期限-->
                <ul class="mangeShowLook">
                  <li>
                    <label>起始日期：</label>
                    <el-input v-model="showEditLookTwo.dateBegun" readonly></el-input>
                  </li>
                  <li>
                    <label>终止日期：</label>
                    <el-input v-model="showEditLookTwo.dateFinished" readonly></el-input>
                  </li>
                  <li>
                    <label>保管期限：</label>
                    <el-input v-model="showEditLookTwo.retentionPeriod" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--备注-->
                <ul class="mangeShowLook">
                  <li>
                    <label>备注：</label>
                    <el-input v-model="showEditLookTwo.folderNote" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--档号，项目代号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>档号：</label>
                    <el-input v-model="showEditLookTwo.officeArchivalCode" readonly></el-input>
                  </li>
                  <li>
                    <label>项目代号：</label>
                    <el-input v-model="showEditLookTwo.c0" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
              </div>
              <div v-if="attributesType == 'p'">
                <!--项目代号，项目名称-->
                <ul class="mangeShowLook">
                  <li>
                    <label>项目代号：</label>
                    <el-input v-model="showEditLookTwo.c0" readonly></el-input>
                  </li>
                  <li>
                    <label>项目名称：</label>
                    <el-input v-model="showEditLookTwo.c11" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--工程地点-->
                <ul class="mangeShowLook">
                  <li style="width: 100%;">
                    <label>工程地点：</label>
                    <el-input v-model="showEditLookTwo.projectSite" readonly style="width: 84.5%;"></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--全宗，归档部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>全宗：</label>
                    <el-input v-model="showEditLookTwo.fondsCode" readonly></el-input>
                  </li>
                  <li>
                    <label>归档部门：</label>
                    <el-input v-model="showEditLookTwo.filingDept" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--分类号，归档人-->
                <ul class="mangeShowLook">
                  <li>
                    <label>分类号：</label>
                    <el-input v-model="showEditLookTwo.seriesCode" readonly></el-input>
                  </li>
                  <li>
                    <label>归档人：</label>
                    <el-input v-model="showEditLookTwo.filingUser" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档日期，可见性-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档日期：</label>
                    <el-input v-model="showEditLookTwo.filingDate" readonly></el-input>
                  </li>
                  <li>
                    <label>可见性：</label>
                    <el-input v-model="showEditLookTwo.c93" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
              </div>
            </el-tab-pane>
            <el-tab-pane label="关联档案" name="contentTwoce" v-if="showViewTwo == 1">
              <div v-if="paramsViewTwo.tlist">
                <div style="margin: 6px;" v-if="attributesType == 'f'">关联目录：</div>
                <ul class="mangeShowLook" v-if="attributesType == 'f'" v-for="(item, index) in paramsViewTwo.tlist" :key="item.id">
                  <li style="width: 25%;">
                    <label style="width: 102px;">{{index + 1}}、档案题名：</label>
                    <el-input v-model="item.titleProper" readonly style="width: 57%"></el-input>
                  </li>
                  <li style="width: 25%;">
                    <label style="width: 102px;">责任者：</label>
                    <el-input v-model="item.c113" readonly style="width: 57%"></el-input>
                  </li>
                  <li style="width: 25%;">
                    <label style="width: 102px;">拟稿人：</label>
                    <el-input v-model="item.c89" readonly style="width: 57%"></el-input>
                  </li>
                  <li style="width: 25%;">
                    <label style="width: 102px;">合同号：</label>
                    <el-input v-model="item.c117" readonly style="width: 57%"></el-input>
                  </li>
                  <!--<li style="width: 25%;margin-top:4px;">
                    <label style="width: 102px;">档案链接：</label>
                    <span style="color: #409eff;cursor: pointer;">点击查看</span>
                  </li>-->
                  <div class="clear"></div>
                </ul>
              </div>
              <div v-if="paramsViewTwo.tflist">
                <div style="margin: 6px;">关联案卷：</div>
                <ul class="mangeShowLook" v-for="(item, index) in paramsViewTwo.tflist" :key="item.id">
                  <li style="width: 25%;">
                    <label style="width: 102px;">{{index + 1}}、档案题名：</label>
                    <el-input v-model="item.titleProper" readonly style="width: 57%"></el-input>
                  </li>
                  <div class="clear"></div>
                  <!--<li style="width: 25%; margin-top:4px;">
                    <label style="width: 102px;">档案链接：</label>
                    <span style="color: #409eff;cursor: pointer;">点击查看</span>
                  </li>-->
                  <div class="clear"></div>
                </ul>
              </div>
              <div v-if="paramsViewTwo.project">
                <div style="margin: 6px;">关联项目：</div>
                <ul class="mangeShowLook">
                  <li style="width: 25%;">
                    <label style="width: 102px;">档案题名：</label>
                    <el-input v-model="paramsViewTwo.project.titleProper" readonly style="width: 57%"></el-input>
                  </li>
                  <div class="clear"></div>
                  <!--<li style="width: 25%; margin-top:4px;">
                    <label style="width: 102px;">档案链接：</label>
                    <span style="color: #409eff;cursor: pointer;">点击查看</span>
                  </li>-->
                  <div class="clear"></div>
                </ul>
              </div>
            </el-tab-pane>
          </el-tabs>
        </div>
        <div class="clear"></div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button @click="dialogShowLookTwo = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 综合员审核 -->
    <el-dialog :visible.sync="dialogShowContent" width="1111px" class="hurdleAll" :before-close="handleClose">
      <div slot="title" class="dialog-title">综合员审核</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li>
            <label>移交人姓名：</label>
            <el-input v-model="showEdit.handoverUser" readonly></el-input>
          </li>
          <li>
            <label>移交部门：</label>
            <el-input v-model="showEdit.handoverDept" readonly></el-input>
          </li>
          <li>
            <label>移交时间：</label>
            <el-input v-model="showEdit.handoverDate" readonly></el-input>
          </li>
          <!--<li>-->
          <!--<label>操作指引：</label>-->
          <!--<el-button type="primary">下载</el-button>-->
          <!--</li>-->
          <div class="clear"></div>
        </ul>
        <!--中-->
        <ul class="mangeShow">
          <li>
            <label>接收人：</label>
            <el-input v-model="showEdit.receiveUser" readonly></el-input>
          </li>
          <li>
            <label>接收方式：</label>
            <el-select v-model="showEdit.handoverType"  placeholder="请选择" filterable @change="receiveBtn">
              <el-option
                v-for="item in handoverTypeList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <li v-if="!showDisable">
            <label>接收地址：</label>
            <el-input v-model="showEdit.receiveAddress" placeholder="请输入接收地址"></el-input>
          </li>
          <div class="clear"></div>
        </ul>
        <ul class="mangeShow">
          <li>
            <label>运单号：</label>
            <el-input v-model="showEdit.handoverYdh" :disabled="showDisable"></el-input>
          </li>
          <li>
            <label>运营商：</label>
            <el-select v-model="showEdit.handoverYys"  placeholder="请选择" filterable :disabled="showDisable" @change="newHandShow">
              <el-option
                v-for="item in handoverYysList"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--申请人意见-->
        <div class="mangeShowList">
          <label>综合员意见：</label>
          <el-input type="textarea" :rows="2" v-model="showEdit.applyRemarkCopy">
          </el-input>
        </div>
        <!--下-列表-->
        <div class="mangeShowList">
          <p>意见详情：</p>
          <div class="showReadOnlyContent" v-if="showEdit.isOldDate == 0">
            <div v-html="showEdit.handoverRemark"></div>
          </div>
          <!-- 表格 -->
          <div class="all-Table" v-else-if="showEdit.isOldDate == 1" style="width: 83%;max-height: 300px;overflow: auto;margin: 0 auto;">
            <el-table
              :data="dialogTable"
              stripe
              border
              style="width: 100%">
              <el-table-column
                show-overflow-tooltip
                prop="handoverRemark"
                label="意见内容">
                <template slot-scope="scope">
                  <div v-for="(item, index) in scope.row.handoverRemark" :key="index">{{ item }}</div>
                </template>
              </el-table-column>
              <el-table-column
                prop="date"
                label="时间">
              </el-table-column>
              <el-table-column
                prop="sendName"
                label="操作人">
              </el-table-column>
            </el-table>
          </div>
        </div>
        <!--合同介绍-->
        <div class="mangeShowList">
          <label>合同上传要求：</label>
          <div class="heTong">
            1,文件彩色扫描为pdf格式；<br/>
            2,命名格式：原OA流程：公司公章："年份+合同号",例：2017年第0001号001份。部门公章：合同名称-扫描件,例：房屋租赁合同-扫描件。
            BPM流程：不区分公司公章与部门公章，均以流程显示的合同号为准。例：广发证券[2018]001234号合同
          </div>
        </div>
      </div>
      <div class="maxHeight">
        <!-- 下操作 -->
        <div style="background-color: #F4F4F4;">
          <div class="searchBtn" @click="showLookBtnTwo">
            <img src="../../assets/turnOver/ck.png" alt="">
            <span>查看</span>
          </div>
          <div class="searchBtn" @click="showLookBtn7">
            <img src="../../assets/turnOver/sc.png" alt="">
            <span>上传</span>
          </div>
          <div class="searchBtn" @click="showLookBtn10">
            <img src="../../assets/turnOver/delete.png" alt="">
            <span>删除附件</span>
          </div>
          <div class="searchBtn" @click="showLookBtn11" v-if="this.params.series2 != 1374133285844">
            <img src="../../assets/turnOver/tj.png" alt="">
            <span>添加异常</span>
          </div>
          <div class="searchBtn" @click="showLookBtn13">
            <img src="../../assets/turnOver/xg.png" alt="">
            <span>修改上传附件题名</span>
          </div>
          <div class="searchBtn" @click="showLookBtn14" v-if="this.params.series2 != 1374133285844">
            <img src="../../assets/turnOver/xg.png" alt="">
            <span>查看合同信息</span>
          </div>
          <div class="searchBtn" @click="showLookBtn16" v-show="showEdit.isZctg == 'true'">
          <!--<div class="searchBtn" @click="showLookBtn16">-->
            <img src="../../assets/turnOver/yj.png" alt="">
            <span>移交详情</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 下表格 -->
        <div v-if="params.series1 == 1388742017269" class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtom"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="archivalCode"
              label="档号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverEmployer"
              label="所属部门"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="serialNumber"
              label="案卷号"
              width="230">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileType"
              label="类别"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="卷（册、袋）标题"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="startDate"
              label="起始时间"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="endDate"
              label="终止时间"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverHt"
              label="凭证起始号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="gzhangLevel"
              label="保管期限"
              width="160">
              <template slot-scope="scope">
                <span v-if="scope.row.gzhangLevel == 3">永久</span>
                <span v-else-if="scope.row.gzhangLevel == 2">长期</span>
                <span v-else-if="scope.row.gzhangLevel == 1">短期</span>
                <span v-else-if="scope.row.gzhangLevel == 5">10年</span>
                <span v-else-if="scope.row.gzhangLevel == 6">15年</span>
                <span v-else-if="scope.row.gzhangLevel == 8">30年</span>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileNum"
              label="卷内张数"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverNote"
              label="备考"
              width="160">
            </el-table-column>
          </el-table>
        </div>
        <div v-else-if="params.series2 == 1374133285844" class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtom"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="caseNo"
              label="盒号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverThNumber"
              label="件号"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverPc"
              label="刻制年度"
              width="230">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              label="刻制日期"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverEmployer"
              label="责任者"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="gzhangLevel"
              label="保管期限"
              width="160">
              <template slot-scope="scope">
                <span v-if="scope.row.gzhangLevel == 3">永久</span>
                <span v-else-if="scope.row.gzhangLevel == 2">长期</span>
                <span v-else-if="scope.row.gzhangLevel == 1">短期</span>
                <span v-else-if="scope.row.gzhangLevel == 5">10年</span>
                <span v-else-if="scope.row.gzhangLevel == 6">15年</span>
                <span v-else-if="scope.row.gzhangLevel == 8">30年</span>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileType"
              label="印章种类"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverHt"
              label="印章形状"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="sealStatus"
              label="印章状态"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverNote"
              label="备注"
              width="160">
            </el-table-column>
          </el-table>
        </div>
        <div v-else-if="params.series2 == 1374133285845 || params.series2 == 1374133285846 || params.series2 == 1374133285847
          || params.series2 == 1374133285848 || params.series2 == 1374133285849" class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtom"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverThNumber"
              label="件号"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverPc"
              label="年度"
              width="230">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="名称"
              width="200">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              label="获奖日期"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverEmployer"
              label="对方单位"
              width="200">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileType"
              label="类别"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverNote"
              label="备注"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="belongDept"
              label="所属部门"
              width="200">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="author"
              label="责任者"
              width="160">
            </el-table-column>
          </el-table>
        </div>
        <div v-else-if="params.series1 == 1374133285828" class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtom"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverThNumber"
              label="件号"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="题名"
              width="230">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="theme"
              label="主题"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              label="拍摄时间"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="site"
              label="地点"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="background"
              label="背景"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="personage"
              label="人物(职务)"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="photographer"
              label="摄(录)者"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="belongDept"
              label="所属部门"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverNote"
              label="内容简介"
              width="160">
            </el-table-column>
          </el-table>
        </div>
        <div v-else class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtom"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileCode"
              label="文件号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverHt"
              label="合同号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverEmployer"
              label="对方单位"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="文件标题"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              label="文件日期"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileType"
              label="文件类型"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverPc"
              label="年度">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="isOriginal"
              label="是否原件"
              width="100">
              <template slot-scope="scope">
                <span v-if="scope.row.isOriginal == 0">是</span>
                <span v-else-if="scope.row.isOriginal == 1">否</span>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverException"
              label="移交异常"
              width="500">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeTwo"
            :current-page="paramsTwo.page"
            :page-size="paramsTwo.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="mangeBtn" v-if="!showEditBtn">确定</el-button>
        <el-button type="primary" @click="tuiHuiBtn">退回</el-button>
        <el-button type="primary" @click="tuiHuiBtnTwo" v-if="showEditBtn">归档</el-button>
        <!--<el-button type="primary" @click="tuiHuiBtnTwo" v-if="showEdit.jsBs == 'zxjs'">归档</el-button>-->
        <el-button @click="dialogShowContent = false">取消</el-button>
      </div>
    </el-dialog>
    <el-dialog :visible.sync="getDataViewDialog" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        询问
      </div>
      <div class="dia-delete">
        蓝色者为本部门档案请归档处理；白色者为总部档案请移交档案中心。
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn1">确定</el-button>
        <el-button @click="getDataViewDialog = false">取消</el-button>
      </div>
    </el-dialog>
    <!--文件上传-->
    <el-dialog :visible.sync="getDataViewDialog8" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        文件上传
      </div>
      <div class="dia-deleteTwo">
        <label>文件上传：</label>
        <el-upload
          ref="AddBtnImgTwo"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :on-change="handleChange"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn8">确定</el-button>
        <el-button @click="getDataViewDialog8 = false">取消</el-button>
      </div>
    </el-dialog>
    <!---删除附件-->
    <el-dialog :visible.sync="getDataViewDialog10" width="896px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        删除附件
      </div>
      <div class="">
        <!-- 删除 -->
        <div @click="tableDeleteFile" style="line-height: 35px;border: 1px solid #929292;">
          <div  class="searchBtn" style="margin-left: 4px;">
            <img src="../../assets/turnOver/delete.png" alt="">
            <span style="cursor: pointer">删除</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 下表格 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="deleteTable"
            stripe
            border
            @selection-change="handleSelectionChangeBtomThree">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="titleProper"
              label="文件标题"
              width="600">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileSize"
              label="文件大小"
              width="100">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileFormat"
              label="文件格式"
              width="99">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeThree"
            :current-page="paramsDelete.page"
            :page-size="paramsDelete.rows"
            layout="prev, pager, next, jumper"
            :total="paramsDelete.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <!--<el-button type="primary" @click="submitBtn9">确定</el-button>-->
        <el-button @click="getDataViewDialog10 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--删除附件--删除确认-->
    <el-dialog :visible.sync="getDataViewDialog11" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        删除确认
      </div>
      <div class="dia-delete">
        确定要删除此附件吗?
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn11">确定</el-button>
        <el-button @click="getDataViewDialog11 = false">取消</el-button>
      </div>
    </el-dialog>
    <!---移交异常-->
    <el-dialog :visible.sync="getDataViewDialog12" width="1111px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        移交异常
      </div>
      <div>
        <!--移交异常-->
        <div class="anomalyError">
          <div class="anomalyErrorOne">移交异常：</div>
          <div class="anomalyErrorTwo">
            <el-checkbox ref="hException1" v-model="checkParams.hException1" true-label="广发未办理盖章" label="广发未办理盖章" :disabled="disYj" @change="selectDis"></el-checkbox>
            <el-checkbox ref="hException2" v-model="checkParams.hException2" true-label="未打印签署" label="未打印签署" :disabled="disYj" @change="selectDis"></el-checkbox>
          </div>
          <div class="anomalyErrorThree ErrorCenter">达标措施</div>
          <div class="anomalyErrorThree ErrorCenter">补救措施</div>
          <span class="clear"></span>
        </div>
        <!--合同遗失-A类-->
        <div class="anomalyErrorOnceTwo">
          <div class="anomalyErrorOne">合同遗失-A类：</div>
          <!--1-->
          <div>
            <div class="anomalyErrorTwo">
              <el-checkbox ref="hException3" @change="selectDis" v-model="checkParams.hException3" true-label="(A1)合同各方已盖章，且已履行完毕" label="(A1)合同各方已盖章，且已履行完毕" :disabled="disHtOne"></el-checkbox>
            </div>
            <div class="anomalyErrorThree">
              <el-checkbox ref="checkBosOne" @change="selectDis" v-model="checkParams.upStandard2" true-label="已补签" label="已补签" :disabled="disHtOneTwo"></el-checkbox>
            </div>
            <div class="anomalyErrorThree">
              <!--<el-checkbox ref="checkBosTwo" @change="selectDis" v-model="checkParams.remedial2" true-label="复印件等附件归档" label="复印件等附件归档" :disabled="disHtOneTwo"></el-checkbox>-->
              <el-checkbox ref="checkBosTwo" @change="selectDis" v-model="checkParams.remedial2" true-label="复印件等附件归档" label="复印件等附件归档" :disabled="disHtThreeTwoFy"></el-checkbox>
            </div>
          </div>
          <!--2-->
          <div style="height: 79px;">
            <div class="anomalyErrorTwo">
              <el-checkbox ref="hException4" @change="selectDis" v-model="checkParams.hException4" true-label="(A2)合同各方已盖章，且正在履行" label="(A2)合同各方已盖章，且正在履行" :disabled="disHtTwo"></el-checkbox>
              <el-checkbox ref="zlhDateOne" @change="selectDisTwo" v-model="checkParams.hException4" true-label="自留函" label="自留函" :disabled="disHtTwoOnce"></el-checkbox>
              <el-date-picker
                class="pickerSelect"
                v-show="disHtTwoDate"
                v-model="checkParams.zlhDate"
                :picker-options="timeChange"
                type="date"
                format="yyyy 年 MM 月 dd 日"
                value-format="yyyy-MM-dd"
                placeholder="选择时间">
              </el-date-picker>
            </div>
            <div class="anomalyErrorThree" style="line-height: 79px;">
              <el-checkbox ref="checkBosThree" @change="selectDis" v-model="checkParams.upStandard3" true-label="已补签" label="已补签" :disabled="disHtTwoTwo"></el-checkbox>
            </div>
            <div class="anomalyErrorThree ErrorCenter"  style="line-height: 79px;">——</div>
          </div>
          <!--3-->
          <div>
            <div class="anomalyErrorTwo">
              <el-checkbox ref="hException5" @change="selectDis" v-model="checkParams.hException5" true-label="(A3)合同各方已盖章，合同不再履行" label="(A3)合同各方已盖章，合同不再履行"  :disabled="disHtThree"></el-checkbox>
            </div>
            <div class="anomalyErrorThree">
              <el-checkbox ref="checkBosFour" @change="selectDis" v-model="checkParams.upStandard5" true-label="已变更、解除、终止" label="已变更、解除、终止"  :disabled="disHtThreeTwo"></el-checkbox>
            </div>
            <div class="anomalyErrorThree ErrorCenter">——</div>
          </div>
          <!--4-->
          <div>
            <div class="anomalyErrorTwo">
              <el-checkbox ref="hException6" @change="selectDis" v-model="checkParams.hException6" true-label="(A4)合同仅有我方盖章" label="(A4)合同仅有我方盖章" :disabled="disHtFour"></el-checkbox>
            </div>
            <div class="anomalyErrorThree">
              <el-checkbox ref="checkBosFive" @change="selectDis" v-model="checkParams.upStandard6" true-label="已全部回收" label="已全部回收" :disabled="disHtFourTwo"></el-checkbox>
            </div>
            <div class="anomalyErrorThree">
              <el-checkbox ref="checkBosSix" @change="selectDis" v-model="checkParams.remedial6" true-label="已有遗失说明" label="已有遗失说明" :disabled="disHtFourTwo"></el-checkbox>
            </div>
          </div>
          <span class="clear"></span>
        </div>
        <!--合同不完整-B类-->
        <div class="anomalyErrorOnceTwo">
          <div class="anomalyErrorOnceFour">合同不完整-B类：</div>
          <div>
            <div class="anomalyErrorOnceThree">
              <el-checkbox ref="contentOne"  v-model="checkParams.contentOne" true-label="原件不完整（对方未盖章）" label="原件不完整（对方未盖章）" :disabled="disHtBOne" @change="selectDis"></el-checkbox>
            </div>
            <div class="anomalyErrorOnceThree">
              <el-checkbox ref="contentTwo"  v-model="checkParams.contentTwo" true-label="原件不完整（无签署时间）" label="原件不完整（无签署时间）" :disabled="disHtBTwo" @change="selectDis"></el-checkbox>
            </div>
            <div class="anomalyErrorOnceThree">
              <el-checkbox ref="contentThree"  v-model="checkParams.contentThree" true-label="原件不完整（缺失授权书）" label="原件不完整（缺失授权书）" :disabled="disHtBThree" @change="selectDis"></el-checkbox>
            </div>
            <div class="anomalyErrorOnceThree">
              <el-checkbox ref="contentFour"  v-model="checkParams.contentFour" true-label="原件不完整（对方未签名）" label="原件不完整（对方未签名）" :disabled="disHtBFour" @change="selectDis"></el-checkbox>
            </div>
            <div class="anomalyErrorOnceThree">
              <el-checkbox ref="contentFive"  v-model="checkParams.contentFive" true-label="原件不完整（缺失部分页）" label="原件不完整（缺失部分页）" :disabled="disHtBFive" @change="selectDis"></el-checkbox>
            </div>
          </div>
          <div class="anomalyErrorOnceFour" style="width: 234px; text-align: left; text-indent: 2px;">
            <el-checkbox ref="checkBosSeven" v-model="checkParams.upStandard7" true-label="补充整改完成后原件归档" label="补充整改完成后原件归档" :disabled="disHtBOnceTwo" @change="selectDis"></el-checkbox>
          </div>
          <div class="anomalyErrorThree ErrorCenter"  style="height: 204px;line-height: 204px;">——</div>
          <span class="clear"></span>
        </div>
        <!--考核标准-->
        <div class="showContentDownload">
          根据《关于加强合同归档管理与考核的通知》相关要求，自2018年起，异常合同归档率超过考核指标的，办公室将报合规与法律事务部出具风险提示函或风险警示函，
          <span @click="getDataViewDialog13 = true">考核标准。</span>
        </div>
        <!--合同异常归档操作说明（点击下载）-->
        <div class="showContentDownload">
          注：选择广发未办理盖章或未打印签署的，不计入移交异常考核。已达标或有补救措施的不计入移交异常考核。
          <br/>
          <span @click="wordPullBtn">合同异常归档操作说明（点击下载）。</span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="errorCheckBtn">确定</el-button>
        <el-button @click="getDataViewDialog12 = false">取消</el-button>
      </div>
    </el-dialog>
    <!---移交异常--考核标准-->
    <el-dialog :visible.sync="getDataViewDialog13" width="800px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        考核标准
      </div>
      <div>
        <!--异常种类-->
        <div class="anomalyError" style="width: 756px;">
          <div class="anomalyErrorOne ErrorCenter" style="text-align: center;font-size: 18px;">异常种类</div>
          <div class="anomalyErrorTwo ErrorCenter" style="font-size: 18px;">
            考核指标=异常合同数/合同总数
          </div>
          <div class="anomalyErrorThree ErrorCenter" style="font-size: 18px;">建议处理措施</div>
          <span class="clear"></span>
        </div>
        <!--A1不达标-->
        <div class="anomalyErrorOnceTwo"  style="width: 757px;">
          <div class="anomalyErrorOne ErrorCenter" style="height: 82px;line-height: 82px;text-align: center;">A1不达标</div>
          <!--1-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A1≥5%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <!--2-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A1≥10%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <span class="clear"></span>
        </div>
        <!--A2不达标-->
        <div class="anomalyErrorOnceTwo"  style="width: 757px;">
          <div class="anomalyErrorOne ErrorCenter" style="height: 82px;line-height: 82px;text-align: center;">A2不达标</div>
          <!--1-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A2≥4%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <!--2-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A2≥8%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <span class="clear"></span>
        </div>
        <!--A3不达标-->
        <div class="anomalyErrorOnceTwo"  style="width: 757px;">
          <div class="anomalyErrorOne ErrorCenter" style="height: 82px;line-height: 82px;text-align: center;">A3不达标</div>
          <!--1-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A3≥2%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <!--2-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A3≥4%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <span class="clear"></span>
        </div>
        <!--A4不达标-->
        <div class="anomalyErrorOnceTwo"  style="width: 757px;">
          <div class="anomalyErrorOne ErrorCenter" style="height: 82px;line-height: 82px;text-align: center;">A4不达标</div>
          <!--1-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A4≥2%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <!--2-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              A4≥4%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <span class="clear"></span>
        </div>
        <!--B不达标-->
        <div class="anomalyErrorOnceTwo"  style="width: 757px;">
          <div class="anomalyErrorOne ErrorCenter" style="height: 82px;line-height: 82px;text-align: center;">B不达标</div>
          <!--1-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              B≥8%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <!--2-->
          <div>
            <div class="anomalyErrorTwo ErrorCenter">
              B≥15%
            </div>
            <div class="anomalyErrorThree ErrorCenter">
              出具风险提示函
            </div>
          </div>
          <span class="clear"></span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button @click="getDataViewDialog13 = false">取消</el-button>
      </div>
    </el-dialog>
    <!---修改附件提名-->
    <el-dialog :visible.sync="getDataViewDialog14" width="896px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        附件
      </div>
      <div class="">
        <!-- 修改 -->
        <div @click="tableDeleteFileTwo" style="line-height: 35px;border: 1px solid #929292;">
          <div class="searchBtn" style="margin-left: 4px;">
            <img src="../../assets/turnOver/xg.png" alt="">
            <span style="cursor: pointer">修改</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 下表格 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="deleteTable"
            stripe
            border
            @selection-change="handleSelectionChangeBtomThree">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="titleProper"
              label="文件标题"
              width="600">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileSize"
              label="文件大小"
              width="100">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileFormat"
              label="文件格式"
              width="99">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeThree"
            :current-page="paramsDelete.page"
            :page-size="paramsDelete.rows"
            layout="prev, pager, next, jumper"
            :total="paramsDelete.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button @click="getDataViewDialog14 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--修改标题-->
    <el-dialog :visible.sync="getDataViewDialog15" width="444px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">
        附件信息
      </div>
      <div class="dia-delete">
        <ul class="mangeShowLook">
          <li class="editorXin" style="width: 410px;">
            <label>题名：</label>
            <el-input v-model="showEditLookTitle" style="width: 65%;"></el-input>
          </li>
          <div class="clear"></div>
        </ul>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn14">确定</el-button>
        <el-button @click="getDataViewDialog15 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--移交详情-->
    <el-dialog :visible.sync="getDataViewDialog20" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        对方单位信息编辑
      </div>
      <div style="text-align: center">
        <el-radio-group v-model="paramsEditContent.completes" @change="radioCompletes">
          <el-radio label="1">已移交齐全</el-radio>
          <el-radio label="0">未移交齐全</el-radio>
        </el-radio-group>
        <!--<div>-->
        <!--<el-radio v-model="paramsEditContent.completes" label="1">已移交齐全</el-radio>-->
        <!--</div>-->
        <!--<div>-->
        <!--<el-radio v-model="paramsEditContent.completes" label="0">未移交齐全</el-radio>-->
        <!--</div>-->
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitBtn17">确定</el-button>
        <el-button @click="getDataViewDialog20 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 查看合同信息（先不做--有BUG，暂停） -->
    <el-dialog :visible.sync="getDataViewDialog4"
               width="880px"
               class="hurdleAll"
               :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">查看合同信息</div>
      <!--文号，题名-->
      <ul class="mangeShowLook">
        <li>
          <label>文号：</label>
          <el-input v-model="showEditLook.fileCode"></el-input>
        </li>
        <li class="editorXin" style="width: 536px;">
          <label>题名：</label>
          <el-input v-model="showEditLook.titleProper" style="width: 81%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--文件日期，年度，页数-->
      <ul class="mangeShowLook">
        <li class="editorXin">
          <label>文件日期：</label>
          <el-date-picker
            v-model="showEditLook.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <li class="editorXin">
          <label>年度：</label>
          <el-input v-model="showEditLook.yearCode"></el-input>
        </li>
        <li>
          <label>页数：</label>
          <el-input v-model="showEditLook.amountOfPage"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--备注-->
      <ul class="mangeShowLook">
        <li style="width: 804px;">
          <label>备注：</label>
          <el-input type="textarea" v-model="showEditLook.c8" style="width: 87.3%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="submitBtn4">保存</el-button>
        <el-button @click="restBtn">重置</el-button>
        <el-button @click="getDataViewDialog4 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--检索--按件-->
    <el-dialog :visible.sync="getDataViewDialog21" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        检索
      </div>
      <div class="editorXinTwo">
        <label>题名：</label>
        <el-input v-model="params.yjTitleProper" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>年度：</label>
        <el-input v-model="params.yjYearCode" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>文号：</label>
        <el-input v-model="params.yjFileCode" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>合同号：</label>
        <el-input v-model="params.yjC117" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>责任者：</label>
        <el-input v-model="params.yjAuthor" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>移交状态：</label>
        <el-select v-model="params.yjStatus" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option v-for="item in yjStatusArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>移交单号：</label>
        <el-input v-model="params.yjSerialNumber" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>拟稿部门：</label>
        <el-select v-model="params.yjc90" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option v-for="item in yjc90Arr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>拟稿人：</label>
        <el-select v-model="params.yjc89" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword
                   :remote-method="remoteMethodMan">
          <el-option v-for="item in yjc89Arr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>当前处理人：</label>
        <el-select v-model="params.yjcurrentuser" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword
                   :remote-method="remoteMethodUser">
          <el-option v-for="item in yjcurrentuserArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>文件类型：</label>
        <el-select v-model="params.fileType" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option v-for="item in fileTypeArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>公章类型：</label>
        <el-select v-model="params.yjc112" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option v-for="item in yjc112Arr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>文件日期：</label>
        <el-date-picker
          v-model="params.dataOfCreate"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div class="editorXinTwo">
        <label>移交类型：</label>
        <el-select v-model="params.type" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option
            v-for="item in handoverTypeModel"
            :key="item.itemValue"
            :label="item.name"
            :value="item.itemValue">
          </el-option>
        </el-select>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitBtn18">确定</el-button>
        <el-button @click="reset">重置</el-button>
        <el-button @click="getDataViewDialog21 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--检索--业务-->
    <el-dialog :visible.sync="getDataViewDialog211" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        检索
      </div>
      <div class="editorXinTwo">
        <label>项目单位全称：</label>
        <el-input v-model="params.thHandoverEmployer" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>项目类型：</label>
        <el-input v-model="params.thFileType" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>业务类型：</label>
        <el-input v-model="params.thHandoverHt" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>项目名称：</label>
        <el-input v-model="params.thTitle" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>项目结束年度：</label>
        <el-input v-model="params.thFileDate" placeholder="请输入内容"></el-input>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitBtn18">确定</el-button>
        <el-button @click="reset">重置</el-button>
        <el-button @click="getDataViewDialog211 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--检索--会计-->
    <el-dialog :visible.sync="getDataViewDialog212" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        检索
      </div>
      <div class="editorXinTwo">
        <label>案卷号：</label>
        <el-input v-model="params.kjc220" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>类别：</label>
        <el-input v-model="params.kjc15" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>卷(册、袋)标题：</label>
        <el-input v-model="params.kjtitleProper" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>起始时间：</label>
        <el-date-picker
          v-model="params.kjdateOfCreation"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div class="editorXinTwo">
        <label>终止时间：</label>
        <el-date-picker
          v-model="params.kjdateOfEnd"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div class="editorXinTwo">
        <label>凭证起始号：</label>
        <el-input v-model="params.kjc160" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>凭证终止号：</label>
        <el-input v-model="params.kjc162" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>移交类型：</label>
        <el-select v-model="params.type" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option
            v-for="item in handoverTypeModel"
            :key="item.itemValue"
            :label="item.name"
            :value="item.itemValue">
          </el-option>
        </el-select>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitBtn18">确定</el-button>
        <el-button @click="reset">重置</el-button>
        <el-button @click="getDataViewDialog212 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--检索--实物档案--印章-->
    <el-dialog :visible.sync="getDataViewDialog213" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        检索
      </div>
      <div class="editorXinTwo">
        <label>印章名称：</label>
        <el-input v-model="params.yzTitleProper" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>刻制年度：</label>
        <el-input v-model="params.yzYearCode" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>印章种类：</label>
        <el-input v-model="params.yzFileType" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>印章形状：</label>
        <el-input v-model="params.yzHandoverHt" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>责任者：</label>
        <el-input v-model="params.yzHandoverEmployer" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>印章状态：</label>
        <el-input v-model="params.yzSealStatus" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>刻制日期：</label>
        <el-date-picker
          v-model="params.yzFileDate"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div class="editorXinTwo">
        <label>移交类型：</label>
        <el-select v-model="params.type" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option
            v-for="item in handoverTypeModel"
            :key="item.itemValue"
            :label="item.name"
            :value="item.itemValue">
          </el-option>
        </el-select>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitBtn18">确定</el-button>
        <el-button @click="reset">重置</el-button>
        <el-button @click="getDataViewDialog213 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--检索--实物档案--非印章-->
    <el-dialog :visible.sync="getDataViewDialog214" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        检索
      </div>
      <div class="editorXinTwo">
        <label>名称：</label>
        <el-input v-model="params.qtTitleProper" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>年度：</label>
        <el-input v-model="params.qtYearCode" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>对方单位：</label>
        <el-input v-model="params.qtC161" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>类别：</label>
        <el-input v-model="params.qtC15" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>责任者：</label>
        <el-input v-model="params.qtC113" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>所属部门：</label>
        <el-input v-model="params.qtC68" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>日期：</label>
        <el-date-picker
          v-model="params.qtDataOfCreate"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div class="editorXinTwo">
        <label>移交类型：</label>
        <el-select v-model="params.type" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option
            v-for="item in handoverTypeModel"
            :key="item.itemValue"
            :label="item.name"
            :value="item.itemValue">
          </el-option>
        </el-select>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitBtn18">确定</el-button>
        <el-button @click="reset">重置</el-button>
        <el-button @click="getDataViewDialog214 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--检索--声像-->
    <el-dialog :visible.sync="getDataViewDialog215" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        检索
      </div>
      <div class="editorXinTwo">
        <label>题名：</label>
        <el-input v-model="params.sxtitleProper" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>地点：</label>
        <el-input v-model="params.sxtakePhotoPlace" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>背景：</label>
        <el-input v-model="params.sxc64" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>人物(职务)：</label>
        <el-input v-model="params.sxc65" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>摄(录)者：</label>
        <el-input v-model="params.sxtakePhotoPerson" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>所属部门：</label>
        <el-input v-model="params.sxc68" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>主题：</label>
        <el-input v-model="params.sxc69" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>日期：</label>
        <el-date-picker
          v-model="params.sxtakePhotoDate"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitBtn18">确定</el-button>
        <el-button @click="reset">重置</el-button>
        <el-button @click="getDataViewDialog215 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--重新发送待办-->
    <el-dialog :visible.sync="getDataViewDialog23" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        待办发送确认
      </div>
      <div class="dia-delete">
        确定要重新发送该移交审核待办给综合员吗?
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn19">确定</el-button>
        <el-button @click="getDataViewDialog23 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--导出合同移交登记表-->
    <el-dialog :visible.sync="getDataViewDialog27" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        导出合同移交登记表
      </div>
      <div class="editorXin editorXinTwo">
        <label>移交部门：</label>
        <el-select v-model="paramsDownload.exportHandoverDept"  placeholder="请选择" filterable @change="receiveBtn">
          <el-option v-for="item in yjc90Arr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXin editorXinTwo">
        <label>导出时间(起)：</label>
        <el-date-picker
          v-model="paramsDownload.exportStartDate"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div class="editorXin editorXinTwo">
        <label>导出时间(止)：</label>
        <el-date-picker
          v-model="paramsDownload.exportEndDate"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn27">确定</el-button>
        <el-button @click="getDataViewDialog27 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--下载非PDF文件-->
    <el-dialog :visible.sync="getDataViewDialog47" width="444px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">
        系统提示
      </div>
      <div class="dia-delete">
        该电子全文暂不提供在线浏览，您是否要离线下载此文件？
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn47">确定</el-button>
        <el-button @click="getDataViewDialog47 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 查看合同信息弹框 -->
    <el-dialog :visible.sync="getDataViewDialog555" width="880px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">录入</div>
      <!--合同号，产品名称-->
      <ul class="mangeShowLook">
        <li style="width: 50%">
          <label style="width: 106px">合同号：</label>
          <el-input v-model="showEditLook.compactCode"></el-input>
        </li>
        <li style="width: 50%">
          <label style="width: 106px">产品名称：</label>
          <!--<el-input v-model="showEditLook.productName"></el-input>-->
          <el-select v-model="showEditLook.productName" placeholder="请选择" filterable remote reserve-keyword
                     :remote-method="productNameChange"
          >
            <el-option v-for="(item, index) in productNameArr" :key="index" :label="item.text" :value="item.id"></el-option>
          </el-select>
        </li>
        <div class="clear"></div>
      </ul>
      <!--产品内部编码，TA代码-->
      <ul class="mangeShowLook">
        <li style="width: 50%">
          <label style="width: 106px">产品内部编码：</label>
          <el-input type="text" v-model="showEditLook.productCode" @keyup.native="opoUp"></el-input>
        </li>
        <li style="width: 50%">
          <label style="width: 106px">TA代码：</label>
          <el-input type="text" v-model="showEditLook.taCode" @keyup.native="opoUpTwo"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <!--日期，文件类型-->
      <ul class="mangeShowLook">
        <li style="width: 50%" class="">
          <!--editorXin-->
          <label style="width: 106px">合同日期：</label>
          <el-date-picker
            v-model="showEditLook.compactDate"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </li>
        <li style="width: 50%" class="">
          <label style="width: 106px">文件类型：</label>
          <!--<el-input v-model="showEditLook.fileType"></el-input>-->
          <el-select v-model="showEditLook.fileType" placeholder="请选择" filterable @change="showContentType">
            <el-option v-for="item in heTongFileTypeArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
          </el-select>
        </li>
        <div class="clear"></div>
      </ul>
      <div v-if="disSelectContent">
        <!--客户名称，客户类型-->
        <ul class="mangeShowLook">
          <li style="width: 50%" class="">
            <!--editorXin-->
            <label style="width: 106px">客户名称：</label>
            <el-input type="text" v-model="showEditLook.clientName"></el-input>
          </li>
          <li style="width: 50%" class="">
            <label style="width: 106px">客户类型：</label>
            <!--<el-input v-model="showEditLook.fileType"></el-input>-->
            <el-select v-model="showEditLook.clientType" placeholder="请选择" filterable @change="showContentTypeTwo">
              <el-option v-for="item in clientTypeArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
            </el-select>
          </li>
          <div class="clear"></div>
        </ul>
        <!--证件类型，证件号码-->
        <ul class="mangeShowLook">
          <li style="width: 50%" class="">
            <label style="width: 106px">证件类型：</label>
            <!--<el-input v-model="showEditLook.fileType"></el-input>-->
            <el-select v-model="showEditLook.papersType" placeholder="请选择" filterable @change="showContentTypeThree">
              <el-option v-for="item in papersTypeArrOnce" :key="item.id" :label="item.text" :value="item.id"></el-option>
            </el-select>
          </li>
          <li style="width: 50%" class="">
            <!--editorXin-->
            <label style="width: 106px">证件号码：</label>
            <el-input type="text" v-model="showEditLook.papersNo"></el-input>
          </li>
          <div class="clear"></div>
        </ul>
      </div>
      <!--备注-->
      <ul class="mangeShowLook">
        <li style="width: 804px;">
          <label style="width: 106px">备注：</label>
          <el-input type="textarea" v-model="showEditLook.remarks" style="width: 85%;"></el-input>
        </li>
        <div class="clear"></div>
      </ul>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <!--<el-button type="primary" @click="submitBtn39">保存</el-button>-->
        <el-button type="primary" @click="submitBtn555">保存</el-button>
        <el-button @click="showLookBtn14">重置</el-button>
        <el-button @click="getDataViewDialog555 = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getFonds, listSeriesByFondsAndRole, listHandOverQrData, listHandOverDetailData, listSeriesByFonds, findChangeUser,
  handOverSave, listHandOverDocumentTree, getHandOverFile, countHandOverDetailByNext, delHandOverFile, resettingHandOverFile,
  findSeriesCode, saveMhYjFile, editMhFileTitle, deleteMhYjFile, uploadPicture, saveUploadYjDoc, uploadExcelH5, uploadExcel,
  listHandOverDocumentData, deleteDoc, saveHandoverYc, saveIsOriginal, downloadExcel, editDocTitle, getQrYjList, getArchiveYjList,
  listKhdaStuffCoding, saveGlKhda, getQrYjRemark, getBusinessType, listHandoverPartnerData, saveImformation, handoverPartnerEditSave,
  delImformation, getYjInformation, saveYjInfoData, searchFindUser, listAllDept, listFileType, listGzdj, newListUserByDept,
  saveMhHandOver, sendMhYjOa, sendZhyShDb, ListArchive, listForJson, ListRetentionPeriod, saveUnderLine, listTimingData,
  saveTiming, uploadPlPicture, savePlHangingDocs, zhyHandOverSave, exportHtTable, countHandOverDetail, handOverBack, powerHandoverDocView,
  BASICURL, listTreeJson, listTreeJsonView, checkExtendInfo, extendInfoView, handoverExtendInfoView, gdHandOverFile, listProductName,
  getProductCodeAndTACode, getHTInfo, saveHTInfo} from '@/js/turnOverData'
import { wordPull } from '../../js/wordDerive'
import { valueIndex } from '../../js/transitionText'
export default {
  name: 'synthesizeAuditMange',
  data () {
    return {
      // 查看弹框需要的
      activeName: 'contentOnce',
      paramsView: {
        project: {titleProper: null}
      },
      paramsViewTwo: {
        project: {titleProper: null}
      },
      attributesType: [],
      treTableTwo: [],
      productNameArr: [],
      clientTypeArr: [{id: '机构', text: '机构'}, {id: '个人', text: '个人'}],
      papersTypeArrOnce: [],
      papersTypeArr: [{id: '身份证', text: '身份证'}, {id: '其他', text: '其他'}],
      papersTypeArrTwo: [{id: '营业执照', text: '营业执照'}, {id: '其他', text: '其他'}],
      heTongFileTypeArr: [
        {id: '基金合同', text: '基金合同'},
        {id: '补充协议', text: '补充协议'},
        {id: '证券经纪服务协议', text: '证券经纪服务协议'},
        {id: '期货投资操作备忘录', text: '期货投资操作备忘录'},
        {id: '托管协议', text: '托管协议'},
        {id: '募集账户监督协议', text: '募集账户监督协议'},
        {id: '基金服务合同', text: '基金服务合同'},
        {id: '基金服务操作备忘录', text: '基金服务操作备忘录'},
        {id: '基金服务合同附件', text: '基金服务合同附件'},
        {id: '外包合作框架协议', text: '外包合作框架协议'},
        {id: '托管合作框架协议', text: '托管合作框架协议'},
        {id: '自定义', text: '自定义'}
      ],
      showEditLookTwo: {},
      dialogShowLookTwo: false,
      showCheckEmbed: false,
      disSelectContent: false,
      embedOnce: '',
      showView: '',
      showViewTwo: '',
      showViewTwoId: '',

      getDataViewDialog: false,
      getDataViewDialog4: false,
      getDataViewDialog8: false,
      getDataViewDialog10: false,
      getDataViewDialog11: false,
      getDataViewDialog12: false,
      getDataViewDialog13: false,
      getDataViewDialog14: false,
      getDataViewDialog15: false,
      getDataViewDialog20: false,
      getDataViewDialog21: false,
      getDataViewDialog211: false,
      getDataViewDialog212: false,
      getDataViewDialog213: false,
      getDataViewDialog214: false,
      getDataViewDialog215: false,
      getDataViewDialog23: false,
      getDataViewDialog27: false,
      getDataViewDialog47: false,
      getDataViewDialog555: false,
      showEditLookTitle: '',
      showEdit: {},
      paramsEditContent: {},
      paramsDownload: {},
      params: {page: 1, rows: 10, status: 2, series1: 1379482316593, fonds: 1374133141812},
      paramsTwo: {page: 1, rows: 10, total: 0},
      paramsDelete: {page: 1, rows: 10, total: 0},
      showEditLook: {productCode: '', taCode: ''},
      // 全宗类型
      fullZong: [],
      // 档案类型
      FondsAndRole: [],
      FondsAndRoleTwo: [],
      FondsAndRoleThree: [],
      exportHandoverDeptArr: [],
      // 移交类型
      handoverTypeModel: [
        {name: '精确移交', itemValue: '0'},
        {name: '模糊移交', itemValue: '1'},
        {name: '线下移交', itemValue: '3'},
        {name: '全部', itemValue: '2'}
      ],
      // 移交类型(弹框移交类型）
      handoverYysList: [
        {name: '顺丰快递', itemValue: '0,顺丰快递'},
        {name: '圆通快递', itemValue: '1,圆通快递'},
        {name: '中通快递', itemValue: '2,中通快递'},
        {name: '韵达快递', itemValue: '3,韵达快递'},
        {name: '百世汇通', itemValue: '4,百世汇通'},
        {name: 'EMS', itemValue: '5,EMS'},
        {name: '申通快递', itemValue: '6,申通快递'}
      ],
      // 接收方式
      handoverTypeList: [
        {name: '邮寄', itemValue: '1'},
        {name: '面交', itemValue: '2'}
      ],
      yjStatusArr: [
        {id: 0, text: '全部', value: ''},
        {id: 1, text: '欠交', value: ''},
        {id: 2, text: '综合员审核', value: ''},
        {id: 3, text: '部门领导审核', value: ''},
        {id: 4, text: '档案管理员审核', value: ''},
        {id: 5, text: '已移交', value: ''}
      ],
      tableData: [],
      tableDataTwo: [],
      dialogTableBtom: [],
      onceTable: [],
      onceTableBtom: [],
      onceTableBtomTwo: [],
      onceTableBtomThree: [],
      dialogShowLook: false,
      dialogShowContent: false,
      showDisable: false,
      treTable: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      deleteTable: [],
      imgVal: [],
      yjc90Arr: [],
      fileTypeArr: [],
      yjc112Arr: [],
      yjc89Arr: [],
      yjcurrentuserArr: [],
      checkParams: {},
      disYj: false,
      disHtOne: false,
      disHtOneTwo: true,
      disHtThreeTwoFy: true,
      disHtTwo: false,
      disHtTwoOnce: false,
      disHtTwoDate: false,
      disHtTwoTwo: true,
      disHtThree: false,
      disHtThreeTwo: true,
      disHtFour: false,
      disHtFourTwo: true,

      disHtBOne: false,
      disHtBTwo: false,
      disHtBThree: false,
      disHtBFour: false,
      disHtBFive: false,
      disHtBOnceTwo: true,
      showEditBtn: true,
      timeChange: {
        disabledDate (time) {
          return time.getTime() < (Date.now() - 3600 * 1000 * 24 * 183) || time.getTime() > Date.now() // 选择时间范围
        }
      }
    }
  },
  methods: {
    submitBtn47 () {
      let params = {id: this.showEditLook.textContentIds}
      valueIndex().exportXls('/gdda-new/gdda/util/downLoadHandoverFile', params, this.showEditLook.textContents, 'post')
      this.getDataViewDialog47 = false
    },
    handleNodeClick (val) {
      powerHandoverDocView({id: val.id}).then(res => {
        this.showCheckEmbed = true
        if (res.optFlag == -1) {
          this.$message.error('此文件不存在')
        } else if (res.optFlag == 0) {
          this.showCheckEmbed = false
          this.embedOnce = `${BASICURL}/gdda-new/gdda/util/viewHandoverPdf?docId=${val.id}`
          this.$forceUpdate()
        } else if (res.optFlag == 2) {
          this.getDataViewDialog47 = true
          this.showEditLook.textContents = val.text
          this.showEditLook.textContentIds = val.id
        }
      })
    },
    handleNodeClickTwo (val) {
      console.log(val)
      let types = val.attributes.type
      let ids = val.id
      let rids = this.showViewTwoId.id
      val.children = []
      // 左侧树
      listTreeJson({id: rids, type: types,resourceParentId: ids}).then(res => {
        if (res.data.data.message) {
          this.$message.info(res.data.data.message)
        } else {
          val.children = res.data.data
        }
      })
      // 右侧基本信息
      listTreeJsonView({id: ids, type: types}).then(res => {
        if (types == 'f') {
          this.showEditLookTwo = res.data.file
        } else if (types == 'v') {
          this.showEditLookTwo = res.data.folder
        } else if (types == 'p') {
          this.showEditLookTwo = res.data.project
        }
      })
      // 判断右侧是否有关键档案
      checkExtendInfo().then(res => {
        this.showViewTwo = res.data.optFlag
      })
      // 右侧关键档案
      extendInfoView({id: ids, type: types}).then(res => {
        this.paramsViewTwo = res.data
      })
    },
    showList () {
      listSeriesByFondsAndRole({id: '1374133141812'}).then(res => {
        // console.log(res)
        this.FondsAndRole = res.data
        listHandOverQrData(this.params).then(resVal => {
          this.tableData = resVal.data.rows
          this.tableData.forEach(item => {
            res.data.forEach(itemVal => {
              if (item.tag == itemVal.tag) {
                item.tagName = itemVal.name
              }
            })
          })
          this.params.total = resVal.data.total
        })
      })
    },
    showListBtom (val) {
      this.dialogTableBtom = []
      this.paramsTwo.subId = this.onceTable[0].gid
      listHandOverDetailData(this.paramsTwo).then(res => {
        if (this.dialogShowContent || this.dialogShowContentFan) {
          this.dialogTableBtom = res.data.rows
        } else {
          this.tableDataTwo = res.data.rows
        }
        this.paramsTwo.total = res.data.total
      })
    },
    // 获取全宗 档案类型第一级
    showSearchData () {
      getFonds().then(res => {
        this.fullZong = res.data
      })
      listSeriesByFondsAndRole({id: '1374133141812'}).then(res => {
        // console.log(res)
        this.FondsAndRole = res.data
        this.searchSeries(1379482316593)
      })
    },
    // 档案类型第1级
    searchSeries (val) {
      this.params.series2 = ''
      this.params.series3 = ''
      this.FondsAndRoleTwo = []
      this.FondsAndRoleThree = []
      listSeriesByFonds({id: val}).then(res => {
        this.FondsAndRoleTwo = res.data
      })
      this.params.page = 1
      this.params.rows = 10
      this.params.total = 0
      this.params.series2 = null
      if (this.params.series1 == 1388742017296 || this.params.series1 == 1379398885203 || this.params.series1 == 1374133285843) {
        this.tableData = []
      } else {
        this.showList()
      }
      /*else if (this.params.series1 == 1374133285843) {
        console.log('不渲染')
        this.tableData = []
      } else if (this.params.series1 == 1379398885203) {
        console.log('不渲染')
        this.tableData = []
      }*/
    },
    // 第2级
    searchSeriesTwo (val) {
      listSeriesByFonds({id: val}).then(res => {
        this.FondsAndRoleThree = res.data
      })
      this.params.page = 1
      this.params.rows = 10
      this.params.total = 0
      this.params.series3 = null
      this.showList()
    },
    // 档案类型第三级获取数据
    searchSeriesThree (val) {
      this.params.page = 1
      this.params.rows = 10
      this.params.total = 0
      this.showList()
      this.$forceUpdate()
    },
    // 上表格的多选
    handleSelectionChange (val) {
      this.onceTable = val
      if (this.onceTable.length == 1) {
        this.paramsTwo.page = 1
        this.paramsTwo.total = 0
        this.showListBtom()
      } else if (this.onceTable.length == 0) {
        this.tableDataTwo = []
        this.paramsTwo.page = 1
        this.paramsTwo.total = 0
      } else if (this.onceTable.length > 1 && this.onceTable.length <= 2) {
        this.$refs.multipleTable.toggleRowSelection(this.onceTable[0])
      }
    },
    // 单页选择
    handleCurrentChange (val) {
      this.params.page = val
      this.showList()
    },
    // 移交类型
    yjTypeBtn (val) {
      this.params.series1 = null
      this.params.series2 = null
      this.params.series3 = null
      this.FondsAndRole = []
      this.FondsAndRoleTwo = []
      this.FondsAndRoleThree = []
      // this.showSearchData()
      listSeriesByFondsAndRole({id: val}).then(res => {
        this.FondsAndRole = res.data
      })
      this.params.page = 1
      this.params.rows = 10
      this.params.total = 0
      this.showList()
    },
    yjTypeBtnTwo (val) {
      // this.showSearchData()
      listSeriesByFondsAndRole({id: val}).then(res => {
        this.FondsAndRole = res.data
      })
      this.params.page = 1
      this.params.rows = 10
      this.params.total = 0
      this.showList()
    },
    // 查看
    showLookBtn () {
      /*let item = this.$onceWay().onceTableList(this.onceTableBtom)
      if (item == 1) {
        this.treTable = []
        this.showEditLook = {}
        this.dialogShowLook = true
        let params = {
          id: this.onceTableBtom[0].fileId,
          gid: this.onceTableBtom[0].handoverId
        }
        listHandOverDocumentTree(params).then(res => {
          this.treTable = res.data
        })
        getHandOverFile({fileId: this.onceTableBtom[0].fileId}).then(res => {
          this.showEditLook = res.data
          this.showEditLook.openingType = this.$onceWay().showOpeningType(this.showEditLook.openingType)
          this.showEditLook.retentionPeriod = this.$onceWay().showRetentionPeriod(this.showEditLook.retentionPeriod)
          this.showEditLook.c58 = this.$onceWay().showC59(this.showEditLook.c58)
          this.showEditLook.c59 = this.$onceWay().showC59(this.showEditLook.c59)
          this.showEditLook.c93 = this.$onceWay().showC93(this.showEditLook.c93)
        })
      }*/
      let item = this.$onceWay().onceTableList(this.onceTableBtom)
      if (item == 1) {
        this.activeName = 'contentOnce'
        this.showEditLook = {}
        this.showCheckEmbed = true
        this.treTable = []
        this.dialogShowLook = true
        let params = {
          id: this.onceTableBtom[0].fileId,
          gid: this.onceTableBtom[0].handoverId
        }
        listHandOverDocumentTree(params).then(res => {
          this.treTable = res.data
        })
        checkExtendInfo(
          {
            id: this.onceTableBtom[0].fileId,
            type: 'f'
          }).then(res => {
          this.showView = res.data.optFlag
        })
        getHandOverFile({fileId: this.onceTableBtom[0].fileId}).then(res => {
          this.showEditLook = res.data
          this.showEditLook.openingType = this.$onceWay().showOpeningType(this.showEditLook.openingType)
          this.showEditLook.retentionPeriod = this.$onceWay().showRetentionPeriod(this.showEditLook.retentionPeriod)
          this.showEditLook.c58 = this.$onceWay().showC59(this.showEditLook.c58)
          this.showEditLook.c59 = this.$onceWay().showC59(this.showEditLook.c59)
          this.showEditLook.c93 = this.$onceWay().showC93(this.showEditLook.c93)
        })
        handoverExtendInfoView({
          id: this.onceTableBtom[0].fileId,
          type: 'f'
        }).then(res => {
          this.paramsView = res.data
        })
      }
    },
    // 弹框查看
    showLookBtnTwo () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.showEditLook = {}
        this.activeName = 'contentOnce'
        this.showCheckEmbed = true
        this.treTable = []
        this.dialogShowLook = true
        let params = {
          id: this.onceTableBtomTwo[0].fileId,
          gid: this.onceTableBtomTwo[0].handoverId
        }
        listHandOverDocumentTree(params).then(res => {
          this.treTable = res.data
        })
        checkExtendInfo(
          {
            id: this.onceTableBtomTwo[0].fileId,
            type: 'f'
          }).then(res => {
          this.showView = res.data.optFlag
        })
        getHandOverFile({fileId: this.onceTableBtomTwo[0].fileId}).then(res => {
          this.showEditLook = res.data
          this.showEditLook.openingType = this.$onceWay().showOpeningType(this.showEditLook.openingType)
          this.showEditLook.retentionPeriod = this.$onceWay().showRetentionPeriod(this.showEditLook.retentionPeriod)
          this.showEditLook.c58 = this.$onceWay().showC59(this.showEditLook.c58)
          this.showEditLook.c59 = this.$onceWay().showC59(this.showEditLook.c59)
          this.showEditLook.c93 = this.$onceWay().showC93(this.showEditLook.c93)
        })
        handoverExtendInfoView({
          id: this.onceTableBtomTwo[0].fileId,
          type: 'f'
        }).then(res => {
          this.paramsView = res.data
        })
      }
    },
    // 下表格表格的多选
    handleSelectionChangeBtom (val) {
      this.onceTableBtom = val
      if (this.onceTableBtom.length > 1) {
        this.$refs.multipleTableBtom.toggleRowSelection(this.onceTableBtom[0])
      }
    },
    // 弹框里下表格表格的多选
    handleSelectionChangeBtomTwo (val) {
      this.onceTableBtomTwo = val
      // if (this.onceTableBtomTwo.length > 1) {
      //   this.$refs.multipleTableBtomTwo.toggleRowSelection(this.onceTableBtomTwo[0])
      // }
    },
    // 页面最下方单页选择
    handleCurrentChangeTwo (val) {
      this.paramsTwo.page = val
      this.showListBtom()
    },
    handleSelectionChangeBtomThree (val) {
      this.onceTableBtomThree = val
    },
    // 页面最下方单页选择
    handleCurrentChangeThree (val) {
      this.paramsThree.page = val
      this.showListDelete()
    },
    handleClose () {
      this.dialogShowContent = false
    },
    handleCloseTwo () {
      this.dialogShowLook = false
      this.getDataViewDialog = false
      this.getDataViewDialog4 = false
      this.getDataViewDialog8 = false
      this.getDataViewDialog10 = false
      this.getDataViewDialog11 = false
      this.getDataViewDialog12 = false
      this.getDataViewDialog13 = false
      this.getDataViewDialog14 = false
      this.getDataViewDialog20 = false
      this.getDataViewDialog21 = false
      this.getDataViewDialog211 = false
      this.getDataViewDialog212 = false
      this.getDataViewDialog213 = false
      this.getDataViewDialog214 = false
      this.getDataViewDialog215 = false
      this.getDataViewDialog23 = false
      this.getDataViewDialog27 = false
    },
    handleCloseThree () {
      this.dialogShowLookTwo = false
      this.getDataViewDialog15 = false
      this.getDataViewDialog47 = false
      this.getDataViewDialog555 = false
    },
    // table标签页切换
    resetTable (val) {
      this.activeName = val.name
    },
    // 综合审核
    tureOverBtn () {
      let item = this.$onceWay().onceTableList(this.onceTable)
      if (item == 1) {
        // getQrYjList({cid: this.onceTable[0].cid}).then(res => {
        getArchiveYjList({subId: this.onceTable[0].cid}).then(res => {
          this.showEdit = res.data.data
          console.log(this.showEdit);
          this.dialogTable = JSON.parse(res.data.data.handoverRemark)
          if (this.dialogTable) {
            this.dialogTable.forEach((item, index) => {
              item.handoverRemark = item.handoverRemark.split('<br>')
            })
          }
          if (this.showEdit.handoverException != null && this.showEdit.handoverException != ''
            && this.showEdit.handoverException.indexOf('广发未办理盖章') == -1 && this.showEdit.handoverException.indexOf('未打印签署') == -1
            && this.showEdit.upStandard == null || this.showEdit.upStandard == '' && this.showEdit.remedial == null || this.showEdit.remedial == '') {
            // this.showEditBtn = true
            this.showEdit.isHandover = 1
          } else {
            // this.showEditBtn = false
            this.showEdit.isHandover = 0
          }
          if (this.showEdit.isHandover == 1) {
            this.showEditBtn = true
          } else {
            if (this.showEdit.jsBs == 'zxjs') {
              this.showEditBtn = false
            } else {
              this.showEditBtn = true
            }
          }
          this.receiveBtn()
          this.dialogShowContent = true
          this.showListBtom()
        })
      }
    },
    mangeBtn () {
      if (this.showEdit.applyRemarkCopy == null || this.showEdit.applyRemarkCopy == '' || this.showEdit.applyRemarkCopy == ' ') {
        this.$message.error('请填写意见')
      } else if (this.showEdit.handoverType == 2) {
        this.mangeBtnTwo()
      } else if (this.showEdit.handoverType == 0) {
        if (this.showEdit.handoverType == null || this.showEdit.handoverType == '') {
          this.$message.error('请选择邮寄方式')
        } else if (this.showEdit.receiveAddress == null || this.showEdit.receiveAddress == '') {
          this.$message.error('请填写邮寄地址')
        } else if (this.showEdit.handoverYys == null || this.showEdit.handoverYys == '') {
          this.$message.error('请选择运营商')
        } else {
          this.mangeBtnTwo()
        }
      } else {
        this.mangeBtnTwo()
      }
    },
    mangeBtnTwo () {
      for (let i in this.dialogTableBtom) {
        if (this.dialogTableBtom[i].handoverException != '' && this.dialogTableBtom[i].handoverException != null && this.dialogTableBtom[i].handoverException != '广发未办理盖章') {
          this.showEdit.isHandover = '1'
          break
        } else {
          this.showEdit.isHandover = '0'
        }
      }
      if (this.onceTable[0].handoverUser != '' && this.onceTable[0].handoverUser != null) {
        this.showEdit.isHandover = '1'
      }
      this.showEdit.subId = this.onceTable[0].cid
      // this.showEdit.bs = 'yz'
      this.showEdit.handoverRemark = this.showEdit.applyRemarkCopy
      this.getDataViewDialog = true
    },
    // 模糊查询确定按钮
    submitBtn1 () {
      if (this.showEdit.receiveUser == undefined || this.showEdit.receiveUser == null) {
        this.$message.error('当前接收人为空，不能进行移交！')
      } else {
        zhyHandOverSave(this.showEdit).then(res => {
          if (res.data.optFlag == 2) {
            this.$message.error('系统提示, "确认失败，当前移交状态的移交单已被其他用户处理了"')
          } else if (res.data.optFlag == 1) {
            this.$message.success('成功')
            this.handleClose()
            this.handleCloseTwo()
            this.showList()
          } else {
            this.$message.success('失败')
          }
        })
      }
    },
    // 邮寄方式选择
    receiveBtn () {
      if (this.showEdit.handoverType == 2) {
        this.showDisable = true
        this.showEdit.handoverYys = null
        this.showEdit.handoverYdh = null
        this.showEdit.receiveAddress = null
      } else if (this.showEdit.handoverType == 1) {
        this.showDisable = false
      }
    },
    // 上传
    showLookBtn7 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.getDataViewDialog8 = true
        this.clearImgDel()
      }
    },
    clearImgDel () {
      this.imgVal = []
      if (this.$refs.AddBtnImgTwo) {
        this.$nextTick(() => {
          this.$refs.AddBtnImgTwo.clearFiles()
        })
      }
      if (this.$refs.AddBtnImgOne) {
        this.$nextTick(() => {
          this.$refs.AddBtnImgOne.clearFiles()
        })
      }
    },
    // 删除附件
    showLookBtn10 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.getDataViewDialog10 = true
        this.showListDelete()
      }
    },
    showListDelete () {
      this.paramsDelete.subId = this.onceTableBtomTwo[0].id
      listHandOverDocumentData(this.paramsDelete).then(res => {
        this.deleteTable = res.data.rows
        this.paramsDelete.total = res.data.total
      })
    },
    // 删除上传
    handleRemove (val) {
      this.imgVal.splice(val, 1)
    },
    handleChange (file, fileList) {
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('type', 'yj')
      formData.append('name', 'file')
      uploadPicture(formData).then(res => {
        if (res.code == 0) {
          this.imgVal.push(res.data.pathAndMD5)
        } else {
          this.$message.error(res.message)
        }
      })
    },
    submitBtn8 () {
      let params = {
        subId: this.onceTableBtomTwo[0].fileId,
        detailId: this.onceTableBtomTwo[0].id,
        gid: this.onceTableBtomTwo[0].handoverId,
        imgVal: JSON.stringify(this.imgVal),
        bs: this.onceTableBtomTwo[0].handoverType == 0 ? 'jqyj' : 'mhyj'
      }
      saveUploadYjDoc(params).then(res => {
        if (res.data.optFlag == 0) {
          this.$message.success('上传成功')
          this.getDataViewDialog8 = false
          this.showListBtom()
        } else if (res.data.optFlag == 1) {
          this.$message.error('上传失败，' + res.data.msg)
        } else if (res.data.optFlag == -1) {
          this.$message.error('上传失败，因为文件' + res.data.msg + '已上传过了，请重新选择上传文件')
        }
      })
    },
    tableDeleteFile () {
      let item = this.$onceWay().onceTableListTwo(this.onceTableBtomThree)
      if (item == 1) {
        this.getDataViewDialog11 = true
      }
    },
    submitBtn9 () {
      let params = {
        subId: this.onceTable[0].gid,
        imgVal: this.imgVal
      }
      uploadExcel(params).then(res => {
        if (res.optFlag == 0) {
          this.$message.success(res.msg)
          this.getDataViewDialog9 = false
          this.showListBtom()
        } else {
          this.$message.error(res.msg)
          this.getDataViewDialog9 = false
          this.showListBtom()
        }
      })
    },
    submitBtn11 () {
      let item = this.$onceWay().deleteId(this.onceTableBtomThree)
      let params = {
        ids: item,
        bs: this.onceTableBtomTwo[0].handoverType == 0 ? 'jqyj' : 'mhyj'
      }
      deleteDoc(params).then(res => {
        if (res.data.optFlag == 0) {
          this.$message.success('删除成功')
          this.getDataViewDialog11 = false
          this.showListDelete()
        } else {
          this.$message.error('删除失败')
          this.getDataViewDialog11 = false
          this.showListDelete()
        }
      })
    },
    // 异常
    showLookBtn11 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.getDataViewDialog12 = true
        this.clearRefs()
        if (this.onceTableBtomTwo[0].handoverException) {
          if (this.onceTableBtomTwo[0].handoverException.split(',').length >= 2) {
            let a = this.onceTableBtomTwo[0].handoverException.split(',')
            a.forEach((item, index) => {
              // if (item == '原件不完整（对方未盖章）') this.checkParams.contentOne = '原件不完整（对方未盖章）'
              if (item == '原件不完整（对方未盖章）') {
                this.$nextTick(() => {
                  this.$refs.contentOne.model = '原件不完整（对方未盖章）'
                })
              }
              if (item == '原件不完整（无签署时间）') {
                this.$nextTick(() => {
                  this.$refs.contentTwo.model = '原件不完整（无签署时间）'
                })
              }
              if (item == '原件不完整（缺失授权书）') {
                this.$nextTick(() => {
                  this.$refs.contentThree.model = '原件不完整（缺失授权书）'
                })
              }
              if (item == '原件不完整（对方未签名）') {
                this.$nextTick(() => {
                  this.$refs.contentFour.model = '原件不完整（对方未签名）'
                })
              }
              if (item == '原件不完整（缺失部分页）') {
                this.$nextTick(() => {
                  this.$refs.contentFive.model = '原件不完整（缺失部分页）'
                })
              }
              if (item == '广发未办理盖章') {
                this.$nextTick(() => {
                  this.$refs.hException1.model = '广发未办理盖章'
                })
              }
              if (item == '未打印签署') {
                this.$nextTick(() => {
                  this.$refs.hException2.model = '未打印签署'
                })
              }
            })
          } else {
            if (this.onceTableBtomTwo[0].handoverException == '(A1)合同各方已盖章，且已履行完毕') {
              this.$nextTick(() => {
                this.$refs.hException3.model = '(A1)合同各方已盖章，且已履行完毕'
              })
            }
            if (this.onceTableBtomTwo[0].handoverException == '(A2)合同各方已盖章，且正在履行') {
              this.$nextTick(() => {
                this.$refs.hException4.model = '(A2)合同各方已盖章，且正在履行'
              })
            }
            if (this.onceTableBtomTwo[0].handoverException == '自留函') {
              this.$nextTick(() => {
                this.$refs.hException4.model = '自留函'
                this.checkParams.zlhDate = this.onceTableBtomTwo[0].handoverDate
                this.selectDisTwo()
              })
            }
            if (this.onceTableBtomTwo[0].handoverException == '(A3)合同各方已盖章，合同不再履行') {
              this.$nextTick(() => {
                this.$refs.hException5.model = '(A3)合同各方已盖章，合同不再履行'
              })
            }
            if (this.onceTableBtomTwo[0].handoverException == '(A4)合同仅有我方盖章') {
              this.$nextTick(() => {
                this.$refs.hException6.model = '(A4)合同仅有我方盖章'
              })
            }
          }
        }
        // 达标措施
        console.log(this.onceTableBtomTwo[0].upStandard)
        if (this.onceTableBtomTwo[0].upStandard) {
          if (this.onceTableBtomTwo[0].upStandard.split(')').length >= 2) {
            let a = this.onceTableBtomTwo[0].upStandard.split(')')
            a.forEach(item => {
              if (item == '补充整改完成后原件归档') {
                this.$nextTick(() => {
                  this.$refs.checkBosSeven.model = '补充整改完成后原件归档'
                })
              }
            })
          } else {
            if (this.onceTableBtomTwo[0].upStandard == '补充整改完成后原件归档') {
              this.$nextTick(() => {
                this.$refs.checkBosSeven.model = '补充整改完成后原件归档'
              })
            }
            if (this.onceTableBtomTwo[0].upStandard == '已补签') {
              if (this.onceTableBtomTwo[0].handoverException == '(A1)合同各方已盖章，且已履行完毕') {
                this.$nextTick(() => {
                  this.$refs.checkBosOne.model = '已补签'
                })
              }
              if (this.onceTableBtomTwo[0].handoverException == '(A2)合同各方已盖章，且正在履行' || this.onceTableBtomTwo[0].handoverException == '自留函') {
                this.$nextTick(() => {
                  this.$refs.checkBosThree.model = '已补签'
                })
              }
            }
            if (this.onceTableBtomTwo[0].upStandard == '已变更、解除、终止') {
              this.$nextTick(() => {
                this.$refs.checkBosFour.model = '已变更、解除、终止'
              })
            }
            if (this.onceTableBtomTwo[0].upStandard == '已全部回收') {
              this.$nextTick(() => {
                this.$refs.checkBosFive.model = '已全部回收'
              })
            }
            if (this.onceTableBtomTwo[0].upStandard == '补充整改完成后原件归档') {
              this.$nextTick(() => {
                this.$refs.checkBosSeven.model = '补充整改完成后原件归档'
              })
            }
          }
        }
        // 补救措施
        if (this.onceTableBtomTwo[0].remedial) {
          if (this.onceTableBtomTwo[0].remedial == '复印件等附件归档') {
            this.$nextTick(() => {
              this.$refs.checkBosTwo.model = '复印件等附件归档'
            })
          }
          if (this.onceTableBtomTwo[0].remedial == '已有遗失说明') {
            this.$nextTick(() => {
              this.$refs.checkBosSix.model = '已有遗失说明'
            })
          }
        }
        this.$nextTick(() => {
          this.selectDis()
        })
      }
    },
    selectDis (val) {
      if (this.checkParams.hException1 == '广发未办理盖章' || this.checkParams.hException2 == '未打印签署') {
        this.disYj = false
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (this.checkParams.hException3 == '(A1)合同各方已盖章，且已履行完毕') {
        this.disYj = true
        this.disHtOne = false
        this.disHtOneTwo = false
        this.disHtThreeTwoFy = false
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (this.checkParams.hException4 == '(A2)合同各方已盖章，且正在履行') {
        this.disYj = true
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = false
        this.disHtTwoOnce = true
        this.disHtTwoTwo = false
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (this.checkParams.hException5 == '(A3)合同各方已盖章，合同不再履行') {
        this.disYj = true
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = false
        this.disHtThreeTwo = false
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (this.checkParams.hException6 == '(A4)合同仅有我方盖章') {
        this.disYj = true
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = false
        this.disHtFourTwo = false
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (
        this.checkParams.contentOne == '原件不完整（对方未盖章）' ||
        this.checkParams.contentTwo == '原件不完整（无签署时间）' ||
        this.checkParams.contentThree == '原件不完整（缺失授权书）' ||
        this.checkParams.contentFour == '原件不完整（对方未签名）' ||
        this.checkParams.contentFive == '原件不完整（缺失部分页）'
      ) {
        this.disYj = true
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = false
        this.disHtBTwo = false
        this.disHtBThree = false
        this.disHtBFour = false
        this.disHtBFive = false
        this.disHtBOnceTwo = false
      } else if (
        this.checkParams.hException1 == undefined &&
        this.checkParams.hException2 == undefined &&
        this.checkParams.hException3 == undefined &&
        this.checkParams.hException4 == undefined &&
        this.checkParams.zlhDateOne == undefined
      ) {
        this.$refs.checkBosOne.model = false
        this.$refs.checkBosTwo.model = false
        this.$refs.checkBosThree.model = false
        this.$refs.checkBosFour.model = false
        this.$refs.checkBosFive.model = false
        this.$refs.checkBosSix.model = false
        this.$refs.checkBosSeven.model = false
        this.disCheckAbel()
      }
      // else if (this.checkParams.hException3 == undefined && this.checkParams.remedial2 == undefined && this.checkParams.upStandard2 == undefined) {
      //   console.log(22);
      //   this.disCheckAbel()
      // }
      else if (
        this.checkParams.hException4 == undefined &&
        this.checkParams.upStandard3 == undefined &&
        this.checkParams.zlhDateOne == undefined &&
        this.checkParams.zlhDate == undefined) {
        this.disCheckAbel()
      }
      if (this.checkParams.upStandard2 == '已补签') {
        console.log(1);
        this.disYj = true
        this.disHtOne = false
        this.disHtOneTwo = false
        this.disHtThreeTwoFy = true
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (this.checkParams.remedial2 == '复印件等附件归档') {
        console.log(2);
        this.disYj = true
        this.disHtOne = false
        this.disHtOneTwo = true
        this.disHtThreeTwoFy = false
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      }
    },
    selectDisTwo (val) {
      if (this.checkParams.hException4 == '自留函') {
        this.$message.info('请于出具自留函之日起6个月内完成全部合同归档，到期未完成将纳入合同异常归档考核！')
        this.disYj = true
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = true
        this.disHtTwoOnce = false
        this.disHtTwoTwo = false

        this.disHtTwoDate = true

        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (
        this.checkParams.hException1 == undefined &&
        this.checkParams.hException2 == undefined &&
        this.checkParams.hException3 == undefined &&
        this.checkParams.hException4 == undefined &&
        this.checkParams.zlhDateOne == undefined
      ) {
        this.$refs.checkBosOne.model = false
        this.$refs.checkBosTwo.model = false
        this.$refs.checkBosThree.model = false
        this.$refs.checkBosFour.model = false
        this.$refs.checkBosFive.model = false
        this.$refs.checkBosSix.model = false
        this.$refs.checkBosSeven.model = false
        this.disCheckAbel()
      }
      /* else {
          this.disYj = false
          this.disHtOne = false
          this.disHtOneTwo = false
          this.disHtTwo = false
          this.disHtTwoTwo = false
          this.disHtThree = false
          this.disHtThreeTwo = false
          this.disHtFour = false
          this.disHtFourTwo = false
          this.disHtBOne = false
          this.disHtBTwo = false
          this.disHtBThree = false
          this.disHtBFour = false
          this.disHtBFive = false
          this.disHtBOnceTwo = false
          this.disHtTwoDate = false
        } */
    },
    disCheckAbel () {
      this.disYj = false
      this.disHtOne = false
      this.disHtOneTwo = true
      this.disHtTwo = false
      this.disHtTwoOnce = false
      this.disHtTwoDate = false
      this.disHtTwoTwo = true
      this.disHtThree = false
      this.disHtThreeTwo = true
      this.disHtFour = false
      this.disHtFourTwo = true
      this.disHtBOne = false
      this.disHtBTwo = false
      this.disHtBThree = false
      this.disHtBFour = false
      this.disHtBFive = false
      this.disHtBOnceTwo = true
      this.checkParams = {}
    },
    errorCheckBtn () {
      this.checkParams.subId = this.onceTableBtomTwo[0].id
      this.checkParams.bs = this.onceTableBtomTwo[0].handoverType == 0 ? 'jqyj' : 'mhyj'
      let one = []
      let two = ''
      one.push(this.checkParams.contentOne)
      one.push(this.checkParams.contentTwo)
      one.push(this.checkParams.contentThree)
      one.push(this.checkParams.contentFour)
      one.push(this.checkParams.contentFive)
      one.forEach((item, index) => {
        if (item) {
          two += item + ','
        }
      })
      if (this.checkParams.hException1 && this.checkParams.hException2) {
        this.checkParams.hException1 = this.checkParams.hException1 + ',' + this.checkParams.hException2
      }
      this.checkParams.hException7 = two
      saveHandoverYc(this.checkParams).then(res => {
        if (res.data.optFlag == 1) {
          let params = {
            id: this.onceTableBtomTwo[0].id,
            subId: this.onceTableBtomTwo[0].fileId,
            isOriginal: this.onceTableBtomTwo[0].isOriginal
          }
          saveIsOriginal(params).then(res => {
            if (res.data.optFlag == 0) {
              this.$message.success('处理结果：成功')
              this.getDataViewDialog12 = false
              this.showListBtom()
            } else if (res.data.optFlag == -1) {
              this.$message.error('处理结果：失败')
              this.getDataViewDialog12 = false
              this.showListBtom()
            }
          })
        } else if (res.data.optFlag == -1) {
          this.$message.error('处理结果：失败')
          this.getDataViewDialog12 = false
          this.showListBtom()
        }
      })
    },
    clearRefs () {
      this.$nextTick(() => {
        this.$refs.hException1.model = false
        this.$refs.hException2.model = false
        this.$refs.hException3.model = false
        this.$refs.checkBosOne.model = false
        this.$refs.checkBosTwo.model = false
        this.$refs.hException4.model = false
        this.$refs.checkBosThree.model = false
        this.$refs.hException5.model = false
        this.$refs.checkBosFour.model = false
        this.$refs.hException5.model = false
        this.$refs.hException6.model = false
        this.$refs.checkBosFive.model = false
        this.$refs.checkBosSix.model = false
        this.$refs.checkBosSeven.model = false
        this.$refs.contentOne.model = false
        this.$refs.contentTwo.model = false
        this.$refs.contentThree.model = false
        this.$refs.contentFour.model = false
        this.$refs.contentFive.model = false
        this.checkParams = {}
      })
    },
    // 合同异常归档下载
    wordPullBtn () {
      wordPull(`gdda-new/gdda/archiveYj/downLoadCzExplain`, '合同异常归档操作说明')
    },
    // 修改附件
    showLookBtn13 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.getDataViewDialog14 = true
        this.showListDelete()
      }
    },
    tableDeleteFileTwo () {
      let item = this.$onceWay().onceTableListTwo(this.onceTableBtomThree)
      if (item == 1) {
        this.getDataViewDialog15 = true
        this.showEditLookTitle = JSON.parse(JSON.stringify(this.onceTableBtomThree[0].titleProper))
      }
    },
    submitBtn14 () {
      let params = {
        titleProper: this.showEditLookTitle,
        subId: this.onceTableBtomThree[0].id,
        id: this.onceTableBtomThree[0].id
      }
      editDocTitle(params).then(res => {
        if (res.data.optFlag == 1) {
          this.$message.success('修改成功')
          this.showListDelete()
          this.getDataViewDialog15 = false
        } else {
          this.$message.error('修改失败')
          this.showListDelete()
          this.getDataViewDialog15 = false
        }
      })
    },
    // 移交详情
    showLookBtn16 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        getYjInformation({subId: this.onceTableBtomTwo[0].id}).then(res => {
          this.paramsEditContent = res.data
          this.getDataViewDialog20 = true
        })
      }
    },
    radioCompletes (val) {
      this.paramsEditContent.completes = val
      this.$forceUpdate()
    },
    submitBtn17 () {
      let params = {
        subId: this.onceTableBtomTwo[0].id,
        completes: this.paramsEditContent.completes
      }
      saveYjInfoData(params).then(res => {
        if (res.data.optFlag == 0) {
          this.$message.success('修改成功')
          this.getDataViewDialog20 = false
          this.showListBtom()
        } else {
          this.$message.error('修改失败')
          this.getDataViewDialog20 = false
        }
      })
    },
    // 查看合同-- 有BUG
    submitBtn4 () {
      let reg = /^[0-9]*$/
      if (this.showEditLook.titleProper == undefined) {
        this.$message.error('请填写题名')
      } else if (this.showEditLook.dateOfCreation == undefined) {
        this.$message.error('请选择时间')
      } else if (this.showEditLook.yearCode == undefined || this.showEditLook.yearCode.length < 4 || this.showEditLook.yearCode.length > 4) {
        this.$message.error('请填写年度(输入长度为4）')
      } else if (!reg.test(this.showEditLook.yearCode)) {
        this.$message.error('年度只能填写数字')
      } else {
        if (this.showBtnLook) {
          this.showEditLook.subId = this.showEditLookSubId
          this.showEditLook.bs = 'qjym'
        } else {
          this.showEditLook.subId = this.onceTable[0].gid
          this.showEditLook.bs = this.onceTable[0].handoverType == 0 ? 'jqyj' : 'mhyj'
        }
        saveMhYjFile(this.showEditLook).then(res => {
          if (res.data.optFlag == 1) {
            // this.$message.success('录入成功')
            this.$message.success(res.message)
            this.getDataViewDialog4 = false
            if (this.showBtnLook) {
              this.showLookBtn44List()
            } else {
              this.showListBtom()
            }
          } else {
            // this.$message.error('录入失败')
            this.$message.error(res.message)
            this.getDataViewDialog4 = false
          }
        })
      }
    },
    restBtn () {
      if (this.showBtnLook) {
        findSeriesCode({id: this.showEditLookSubId}).then(res => {
          this.showEditLook = res.data
        })
      } else {
        this.showEditLookSubId = ''
        findSeriesCode({id: this.onceTable[0].gid}).then(res => {
          this.showEditLook = res.data
        })
      }
    },
    // 检索
    searchContent () {
      let fk = null
      if (this.params.series1 == 1379482316593 || this.params.series1 == 1383033168454) {
        fk = 1
      } else if (this.params.series1 == 1388742017296) {
        if (this.params.series2 == 1388742017297 || this.params.series2 == 1388742017298) {
          fk = 2
        } else {
          fk = 1
        }
      } else if (this.params.series1 == 1388742017269) {
        fk = 3
      } else if (this.params.series1 == 1374133285843) {
        if (this.params.series2 == 1374133285844) {
          fk = 4
        } else if (this.params.series2 == 1374133285845) {
          fk = 5
        }
      } else if (this.params.series1 == 1374133285828) {
        fk = 6
      }
      this.params = {
        page: 1,
        rows: 10,
        status: this.params.status,
        fonds: this.params.fonds,
        series1: this.params.series1,
        searchType: fk,
        total: this.params.total
      }
      if (this.params.series1 == 1388742017296) {
        this.getDataViewDialog211 = true
      } else if (this.params.series1 == 1388742017269) {
        this.getDataViewDialog212 = true
      } else if (this.params.series1 == 1374133285843) {
        if (this.params.series1 == 1374133285844) {
          this.getDataViewDialog213 = true
        } else {
          this.getDataViewDialog214 = true
        }
      } else if (this.params.series1 == 1374133285828) {
        this.getDataViewDialog215 = true
      } else {
        this.getDataViewDialog21 = true
      }
    },
    // 检索
    submitBtn18 () {
      this.showList()
      this.getDataViewDialog21 = false
    },
    reset () {
      this.params = {
        page: 1,
        rows: 10,
        status: this.params.status,
        fonds: this.params.fonds,
        series1: this.params.series1,
        searchType: this.params.searchType,
        total: this.params.total
      }
    },
    // 监所内的搜索
    remoteMethodUser (val) {
      let params = {
        orgFlag1: -10000,
        q: val
      }
      searchFindUser(params).then(res => {
        this.yjcurrentuserArr = res
      })
    },
    // 监所内的搜索
    remoteMethodMan (val) {
      let params = {
        orgFlag1: -10000,
        q: val
      }
      searchFindUser(params).then(res => {
        this.yjc89Arr = res
      })
    },
    // 重新发送代办
    retryBtn () {
      let item = this.$onceWay().onceTableList(this.onceTable)
      if (item == 1) {
        this.getDataViewDialog23 = true
      }
    },
    submitBtn19 () {
      sendZhyShDb({id: this.onceTable[0].cid}).then(res => {
        if (res.data.optFlag == 1) {
          this.$message.success('发送成功')
          this.getDataViewDialog23 = false
          this.showList()
        } else {
          this.$message.error(res.data.msg)
          this.getDataViewDialog23 = false
        }
      })
    },
    // 导出合同移交登记表
    submitBtn27 () {
      if (this.paramsDownload.exportHandoverDept == null || this.paramsDownload.exportHandoverDept == '') {
        this.$message.error('请选择移交部门')
      } else if (this.paramsDownload.exportStartDate == null || this.paramsDownload.exportStartDate == '') {
        this.$message.error('请选择导出时间（起）')
      } else if (this.paramsDownload.exportEndDate == null || this.paramsDownload.exportEndDate == '') {
        this.$message.error('请选择导出时间（止）')
      } else {
        valueIndex().exportFiles('/gdda-new/gdda/archiveYj/exportHtTable', this.paramsDownload, '导出合同移交登记表.xls', 'get')
      }
      // exportHtTable(this.paramsDownload).then(res => {
      //   console.log(res);
      // })
    },
    // 移交退回
    tuiHuiBtn () {
      if (this.showEdit.applyRemarkCopy == null || this.showEdit.applyRemarkCopy == undefined || this.showEdit.applyRemarkCopy == '') {
        this.$message.error('请填写意见')
      } else {
        let params = {
          type: this.onceTable[0].handoverStyle == 0 ? 'jqyj' : 'mhyj',
          gid: this.onceTable[0].gid
        }
        countHandOverDetail(params).then(res => {
          if (res.data.optFlag == -1) {
            this.$message.error('系统提示, "移交失败，系统出错')
          } else if (res.data.optFlag == 2) {
            this.$message.error('系统提示, "确认失败，当前移交状态的移交单已被其他用户处理了')
          } else {
            this.showEdit.gid = this.onceTable[0].gid
            this.showEdit.subId = this.onceTable[0].cid
            this.showEdit.handoverRemark = this.showEdit.applyRemarkCopy
            this.isHander()
            handOverBack(this.showEdit).then(res => {
              if (res.data.optFlag == 1) {
                this.$message.success('退回成功')
                this.handleCloseTwo()
                this.handleClose()
                this.showList()
              } else if (res.data.optFlag == 2) {
                this.$message.error('已被处理')
                this.handleCloseTwo()
                this.handleClose()
                this.showList()
              } else {
                this.$message.error('退回失败')
                this.handleCloseTwo()
                this.handleClose()
                this.showList()
              }
            })
          }
        })
      }
    },
    // 移交归档
    tuiHuiBtnTwo () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        let params = {
          fileId: this.onceTableBtomTwo[0].id,
          subId: this.onceTable[0].gid,
        }
        gdHandOverFile(params).then(res => {
          if (res.data.optFlag == 1) {
            this.$message.success('归档成功')
            this.handleCloseThree()
            this.handleCloseTwo()
            this.handleClose()
            this.showList()
          } else {
            this.$message.error('归档失败')
          }
        })
      }
    },
    // 判断是否有异常
    isHander () {
      for (let i in this.dialogTableBtom) {
        if (this.dialogTableBtom[i].handoverException != '' && this.dialogTableBtom[i].handoverException != null && this.dialogTableBtom[i].handoverException != '广发未办理盖章') {
          this.showEdit.isHandover = '1'
          break
        } else {
          this.showEdit.isHandover = '0'
        }
      }
      if (this.onceTable[0].handoverUser != '' && this.onceTable[0].handoverUser != null) {
        this.showEdit.isHandover = '1'
      }
    },
    lookFileContent (val, item) {
      this.activeName = 'contentOnce'
      this.showEditLookTwo = {}
      let types = val
      let ids = item.id
      this.showViewTwoId = item
      this.showCheckEmbed = true
      // 左侧树
      listTreeJson({id: ids, type: types}).then(res => {
        this.treTableTwo = res.data.data
        this.attributesType = this.treTableTwo[0].attributes.type
      })
      // 右侧基本信息
      listTreeJsonView({id: ids, type: types}).then(res => {
        if (types == 'f') {
          this.showEditLookTwo = res.data.file
        } else if (types == 'v') {
          this.showEditLookTwo = res.data.folder
        } else if (types == 'p') {
          this.showEditLookTwo = res.data.project
        }
      })
      // 判断右侧是否有关键档案
      checkExtendInfo().then(res => {
        this.showViewTwo = res.data.optFlag
      })
      // 右侧关键档案
      extendInfoView({id: ids, type: types}).then(res => {
        this.paramsViewTwo = res.data
      })
      this.dialogShowLookTwo = true
    },

    // 查看合同信息
    showLookBtn14 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.showEditLook = {
          clientName: null,
          clientType: null,
          papersType: null,
          papersNo: null,
          productCode: null,
          taCode: null
        }
        // getHTInfo({subId: this.onceTableBtomTwo[0].fileId}).then(res => {
        getHTInfo({subId: this.onceTableBtomTwo[0].id}).then(res => {
        // getHTInfo({subId: 1575355574151}).then(res => {
          if (res.data) {
            if (res.data.fileType != '' || res.data.fileType != undefined) { this.showContentType(res.data.fileType) }
            if (res.data.clientType != '' || res.data.clientType != undefined) { this.showContentTypeTwo(res.data.clientType) }
            this.showEditLook = res.data
            // let arr = ''
            if (this.showEditLook.productName != '' || this.showEditLook.productName != undefined || this.showEditLook.productName != ' ') {
              getProductCodeAndTACode({prodname: res.data.productName}).then(res => {
                // arr = res.data
                // this.showEditLook.productCode = JSON.parse(JSON.stringify(res.data.productCode))
                this.showEditLook.productCode = res.data.productCode
                // this.showEditLook.taCode = JSON.parse(JSON.stringify(res.data.taCode))
                this.showEditLook.taCode = res.data.taCode
                this.getDataViewDialog555 = true
                this.$forceUpdate()
              })
            }
          } else {
            // this.getDataViewDialog555 = true
            this.$message.info('没有找到相关的合同')
          }
        })
      }
    },
    productNameChange (val) {
      listProductName({q: val}).then(res => {
        this.productNameArr = res.data
        getProductCodeAndTACode({prodname: val}).then(res => {
          this.showEditLook.taCode = res.data.taCode
          this.showEditLook.productCode = res.data.productCode
        })
      })
    },
    showContentType (val) {
      this.showEditLook.clientName = ''
      this.showEditLook.clientType = ''
      this.showEditLook.papersType = ''
      this.showEditLook.papersNo = ''
      if (val == '基金合同' || val == '补充协议' || val == '证券经纪服务协议' || val == '期货投资操作备忘录') {
        this.disSelectContent = true
      } else {
        this.disSelectContent = false
      }
    },
    showContentTypeTwo (val) {
      this.showEditLook.papersType = ''
      if (val == '个人') {
        this.papersTypeArrOnce = this.papersTypeArr
      } else {
        this.papersTypeArrOnce = this.papersTypeArrTwo
      }
    },
    showContentTypeThree (val) {
      this.showEditLook.papersType = val
      this.$forceUpdate()
    },
    opoUp () {
      this.showEditLook.productCode = JSON.parse(JSON.stringify(this.showEditLook.productCode))
      this.$forceUpdate()
    },
    opoUpTwo () {
      this.showEditLook.taCode = JSON.parse(JSON.stringify(this.showEditLook.taCode))
      this.$forceUpdate()
    },
    submitBtn555 () {
      // this.showEditLook.subId = this.onceTableBtomTwo[0].fileId
      this.showEditLook.subId = this.onceTableBtomTwo[0].id
      // this.showEditLook.subId = 1575355574151
      saveHTInfo(this.showEditLook).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.getDataViewDialog555 = false
          this.showListBtom()
        } else {
          this.$message.error(res.message)
        }
      })
    },
    newHandShow (val) {
      this.showEdit.handoverYys = val
      this.$forceUpdate()
    }
  },
  created () {
    this.showSearchData()
    this.showList()
    listAllDept().then(res => {
      this.yjc90Arr = res.data
    })
    listFileType().then(res => {
      this.fileTypeArr = res.data
    })
    listGzdj().then(res => {
      this.yjc112Arr = res.data
    })
  }
}
</script>

<style scoped lang="less">
  @import '../../css/public';
  .editorXinTwo {
    margin-bottom: 6px;
    label{
      display: inline-block;
      width: 109px;
      text-align: right;
    }
    .el-input, .el-select{
      width: 70%;
    }
  }
  .search-select {
    float: left;
    margin: 0 8px;
    label {
      font-size: 14px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 143px;
    }
  }
  .search-selectOnce{
    margin:1px 6px;
    height: 35px;
    border:1px solid #DEDEDE;
  }

  .mangeShowLook{
    margin-bottom: 10px;
    li{
      float: left;
      width: 268px;
      .el-input, .el-select{
        width: 62%;
      }
      label{
        display: inline-block;
        width: 96px;
        text-align: right;
      }
      /deep/.el-input.is-disabled .el-input__inner{
        background-color: #fff!important;
        color: #606266!important;
      }
    }
  }
  .searchBtn{
    float: left;
    line-height: 47px;
    font-size: 13px;
    cursor: pointer;
    margin: 0 8px;
    img{
      vertical-align: middle;
      margin-right: 4px;
    }
  }
  .search-selectOnce{
    margin: 5px 6px;
    height: 35px;
    border:1px solid #DEDEDE;
    cursor: auto;
  }
  .showClearLook{
    height: 600px;
    overflow: auto;
  }
  .mangeShow{
    margin-bottom: 10px;
    li{
      float: left;
      width: 350px;
      .el-input, .el-select{
        width: 62%;
      }
      label{
        display: inline-block;
        width: 96px;
        text-align: right;
      }
      /deep/.el-input.is-disabled .el-input__inner{
        background-color: #fff!important;
        color: #606266!important;
      }
    }
  }
  .maxHeight{
    max-height: 300px;
    overflow: auto;
  }
  .mangeShowList{
    margin-bottom: 10px;
    >p{
      width: 99px;
      text-align: right;
    }
    >label{
      display: inline-block;
      width: 99px;
      text-align: right;
      vertical-align: top;
    }
    .heTong {
      display: inline-block;
      width: 86%;
      color: red;
    }
    .el-textarea{
      width: 86%;
    }
  }
  .showReadOnlyContent {
    width: 82%;
    margin: 0 auto;
    border: 1px solid #E4E7ED;
    min-height: 200px;
    padding: 6px;
    max-height: 200px;
    overflow: auto;
  }

  .anomalyError{
    width: 993px;
    border: 1px solid;
    >div{
      float:left;
      border:1px solid;
      height: 40px;
      line-height: 40px;
    }
    .anomalyErrorOne{
      width: 182px;
      text-align: right;
    }
    .anomalyErrorTwo{
      text-indent: 2px;
      width: 333px;
      /deep/.el-checkbox__label{
        padding-top: 2px;
        font-size: 16px;
      }
    }
    .anomalyErrorThree{
      width: 235px;
      text-indent: 2px;
      /deep/.el-checkbox__label{
        padding-top: 2px;
        font-size: 16px;
      }
    }
  }
  .ErrorCenter{
    text-align: center;
  }
  .anomalyErrorOnceTwo{
    width: 993px;
    font-size: 20px;
    border: 1px solid;
    >div{
      float:left;
      border:1px solid;
      height: 40px;
    }
    .anomalyErrorOne{
      width: 182px;
      height: 205px;
      line-height: 205px;
      text-align: right;
    }
    .anomalyErrorTwo{
      float: left;
      width: 333px;
      height: 100%;
      text-indent: 2px;
      line-height: 40px;
      border: 1px solid;
      /deep/.el-checkbox__label{
        padding-top: 2px;
        font-size: 16px;
      }
    }
    .anomalyErrorThree{
      float: left;
      width: 234px;
      height: 100%;
      text-indent: 2px;
      line-height: 40px;
      border: 1px solid;
      /deep/.el-checkbox__label{
        padding-top: 2px;
        font-size: 16px;
      }
    }
    .anomalyErrorOnceThree{
      width: 333px;
      height: 39px;
      text-indent: 2px;
      line-height: 40px;
      border: 1px solid;
      /deep/.el-checkbox__label{
        padding-top: 2px;
        font-size: 16px;
      }
    }
    .anomalyErrorOnceFour{
      width: 182px;
      height: 204px;
      line-height: 204px;
      text-align: right;
    }
    .pickerSelect{
      width: 190px;
      /deep/.el-input__inner{
        height: 28px;
      }
    }
  }
  .showContentDownload{
    width: 993px;
    margin-top: 10px;
    font-size: 16px;
    span{
      color: #01ABE7;
      cursor: pointer;
    }
  }
  .clientAdd{
    /deep/.el-input__inner{
      height: 30px;
      width: 88%;
    }
  }
</style>

<style lang="less">
  .elTabsCssMange{
    >.el-tabs__header{
      .el-tabs__item{
        width: 129px;
        margin: 0;
        border-radius: 10px 10px 0 0;
        background-color: #EEF2F7;
        border: 1px solid #EEF2F7;
        text-align: center;
        padding: 0;
      }
      .el-tabs__item.is-active{
        color: #454545;
        background-color: #fff;
      }
    }
    .el-tabs__header .el-tabs__item.is-active{
     color: #409EFF;
    }
  }
</style>
