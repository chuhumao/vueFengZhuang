<!-- 移交（全部） -->
<template>
  <div class="" style="background-color: #fff">
    <!-- 搜索 -->
    <div style="padding: 10px 0;">
      <div class="search-select">
        <label>全宗：</label>
        <el-select v-model="params.fonds" filterable placeholder="请选择" @change="yjTypeBtn">
          <el-option
            v-for="item in fullZong"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
      </div>
      <div class="search-select">
        <label>档案类型：</label>
        <el-select v-model="params.series1" filterable placeholder="请选择" @change="searchSeries">
          <el-option
            v-for="item in FondsAndRole"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
        <el-select v-model="params.series2" filterable placeholder="请选择" @change="searchSeriesTwo">
          <el-option
            v-for="item in FondsAndRoleTwo"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
        <el-select v-model="params.series3" filterable placeholder="请选择" @change="searchSeriesThree">
          <el-option
            v-for="item in FondsAndRoleThree"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
      </div>
      <div class="search-select">
        <label>移交类型：</label>
        <el-select v-model="params.yjType" filterable placeholder="请选择" @change="yjTypeBtnTwo">
          <el-option
            v-for="item in handoverTypeModel"
            :key="item.itemValue"
            :label="item.name"
            :value="item.itemValue">
          </el-option>
        </el-select>
      </div>
      <div class="clear"></div>
    </div>
    <!-- 上操作 -->
    <div>
      <div class="searchBtn" @click="tureOverBtn">
        <img src="../../assets/turnOver/ck.png" alt="">
        <span>查看</span>
      </div>
      <div class="searchBtn" @click="searchContent">
        <img src="../../assets/turnOver/js.png" alt="">
        <span>检索</span>
      </div>
      <!-- 没有功能，放这 -->
      <!--<div class="searchBtn">-->
        <!--<span>扫一扫</span>-->
      <!--</div>-->
      <div class="clear"></div>
    </div>
    <!-- 上表格 -->
    <div class="all-Table">
      <el-table
        ref="multipleTable"
        :data="tableData"
        stripe
        border
        @selection-change="handleSelectionChange">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="status"
          label="移交状态"
          width="180">
          <template slot-scope="scope">
            <span v-if="scope.row.status == 1">欠交</span>
            <span v-else-if="scope.row.status == 2">综合员移交</span>
            <span v-else-if="scope.row.status == 3">领导审核</span>
            <span v-else-if="scope.row.status == 4">档案员审核</span>
            <span v-else-if="scope.row.status == 5">已移交</span>
            <span v-else-if="scope.row.status == 6">不移交</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="serialNumber"
          label="移交单号"
          width="250">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverUser"
          label="移交人姓名"
          width="180">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverDept"
          label="移交部门"
          width="300">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverType"
          label="移交方式"
          width="160">
          <template slot-scope="scope">
            <span v-if="scope.row.handoverType == 1">邮寄</span>
            <!--<span v-else-if="scope.row.handoverType == 2">本人亲自移交</span>-->
            <span v-else>面交</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverYdh"
          label="运单号"
          width="179">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverDate"
          label="移交时间"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="tagName"
          label="档案类型"
          width="180">
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <div class="pageLayout">
      <el-pagination
        @current-change="handleCurrentChange"
        :current-page="params.page"
        :page-size="params.rows"
        layout="prev, pager, next, jumper"
        :total="params.total">
      </el-pagination>
    </div>

    <!-- 下操作 -->
    <div style="background-color: #F4F4F4;">
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="showLookBtn">
        <img src="../../assets/turnOver/ck.png" alt="">
        <span>查看</span>
      </div>
      <div class="searchBtn search-selectOnce" v-if="showSelectAudit"></div>
      <div class="searchBtn" @click="showLookBtn50" v-if="showSelectAudit">
        <img src="../../assets/turnOver/ck.png" alt="">
        <span>认领</span>
      </div>
      <div class="searchBtn search-selectOnce" v-if="showSelectAuditTwo"></div>
      <div class="searchBtn" @click="showLookBtn51" v-if="showSelectAuditTwo">
        <img src="../../assets/turnOver/ck.png" alt="">
        <span>同步材料</span>
      </div>
      <div class="clear"></div>
    </div>
    <!-- 下表格 -->
    <!--<div class="all-Table">
      <el-table
        ref="multipleTableBtom"
        :data="tableDataTwo"
        stripe
        border
        @selection-change="handleSelectionChangeBtom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileCode"
          label="文件号"
          width="220">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverHt"
          label="合同号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="文件标题"
          width="250">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverEmployer"
          label="对方单位"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          label="文件日期"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileType"
          label="文件类型"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="isOriginal"
          label="是否原件"
          width="120">
          <template slot-scope="scope">
            <span v-if="scope.row.isOriginal == 0">是</span>
            <span v-else-if="scope.row.isOriginal == 1">否</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="gzhangLevel"
          label="公章等级"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverException"
          label="移交异常"
          width="159">
        </el-table-column>
      </el-table>
    </div>-->
    <div class="all-Table" v-if="params.series2 == 1388742017297">
      <el-table
        ref="multipleTableBtomTwo"
        :data="tableDataTwo"
        stripe
        border
        @selection-change="handleSelectionChangeBtom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverThNumber"
          label="序号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverEmployer"
          label="项目单位全称"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileType"
          label="项目类型"
          width="230">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverHt"
          label="业务类型"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="项目名称"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          label="项目结束年度"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileCode"
          label="接收箱数（总箱数）"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileNum"
          label="接收册数（总册数）"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="gzhangLevel"
          label="快递单号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverDate"
          label="移交时间"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverPc"
          label="移交批次"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverException"
          label="移交异常"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverNote"
          label="备注"
          width="160">
        </el-table-column>
      </el-table>
    </div>
    <div v-else-if="params.series2 == 1388742017298" class="all-Table">
      <el-table
        ref="multipleTableBtomTwo"
        :data="tableDataTwo"
        stripe
        border
        @selection-change="handleSelectionChangeBtom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="serialNumber"
          label="项目编号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          label="项目年度"
          width="230">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="bondNo"
          label="债券代码"
          width="200">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverEmployer"
          label="项目单位全称"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="项目名称"
          width="200">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileType"
          label="项目类型"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverHt"
          label="业务类型"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="author"
          label="承做单位"
          width="200">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverDate"
          label="归档日期"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="pageNo"
          label="页号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="retentionPeriod"
          label="保管期限"
          width="160">
          <template slot-scope="scope">
            <span v-if="scope.row.retentionPeriod == 3">永久</span>
            <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
            <span v-else-if="scope.row.retentionPeriod == 1">短期</span>
            <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
            <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
            <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverNote"
          label="备注"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="folderNo"
          label="案卷号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="folderTitle"
          label="案卷题名"
          width="160">
        </el-table-column>
      </el-table>
    </div>
    <div v-else-if="params.series1 == 1388742017269" class="all-Table">
      <el-table
        ref="multipleTableBtomTwo"
        :data="tableDataTwo"
        stripe
        border
        @selection-change="handleSelectionChangeBtom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="archivalCode"
          label="档号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverEmployer"
          label="所属部门"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="serialNumber"
          label="案卷号"
          width="230">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileType"
          label="类别"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="卷（册、袋）标题"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="startDate"
          label="起始时间"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="endDate"
          label="终止时间"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverHt"
          label="凭证起始号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="gzhangLevel"
          label="保管期限"
          width="160">
          <template slot-scope="scope">
            <span v-if="scope.row.gzhangLevel == 3">永久</span>
            <span v-else-if="scope.row.gzhangLevel == 2">长期</span>
            <span v-else-if="scope.row.gzhangLevel == 1">短期</span>
            <span v-else-if="scope.row.gzhangLevel == 5">10年</span>
            <span v-else-if="scope.row.gzhangLevel == 6">15年</span>
            <span v-else-if="scope.row.gzhangLevel == 8">30年</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileNum"
          label="卷内张数"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverNote"
          label="备考"
          width="160">
        </el-table-column>
      </el-table>
    </div>
    <div v-else-if="params.series2 == 1374133285844" class="all-Table">
      <el-table
        ref="multipleTableBtomTwo"
        :data="tableDataTwo"
        stripe
        border
        @selection-change="handleSelectionChangeBtom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="caseNo"
          label="盒号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverThNumber"
          label="件号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverPc"
          label="刻制年度"
          width="230">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          label="刻制日期"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverEmployer"
          label="责任者"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="gzhangLevel"
          label="保管期限"
          width="160">
          <template slot-scope="scope">
            <span v-if="scope.row.retentionPeriod == 3">永久</span>
            <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
            <span v-else-if="scope.row.retentionPeriod == 1">短期</span>
            <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
            <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
            <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileType"
          label="印章种类"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverHt"
          label="印章形状"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="sealStatus"
          label="印章状态"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverNote"
          label="备注"
          width="160">
        </el-table-column>
      </el-table>
    </div>
    <div v-else-if="params.series2 == 1374133285845 || params.series2 == 1374133285846 || params.series2 == 1374133285847
          || params.series2 == 1374133285848 || params.series2 == 1374133285849 || params.series2 == 1547110001600" class="all-Table">
      <el-table
        ref="multipleTableBtomTwo"
        :data="tableDataTwo"
        stripe
        border
        @selection-change="handleSelectionChangeBtom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverThNumber"
          label="件号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverPc"
          label="年度"
          width="230">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="名称"
          width="200">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          label="获奖日期"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverEmployer"
          label="对方单位"
          width="200">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileType"
          label="类别"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverNote"
          label="备注"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="belongDept"
          label="所属部门"
          width="200">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="author"
          label="责任者"
          width="160">
        </el-table-column>
      </el-table>
    </div>
    <div v-else-if="params.series1 == 1374133285828" class="all-Table">
      <el-table
        ref="multipleTableBtomTwo"
        :data="tableDataTwo"
        stripe
        border
        @selection-change="handleSelectionChangeBtom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverThNumber"
          label="件号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="题名"
          width="230">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="theme"
          label="主题"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          label="拍摄时间"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="site"
          label="地点"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="background"
          label="背景"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="personage"
          label="人物(职务)"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="photographer"
          label="摄(录)者"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="belongDept"
          label="所属部门"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverNote"
          label="内容简介"
          width="160">
        </el-table-column>
      </el-table>
    </div>
    <div class="all-Table" v-else>
      <el-table
        ref="multipleTableBtomTwo"
        :data="tableDataTwo"
        stripe
        border
        @selection-change="handleSelectionChangeBtom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileCode"
          label="文件号"
          width="220">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="title"
          label="文件标题"
          width="230">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileDate"
          label="文件日期"
          width="210">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverPc"
          label="年度"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="isOriginal"
          label="是否原件"
          width="130">
          <template slot-scope="scope">
            <span v-if="scope.row.isOriginal == 0">是</span>
            <span v-else-if="scope.row.isOriginal == 1">否</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="handoverException"
          label="移交异常"
          width="400">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="isDelete"
          label="移交状态"
          width="249">
          <template slot-scope="scope">
            <span v-if="scope.row.isDelete == 0" style="color: green;">正常移交</span>
            <span v-else style="color: red;">下次移交</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 下分页 -->
    <div class="pageLayout">
      <el-pagination
        @current-change="handleCurrentChangeTwo"
        :current-page="paramsTwo.page"
        :page-size="paramsTwo.rows"
        layout="prev, pager, next, jumper"
        :total="paramsTwo.total">
      </el-pagination>
    </div>
    <!-- 查看弹框 -->
    <el-dialog :visible.sync="dialogShowLook" width="1314px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">查看材料</div>
      <div class="showClearLook">
        <div class="bigDog menuShrink black-tree" style="float: left;height: 100%;min-height: unset;max-height: unset;">
          <el-tree
            :data="treTable"
            :props="defaultProps"
            :check-strictly="true"
            :default-expand-all="true"
            :expand-on-click-node="false"
            :highlight-current="true"
            accordion
            @node-click="handleNodeClick">
          </el-tree>
        </div>
        <div style="float: left;margin-left: 10px;width: 80%; max-height: 600px; overflow: auto;">
          <el-tabs v-model="activeName" class="elTabsCssMange"  type="card" @tab-click="resetTable">
            <!-- 广发上市 -->
            <el-tab-pane label="基本信息" name="contentOnce">
              <div v-if="showCheckEmbed">
                <!--件号，问号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>件号：</label>
                    <el-input v-model="showEditLook.itemNo" readonly></el-input>
                  </li>
                  <li>
                    <label>文号：</label>
                    <el-input v-model="showEditLook.fileCode" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--题名-->
                <ul class="mangeShowLook">
                  <li style="width: 100%;">
                    <label>题名：</label>
                    <el-input v-model="showEditLook.titleProper" readonly style="width: 84.5%;"></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--保管期限，公开属性，文件盒号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>保管期限：</label>
                    <el-input v-model="showEditLook.retentionPeriod" readonly></el-input>
                  </li>
                  <li>
                    <label>公开属性：</label>
                    <el-input v-model="showEditLook.openingType" readonly></el-input>
                  </li>
                  <li>
                    <label>文件盒号：</label>
                    <el-input v-model="showEditLook.caseNo" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--文件日期，年度，页数-->
                <ul class="mangeShowLook">
                  <li>
                    <label>文件日期：</label>
                    <el-input v-model="showEditLook.dateOfCreation" readonly></el-input>
                  </li>
                  <li>
                    <label>年度：</label>
                    <el-input v-model="showEditLook.yearCode" readonly></el-input>
                  </li>
                  <li>
                    <label>页数：</label>
                    <el-input v-model="showEditLook.amountOfPages" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--档号，责任者，分类号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>档号：</label>
                    <el-input v-model="showEditLook.officeArchivalCode" readonly></el-input>
                  </li>
                  <li>
                    <label>责任者：</label>
                    <el-input v-model="showEditLook.c113" readonly></el-input>
                  </li>
                  <li>
                    <label>分类号：</label>
                    <el-input v-model="showEditLook.seriesCode" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--是否为原件，是否在库，可见性-->
                <ul class="mangeShowLook">
                  <li>
                    <label>是否为原件：</label>
                    <el-input v-model="showEditLook.c58" readonly></el-input>
                  </li>
                  <li>
                    <label>是否在库：</label>
                    <el-input v-model="showEditLook.c59" readonly></el-input>
                  </li>
                  <li>
                    <label>可见性：</label>
                    <el-input v-model="showEditLook.c93" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档人，归档部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档人：</label>
                    <el-input v-model="showEditLook.filingUser" readonly></el-input>
                  </li>
                  <li>
                    <label>归档部门：</label>
                    <el-input v-model="showEditLook.filingDept" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--备注-->
                <ul class="mangeShowLook">
                  <li>
                    <label>备注：</label>
                    <el-input v-model="showEditLook.c8" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--部门，全宗，合同号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>部门：</label>
                    <el-input v-model="showEditLook.c98" readonly></el-input>
                  </li>
                  <li>
                    <label>全宗：</label>
                    <el-input v-model="showEditLook.fondsCode" readonly></el-input>
                  </li>
                  <li>
                    <label>合同号：</label>
                    <el-input v-model="showEditLook.c117" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档日期，来文系统，文件类型-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档日期：</label>
                    <el-input v-model="showEditLook.filingDate" readonly></el-input>
                  </li>
                  <li>
                    <label>来文系统：</label>
                    <el-input v-model="showEditLook.c92" readonly></el-input>
                  </li>
                  <li>
                    <label>文件类型：</label>
                    <el-input v-model="showEditLook.c100" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--公章等级，拟稿人，拟稿部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>公章等级：</label>
                    <el-input v-model="showEditLook.c112" readonly></el-input>
                  </li>
                  <li>
                    <label>拟稿人：</label>
                    <el-input v-model="showEditLook.c89" readonly></el-input>
                  </li>
                  <li>
                    <label>拟稿部门：</label>
                    <el-input v-model="showEditLook.c90" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
              </div>
              <div v-else>
                <embed :src="embedOnce"type="application/pdf" width="100%" height="600px"/>
              </div>
            </el-tab-pane>
            <el-tab-pane label="关联档案" name="contentTwoce" v-if="showView == 1">
              <div style="margin: 6px;">关联目录：</div>
              <ul class="mangeShowLook" v-for="(item, index) in paramsView.tlist" :key="item.id">
                <li style="width: 25%;">
                  <label style="width: 102px;">{{index + 1}}、档案题名：</label>
                  <el-input v-model="item.titleProper" readonly style="width: 57%"></el-input>
                </li>
                <li style="width: 25%;">
                  <label style="width: 102px;">责任者：</label>
                  <el-input v-model="item.c113" readonly style="width: 57%"></el-input>
                </li>
                <li style="width: 25%;">
                  <label style="width: 102px;">拟稿人：</label>
                  <el-input v-model="item.c89" readonly style="width: 57%"></el-input>
                </li>
                <li style="width: 25%;">
                  <label style="width: 102px;">合同号：</label>
                  <el-input v-model="item.c117" readonly style="width: 57%"></el-input>
                </li>
                <li style="width: 25%;margin-top:4px;">
                  <label style="width: 102px;">档案链接：</label>
                  <span style="color: #409eff;cursor: pointer;" @click="lookFileContent('f', item)">点击查看</span>
                </li>
                <div class="clear"></div>
              </ul>
              <div style="margin: 6px;">关联案卷：</div>
              <ul class="mangeShowLook" v-for="(item, index) in paramsView.tflist" :key="item.id">
                <li style="width: 25%;">
                  <label style="width: 102px;">{{index + 1}}、档案题名：</label>
                  <el-input v-model="item.titleProper" readonly style="width: 57%"></el-input>
                </li>
                <div class="clear"></div>
                <li style="width: 25%; margin-top:4px;">
                  <label style="width: 102px;">档案链接：</label>
                  <span style="color: #409eff;cursor: pointer;" @click="lookFileContent('v', item)">点击查看</span>
                </li>
                <div class="clear"></div>
              </ul>
              <div style="margin: 6px;">关联项目：</div>
              <ul class="mangeShowLook">
                <li style="width: 25%;">
                  <label style="width: 102px;">档案题名：</label>
                  <el-input v-model="paramsView.project.titleProper" readonly style="width: 57%"></el-input>
                </li>
                <div class="clear"></div>
                <li style="width: 25%; margin-top:4px;">
                  <label style="width: 102px;">档案链接：</label>
                  <span style="color: #409eff;cursor: pointer;" @click="lookFileContent('p', paramsView.project)">点击查看</span>
                </li>
                <div class="clear"></div>
              </ul>
            </el-tab-pane>
          </el-tabs>
        </div>
        <div class="clear"></div>
      </div>
      <div slot="footer" class="dialog-footer" style="text-align: right">
        <el-button @click="dialogShowLook = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 查看弹框--第二级查看资料弹框 -->
    <el-dialog :visible.sync="dialogShowLookTwo" width="1314px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">查看材料</div>
      <div class="showClearLook">
        <div class="bigDog menuShrink black-tree" style="float: left;height: 100%;min-height: unset;max-height: unset;">
          <el-tree
            :data="treTableTwo"
            :props="defaultProps"
            :check-strictly="true"
            :default-expand-all="true"
            :expand-on-click-node="false"
            :highlight-current="true"
            accordion
            @node-click="handleNodeClickTwo">
          </el-tree>
        </div>
        <div style="float: left;margin-left: 10px;width: 80%; max-height: 600px; overflow: auto;">
          <el-tabs v-model="activeName" class="elTabsCssMange"  type="card" @tab-click="resetTable">
            <!-- 广发上市 -->
            <el-tab-pane label="基本信息" name="contentOnce">
              <div v-if="attributesType == 'f'">
                <!--件号，问号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>件号：</label>
                    <el-input v-model="showEditLookTwo.itemNo" readonly></el-input>
                  </li>
                  <li>
                    <label>文号：</label>
                    <el-input v-model="showEditLookTwo.fileCode" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--题目-->
                <ul class="mangeShowLook">
                  <li style="width: 100%;">
                    <label>题名：</label>
                    <el-input v-model="showEditLookTwo.titleProper" readonly style="width: 84.5%;"></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--保管期限，公开属性，文件盒号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>保管期限：</label>
                    <el-input v-model="showEditLookTwo.retentionPeriod" readonly></el-input>
                  </li>
                  <li>
                    <label>公开属性：</label>
                    <el-input v-model="showEditLookTwo.openingType" readonly></el-input>
                  </li>
                  <li>
                    <label>文件盒号：</label>
                    <el-input v-model="showEditLookTwo.caseNo" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--文件日期，年度，页数-->
                <ul class="mangeShowLook">
                  <li>
                    <label>文件日期：</label>
                    <el-input v-model="showEditLookTwo.dateOfCreation" readonly></el-input>
                  </li>
                  <li>
                    <label>年度：</label>
                    <el-input v-model="showEditLookTwo.yearCode" readonly></el-input>
                  </li>
                  <li>
                    <label>页数：</label>
                    <el-input v-model="showEditLookTwo.amountOfPages" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--档号，责任者，分类号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>档号：</label>
                    <el-input v-model="showEditLookTwo.officeArchivalCode" readonly></el-input>
                  </li>
                  <li>
                    <label>责任者：</label>
                    <el-input v-model="showEditLookTwo.c113" readonly></el-input>
                  </li>
                  <li>
                    <label>分类号：</label>
                    <el-input v-model="showEditLookTwo.seriesCode" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--是否为原件，是否在库，可见性-->
                <ul class="mangeShowLook">
                  <li>
                    <label>是否为原件：</label>
                    <el-input v-model="showEditLookTwo.c58" readonly></el-input>
                  </li>
                  <li>
                    <label>是否在库：</label>
                    <el-input v-model="showEditLookTwo.c59" readonly></el-input>
                  </li>
                  <li>
                    <label>可见性：</label>
                    <el-input v-model="showEditLookTwo.c93" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档人，归档部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档人：</label>
                    <el-input v-model="showEditLookTwo.filingUser" readonly></el-input>
                  </li>
                  <li>
                    <label>归档部门：</label>
                    <el-input v-model="showEditLookTwo.filingDept" readonly></el-input>
                  </li>
                  <li>
                    <label>归档部门：</label>
                    <el-input v-model="showEditLookTwo.c107 == 0 ? '已盖章':'未盖章'" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--备注-->
                <ul class="mangeShowLook">
                  <li>
                    <label>备注：</label>
                    <el-input v-model="showEditLookTwo.c8" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--部门，全宗，合同号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>部门：</label>
                    <el-input v-model="showEditLookTwo.c98" readonly></el-input>
                  </li>
                  <li>
                    <label>全宗：</label>
                    <el-input v-model="showEditLookTwo.fondsCode" readonly></el-input>
                  </li>
                  <li>
                    <label>合同号：</label>
                    <el-input v-model="showEditLookTwo.c117" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档日期，来文系统，文件类型-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档日期：</label>
                    <el-input v-model="showEditLookTwo.filingDate" readonly></el-input>
                  </li>
                  <li>
                    <label>来文系统：</label>
                    <el-input v-model="showEditLookTwo.c92" readonly></el-input>
                  </li>
                  <li>
                    <label>文件类型：</label>
                    <el-input v-model="showEditLookTwo.c100" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--公章等级，拟稿人，拟稿部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>公章等级：</label>
                    <el-input v-model="showEditLookTwo.c112" readonly></el-input>
                  </li>
                  <li>
                    <label>拟稿人：</label>
                    <el-input v-model="showEditLookTwo.c89" readonly></el-input>
                  </li>
                  <li>
                    <label>拟稿部门：</label>
                    <el-input v-model="showEditLookTwo.c90" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
              </div>
              <div v-if="attributesType == 'v'">
                <!--项目名称，全宗，分类号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>项目名称：</label>
                    <el-input v-model="showEditLookTwo.c11" readonly></el-input>
                  </li>
                  <li>
                    <label>全宗：</label>
                    <el-input v-model="showEditLookTwo.fondsCode" readonly></el-input>
                  </li>
                  <li>
                    <label>分类号：</label>
                    <el-input v-model="showEditLookTwo.seriesCode" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--案卷题名-->
                <ul class="mangeShowLook">
                  <li style="width: 100%;">
                    <label>案卷题名：</label>
                    <el-input v-model="showEditLookTwo.titleProper" readonly style="width: 84.5%;"></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--案卷号，年度，可见性-->
                <ul class="mangeShowLook">
                  <li>
                    <label>案卷号：</label>
                    <el-input v-model="showEditLookTwo.folderNo" readonly></el-input>
                  </li>
                  <li>
                    <label>年度：</label>
                    <el-input v-model="showEditLookTwo.yearCode" readonly></el-input>
                  </li>
                  <li>
                    <label>可见性：</label>
                    <el-input v-model="showEditLookTwo.c93" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档人，归档日期，归档部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档人：</label>
                    <el-input v-model="showEditLookTwo.filingUser" readonly></el-input>
                  </li>
                  <li>
                    <label>归档日期：</label>
                    <el-input v-model="showEditLookTwo.filingDate" readonly></el-input>
                  </li>
                  <li>
                    <label>归档部门：</label>
                    <el-input v-model="showEditLookTwo.filingDept" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--起始日期，责任者，保管期限-->
                <ul class="mangeShowLook">
                  <li>
                    <label>起始日期：</label>
                    <el-input v-model="showEditLookTwo.dateBegun" readonly></el-input>
                  </li>
                  <li>
                    <label>终止日期：</label>
                    <el-input v-model="showEditLookTwo.dateFinished" readonly></el-input>
                  </li>
                  <li>
                    <label>保管期限：</label>
                    <el-input v-model="showEditLookTwo.retentionPeriod" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--备注-->
                <ul class="mangeShowLook">
                  <li>
                    <label>备注：</label>
                    <el-input v-model="showEditLookTwo.folderNote" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--档号，项目代号-->
                <ul class="mangeShowLook">
                  <li>
                    <label>档号：</label>
                    <el-input v-model="showEditLookTwo.officeArchivalCode" readonly></el-input>
                  </li>
                  <li>
                    <label>项目代号：</label>
                    <el-input v-model="showEditLookTwo.c0" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
              </div>
              <div v-if="attributesType == 'p'">
                <!--项目代号，项目名称-->
                <ul class="mangeShowLook">
                  <li>
                    <label>项目代号：</label>
                    <el-input v-model="showEditLookTwo.c0" readonly></el-input>
                  </li>
                  <li>
                    <label>项目名称：</label>
                    <el-input v-model="showEditLookTwo.c11" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--工程地点-->
                <ul class="mangeShowLook">
                  <li style="width: 100%;">
                    <label>工程地点：</label>
                    <el-input v-model="showEditLookTwo.projectSite" readonly style="width: 84.5%;"></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--全宗，归档部门-->
                <ul class="mangeShowLook">
                  <li>
                    <label>全宗：</label>
                    <el-input v-model="showEditLookTwo.fondsCode" readonly></el-input>
                  </li>
                  <li>
                    <label>归档部门：</label>
                    <el-input v-model="showEditLookTwo.filingDept" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--分类号，归档人-->
                <ul class="mangeShowLook">
                  <li>
                    <label>分类号：</label>
                    <el-input v-model="showEditLookTwo.seriesCode" readonly></el-input>
                  </li>
                  <li>
                    <label>归档人：</label>
                    <el-input v-model="showEditLookTwo.filingUser" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
                <!--归档日期，可见性-->
                <ul class="mangeShowLook">
                  <li>
                    <label>归档日期：</label>
                    <el-input v-model="showEditLookTwo.filingDate" readonly></el-input>
                  </li>
                  <li>
                    <label>可见性：</label>
                    <el-input v-model="showEditLookTwo.c93" readonly></el-input>
                  </li>
                  <div class="clear"></div>
                </ul>
              </div>
            </el-tab-pane>
            <el-tab-pane label="关联档案" name="contentTwoce" v-if="showViewTwo == 1">
              <div v-if="paramsViewTwo.tlist">
                <div style="margin: 6px;" v-if="attributesType == 'f'">关联目录：</div>
                <ul class="mangeShowLook" v-if="attributesType == 'f'" v-for="(item, index) in paramsViewTwo.tlist" :key="item.id">
                  <li style="width: 25%;">
                    <label style="width: 102px;">{{index + 1}}、档案题名：</label>
                    <el-input v-model="item.titleProper" readonly style="width: 57%"></el-input>
                  </li>
                  <li style="width: 25%;">
                    <label style="width: 102px;">责任者：</label>
                    <el-input v-model="item.c113" readonly style="width: 57%"></el-input>
                  </li>
                  <li style="width: 25%;">
                    <label style="width: 102px;">拟稿人：</label>
                    <el-input v-model="item.c89" readonly style="width: 57%"></el-input>
                  </li>
                  <li style="width: 25%;">
                    <label style="width: 102px;">合同号：</label>
                    <el-input v-model="item.c117" readonly style="width: 57%"></el-input>
                  </li>
                  <!--<li style="width: 25%;margin-top:4px;">
                    <label style="width: 102px;">档案链接：</label>
                    <span style="color: #409eff;cursor: pointer;">点击查看</span>
                  </li>-->
                  <div class="clear"></div>
                </ul>
              </div>
              <div v-if="paramsViewTwo.tflist">
                <div style="margin: 6px;">关联案卷：</div>
                <ul class="mangeShowLook" v-for="(item, index) in paramsViewTwo.tflist" :key="item.id">
                  <li style="width: 25%;">
                    <label style="width: 102px;">{{index + 1}}、档案题名：</label>
                    <el-input v-model="item.titleProper" readonly style="width: 57%"></el-input>
                  </li>
                  <div class="clear"></div>
                  <!--<li style="width: 25%; margin-top:4px;">
                    <label style="width: 102px;">档案链接：</label>
                    <span style="color: #409eff;cursor: pointer;">点击查看</span>
                  </li>-->
                  <div class="clear"></div>
                </ul>
              </div>
              <div v-if="paramsViewTwo.project">
                <div style="margin: 6px;">关联项目：</div>
                <ul class="mangeShowLook">
                  <li style="width: 25%;">
                    <label style="width: 102px;">档案题名：</label>
                    <el-input v-model="paramsViewTwo.project.titleProper" readonly style="width: 57%"></el-input>
                  </li>
                  <div class="clear"></div>
                  <!--<li style="width: 25%; margin-top:4px;">
                    <label style="width: 102px;">档案链接：</label>
                    <span style="color: #409eff;cursor: pointer;">点击查看</span>
                  </li>-->
                  <div class="clear"></div>
                </ul>
              </div>
            </el-tab-pane>
          </el-tabs>
        </div>
        <div class="clear"></div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button @click="dialogShowLookTwo = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 档案管理审核 -->
    <el-dialog :visible.sync="dialogShowContent" width="1111px" class="hurdleAll" :before-close="handleClose">
      <div slot="title" class="dialog-title">移交单</div>
      <!--输入框-->
      <div class="maxHeight">
        <!--上-->
        <ul class="mangeShow">
          <li>
            <label>移交人姓名：</label>
            <el-input v-model="showEdit.handoverUser" readonly></el-input>
          </li>
          <li>
            <label>移交部门：</label>
            <el-input v-model="showEdit.handoverDept" readonly></el-input>
          </li>
          <li>
            <label>移交时间：</label>
            <el-input v-model="showEdit.handoverDate" readonly></el-input>
          </li>
          <!--<li>-->
          <!--<label>操作指引：</label>-->
          <!--<el-button type="primary">下载</el-button>-->
          <!--</li>-->
          <div class="clear"></div>
        </ul>
        <!--下-列表-->
        <div class="mangeShowList">
          <p>意见详情：</p>
          <div class="showReadOnlyContent" v-if="showEdit.isOldDate == 0">
            <div v-html="showEdit.handoverRemark"></div>
          </div>
          <!-- 表格 -->
          <div class="all-Table" v-else-if="showEdit.isOldDate == 1" style="width: 83%;max-height: 300px;overflow: auto;margin: 0 auto;">
            <el-table
              :data="dialogTable"
              stripe
              border
              style="width: 100%">
              <el-table-column
                show-overflow-tooltip
                prop="handoverRemark"
                label="意见内容">
                <template slot-scope="scope">
                  <div v-for="(item, index) in scope.row.handoverRemark" :key="index">{{ item }}</div>
                </template>
              </el-table-column>
              <el-table-column
                prop="date"
                label="时间">
              </el-table-column>
              <el-table-column
                prop="sendName"
                label="操作人">
              </el-table-column>
            </el-table>
          </div>
        </div>
      </div>
      <!-- 下操作 -->
      <div class="maxHeight">
        <div style="background-color: #F4F4F4;">
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtnTwo">
            <img src="../../assets/turnOver/ck.png" alt="">
            <span>查看</span>
          </div>
          <!--<div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn7">
            <img src="../../assets/turnOver/sc.png" alt="">
            <span>上传</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn10">
            <img src="../../assets/turnOver/delete.png" alt="">
            <span>删除附件</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn13">
            <img src="../../assets/turnOver/xg.png" alt="">
            <span>修改附件</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showLookBtn11">
            <img src="../../assets/turnOver/tj.png" alt="">
            <span>添加异常</span>
          </div>-->
          <div class="clear"></div>
        </div>
        <!-- 下表格 -->
        <!-- 投资银行 -->
        <div class="all-Table" v-if="params.series2 == 1388742017297">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtom"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverThNumber"
              label="序号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverEmployer"
              label="项目单位全称"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileType"
              label="项目类型"
              width="230">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverHt"
              label="业务类型"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="项目名称"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              label="项目结束年度"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileCode"
              label="接收箱数（总箱数）"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileNum"
              label="接收册数（总册数）"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="gzhangLevel"
              label="快递单号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverDate"
              label="移交时间"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverPc"
              label="移交批次"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverException"
              label="移交异常"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverNote"
              label="备注"
              width="160">
            </el-table-column>
          </el-table>
        </div>
        <div v-else-if="params.series2 == 1388742017298" class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtom"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="serialNumber"
              label="项目编号"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              label="项目年度"
              width="230">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="bondNo"
              label="债券代码"
              width="200">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverEmployer"
              label="项目单位全称"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="项目名称"
              width="200">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileType"
              label="项目类型"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverHt"
              label="业务类型"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="author"
              label="承做单位"
              width="200">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverDate"
              label="归档日期"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="pageNo"
              label="页号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="retentionPeriod"
              label="保管期限"
              width="160">
              <template slot-scope="scope">
                <span v-if="scope.row.retentionPeriod == 3">永久</span>
                <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
                <span v-else-if="scope.row.retentionPeriod == 1">短期</span>
                <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
                <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
                <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverNote"
              label="备注"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="folderNo"
              label="案卷号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="folderTitle"
              label="案卷题名"
              width="160">
            </el-table-column>
          </el-table>
        </div>
        <div v-else-if="params.series1 == 1388742017269" class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtom"
            stripe
            border
            @selection-change="handleSelectionChangeBtom">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="archivalCode"
              label="档号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverEmployer"
              label="所属部门"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="serialNumber"
              label="案卷号"
              width="230">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileType"
              label="类别"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="卷（册、袋）标题"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="startDate"
              label="起始时间"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="endDate"
              label="终止时间"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverHt"
              label="凭证起始号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="gzhangLevel"
              label="保管期限"
              width="160">
              <template slot-scope="scope">
                <span v-if="scope.row.gzhangLevel == 3">永久</span>
                <span v-else-if="scope.row.gzhangLevel == 2">长期</span>
                <span v-else-if="scope.row.gzhangLevel == 1">短期</span>
                <span v-else-if="scope.row.gzhangLevel == 5">10年</span>
                <span v-else-if="scope.row.gzhangLevel == 6">15年</span>
                <span v-else-if="scope.row.gzhangLevel == 8">30年</span>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileNum"
              label="卷内张数"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverNote"
              label="备考"
              width="160">
            </el-table-column>
          </el-table>
        </div>
        <div v-else-if="params.series2 == 1374133285844" class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtom"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="caseNo"
              label="盒号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverThNumber"
              label="件号"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverPc"
              label="刻制年度"
              width="230">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              label="刻制日期"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverEmployer"
              label="责任者"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="gzhangLevel"
              label="保管期限"
              width="160">
              <template slot-scope="scope">
                <span v-if="scope.row.retentionPeriod == 3">永久</span>
                <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
                <span v-else-if="scope.row.retentionPeriod == 1">短期</span>
                <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
                <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
                <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileType"
              label="印章种类"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverHt"
              label="印章形状"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="sealStatus"
              label="印章状态"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverNote"
              label="备注"
              width="160">
            </el-table-column>
          </el-table>
        </div>
        <div v-else-if="params.series2 == 1374133285845 || params.series2 == 1374133285846 || params.series2 == 1374133285847
          || params.series2 == 1374133285848 || params.series2 == 1374133285849 || params.series2 == 1547110001600" class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtom"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverThNumber"
              label="件号"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverPc"
              label="年度"
              width="230">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="名称"
              width="200">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              label="获奖日期"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverEmployer"
              label="对方单位"
              width="200">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileType"
              label="类别"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverNote"
              label="备注"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="belongDept"
              label="所属部门"
              width="200">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="author"
              label="责任者"
              width="160">
            </el-table-column>
          </el-table>
        </div>
        <div v-else-if="params.series1 == 1374133285828" class="all-Table">
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtom"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverThNumber"
              label="件号"
              width="120">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="题名"
              width="230">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="theme"
              label="主题"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              label="拍摄时间"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="site"
              label="地点"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="background"
              label="背景"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="personage"
              label="人物(职务)"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="photographer"
              label="摄(录)者"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="belongDept"
              label="所属部门"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverNote"
              label="内容简介"
              width="160">
            </el-table-column>
          </el-table>
        </div>
        <div class="all-Table" v-else>
          <el-table
            ref="multipleTableBtomTwo"
            :data="dialogTableBtom"
            stripe
            border
            @selection-change="handleSelectionChangeBtomTwo">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileCode"
              label="文件号"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="title"
              label="文件标题"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileDate"
              label="文件日期"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverPc"
              label="年度">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="isOriginal"
              label="是否原件"
              width="100">
              <template slot-scope="scope">
                <span v-if="scope.row.isOriginal == 0">是</span>
                <span v-else-if="scope.row.isOriginal == 1">否</span>
              </template>
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="handoverException"
              label="移交异常"
              width="500">
            </el-table-column>
          </el-table>
        </div>
        <!-- 下分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeTwo"
            :current-page="paramsTwo.page"
            :page-size="paramsTwo.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer" style="text-align: right;">
        <!--<el-button type="primary" @click="mangeBtn">确定移交</el-button>-->
        <!--<el-button type="primary" @click="tuiHuiBtn">退回补充</el-button>-->
        <el-button @click="dialogShowContent = false">关闭</el-button>
      </div>
    </el-dialog>
    <el-dialog :visible.sync="getDataViewDialog" width="444px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">
        审核确认
      </div>
      <div class="dia-delete">
        确定要审核通过该批次吗?
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn1">确定</el-button>
        <el-button @click="getDataViewDialog = false">取消</el-button>
      </div>
    </el-dialog>
    <!--检索-->
    <el-dialog :visible.sync="getDataViewDialog21" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        检索
      </div>
      <div class="editorXinTwo">
        <label>题名：</label>
        <el-input v-model="params.yjTitleProper" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>年度：</label>
        <el-input v-model="params.yjYearCode" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>文号：</label>
        <el-input v-model="params.yjFileCode" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>合同号：</label>
        <el-input v-model="params.yjC117" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>责任者：</label>
        <el-input v-model="params.yjAuthor" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>移交状态：</label>
        <el-select v-model="params.yjStatus" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option v-for="item in yjStatusArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>移交单号：</label>
        <el-input v-model="params.yjSerialNumber" placeholder="请输入内容"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>拟稿部门：</label>
        <el-select v-model="params.yjc90" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option v-for="item in yjc90Arr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>拟稿人：</label>
        <el-select v-model="params.yjc89" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword
                   :remote-method="remoteMethodMan">
          <el-option v-for="item in yjc89Arr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>当前处理人：</label>
        <el-select v-model="params.yjcurrentuser" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword
                   :remote-method="remoteMethodUser">
          <el-option v-for="item in yjcurrentuserArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>文件类型：</label>
        <el-select v-model="params.fileType" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option v-for="item in fileTypeArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>公章类型：</label>
        <el-select v-model="params.yjc112" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option v-for="item in yjc112Arr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div class="editorXinTwo">
        <label>文件日期：</label>
        <el-date-picker
          v-model="params.dataOfCreate"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div class="editorXinTwo">
        <label>移交类型：</label>
        <el-select v-model="params.type" placeholder="请选择"
                   filterable
                   remote
                   reserve-keyword>
          <el-option
            v-for="item in handoverTypeModel"
            :key="item.itemValue"
            :label="item.name"
            :value="item.itemValue">
          </el-option>
        </el-select>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitBtn18">确定</el-button>
        <el-button @click="reset">重置</el-button>
        <el-button @click="getDataViewDialog21 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--重新发送待办-->
    <el-dialog :visible.sync="getDataViewDialog23" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        退回确认
      </div>
      <div class="dia-delete">
        确定要将该移交单退回到欠交吗?
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn19">确定</el-button>
        <el-button @click="getDataViewDialog23 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--导出合同移交登记表-->
    <el-dialog :visible.sync="getDataViewDialog27" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        导出合同移交登记表
      </div>
      <div class="editorXinTwo">
        <label>产品类型：</label>
        <el-input v-model="paramsDownload.productName"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>文件类型：</label>
        <el-input v-model="paramsDownload.fileType"></el-input>
      </div>
      <div class="editorXinTwo">
        <label>客户名称：</label>
        <el-input v-model="paramsDownload.clientName"></el-input>
      </div>
      <div class="editorXin editorXinTwo">
        <label>合同日期(起)：</label>
        <el-date-picker
          v-model="paramsDownload.exportStartDate"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div class="editorXin editorXinTwo">
        <label>合同日期(止)：</label>
        <el-date-picker
          v-model="paramsDownload.exportEndDate"
          type="date"
          format="yyyy年MM月dd日"
          value-format="yyyy-MM-dd"
          placeholder="选择时间">
        </el-date-picker>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn27">导出</el-button>
        <el-button type="primary" @click="paramsDownload = {}">重置</el-button>
        <el-button @click="getDataViewDialog27 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--下载非PDF文件-->
    <el-dialog :visible.sync="getDataViewDialog47" width="444px" class="hurdleAll" :before-close="handleCloseThree">
      <div slot="title" class="dialog-title">
        系统提示
      </div>
      <div class="dia-delete">
        该电子全文暂不提供在线浏览，您是否要离线下载此文件？
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn47">确定</el-button>
        <el-button @click="getDataViewDialog47 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--移交表单-->
    <el-dialog :visible.sync="getDataViewDialog48" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        系统提示
      </div>
      <div class="dia-delete">
        确定要将该移交单生成移交表单吗?
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn48">确定</el-button>
        <el-button @click="getDataViewDialog48 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--移交表单-->
    <el-dialog :visible.sync="getDataViewDialog49" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        整理确认
      </div>
      <div class="dia-delete">
        确定要将该项目提交到整理状态吗?
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn49">确定</el-button>
        <el-button @click="getDataViewDialog49 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--认领-->
    <el-dialog :visible.sync="getDataViewDialog50" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        认领确认
      </div>
      <div class="dia-delete">
        勾选的档案的移交人将变更为您本人，确定要认领吗？
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn50">确定</el-button>
        <el-button @click="getDataViewDialog50 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--同步材料-->
    <el-dialog :visible.sync="getDataViewDialog51" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        系统提示
      </div>
      <div class="dia-delete">
        确定要进行同步操作?
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitBtn51">确定</el-button>
        <el-button @click="getDataViewDialog51 = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getFonds, listSeriesByFondsAndRole, listHandOverQrData, listHandOverDetailData, listSeriesByFonds, findChangeUser,
  handOverSave, listHandOverDocumentTree, getHandOverFile, countHandOverDetailByNext, delHandOverFile, resettingHandOverFile,
  findSeriesCode, saveMhYjFile, editMhFileTitle, deleteMhYjFile, uploadPicture, saveUploadYjDoc, uploadExcelH5, uploadExcel,
  listHandOverDocumentData, deleteDoc, saveHandoverYc, saveIsOriginal, downloadExcel, editDocTitle, getQrYjList, getArchiveYjList,
  listKhdaStuffCoding, saveGlKhda, getQrYjRemark, getBusinessType, listHandoverPartnerData, saveImformation, handoverPartnerEditSave,
  delImformation, getYjInformation, saveYjInfoData, searchFindUser, listAllDept, listFileType, listGzdj, newListUserByDept,
  saveMhHandOver, sendMhYjOa, sendGlyShDb, ListArchive, listForJson, ListRetentionPeriod, saveUnderLine, listTimingData,
  saveTiming, uploadPlPicture, savePlHangingDocs, zhyHandOverSave, exportHtTable, countHandOverDetail, handOverBack, powerHandoverDocView,
  BASICURL, listTreeJson, listTreeJsonView, checkExtendInfo, extendInfoView, handoverExtendInfoView, gdHandOverFile, glyShPass, glyHandOverBack,
  yyjBackSave, createYjForm, zLingThProject, checkRlPermissions, handOverClaim, syncDoc} from '@/js/turnOverData'
import { wordPull } from '../../js/wordDerive'
import { valueIndex } from '../../js/transitionText'
export default {
  name: 'allMange',
  data () {
    return {
      // 查看弹框需要的
      activeName: 'contentOnce',
      paramsView: {
        project: {titleProper: null}
      },
      paramsViewTwo: {
        project: {titleProper: null}
      },
      showClearUpBtn: false,
      // 变更人
      sqFondsList: [],
      attributesType: [],
      treTableTwo: [],
      showEditLookTwo: {},
      dialogShowLookTwo: false,
      showCheckEmbed: false,
      embedOnce: '',
      showView: '',
      showViewTwo: '',
      showViewTwoId: '',

      getDataViewDialog: false,
      getDataViewDialog4: false,
      getDataViewDialog8: false,
      getDataViewDialog10: false,
      getDataViewDialog11: false,
      getDataViewDialog12: false,
      getDataViewDialog13: false,
      getDataViewDialog14: false,
      getDataViewDialog15: false,
      getDataViewDialog20: false,
      getDataViewDialog21: false,
      getDataViewDialog23: false,
      getDataViewDialog27: false,
      getDataViewDialog47: false,
      getDataViewDialog48: false,
      getDataViewDialog49: false,
      getDataViewDialog50: false,
      getDataViewDialog51: false,
      showEditLookTitle: '',
      showEdit: {},
      paramsEditContent: {},
      paramsDownload: {
        exportStartDate: new Date().getFullYear() + '-' + '1' + '-' + new Date().getDate(),
        exportEndDate: new Date().getFullYear() + '-' + (new Date().getMonth() + 1) + '-' + new Date().getDate()
      },
      params: {page: 1, rows: 10, status: 0, series1: 1379482316593, fonds: 1374133141812},
      paramsTwo: {page: 1, rows: 10, total: 0,status: 0},
      paramsDelete: {page: 1, rows: 10, total: 0},
      showEditLook: {},
      // 全宗类型
      fullZong: [],
      // 档案类型
      FondsAndRole: [],
      FondsAndRoleTwo: [],
      FondsAndRoleThree: [],
      exportHandoverDeptArr: [],
      // 移交类型
      handoverTypeModel: [
        {name: '精确移交', itemValue: '0'},
        {name: '模糊移交', itemValue: '1'},
        {name: '线下移交', itemValue: '3'},
        {name: '全部', itemValue: '2'}
      ],
      // 移交类型(弹框移交类型）
      handoverYysList: [
        {name: '顺丰快递', itemValue: '0,顺丰快递'},
        {name: '圆通快递', itemValue: '1,圆通快递'},
        {name: '中通快递', itemValue: '2,中通快递'},
        {name: '韵达快递', itemValue: '3,韵达快递'},
        {name: '百世汇通', itemValue: '4,百世汇通'},
        {name: 'EMS', itemValue: '5,EMS'},
        {name: '申通快递', itemValue: '6,申通快递'}
      ],
      // 接收方式
      handoverTypeList: [
        {name: '邮寄', itemValue: '1'},
        {name: '面交', itemValue: '2'}
      ],
      yjStatusArr: [
        {id: 0, text: '全部', value: ''},
        {id: 1, text: '欠交', value: ''},
        {id: 2, text: '综合员审核', value: ''},
        {id: 3, text: '部门领导审核', value: ''},
        {id: 4, text: '档案管理员审核', value: ''},
        {id: 5, text: '已移交', value: ''}
      ],
      tableData: [],
      tableDataTwo: [],
      dialogTableBtom: [],
      onceTable: [],
      onceTableBtom: [],
      onceTableBtomTwo: [],
      onceTableBtomThree: [],
      dialogShowLook: false,
      dialogShowContent: false,
      showDisable: false,
      treTable: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      deleteTable: [],
      imgVal: [],
      yjc90Arr: [],
      fileTypeArr: [],
      yjc112Arr: [],
      yjc89Arr: [],
      yjcurrentuserArr: [],
      checkParams: {},
      disYj: false,
      disHtOne: false,
      disHtOneTwo: true,
      disHtTwo: false,
      disHtTwoOnce: false,
      disHtTwoDate: false,
      disHtTwoTwo: true,
      disHtThree: false,
      disHtThreeTwo: true,
      disHtFour: false,
      disHtFourTwo: true,

      disHtBOne: false,
      disHtBTwo: false,
      disHtBThree: false,
      disHtBFour: false,
      disHtBFive: false,
      disHtBOnceTwo: true,
      showSelectAudit: true,
      showSelectAuditTwo: true,
      timeChange: {
        disabledDate (time) {
          return time.getTime() < (Date.now() - 3600 * 1000 * 24 * 183) || time.getTime() > Date.now() // 选择时间范围
        }
      }
    }
  },
  methods: {
    showLookBtn51 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtom)
      if (item == 1) {
        this.getDataViewDialog51 = true
      }
    },
    submitBtn51 () {
      syncDoc({id: this.onceTableBtom[0].id}).then(res => {
        if (res.data.result == 0) {
          this.$message.success('同步成功')
          this.getDataViewDialog51 = false
        } else {
          this.$message.error(res.data.msg)
          this.getDataViewDialog51 = false
        }
      })
    },
    showLookBtn50 () {
      let item = this.$onceWay().onceTableListTwo(this.onceTableBtom)
      if (item == 1) {
        let ids = ''
        let idsArr = ''
        this.onceTableBtom.forEach(item => {
          if (item.isDelete == 1) {
            this.$message.error('所选档案包含已下次移交的档案，请重新选择!')
          } else {
            ids = 1
            idsArr += item.id + ','
          }
        })
        if (ids == 1) {
          checkRlPermissions({docIds: idsArr, id: this.onceTable[0].gid}).then(res => {
            console.log(res);
            if (res.data.data == 1) {
              this.getDataViewDialog50 = true
            } else if (res.data.data == 2) {
              this.$message.error('所选档案中包含无权限查看的档案，如需认领请联系档案管理员!')
            } else {
              this.$message.warning('此档案已完成移交，如需认领请联系档案管理员!')
            }
          })
        }
      }
    },
    submitBtn50 () {
      let idsArr = ''
      this.onceTableBtom.forEach(item => {
        idsArr += item.id + ','
      })
      handOverClaim({docIds: idsArr, gId: this.onceTable[0].cid, hId: this.onceTable[0].gid}).then(res => {
        if (res.data.optFlag == 1) {
          this.$message.success('认领成功')
          this.getDataViewDialog50 = false
        } else if (res.data.optFlag == 2) {
          this.$message.error('已被其他用户处理')
          this.getDataViewDialog50 = false
        } else if (res.data.optFlag == 3) {
          this.$message.error('所选档案包含已下次移交的档案')
          this.getDataViewDialog50 = false
        } else {
          this.$message.error('认领失败，系统出错')
          this.getDataViewDialog50 = false
        }
      })
    },
    clearUpBtn () {
      let item = this.$onceWay().onceTableListTwo(this.onceTable)
      if (item == 1) {
        this.getDataViewDialog49 = true
      }
    },
    submitBtn49 () {
      let arrId = ''
      this.onceTableBtom.forEach((item) => {
        arrId += item.id + ','
      })
      zLingThProject({hdtailIds: arrId, gid: this.onceTable[0].gid}).then(res => {
        console.log(res);
        if (res.data.optFlag == 0) {
          this.$message.success('处理成功')
          this.getDataViewDialog49 = false
        } else if (res.data.optFlag == 1) {
          this.$message.info('已存在于档案整理')
          this.getDataViewDialog49 = false
        } else {
          this.$message.error('处理失败')
          this.getDataViewDialog49 = false
        }
      })
    },
    generateBtn () {
      let item = this.$onceWay().onceTableList(this.onceTable)
      if (item == 1) {
        this.getDataViewDialog48 = true
      }
    },
    submitBtn48 () {
      let params = {
        cid: this.onceTable[0].cid,
        gid: this.onceTable[0].gid
      }
      createYjForm(params).then(res => {
        if (res.data.optFlage == 1) {
          this.$message.success('生成成功')
          this.getDataViewDialog48 = false
          this.showList()
        } else {
          this.$message.error('生成失败')
          this.getDataViewDialog48 = false
          this.showList()
        }
      })
    },
    submitBtn47 () {
      let params = {id: this.showEditLook.textContentIds}
      valueIndex().exportXls('/gdda-new/gdda/util/downLoadHandoverFile', params, this.showEditLook.textContents, 'post')
      this.getDataViewDialog47 = false
    },
    handleNodeClick (val) {
      powerHandoverDocView({id: val.id}).then(res => {
        this.showCheckEmbed = true
        if (res.optFlag == -1) {
          this.$message.error('此文件不存在')
        } else if (res.optFlag == 0) {
          this.showCheckEmbed = false
          this.embedOnce = `${BASICURL}/gdda-new/gdda/util/viewHandoverPdf?docId=${val.id}`
          this.$forceUpdate()
        } else if (res.optFlag == 2) {
          this.getDataViewDialog47 = true
          this.showEditLook.textContents = val.text
          this.showEditLook.textContentIds = val.id
        }
      })
    },
    handleNodeClickTwo (val) {
      console.log(val)
      let types = val.attributes.type
      let ids = val.id
      let rids = this.showViewTwoId.id
      val.children = []
      // 左侧树
      listTreeJson({id: rids, type: types,resourceParentId: ids}).then(res => {
        if (res.data.data.message) {
          this.$message.info(res.data.data.message)
        } else {
          val.children = res.data.data
        }
      })
      // 右侧基本信息
      listTreeJsonView({id: ids, type: types}).then(res => {
        if (types == 'f') {
          this.showEditLookTwo = res.data.file
        } else if (types == 'v') {
          this.showEditLookTwo = res.data.folder
        } else if (types == 'p') {
          this.showEditLookTwo = res.data.project
        }
      })
      // 判断右侧是否有关键档案
      checkExtendInfo().then(res => {
        this.showViewTwo = res.data.optFlag
      })
      // 右侧关键档案
      extendInfoView({id: ids, type: types}).then(res => {
        this.paramsViewTwo = res.data
      })
    },
    showList () {
      listSeriesByFondsAndRole({id: '1374133141812'}).then(res => {
        // console.log(res)
        this.FondsAndRole = res.data
        listHandOverQrData(this.params).then(resVal => {
          console.log(resVal);
          this.tableData = resVal.data.rows
          this.tableData.forEach(item => {
            res.data.forEach(itemVal => {
              if (item.tag == itemVal.tag) {
                item.tagName = itemVal.name
              }
            })
          })
          this.params.total = resVal.data.total
        })
      })
    },
    showListBtom (val) {
      this.dialogTableBtom = []
      this.paramsTwo.subId = this.onceTable[0].gid
      this.paramsTwo.status = 0
      listHandOverDetailData(this.paramsTwo).then(res => {
        if (this.dialogShowContent || this.dialogShowContentFan) {
          this.dialogTableBtom = res.data.rows
        } else {
          this.tableDataTwo = res.data.rows
        }
        this.paramsTwo.total = res.data.total
      })
    },
    // 获取全宗 档案类型第一级
    showSearchData () {
      getFonds().then(res => {
        this.fullZong = res.data
      })
      listSeriesByFondsAndRole({id: '1374133141812'}).then(res => {
        // console.log(res)
        this.FondsAndRole = res.data
        this.searchSeries(1379482316593)
      })
    },
    // 档案类型第1级
    searchSeries (val) {
      listSeriesByFonds({id: val}).then(res => {
        this.FondsAndRoleTwo = res.data
      })
      this.params.page = 1
      this.params.rows = 10
      this.params.total = 0
      this.params.series2 = null
      if (this.params.series1 == 1388742017296 || this.params.series1 == 1379398885203 || this.params.series1 == 1374133285843) {
        this.tableData = []
      } else {
        this.showList()
      }
      if (this.params.series1 == 1388742017296 || this.params.series1 == 1388742017269) {
        this.showSelectAudit = false
        this.showSelectAuditTwo = false
      } else if (this.params.series1 == 1374133285843) {
        this.showSelectAudit = false
        this.showSelectAuditTwo = false
      } else {
        this.showSelectAudit = true
        this.showSelectAuditTwo = true
      }
    },
    // 第2级
    searchSeriesTwo (val) {
      listSeriesByFonds({id: val}).then(res => {
        this.FondsAndRoleThree = res.data
      })
      this.params.page = 1
      this.params.rows = 10
      this.params.total = 0
      this.params.series3 = null
      if (this.params.series2 == 1388742017297 || this.params.series2 == 1388742017298) {
        this.showClearUpBtn = true
      } else {
        this.showClearUpBtn = false
      }
      if (this.params.series2 == 1374133285844) {
        this.showSelectAudit = true
        this.showSelectAuditTwo = false
      } else if (this.params.series2 == 1388742017297) {
        this.showSelectAudit = false
        this.showSelectAuditTwo = false
      } else {
        this.showSelectAudit = false
        this.showSelectAuditTwo = false
      }
      this.showList()
    },
    // 档案类型第三级获取数据
    searchSeriesThree (val) {
      this.params.page = 1
      this.params.rows = 10
      this.params.total = 0
      this.showList()
      this.$forceUpdate()
    },

    // 上表格的多选
    handleSelectionChange (val) {
      this.onceTable = val
      if (this.onceTable.length == 1) {
        this.showListBtom()
      } else if (this.onceTable.length == 0) {
        this.tableDataTwo = []
        this.paramsTwo.total = null
      } else if (this.onceTable.length > 1 && this.onceTable.length <= 2) {
        this.$refs.multipleTable.toggleRowSelection(this.onceTable[0])
      }
    },
    // 单页选择
    handleCurrentChange (val) {
      this.params.page = val
      this.showList()
    },
    // 移交类型
    yjTypeBtn (val) {
      this.params.series1 = null
      this.params.series2 = null
      this.params.series3 = null
      this.FondsAndRole = []
      this.FondsAndRoleTwo = []
      this.FondsAndRoleThree = []
      // this.showSearchData()
      listSeriesByFondsAndRole({id: val}).then(res => {
        this.FondsAndRole = res.data
      })
      this.params.page = 1
      this.params.rows = 10
      this.params.total = 0
      this.showList()
    },
    yjTypeBtnTwo (val) {
      // this.showSearchData()
      listSeriesByFondsAndRole({id: val}).then(res => {
        this.FondsAndRole = res.data
      })
      this.params.page = 1
      this.params.rows = 10
      this.params.total = 0
      this.showList()
    },
    // 查看
    showLookBtn () {
      let item = this.$onceWay().onceTableList(this.onceTableBtom)
      if (item == 1) {
        this.activeName = 'contentOnce'
        this.showEditLook = {}
        this.showCheckEmbed = true
        this.treTable = []
        this.dialogShowLook = true
        let params = {
          id: this.onceTableBtom[0].fileId,
          gid: this.onceTableBtom[0].handoverId
        }
        listHandOverDocumentTree(params).then(res => {
          this.treTable = res.data
        })
        checkExtendInfo(
          {
            id: this.onceTableBtom[0].fileId,
            type: 'f'
          }).then(res => {
          this.showView = res.data.optFlag
        })
        getHandOverFile({fileId: this.onceTableBtom[0].fileId}).then(res => {
          console.log(res);
          this.showEditLook = res.data
          this.showEditLook.openingType = this.$onceWay().showOpeningType(this.showEditLook.openingType)
          this.showEditLook.retentionPeriod = this.$onceWay().showRetentionPeriod(this.showEditLook.retentionPeriod)
          this.showEditLook.c58 = this.$onceWay().showC59(this.showEditLook.c58)
          this.showEditLook.c59 = this.$onceWay().showC59(this.showEditLook.c59)
          this.showEditLook.c93 = this.$onceWay().showC93(this.showEditLook.c93)
        })
        handoverExtendInfoView({
          id: this.onceTableBtom[0].fileId,
          type: 'f'
        }).then(res => {
          this.paramsView = res.data
        })
      }
    },
    // 弹框查看
    showLookBtnTwo () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.showEditLook = {}
        this.activeName = 'contentOnce'
        this.showCheckEmbed = true
        this.treTable = []
        this.dialogShowLook = true
        let params = {
          id: this.onceTableBtomTwo[0].fileId,
          gid: this.onceTableBtomTwo[0].handoverId
        }
        listHandOverDocumentTree(params).then(res => {
          this.treTable = res.data
        })
        checkExtendInfo(
          {
            id: this.onceTableBtomTwo[0].fileId,
            type: 'f'
          }).then(res => {
          this.showView = res.data.optFlag
        })
        getHandOverFile({fileId: this.onceTableBtomTwo[0].fileId}).then(res => {
          console.log(res);
          this.showEditLook = res.data
          this.showEditLook.openingType = this.$onceWay().showOpeningType(this.showEditLook.openingType)
          this.showEditLook.retentionPeriod = this.$onceWay().showRetentionPeriod(this.showEditLook.retentionPeriod)
          this.showEditLook.c58 = this.$onceWay().showC59(this.showEditLook.c58)
          this.showEditLook.c59 = this.$onceWay().showC59(this.showEditLook.c59)
          this.showEditLook.c93 = this.$onceWay().showC93(this.showEditLook.c93)
        })
        handoverExtendInfoView({
          id: this.onceTableBtomTwo[0].fileId,
          type: 'f'
        }).then(res => {
          this.paramsView = res.data
        })
      }
    },
    // 下表格表格的多选
    handleSelectionChangeBtom (val, even, item) {
      this.onceTableBtom = val
      // if (this.onceTableBtom.length > 1) {
      //   this.$refs.multipleTableBtom.toggleRowSelection(this.onceTableBtom[0])
      // }
    },
    // 弹框里下表格表格的多选
    handleSelectionChangeBtomTwo (val) {
      this.onceTableBtomTwo = val
      // if (this.onceTableBtomTwo.length > 1) {
      //   this.$refs.multipleTableBtomTwo.toggleRowSelection(this.onceTableBtomTwo[0])
      // }
    },
    // 页面最下方单页选择
    handleCurrentChangeTwo (val) {
      this.paramsTwo.page = val
      this.showListBtom()
    },
    handleSelectionChangeBtomThree (val) {
      this.onceTableBtomThree = val
    },
    // 页面最下方单页选择
    handleCurrentChangeThree (val) {
      this.paramsThree.page = val
      this.showListDelete()
    },
    handleClose () {
      this.dialogShowContent = false
    },
    handleCloseTwo () {
      this.dialogShowLook = false
      this.getDataViewDialog4 = false
      this.getDataViewDialog8 = false
      this.getDataViewDialog10 = false
      this.getDataViewDialog11 = false
      this.getDataViewDialog12 = false
      this.getDataViewDialog13 = false
      this.getDataViewDialog14 = false
      this.getDataViewDialog20 = false
      this.getDataViewDialog21 = false
      this.getDataViewDialog23 = false
      this.getDataViewDialog27 = false
      this.getDataViewDialog48 = false
      this.getDataViewDialog49 = false
      this.getDataViewDialog50 = false
      this.getDataViewDialog51 = false
    },
    handleCloseThree () {
      this.dialogShowLookTwo = false
      this.getDataViewDialog = false
      this.getDataViewDialog15 = false
      this.getDataViewDialog47 = false
    },
    // table标签页切换
    resetTable (val) {
      this.activeName = val.name
    },
    // 综合审核
    tureOverBtn () {
      let item = this.$onceWay().onceTableList(this.onceTable)
      if (item == 1) {
        // getQrYjList({cid: this.onceTable[0].cid}).then(res => {
        getArchiveYjList({subId: this.onceTable[0].cid}).then(res => {
          this.showEdit = res.data.data
          this.dialogTable = JSON.parse(res.data.data.handoverRemark)
          if (this.dialogTable) {
            this.dialogTable.forEach((item, index) => {
              item.handoverRemark = item.handoverRemark.split('<br>')
            })
          }
          // this.showEdit.handoverRemark = JSON.parse(this.showEdit.handoverRemark)
          // console.log(this.showEdit.handoverRemark);
          this.dialogShowContent = true
          this.showListBtom()
        })
      }
    },
    mangeBtn () {
      if (this.showEdit.applyRemarkCopy == null || this.showEdit.applyRemarkCopy == '') {
        this.$message.error('请填写意见')
      } else if (this.showEdit.handoverStyle == 1) {
        if (this.showEdit.receiveAddress == null || this.showEdit.receiveAddress == '') {
          this.$message.error('请填写邮寄地址')
        } else {
          this.mangeBtnTwo()
        }
      } else if (this.showEdit.handoverStyle == 0) {
        if (this.showEdit.handoverType == null || this.showEdit.handoverType == '') {
          this.$message.error('请选择邮寄方式')
        } else if (this.showEdit.receiveAddress == null || this.showEdit.receiveAddress == '') {
          this.$message.error('请填写邮寄地址')
        } else {
          this.mangeBtnTwo()
        }
      } else {
        this.mangeBtnTwo()
      }
    },
    mangeBtnTwo () {
      for (let i in this.dialogTableBtom) {
        if (this.dialogTableBtom[i].handoverException != '' && this.dialogTableBtom[i].handoverException != null && this.dialogTableBtom[i].handoverException != '广发未办理盖章') {
          this.showEdit.isHandover = '1'
          break
        } else {
          this.showEdit.isHandover = '0'
        }
      }
      if (this.onceTable[0].handoverUser != '' && this.onceTable[0].handoverUser != null) {
        this.showEdit.isHandover = '1'
      }
      this.showEdit.subId = this.onceTable[0].cid
      // this.showEdit.bs = 'yz'
      this.showEdit.handoverRemark = this.showEdit.applyRemarkCopy
      this.getDataViewDialog = true
    },
    // 确定按钮
    submitBtn1 () {
      // glyShPass
      this.showEdit.changeMode = 'glySh'
      this.showEdit.bs = ''
      glyShPass(this.showEdit).then(res => {
        if (res.data.optFlag == 2) {
          this.$message.error('系统提示, "确认失败，当前移交状态的移交单已被其他用户处理了"')
        } else if (res.data.optFlag == 1) {
          this.$message.success('成功')
          this.handleClose()
          this.handleCloseTwo()
          this.showList()
        } else {
          this.$message.success('失败')
        }
      })
    },
    // 邮寄方式选择
    receiveBtn () {
      if (this.showEdit.handoverType == 2) {
        this.showDisable = true
        this.showEdit.handoverYys = null
        this.showEdit.handoverYdh = null
        this.showEdit.receiveAddress = null
      } else if (this.showEdit.handoverType == 1) {
        this.showDisable = false
      }
    },
    // 上传
    showLookBtn7 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.getDataViewDialog8 = true
        this.clearImgDel()
      }
    },
    clearImgDel () {
      this.imgVal = []
      if (this.$refs.AddBtnImgTwo) {
        this.$nextTick(() => {
          this.$refs.AddBtnImgTwo.clearFiles()
        })
      }
      if (this.$refs.AddBtnImgOne) {
        this.$nextTick(() => {
          this.$refs.AddBtnImgOne.clearFiles()
        })
      }
    },
    // 删除附件
    showLookBtn10 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.getDataViewDialog10 = true
        this.showListDelete()
      }
    },
    showListDelete () {
      this.paramsDelete.subId = this.onceTableBtomTwo[0].id
      listHandOverDocumentData(this.paramsDelete).then(res => {
        this.deleteTable = res.data.rows
        this.paramsDelete.total = res.data.total
      })
    },
    // 删除上传
    handleRemove (val) {
      this.imgVal.splice(val, 1)
    },
    handleChange (file, fileList) {
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('type', 'yj')
      formData.append('name', 'file')
      uploadPicture(formData).then(res => {
        if (res.code == 0) {
          this.imgVal.push(res.data.pathAndMD5)
        } else {
          this.$message.error(res.message)
        }
      })
    },
    submitBtn8 () {
      let params = {
        subId: this.onceTableBtomTwo[0].fileId,
        detailId: this.onceTableBtomTwo[0].id,
        gid: this.onceTableBtomTwo[0].handoverId,
        imgVal: JSON.stringify(this.imgVal),
        bs: 'glysh'
      }
      saveUploadYjDoc(params).then(res => {
        if (res.data.optFlag == 0) {
          this.$message.success('上传成功')
          this.getDataViewDialog8 = false
          this.showListBtom()
        } else if (res.data.optFlag == 1) {
          this.$message.error('上传失败，' + res.data.msg)
        } else if (res.data.optFlag == -1) {
          this.$message.error('上传失败，因为文件' + res.data.msg + '已上传过了，请重新选择上传文件')
        }
      })
    },
    tableDeleteFile () {
      let item = this.$onceWay().onceTableListTwo(this.onceTableBtomTwo)
      if (item == 1) {
        this.getDataViewDialog11 = true
      }
    },
    submitBtn9 () {
      let params = {
        subId: this.onceTable[0].gid,
        imgVal: this.imgVal
      }
      uploadExcel(params).then(res => {
        if (res.optFlag == 0) {
          this.$message.success(res.msg)
          this.getDataViewDialog10 = false
          this.showListBtom()
        } else {
          this.$message.error(res.msg)
          this.getDataViewDialog10 = false
          this.showListBtom()
        }
      })
    },
    submitBtn11 () {
      let item = this.$onceWay().deleteId(this.onceTableBtomThree)
      let params = {
        ids: item,
        // bs: this.onceTableBtomTwo[0].handoverType == 0 ? 'jqyj' : 'mhyj'
        bs: 'glysh'
      }
      deleteDoc(params).then(res => {
        if (res.data.optFlag == 0) {
          this.$message.success('删除成功')
          this.getDataViewDialog11 = false
          this.showListDelete()
        } else {
          this.$message.error('删除失败')
          this.getDataViewDialog11 = false
          this.showListDelete()
        }
      })
    },
    // 异常
    showLookBtn11 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.getDataViewDialog12 = true
        this.clearRefs()
        if (this.onceTableBtomTwo[0].handoverException) {
          if (this.onceTableBtomTwo[0].handoverException.split(',').length >= 2) {
            let a = this.onceTableBtomTwo[0].handoverException.split(',')
            a.forEach((item, index) => {
              // if (item == '原件不完整（对方未盖章）') this.checkParams.contentOne = '原件不完整（对方未盖章）'
              if (item == '原件不完整（对方未盖章）') {
                this.$nextTick(() => {
                  this.$refs.contentOne.model = '原件不完整（对方未盖章）'
                })
              }
              if (item == '原件不完整（无签署时间）') {
                this.$nextTick(() => {
                  this.$refs.contentTwo.model = '原件不完整（无签署时间）'
                })
              }
              if (item == '原件不完整（缺失授权书）') {
                this.$nextTick(() => {
                  this.$refs.contentThree.model = '原件不完整（缺失授权书）'
                })
              }
              if (item == '原件不完整（对方未签名）') {
                this.$nextTick(() => {
                  this.$refs.contentFour.model = '原件不完整（对方未签名）'
                })
              }
              if (item == '原件不完整（缺失部分页）') {
                this.$nextTick(() => {
                  this.$refs.contentFive.model = '原件不完整（缺失部分页）'
                })
              }
              if (item == '广发未办理盖章') {
                this.$nextTick(() => {
                  this.$refs.hException1.model = '广发未办理盖章'
                })
              }
              if (item == '未打印签署') {
                this.$nextTick(() => {
                  this.$refs.hException2.model = '未打印签署'
                })
              }
            })
          } else {
            if (this.onceTableBtomTwo[0].handoverException == '(A1)合同各方已盖章，且已履行完毕') {
              this.$nextTick(() => {
                this.$refs.hException3.model = '(A1)合同各方已盖章，且已履行完毕'
              })
            }
            if (this.onceTableBtomTwo[0].handoverException == '(A2)合同各方已盖章，且正在履行') {
              this.$nextTick(() => {
                this.$refs.hException4.model = '(A2)合同各方已盖章，且正在履行'
              })
            }
            if (this.onceTableBtomTwo[0].handoverException == '自留函') {
              this.$nextTick(() => {
                this.$refs.hException4.model = '自留函'
                this.checkParams.zlhDate = this.onceTableBtomTwo[0].handoverDate
                this.selectDisTwo()
              })
            }
            if (this.onceTableBtomTwo[0].handoverException == '(A3)合同各方已盖章，合同不再履行') {
              this.$nextTick(() => {
                this.$refs.hException5.model = '(A3)合同各方已盖章，合同不再履行'
              })
            }
            if (this.onceTableBtomTwo[0].handoverException == '(A4)合同仅有我方盖章') {
              this.$nextTick(() => {
                this.$refs.hException6.model = '(A4)合同仅有我方盖章'
              })
            }
          }
        }
        // 达标措施
        console.log(this.onceTableBtomTwo[0].upStandard)
        if (this.onceTableBtomTwo[0].upStandard) {
          if (this.onceTableBtomTwo[0].upStandard.split(')').length >= 2) {
            let a = this.onceTableBtomTwo[0].upStandard.split(')')
            a.forEach(item => {
              if (item == '补充整改完成后原件归档') {
                this.$nextTick(() => {
                  this.$refs.checkBosSeven.model = '补充整改完成后原件归档'
                })
              }
            })
          } else {
            if (this.onceTableBtomTwo[0].upStandard == '补充整改完成后原件归档') {
              this.$nextTick(() => {
                this.$refs.checkBosSeven.model = '补充整改完成后原件归档'
              })
            }
            if (this.onceTableBtomTwo[0].upStandard == '已补签') {
              if (this.onceTableBtomTwo[0].handoverException == '(A1)合同各方已盖章，且已履行完毕') {
                this.$nextTick(() => {
                  this.$refs.checkBosOne.model = '已补签'
                })
              }
              if (this.onceTableBtomTwo[0].handoverException == '(A2)合同各方已盖章，且正在履行' || this.onceTableBtomTwo[0].handoverException == '自留函') {
                this.$nextTick(() => {
                  this.$refs.checkBosThree.model = '已补签'
                })
              }
            }
            if (this.onceTableBtomTwo[0].upStandard == '已变更、解除、终止') {
              this.$nextTick(() => {
                this.$refs.checkBosFour.model = '已变更、解除、终止'
              })
            }
            if (this.onceTableBtomTwo[0].upStandard == '已全部回收') {
              this.$nextTick(() => {
                this.$refs.checkBosFive.model = '已全部回收'
              })
            }
            if (this.onceTableBtomTwo[0].upStandard == '补充整改完成后原件归档') {
              this.$nextTick(() => {
                this.$refs.checkBosSeven.model = '补充整改完成后原件归档'
              })
            }
          }
        }
        // 补救措施
        if (this.onceTableBtomTwo[0].remedial) {
          if (this.onceTableBtomTwo[0].remedial == '复印件等附件归档') {
            this.$nextTick(() => {
              this.$refs.checkBosTwo.model = '复印件等附件归档'
            })
          }
          if (this.onceTableBtomTwo[0].remedial == '已有遗失说明') {
            this.$nextTick(() => {
              this.$refs.checkBosSix.model = '已有遗失说明'
            })
          }
        }
        this.$nextTick(() => {
          this.selectDis()
        })
      }
    },
    selectDis (val) {
      if (this.checkParams.hException1 == '广发未办理盖章' || this.checkParams.hException2 == '未打印签署') {
        this.disYj = false
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (this.checkParams.hException3 == '(A1)合同各方已盖章，且已履行完毕') {
        this.disYj = true
        this.disHtOne = false
        this.disHtOneTwo = false
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (this.checkParams.hException4 == '(A2)合同各方已盖章，且正在履行') {
        this.disYj = true
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = false
        this.disHtTwoOnce = true
        this.disHtTwoTwo = false
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (this.checkParams.hException5 == '(A3)合同各方已盖章，合同不再履行') {
        this.disYj = true
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = false
        this.disHtThreeTwo = false
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (this.checkParams.hException6 == '(A4)合同仅有我方盖章') {
        this.disYj = true
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = false
        this.disHtFourTwo = false
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (
        this.checkParams.contentOne == '原件不完整（对方未盖章）' ||
        this.checkParams.contentTwo == '原件不完整（无签署时间）' ||
        this.checkParams.contentThree == '原件不完整（缺失授权书）' ||
        this.checkParams.contentFour == '原件不完整（对方未签名）' ||
        this.checkParams.contentFive == '原件不完整（缺失部分页）'
      ) {
        this.disYj = true
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = true
        this.disHtTwoOnce = true
        this.disHtTwoTwo = true
        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = false
        this.disHtBTwo = false
        this.disHtBThree = false
        this.disHtBFour = false
        this.disHtBFive = false
        this.disHtBOnceTwo = false
      } else if (
        this.checkParams.hException1 == undefined &&
        this.checkParams.hException2 == undefined &&
        this.checkParams.hException3 == undefined &&
        this.checkParams.hException4 == undefined &&
        this.checkParams.zlhDateOne == undefined
      ) {
        this.$refs.checkBosOne.model = false
        this.$refs.checkBosTwo.model = false
        this.$refs.checkBosThree.model = false
        this.$refs.checkBosFour.model = false
        this.$refs.checkBosFive.model = false
        this.$refs.checkBosSix.model = false
        this.$refs.checkBosSeven.model = false
        this.disCheckAbel()
      }
      // else if (this.checkParams.hException3 == undefined && this.checkParams.remedial2 == undefined && this.checkParams.upStandard2 == undefined) {
      //   console.log(22);
      //   this.disCheckAbel()
      // }
      else if (
        this.checkParams.hException4 == undefined &&
        this.checkParams.upStandard3 == undefined &&
        this.checkParams.zlhDateOne == undefined &&
        this.checkParams.zlhDate == undefined) {
        console.log(1)
        this.disCheckAbel()
      }
    },
    selectDisTwo (val) {
      if (this.checkParams.hException4 == '自留函') {
        this.$message.info('请于出具自留函之日起6个月内完成全部合同归档，到期未完成将纳入合同异常归档考核！')
        this.disYj = true
        this.disHtOne = true
        this.disHtOneTwo = true
        this.disHtTwo = true
        this.disHtTwoOnce = false
        this.disHtTwoTwo = false

        this.disHtTwoDate = true

        this.disHtThree = true
        this.disHtThreeTwo = true
        this.disHtFour = true
        this.disHtFourTwo = true
        this.disHtBOne = true
        this.disHtBTwo = true
        this.disHtBThree = true
        this.disHtBFour = true
        this.disHtBFive = true
        this.disHtBOnceTwo = true
      } else if (
        this.checkParams.hException1 == undefined &&
        this.checkParams.hException2 == undefined &&
        this.checkParams.hException3 == undefined &&
        this.checkParams.hException4 == undefined &&
        this.checkParams.zlhDateOne == undefined
      ) {
        this.$refs.checkBosOne.model = false
        this.$refs.checkBosTwo.model = false
        this.$refs.checkBosThree.model = false
        this.$refs.checkBosFour.model = false
        this.$refs.checkBosFive.model = false
        this.$refs.checkBosSix.model = false
        this.$refs.checkBosSeven.model = false
        this.disCheckAbel()
      }
      /* else {
          this.disYj = false
          this.disHtOne = false
          this.disHtOneTwo = false
          this.disHtTwo = false
          this.disHtTwoTwo = false
          this.disHtThree = false
          this.disHtThreeTwo = false
          this.disHtFour = false
          this.disHtFourTwo = false
          this.disHtBOne = false
          this.disHtBTwo = false
          this.disHtBThree = false
          this.disHtBFour = false
          this.disHtBFive = false
          this.disHtBOnceTwo = false
          this.disHtTwoDate = false
        } */
    },
    disCheckAbel () {
      this.disYj = false
      this.disHtOne = false
      this.disHtOneTwo = true
      this.disHtTwo = false
      this.disHtTwoOnce = false
      this.disHtTwoDate = false
      this.disHtTwoTwo = true
      this.disHtThree = false
      this.disHtThreeTwo = true
      this.disHtFour = false
      this.disHtFourTwo = true
      this.disHtBOne = false
      this.disHtBTwo = false
      this.disHtBThree = false
      this.disHtBFour = false
      this.disHtBFive = false
      this.disHtBOnceTwo = true
      this.checkParams = {}
    },
    errorCheckBtn () {
      this.checkParams.subId = this.onceTableBtomTwo[0].id
      // this.checkParams.bs = this.onceTableBtomTwo[0].handoverType == 0 ? 'jqyj' : 'mhyj'
      this.checkParams.bs = 'glysh'
      let one = []
      let two = ''
      one.push(this.checkParams.contentOne)
      one.push(this.checkParams.contentTwo)
      one.push(this.checkParams.contentThree)
      one.push(this.checkParams.contentFour)
      one.push(this.checkParams.contentFive)
      one.forEach((item, index) => {
        if (item) {
          two += item + ','
        }
      })
      this.checkParams.hException7 = two
      saveHandoverYc(this.checkParams).then(res => {
        if (res.data.optFlag == 1) {
          let params = {
            id: this.onceTableBtomTwo[0].id,
            subId: this.onceTableBtomTwo[0].fileId,
            isOriginal: this.onceTableBtomTwo[0].isOriginal
          }
          saveIsOriginal(params).then(res => {
            if (res.data.optFlag == 0) {
              this.$message.success('处理结果：成功')
              this.getDataViewDialog12 = false
              this.showListBtom()
            } else if (res.data.optFlag == -1) {
              this.$message.error('处理结果：失败')
              this.getDataViewDialog12 = false
              this.showListBtom()
            }
          })
        } else if (res.data.optFlag == -1) {
          this.$message.error('处理结果：失败')
          this.getDataViewDialog12 = false
          this.showListBtom()
        }
      })
    },
    clearRefs () {
      this.$nextTick(() => {
        this.$refs.hException1.model = false
        this.$refs.hException2.model = false
        this.$refs.hException3.model = false
        this.$refs.checkBosOne.model = false
        this.$refs.checkBosTwo.model = false
        this.$refs.hException4.model = false
        this.$refs.checkBosThree.model = false
        this.$refs.hException5.model = false
        this.$refs.checkBosFour.model = false
        this.$refs.hException5.model = false
        this.$refs.hException6.model = false
        this.$refs.checkBosFive.model = false
        this.$refs.checkBosSix.model = false
        this.$refs.checkBosSeven.model = false
        this.$refs.contentOne.model = false
        this.$refs.contentTwo.model = false
        this.$refs.contentThree.model = false
        this.$refs.contentFour.model = false
        this.$refs.contentFive.model = false
        this.checkParams = {}
      })
    },
    // 合同异常归档下载
    wordPullBtn () {
      wordPull(`gdda-new/gdda/archiveYj/downLoadCzExplain`, '合同异常归档操作说明')
    },
    // 修改附件
    showLookBtn13 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        this.getDataViewDialog14 = true
        this.showListDelete()
      }
    },
    tableDeleteFileTwo () {
      let item = this.$onceWay().onceTableListTwo(this.onceTableBtomThree)
      if (item == 1) {
        this.getDataViewDialog15 = true
        this.showEditLookTitle = JSON.parse(JSON.stringify(this.onceTableBtomThree[0].titleProper))
      }
    },
    submitBtn14 () {
      let params = {
        titleProper: this.showEditLookTitle,
        subId: this.onceTableBtomThree[0].id,
        id: this.onceTableBtomThree[0].id
      }
      editDocTitle(params).then(res => {
        if (res.data.optFlag == 1) {
          this.$message.success('修改成功')
          this.showListDelete()
          this.getDataViewDialog15 = false
        } else {
          this.$message.error('修改失败')
          this.showListDelete()
          this.getDataViewDialog15 = false
        }
      })
    },
    // 移交详情
    showLookBtn16 () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        getYjInformation({subId: this.onceTableBtomTwo[0].id}).then(res => {
          this.paramsEditContent = res.data
          this.getDataViewDialog20 = true
        })
      }
    },
    radioCompletes (val) {
      this.paramsEditContent.completes = val
      this.$forceUpdate()
    },
    submitBtn17 () {
      let params = {
        subId: this.onceTableBtomTwo[0].id,
        completes: this.paramsEditContent.completes
      }
      saveYjInfoData(params).then(res => {
        if (res.data.optFlag == 0) {
          this.$message.success('修改成功')
          this.getDataViewDialog20 = false
          this.showListBtom()
        } else {
          this.$message.error('修改失败')
          this.getDataViewDialog20 = false
        }
      })
    },
    // 查看合同-- 有BUG
    submitBtn4 () {
      let reg = /^[0-9]*$/
      if (this.showEditLook.titleProper == undefined) {
        this.$message.error('请填写题名')
      } else if (this.showEditLook.dateOfCreation == undefined) {
        this.$message.error('请选择时间')
      } else if (this.showEditLook.yearCode == undefined || this.showEditLook.yearCode.length < 4 || this.showEditLook.yearCode.length > 4) {
        this.$message.error('请填写年度(输入长度为4）')
      } else if (!reg.test(this.showEditLook.yearCode)) {
        this.$message.error('年度只能填写数字')
      } else {
        if (this.showBtnLook) {
          this.showEditLook.subId = this.showEditLookSubId
          this.showEditLook.bs = 'qjym'
        } else {
          this.showEditLook.subId = this.onceTable[0].gid
          this.showEditLook.bs = this.onceTable[0].handoverType == 0 ? 'jqyj' : 'mhyj'
        }
        saveMhYjFile(this.showEditLook).then(res => {
          if (res.data.optFlag == 1) {
            // this.$message.success('录入成功')
            this.$message.success(res.message)
            this.getDataViewDialog4 = false
            if (this.showBtnLook) {
              this.showLookBtn44List()
            } else {
              this.showListBtom()
            }
          } else {
            // this.$message.error('录入失败')
            this.$message.error(res.message)
            this.getDataViewDialog4 = false
          }
        })
      }
    },
    restBtn () {
      if (this.showBtnLook) {
        findSeriesCode({id: this.showEditLookSubId}).then(res => {
          this.showEditLook = res.data
        })
      } else {
        this.showEditLookSubId = ''
        findSeriesCode({id: this.onceTable[0].gid}).then(res => {
          this.showEditLook = res.data
        })
      }
    },
    // 检索
    searchContent () {
      this.getDataViewDialog21 = true
      this.params = {
        page: 1,
        rows: 10,
        status: this.params.status,
        fonds: this.params.fonds,
        series1: this.params.series1,
        searchType: this.params.searchType,
        total: this.params.total
      }
    },
    // 检索
    submitBtn18 () {
      this.showList()
      this.getDataViewDialog21 = false
    },
    reset () {
      this.params = {
        page: 1,
        rows: 10,
        status: this.params.status,
        fonds: this.params.fonds,
        series1: this.params.series1,
        searchType: this.params.searchType,
        total: this.params.total
      }
    },
    // 监所内的搜索
    remoteMethodUser (val) {
      let params = {
        orgFlag1: -10000,
        q: val
      }
      searchFindUser(params).then(res => {
        this.yjcurrentuserArr = res
      })
    },
    // 监所内的搜索
    remoteMethodMan (val) {
      let params = {
        orgFlag1: -10000,
        q: val
      }
      searchFindUser(params).then(res => {
        this.yjc89Arr = res
      })
    },
    // 重新发送代办
    retryBtn () {
      let item = this.$onceWay().onceTableList(this.onceTable)
      if (item == 1) {
        this.getDataViewDialog23 = true
      }
    },
    submitBtn19 () {
      // sendGlyShDb({id: this.onceTable[0].cid}).then(res => {
      let types = ''
      if (this.params.series1 == 1388742017269) types = 'kj'
      else if (this.params.series1 == 1374133285828) types = 'sx'
      else if (this.params.series2 == 1374133285844) types = 'yz'
      yyjBackSave({cid: this.onceTable[0].cid, gid: this.onceTable[0].gid}).then(res => {
        if (res.data.optFlag == 1) {
          this.$message.success('处理成功')
          this.getDataViewDialog23 = false
          this.showList()
        } else {
          this.$message.error(res.data.msg)
          this.getDataViewDialog23 = false
          this.showList()
        }
      })
    },
    // 导出合同移交登记表
    submitBtn27 () {
      if (this.paramsDownload.exportStartDate == null || this.paramsDownload.exportStartDate == '') {
        this.$message.error('请选择合同日期（起）')
      } else if (this.paramsDownload.exportEndDate == null || this.paramsDownload.exportEndDate == '') {
        this.$message.error('请选择合同日期（止）')
      } else {
        valueIndex().exportXls('/gdda-new/gdda/archiveYj/exportHtInfoTable', this.paramsDownload, '导出录入合同信息模板', 'get')
      }
      // exportHtTable(this.paramsDownload).then(res => {
      //   console.log(res);
      // })
    },
    // 移交退回
    tuiHuiBtn () {
      let params = {
        // type: this.onceTable[0].handoverStyle == 0 ? 'jqyj' : 'mhyj',
        type: this.onceTable[0].handoverStyle,
        gid: this.onceTable[0].gid
      }
      countHandOverDetail(params).then(res => {
        if (res.data.optFlag == -1) {
          this.$message.error('系统提示, "移交失败，系统出错')
        } else if (res.data.optFlag == 2) {
          this.$message.error('系统提示, "确认失败，当前移交状态的移交单已被其他用户处理了')
        } else {
          this.showEdit.gid = this.onceTable[0].gid
          this.showEdit.subId = this.onceTable[0].cid
          this.showEdit.handoverRemark = this.showEdit.applyRemarkCopy
          this.isHander()
          // handOverBack(this.showEdit).then(res => {
          glyHandOverBack(this.showEdit).then(res => {
            if (res.optFlag == 1) {
              this.$message.success('退回成功')
              this.handleCloseTwo()
              this.handleClose()
              this.showList()
            } else if (res.optFlag == 2) {
              this.$message.error('已被处理')
              this.handleCloseTwo()
              this.handleClose()
              this.showList()
            } else {
              this.$message.error('退回失败')
              this.handleCloseTwo()
              this.handleClose()
              this.showList()
            }
          })
        }
      })
    },
    // 移交归档
    tuiHuiBtnTwo () {
      let item = this.$onceWay().onceTableList(this.onceTableBtomTwo)
      if (item == 1) {
        let params = {
          fileId: this.onceTableBtomTwo[0].id,
          subId: this.onceTable[0].gid,
        }
        gdHandOverFile(params).then(res => {
          console.log(res);
          if (res.data.optFlag == 1) {
            this.$message.success('归档成功')
            this.handleCloseThree()
            this.handleCloseTwo()
            this.handleClose()
            this.showList()
          } else {
            this.$message.error('归档失败')
          }
        })
      }
    },
    // 判断是否有异常
    isHander () {
      for (let i in this.dialogTableBtom) {
        if (this.dialogTableBtom[i].handoverException != '' && this.dialogTableBtom[i].handoverException != null && this.dialogTableBtom[i].handoverException != '广发未办理盖章') {
          this.showEdit.isHandover = '1'
          break
        } else {
          this.showEdit.isHandover = '0'
        }
      }
      if (this.onceTable[0].handoverUser != '' && this.onceTable[0].handoverUser != null) {
        this.showEdit.isHandover = '1'
      }
    },
    lookFileContent (val, item) {
      this.activeName = 'contentOnce'
      this.showEditLookTwo = {}
      let types = val
      let ids = item.id
      this.showViewTwoId = item
      this.showCheckEmbed = true
      // 左侧树
      listTreeJson({id: ids, type: types}).then(res => {
        this.treTableTwo = res.data.data
        this.attributesType = this.treTableTwo[0].attributes.type
      })
      // 右侧基本信息
      listTreeJsonView({id: ids, type: types}).then(res => {
        if (types == 'f') {
          this.showEditLookTwo = res.data.file
        } else if (types == 'v') {
          this.showEditLookTwo = res.data.folder
        } else if (types == 'p') {
          this.showEditLookTwo = res.data.project
        }
      })
      // 判断右侧是否有关键档案
      checkExtendInfo().then(res => {
        this.showViewTwo = res.data.optFlag
      })
      // 右侧关键档案
      extendInfoView({id: ids, type: types}).then(res => {
        this.paramsViewTwo = res.data
      })
      this.dialogShowLookTwo = true
    },
    // 变更移交人查询
    orgFlag (val) {
      console.log(val)
      let params = {
        q: val,
        orgFlag1: -10000
      }
      findChangeUser(params).then(res => {
        this.sqFondsList = res.data
      })
    },
  },
  created () {
    this.showSearchData()
    this.showList()
    listAllDept().then(res => {
      this.yjc90Arr = res.data
    })
    listFileType().then(res => {
      this.fileTypeArr = res.data
    })
    listGzdj().then(res => {
      this.yjc112Arr = res.data
    })
  }
}
</script>

<style scoped lang="less">
  @import '../../css/public';
  .editorXinTwo {
    margin-bottom: 6px;
    label{
      display: inline-block;
      width: 103px;
      text-align: right;
    }
    .el-input, .el-select{
      width: 70%;
    }
  }
  .search-select {
    float: left;
    margin: 0 8px;
    label {
      font-size: 14px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 143px;
    }
  }
  .search-selectOnce{
    margin:1px 6px;
    height: 35px;
    border:1px solid #DEDEDE;
  }

  .mangeShowLook{
    margin-bottom: 10px;
    li{
      float: left;
      width: 268px;
      .el-input, .el-select{
        width: 62%;
      }
      label{
        display: inline-block;
        width: 96px;
        text-align: right;
      }
      /deep/.el-input.is-disabled .el-input__inner{
        background-color: #fff!important;
        color: #606266!important;
      }
    }
  }
  .searchBtn{
    float: left;
    line-height: 47px;
    font-size: 13px;
    cursor: pointer;
    margin: 0 8px;
    img{
      vertical-align: middle;
      margin-right: 4px;
    }
  }
  .search-selectOnce{
    margin: 5px 6px;
    height: 35px;
    border:1px solid #DEDEDE;
    cursor: auto;
  }
  .showClearLook{
    height: 600px;
    overflow: auto;
  }
  .mangeShow{
    margin-bottom: 10px;
    li{
      float: left;
      width: 350px;
      .el-input, .el-select{
        width: 62%;
      }
      label{
        display: inline-block;
        width: 96px;
        text-align: right;
      }
      /deep/.el-input.is-disabled .el-input__inner{
        background-color: #fff!important;
        color: #606266!important;
      }
    }
  }
  .maxHeight{
    max-height: 300px;
    overflow: auto;
  }
  .mangeShowList{
    margin-bottom: 10px;
    >p{
      width: 99px;
      text-align: right;
    }
    >label{
      display: inline-block;
      width: 99px;
      text-align: right;
      vertical-align: top;
    }
    .heTong {
      display: inline-block;
      width: 86%;
      color: red;
    }
    .el-textarea{
      width: 86%;
    }
  }
  .showReadOnlyContent {
    width: 82%;
    margin: 0 auto;
    border: 1px solid #E4E7ED;
    min-height: 200px;
    padding: 6px;
    max-height: 200px;
    overflow: auto;
  }

  .anomalyError{
    width: 993px;
    border: 1px solid;
    >div{
      float:left;
      border:1px solid;
      height: 40px;
      line-height: 40px;
    }
    .anomalyErrorOne{
      width: 182px;
      text-align: right;
    }
    .anomalyErrorTwo{
      text-indent: 2px;
      width: 333px;
      /deep/.el-checkbox__label{
        padding-top: 2px;
        font-size: 16px;
      }
    }
    .anomalyErrorThree{
      width: 235px;
      text-indent: 2px;
      /deep/.el-checkbox__label{
        padding-top: 2px;
        font-size: 16px;
      }
    }
  }
  .ErrorCenter{
    text-align: center;
  }
  .anomalyErrorOnceTwo{
    width: 993px;
    font-size: 20px;
    border: 1px solid;
    >div{
      float:left;
      border:1px solid;
      height: 40px;
    }
    .anomalyErrorOne{
      width: 182px;
      height: 205px;
      line-height: 205px;
      text-align: right;
    }
    .anomalyErrorTwo{
      float: left;
      width: 333px;
      height: 100%;
      text-indent: 2px;
      line-height: 40px;
      border: 1px solid;
      /deep/.el-checkbox__label{
        padding-top: 2px;
        font-size: 16px;
      }
    }
    .anomalyErrorThree{
      float: left;
      width: 234px;
      height: 100%;
      text-indent: 2px;
      line-height: 40px;
      border: 1px solid;
      /deep/.el-checkbox__label{
        padding-top: 2px;
        font-size: 16px;
      }
    }
    .anomalyErrorOnceThree{
      width: 333px;
      height: 39px;
      text-indent: 2px;
      line-height: 40px;
      border: 1px solid;
      /deep/.el-checkbox__label{
        padding-top: 2px;
        font-size: 16px;
      }
    }
    .anomalyErrorOnceFour{
      width: 182px;
      height: 204px;
      line-height: 204px;
      text-align: right;
    }
    .pickerSelect{
      width: 190px;
      /deep/.el-input__inner{
        height: 28px;
      }
    }
  }
  .showContentDownload{
    width: 993px;
    margin-top: 10px;
    font-size: 16px;
    span{
      color: #01ABE7;
      cursor: pointer;
    }
  }
  .clientAdd{
    /deep/.el-input__inner{
      height: 30px;
      width: 88%;
    }
  }
</style>

<style lang="less">
  .elTabsCssMange{
    >.el-tabs__header{
      .el-tabs__item{
        width: 129px;
        margin: 0;
        border-radius: 10px 10px 0 0;
        background-color: #EEF2F7;
        border: 1px solid #EEF2F7;
        text-align: center;
        padding: 0;
      }
      .el-tabs__item.is-active{
        color: #454545;
        background-color: #fff;
      }
    }
    .el-tabs__header .el-tabs__item.is-active{
      color: #409EFF;
    }
  }
</style>
