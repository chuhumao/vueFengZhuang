<!-- 声像 -->
<template>
  <div>
    <!-- 上操作 -->
    <div style="background-color: #F4F4F4;">
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="sxLuRuAdd">
        <img src="../../assets/turnOver/lr.png" alt="">
        <span>录入</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="sxLuRuEdit">
        <img src="../../assets/turnOver/bj.png" alt="">
        <span>编辑</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="sxDelete3">
        <img src="../../assets/turnOver/delete.png" alt="">
        <span>删除</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="sxDownload4">
        <img src="../../assets/turnOver/xz.png" alt="">
        <span>下载Excel模板</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="sxDownloadFile5">
        <img src="../../assets/turnOver/dr.png" alt="">
        <span>导入Excel目录</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="resetSearch6">
        <img src="../../assets/turnOver/js.png" alt="">
        <span>检索</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="sxSave7">
        <img src="../../assets/turnOver/bc.png" alt="">
        <span>保存</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="sxDownload8">
        <img src="../../assets/turnOver/dy.png" alt="">
        <span>打印目录</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="sxDownload9">
        <img src="../../assets/turnOver/dy.png" alt="">
        <span>打印脊背</span>
      </div>
      <div class="clear"></div>
    </div>
    <!-- 上表格 -->
    <div class="all-Table">
      <el-table
        ref="multipleTable"
        :data="tableData"
        stripe
        border
        @select="handleSelectionChange"
        @select-all="handleSelectionChangeAll"
        @cell-click="handleSelectionClick">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="seriesCode"
          label="分类号"
          width="220">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="folderNo"
          label="案卷号">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="titleProper"
          label="案卷题名">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="descriptor"
          label="内容主题">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="descriptor"
          label="张数">
        </el-table-column>
        <el-table-column
          sortable
          show-overflow-tooltip
          prop="retentionPeriod"
          label="保管期限"
          width='160'>
          <template slot-scope="scope">
            <span v-if="scope.row.retentionPeriod == 1">短期</span>
            <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
            <span v-else-if="scope.row.retentionPeriod == 3">永久</span>
            <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
            <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
            <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <div class="pageLayout">
      <el-pagination
        @current-change="handleCurrentChange"
        :current-page="params.page"
        :page-size="params.rows"
        layout="prev, pager, next, jumper"
        :total="params.total">
      </el-pagination>
    </div>
    <!-- 下操作 -->
    <div style="background-color: #F4F4F4;">
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="dateShowLookLook">
        <img src="../../assets/turnOver/ck.png" alt="">
        <span>查看</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="sxLuRuAdd11">
        <img src="../../assets/turnOver/lr.png" alt="">
        <span>录入</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="sxLuRuEdit12">
        <img src="../../assets/turnOver/bj.png" alt="">
        <span>编辑</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="sxDelete13">
        <img src="../../assets/turnOver/delete.png" alt="">
        <span>删除</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="sxDownload14">
        <img src="../../assets/turnOver/sc.png" alt="">
        <span>上传</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="fileDelete15">
        <img src="../../assets/turnOver/delete.png" alt="">
        <span>删除材料</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="sxDownload16">
        <img src="../../assets/turnOver/xz.png" alt="">
        <span>下载Excel模板</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="sxDownload17">
        <img src="../../assets/turnOver/dr.png" alt="">
        <span>导入Excel目录</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="sxSearch18">
        <img src="../../assets/turnOver/js.png" alt="">
        <span>检索</span>
      </div>
      <div class="clear"></div>
    </div>
    <!--下表格 -->
    <div class="all-Table">
      <el-table
        ref="multipleTableBottom"
        :data="tableDataBottom"
        stripe
        border
        @select="handleSelectionChangeBottom"
        @select-all="handleSelectionChangeBottomAll"
        @cell-click="handleSelectionClickBottom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="officeArchivalCode"
          label="档号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="seriesCode"
          label="分类号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="itemNo"
          label="件号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="yearCode"
          label="年度"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="titleProper"
          label="文件标题"
          width="300">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="contentDescription"
          label="内容说明"
          width="200">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="openingType"
          label="公开属性"
          width="160">
          <template slot-scope="scope">
            <span v-if="scope.row.openingType == 1">公开</span>
            <span v-else-if="scope.row.openingType == 2">内部</span>
            <span v-else-if="scope.row.openingType == 3">受控</span>
            <span v-else-if="scope.row.openingType == 4">广发商密三级</span>
            <span v-else-if="scope.row.openingType == 5">广发商密二级</span>
            <span v-else-if="scope.row.openingType == 6">广发商密一级</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="takePhotoDate"
          label="摄制时间"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="takePhotoPlace"
          label="摄制地点"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="takePhotoPerson"
          label="摄制者"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c68"
          label="摄制部门"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c211"
          label="底片号"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c8"
          label="日期备注"
          width="200">
        </el-table-column>
      </el-table>
    </div>
    <!-- 下分页 -->
    <div class="pageLayout">
      <el-pagination
        @current-change="handleCurrentChangeBottom"
        :current-page="paramsBottom.page"
        :page-size="paramsBottom.rows"
        layout="prev, pager, next, jumper"
        :total="paramsBottom.total">
      </el-pagination>
    </div>


    <!-- 录入--添加 -->
    <el-dialog :visible.sync="dialogSx1" width="1111px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        录入案卷信息
      </div>
      <el-form :model="paramsSx" :rules="rulesSx" ref="ruleFormAddSx" label-width="116px" class="demo-ruleForm">
        <el-form-item label="案卷号" prop="folderNo" class="mangeShowLook">
          <el-input v-model="paramsSx.folderNo"></el-input>
        </el-form-item>
        <el-form-item label="年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsSx.yearCode"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <el-form-item label="题名" prop="titleProper" class="" style="width: 99%">
          <el-input v-model="paramsSx.titleProper"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <el-form-item label="保管期限" prop="retentionPeriod" class="mangeShowLook">
          <el-select v-model="paramsSx.retentionPeriod" filterable placeholder="请选择" style="width: 100%;">
            <el-option v-for="item in retentionPeriod" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="公开属性" prop="openingType" class="mangeShowLook">
          <el-select v-model="paramsSx.openingType" filterable placeholder="请选择" style="width: 100%;">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="分类号" prop="seriesCode" class="mangeShowLook">
          <el-input v-model="paramsSx.seriesCode" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsSx.filingDeptName" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档人" class="mangeShowLook">
          <el-input v-model="paramsSx.filingUserName" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsSx.filingDate" readonly></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="sxLuRuAdd1Btn">保存</el-button>
        <el-button @click="sxLuRuAdd">重置</el-button>
        <el-button @click="dialogSx1 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 录入--添加确定 -->
    <el-dialog :visible.sync="dialogSx1Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        录入确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxLuRuAdd1BtnTwo">确定</el-button>
        <el-button @click="dialogSx1Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 录入--编辑 -->
    <el-dialog :visible.sync="dialogSx2" width="1111px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        修改案卷信息
      </div>
      <el-form :model="paramsSx" :rules="rulesSx" ref="ruleFormEditSx" label-width="116px" class="demo-ruleForm">
        <el-form-item label="案卷号" prop="folderNo" class="mangeShowLook">
          <el-input v-model="paramsSx.folderNo"></el-input>
        </el-form-item>
        <el-form-item label="年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsSx.yearCode"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <el-form-item label="题名" prop="titleProper" class="" style="width: 99%">
          <el-input v-model="paramsSx.titleProper"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <el-form-item label="保管期限" prop="retentionPeriod" class="mangeShowLook">
          <el-select v-model="paramsSx.retentionPeriod" filterable placeholder="请选择" style="width: 100%;">
            <el-option v-for="item in retentionPeriod" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="公开属性" prop="openingType" class="mangeShowLook">
          <el-select v-model="paramsSx.openingType" filterable placeholder="请选择" style="width: 100%;">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="分类号" prop="seriesCode" class="mangeShowLook">
          <el-input v-model="paramsSx.seriesCode" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsSx.filingDeptName" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档人" class="mangeShowLook">
          <el-input v-model="paramsSx.filingUserName" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsSx.filingDate" readonly></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="sxLuRuEdit2Btn">保存</el-button>
        <el-button @click="sxLuRuEdit">重置</el-button>
        <el-button @click="dialogSx2 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 录入--编辑确定 -->
    <el-dialog :visible.sync="dialogSx2Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        更新确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxLuRuEdit2BtnTwo">确定</el-button>
        <el-button @click="dialogSx2Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 录入--删除 -->
    <el-dialog :visible.sync="dialogSx3" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除案卷确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>删除案卷会将其下的案件一并删除，确定吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxDelete3Btn">确定</el-button>
        <el-button @click="dialogSx3 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 录入--下载Excel -->
    <el-dialog :visible.sync="dialogSx4" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要下载该模板吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxDownload4Btn">确定</el-button>
        <el-button @click="dialogSx4 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- Excel文件导入（录入） -->
    <el-dialog :visible.sync="dialogSx5" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/dr.png" alt="">
        Excel文件导入
      </div>
      <div class="dia-deleteTwo">
        <label>文件上传：</label>
        <el-upload
          ref="sxFileAddOne"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="handleChange"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <div style="text-align: center;margin:10px 0;">
          <span v-for="(item, index) in imgVal" :key="index">
            {{ item }}
            <img @click="handleRemove" style="margin: 0 0 0 10px; vertical-align:middle;cursor: pointer;" src="../../assets/hurdle/hurdleDelete.png" alt="">
          </span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxDownloadFile5Btn">确定</el-button>
        <el-button @click="dialogSx5 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 导出错误信息 -->
    <el-dialog :visible.sync="dialogSx5Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>是否要导出错误信息？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxDownloadFile5BtnTwo">确定</el-button>
        <el-button @click="dialogSx5Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 检索 -->
    <el-dialog :visible.sync="dialogSx6" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/js.png" alt="">
        检索
      </div>
      <el-form :model="params" ref="ruleFormAjSearch" label-width="100px" class="demo-ruleForm searchForm">
        <el-form-item label="档号">
          <el-input v-model="params.officeArchivalCode" ></el-input>
        </el-form-item>
        <el-form-item label="题名" prop="">
          <el-input v-model="params.titleProper" ></el-input>
        </el-form-item>
        <el-form-item label="年度" prop="">
          <el-input v-model="params.yearCode" ></el-input>
        </el-form-item>
        <el-form-item label="保管期限">
          <el-select v-model="params.retentionPeriod" filterable placeholder="请选择" style="width: 100%;">
            <el-option v-for="item in retentionPeriod" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="showList(params)">确定</el-button>
        <el-button @click="resetSearch6">重置</el-button>
        <el-button @click="dialogSx6 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 保存 -->
    <el-dialog :visible.sync="dialogSx7" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定保存该案件吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxSave7Btn">确定</el-button>
        <el-button @click="dialogSx7 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 打印目录 -->
    <el-dialog :visible.sync="dialogSx8" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>您没有选择要打印的归档文件，是否要打印全部？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxDownload8Btn">确定</el-button>
        <el-button @click="dialogSx8 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 打印脊背（上表格） -->
    <el-dialog :visible.sync="dialogSx9" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        打印
      </div>
      <div class="editorXin">
        <label>选择尺寸：</label>
        <el-select v-model="paramsSx.scope" filterable placeholder="请选择" style="width: 76%;">
          <el-option v-for="item in scopeArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxDownload9Btn">确定</el-button>
        <el-button @click="dialogSx9 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 查看（下表格） -->
    <el-dialog :visible.sync="dialogSx10" width="1111px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/ck.png" alt="">
        查看材料
      </div>
      <div class="showClearLook">
        <div class="bigDog menuShrink black-tree" style="float: left;height: 100%;min-height: unset;max-height: unset;">
          <el-tree
            :data="treTable"
            :props="defaultProps"
            :check-strictly="true"
            :default-expand-all="true"
            :expand-on-click-node="false"
            :highlight-current="true"
            accordion
            @node-click="handleNodeClick">
          </el-tree>
        </div>
        <el-form v-if="showLookDownload" :model="paramsSx" :rules="rulesSx" ref="ruleFormEditSx" label-width="116px" class="demo-ruleForm">
          <el-form-item label="序号" prop="" class="mangeShowLook" style="width: 25%">
            <el-input v-model="paramsSx.itemNo" readonly></el-input>
          </el-form-item>
          <el-form-item label="年度" prop="" class="mangeShowLook" style="width: 25%">
            <el-input v-model="paramsSx.yearCode" readonly></el-input>
          </el-form-item>
          <el-form-item label="片长" prop="" class="mangeShowLook" style="width: 25%">
            <el-input v-model="paramsSx.c11" readonly></el-input>
          </el-form-item>
          <!--<div class="clear"></div>-->
          <el-form-item label="题名" prop="titleProper" class="mangeShowLook" style="width: 75%">
            <el-input v-model="paramsSx.titleProper" readonly></el-input>
          </el-form-item>
          <!--<div class="clear"></div>-->
          <el-form-item label="保管期限" prop="" class="mangeShowLook" style="width: 25%">
            <el-input v-model="paramsSx.retentionPeriod" readonly></el-input>
            <!--<el-select v-model="paramsSx.retentionPeriod" filterable placeholder="请选择" style="width: 100%;">-->
              <!--<el-option v-for="item in retentionPeriod" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>-->
            <!--</el-select>-->
          </el-form-item>
          <el-form-item label="公开属性" prop="" class="mangeShowLook" style="width: 25%">
            <el-input v-model="paramsSx.openingType" readonly></el-input>
            <!--<el-select v-model="paramsSx.openingType" filterable placeholder="请选择" style="width: 100%;">-->
              <!--<el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>-->
            <!--</el-select>-->
          </el-form-item>
          <el-form-item label="分类号" prop="" class="mangeShowLook" style="width: 25%">
            <el-input v-model="paramsSx.seriesCode" readonly></el-input>
          </el-form-item>
          <el-form-item label="归档部门" class="mangeShowLook" style="width: 25%">
            <el-input v-model="paramsSx.filingDept" readonly></el-input>
          </el-form-item>
          <el-form-item label="归档人" class="mangeShowLook" style="width: 25%">
            <el-input v-model="paramsSx.filingUser" readonly></el-input>
          </el-form-item>
          <el-form-item label="归档日期" class="mangeShowLook" style="width: 25%">
            <el-input v-model="paramsSx.filingDate" readonly></el-input>
          </el-form-item>
        </el-form>
        <div v-else style="float: left;margin-left: 10px;width: 78%; max-height: 600px; overflow: auto;">
          <embed :src="embedOnce" type="application/pdf" width="100%" height="600px"/>
          <!--<iframe :src="embedOnce" width="100%" height="600px"></iframe>-->
        </div>
        <div class="clear"></div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <!--<el-button @click="pdfDownload" :disabled="showLookDownload">下载</el-button>-->
        <el-button @click="dialogSx10 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 查看--非PDF下载 -->
    <el-dialog :visible.sync="dialogSx10Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        下载确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/xz.png" alt="">
        <br>
        <div>该文件非PDF文件，是否要进行下载？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="dateShowLookDownload">确定</el-button>
        <el-button @click="dialogSx10Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 录入（下表格） -->
    <el-dialog :visible.sync="dialogSx11" width="1111px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        录入案卷信息
      </div>
      <el-form :model="paramsSx" :rules="rulesSxBottom" ref="ruleFormAddSxTwo" label-width="116px" class="demo-ruleForm">
        <el-form-item label="序号" class="mangeShowLook">
          <el-input v-model="paramsSx.folderNo" readonly></el-input>
        </el-form-item>
        <el-form-item label="年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsSx.yearCode"></el-input>
        </el-form-item>
        <el-form-item label="片长" prop="c11" class="mangeShowLook">
          <el-input v-model="paramsSx.c11"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <el-form-item label="题名" prop="titleProper" class="" style="width: 99%">
          <el-input v-model="paramsSx.titleProper"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <el-form-item label="保管期限" class="mangeShowLook">
          <el-select v-model="paramsSx.retentionPeriod" filterable placeholder="请选择" style="width: 100%;" disabled>
            <el-option v-for="item in retentionPeriod" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="公开属性" class="mangeShowLook">
          <el-select v-model="paramsSx.openingType" filterable placeholder="请选择" style="width: 100%;" disabled>
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="分类号" class="mangeShowLook">
          <el-input v-model="paramsSx.seriesCode" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsSx.filingDeptName" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档人" class="mangeShowLook">
          <el-input v-model="paramsSx.filingUserName" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsSx.filingDate" readonly></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="sxLuRuAdd11Btn">保存</el-button>
        <el-button @click="sxLuRuAdd11">重置</el-button>
        <el-button @click="dialogSx11 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 录入--添加确定（下表格） -->
    <el-dialog :visible.sync="dialogSx11Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        录入确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxLuRuAdd11BtnTwo">确定</el-button>
        <el-button @click="dialogSx11Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 编辑（下表格） -->
    <el-dialog :visible.sync="dialogSx12" width="1111px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        修改案件信息
      </div>
      <el-form :model="paramsSx" :rules="rulesSxBottom" ref="ruleFormEditSxTwo" label-width="116px" class="demo-ruleForm">
        <el-form-item label="序号" class="mangeShowLook">
          <el-input v-model="paramsSx.folderNo" readonly></el-input>
        </el-form-item>
        <el-form-item label="年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsSx.yearCode"></el-input>
        </el-form-item>
        <el-form-item label="片长" prop="c11" class="mangeShowLook">
          <el-input v-model="paramsSx.c11"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <el-form-item label="题名" prop="titleProper" class="" style="width: 99%">
          <el-input v-model="paramsSx.titleProper"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <el-form-item label="保管期限" class="mangeShowLook">
          <el-select v-model="paramsSx.retentionPeriod" filterable placeholder="请选择" style="width: 100%;" disabled>
            <el-option v-for="item in retentionPeriod" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="公开属性" class="mangeShowLook">
          <el-select v-model="paramsSx.openingType" filterable placeholder="请选择" style="width: 100%;" disabled>
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="分类号" class="mangeShowLook">
          <el-input v-model="paramsSx.seriesCode" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsSx.filingDeptName" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档人" class="mangeShowLook">
          <el-input v-model="paramsSx.filingUserName" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsSx.filingDate" readonly></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="sxLuRuEdit12Btn">保存</el-button>
        <el-button @click="sxLuRuEdit12">重置</el-button>
        <el-button @click="dialogSx12 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 编辑--编辑确定（下表格） -->
    <el-dialog :visible.sync="dialogSx12Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        更新确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxLuRuEdit12BtnTwo">确定</el-button>
        <el-button @click="dialogSx12Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 删除（下表格） -->
    <el-dialog :visible.sync="dialogSx13" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除案件确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要删除该案件吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxDelete13Btn">确定</el-button>
        <el-button @click="dialogSx13 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 上传（下表格） -->
    <el-dialog :visible.sync="dialogSx14" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sc.png" alt="">
        文件上传
      </div>
      <div class="dia-deleteTwo">
        <label>文件上传：</label>
        <el-upload
          ref="sxFileAddTwo"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="handleChangeTwo"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <div style="text-align: center;margin:10px 0;">
          <span v-for="(item, index) in imgVal" :key="index">
            {{ item.path }}
            <img @click="handleRemove" style="margin: 0 0 0 10px; vertical-align:middle;cursor: pointer;" src="../../assets/hurdle/hurdleDelete.png" alt="">
          </span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxDownload14Btn">确定</el-button>
        <el-button @click="dialogSx14 = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 删除材料 -->
    <el-dialog :visible.sync="dialogSx15" width="1111px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sccl.png" alt="">
        附件
      </div>
      <div>
        <div style="background-color: #F4F4F4;">
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="fileDelete15Btn">
            <img src="../../assets/turnOver/delete.png" alt="">
            <span>删除</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 上表格 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableDeleteFile"
            :data="tableDataDeleteFile"
            stripe
            border
            @select="handleSelectionChangeDeleteFile"
            @select-all="handleSelectionChangeAllDeleteFile"
            @cell-click="handleSelectionClickDeleteFile">
            <el-table-column
              type="index"
              align="center"
              width="60">
            </el-table-column>
            <el-table-column
              type="selection"
              align="center"
              width="60">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="titleProper"
              label="文件标题">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileSize"
              label="文件大小">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileFormat"
              label="文件格式">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeDeleteFile"
            :current-page="paramsDeleteFile.page"
            :page-size="paramsDeleteFile.rows"
            layout="prev, pager, next, jumper"
            :total="paramsDeleteFile.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;text-align: right">
        <!--<el-button type="primary" @click="fileDownload18Two">确定</el-button>-->
        <el-button @click="dialogSx15 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 删除材料确定 -->
    <el-dialog :visible.sync="dialogSx15Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除附件确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要删除此附件吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="fileDelete15BtnTwo">确定</el-button>
        <el-button @click="dialogSx15Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 删除材料确定 -->
    <el-dialog :visible.sync="dialogSx16" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/xz.png" alt="">
        <br>
        <div>确定要下载该模板吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxDownload16Btn">确定</el-button>
        <el-button @click="dialogSx16 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 上传（下表格） -->
    <el-dialog :visible.sync="dialogSx17" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/dr.png" alt="">
        Excel文件导入
      </div>
      <div class="dia-deleteTwo">
        <label>文件上传：</label>
        <el-upload
          ref="sxFileAddThree"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="handleChangeThree"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <div style="text-align: center;margin:10px 0;">
          <span v-for="(item, index) in imgVal" :key="index">
            {{ item }}
            <img @click="handleRemove" style="margin: 0 0 0 10px; vertical-align:middle;cursor: pointer;" src="../../assets/hurdle/hurdleDelete.png" alt="">
          </span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxDownload17Btn">确定</el-button>
        <el-button @click="dialogSx17 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 导出错误信息 -->
    <el-dialog :visible.sync="dialogSx17Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/xz.png" alt="">
        <br>
        <div>是否要导出错误信息？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="sxDownload17BtnTwo">确定</el-button>
        <el-button @click="dialogSx17Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 检索 -->
    <el-dialog :visible.sync="dialogSx18" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/js.png" alt="">
        检索
      </div>
      <el-form :model="paramsBottom" ref="ruleFormAjSearch" label-width="100px" class="demo-ruleForm searchForm">
        <el-form-item label="序号">
          <el-input v-model="paramsBottom.officeArchivalCode" ></el-input>
        </el-form-item>
        <el-form-item label="题名" prop="">
          <el-input v-model="paramsBottom.titleProper" ></el-input>
        </el-form-item>
        <el-form-item label="年度" prop="">
          <el-input v-model="paramsBottom.yearCode" ></el-input>
        </el-form-item>
        <el-form-item label="公开属性">
          <el-select v-model="paramsBottom.openingType" filterable placeholder="请选择" style="width: 100%;">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="归档部门">
          <el-select v-model="paramsBottom.thfilingDept" filterable placeholder="请选择">
            <el-option v-for="item in filingDept" :key="item.id" :label="item.text" :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="showListBottom(paramsBottom)">检索</el-button>
        <el-button @click="sxSearch18">重置</el-button>
        <el-button @click="dialogSx18 = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {getFonds, listSeriesByFondsAndRole, listSeriesByFonds, BASICURL, } from '@/js/turnOverData'
import { valueIndex } from '@/js/transitionText'
import {listArchiveZL, listDoc, listUserByDeptId, listDept, addArchiveZL, findSeriesCode, editFileAnJian, updateFileAnJian,
  updateSpecialFileAnJia, deleteArchiveZL, listAllDept, findArchiveZL, saveCaseNoByBatch, uploadExcelH5, uploadExcel,
  uploadExcelZl, listFileType, listGzdj, listLwxt, coverElectronicSeal, removeElectronicSeal, saveFileWrk, listAnJianTree,
  powerDocView, uploadPicture, saveZlUploadDoc, editDocAnJian, updateDoc, deleteDoc, listShengxArchiveZL, getInitStaffFolder,
  saveShengxFolder, getShengxFolder, updateShengxFolder, deleteStaffFolder, uploadShengxExcel, saveWrkFolder, listShengxFilePage,
  powerDocViewLeft, listFileTree, getInitShengxFile, saveShengxFile, getShengxFile, updateShengxFile, deleteStaffFile,saveStaffZlUploadDoc,
  listDocumentData, uploadShengxExcelFile, powerDocViewByShengx, getShengxFileByView} from '@/js/fileMangeOver'
export default {
  name: 'fileSx',
  props: {
    paramsC: Object,
    tableDataC: Array,
    tableDataBottomC: Array,
  },
  data () {
    const yearCodeAudit = (rules, item, callback) => {
      let reg = /^[0-9]*$/
      if (!reg.test(item)) {
        callback('请输入数字')
      } else if (item.length > 4 || item.length < 4) {
        callback('输入长度为4')
      } else {
        callback()
      }
    }
    return {
      /* 此处表格数据 */
      params: {
        c10: 1,
        page: 1,
        rows: 10,
        fonds: 1374133141812,
        series1: 1374133285828,
        officeArchivalCode: null,
        titleProper: null,
        yearCode: null,
        retentionPeriod: null
      }, // 对应 全宗、类型、上一级表格数据
      paramsBottom: {page: 1, rows: 5, total: 0}, // 对应 全宗、类型、上一级表格数据
      paramsSearch: {page: 1, rows: 10, total: 0}, // 按件--批量设置盒号（检索）
      paramsDeleteFile: {page: 1, rows: 5, total: 0}, // 删除材料
      paramsSx: {}, // 录入 or 编辑 or 特殊编辑 or 修改（下表格）
      paramsAjEdit: {}, // 编辑

      /* 此处select类型 */
      fullZong: [], // 全宗
      FondsAndRole: [], // 类型一级
      FondsAndRoleTwo: [], // 类型二级
      FondsAndRoleThree: [], // 类型三级

      /* 此处表格 */
      tableData: [], // 上表格第一级
      tableDataBottom: [], // 下表格第一级
      tableDataDialogAJ5: [], // 批量设置盒号
      tableDataDeleteFile: [], // 删除材料

      /* 此处表格多选选择数据 */
      tableDataTopOnce: [], // 上表格第一级
      tableDataTopOnceItem: {}, // 上表格第一级(单个数据）
      tableDataBottomOnce: [], // 下表格第一级
      tableDataDeleteFileOnce: [], // 下表格--删除材料

      /* form判断 */
      rulesSx: {
        folderNo: [{required: true, message: '请填写案卷号', trigger: 'blur'}],
        yearCode: [{required: true, message: '请填写年度', trigger: 'blur'}, {validator: yearCodeAudit}],
        titleProper: [{required: true, message: '请填写题名', trigger: 'blur'}],
        retentionPeriod: [{required: true, message: '请选择保管期限', trigger: 'change'}],
        openingType: [{required: true, message: '请选择公开属性', trigger: 'change'}],
      },
      rulesSxBottom: {
        yearCode: [{required: true, message: '请填写年度', trigger: 'blur'}, {validator: yearCodeAudit}],
        titleProper: [{required: true, message: '请填写题名', trigger: 'blur'}],
        c11: [{required: true, message: '请填写片长', trigger: 'blur'}],
      },

      /* select类型 */
      retentionPeriod: [
        {'name': '永久', 'itemValue': '3'},
        {'name': '长期', 'itemValue': '2'},
        {'name': '短期', 'itemValue': '1'},
        {'name': '10年', 'itemValue': '5'},
        {'name': '15年', 'itemValue': '6'},
        {'name': '30年', 'itemValue': '8'}
      ], // 保管期限
      c58: [{'name': '否', 'itemValue': '1'}, {'name': '是', 'itemValue': '0'}], // 是否为原件
      c59: [{'name': '否', 'itemValue': '1'}, {'name': '是', 'itemValue': '0'}], // 是否在库
      c89: [], // 拟稿人
      c90: [], // 拟稿部门
      c92: [], // 来文系统
      c100: [], // 文件类型
      c112: [], // 盖章类型
      openingType: [
        {'name': '内部', 'itemValue': '2'},
        {'name': '公开', 'itemValue': '1'},
        {'name': '受控', 'itemValue': '3'},
        {'name': '广发商密三级', 'itemValue': '4'},
        {'name': '广发商密二级', 'itemValue': '5'},
        {'name': '广发商密一级', 'itemValue': '6'}
      ], // 公开属性
      filingDept: [], // 归档部门
      yjc89Arr: [], // 拟稿人--检索
      scopeArr: [{id: 3, text: '3cm'}, {id: 5, text: '5cm'}], // 打印脊背--尺寸

      /* 单个数据 */
      addCaseNo: '',
      editCaseNo: '',
      imgVal: [],
      fileErrorMsg: '',
      scope: '',
      embedOnce: '',
      showLookDownload: false,
      showLookDownloadId: '',
      showLookDownloadIdTwo: '',
      // dateShowLook: 2,
      dateShowLook: 2,
      yeWuaActiveName: '案卷层',

      /* tree数据 */
      treTable: [],
      defaultProps: {children: 'children', label: 'text'},

      /* 弹框 */
      dialogSx1: false,
      dialogSx1Two: false,
      dialogSx2: false,
      dialogSx2Two: false,
      dialogSx3: false,
      dialogSx4: false,
      dialogSx5: false,
      dialogSx5Two: false,
      dialogSx6: false,
      dialogSx7: false,
      dialogSx8: false,
      dialogSx9: false,
      dialogSx10: false,
      dialogSx10Two: false,
      dialogSx11: false,
      dialogSx11Two: false,
      dialogSx12: false,
      dialogSx12Two: false,
      dialogSx13: false,
      dialogSx14: false,
      dialogSx15: false,
      dialogSx15Two: false,
      dialogSx16: false,
      dialogSx17: false,
      dialogSx17Two: false,
      dialogSx18: false,
    }
  },
  methods: {
    // 获取上表格第一级数据
    showList (val) {
      this.tableData = []
      // val.c5 = 2
      if (this.params.series2) {
        listShengxArchiveZL(val).then(res => {
          if (res.data.rows.length <= 0) {
            this.$message.error('该条件下查无数据！')
            this.tableData = []
            this.params.total = 0
          } else {
            this.tableData = res.data.rows
            this.params.total = res.data.total
            this.tableData.forEach(item => {
              item.checkOnce = false
            })
          }
          this.dialogSx6 = false
        })
      }
      // this.$forceUpdate()
    },
    // 上表格多选
    handleSelectionChange (val, item) {
      this.tableDataBottom = []
      item.checkOnce = !item.checkOnce
      this.tableDataTopOnce = val
      this.tableDataTopOnceItem = {}
      if (this.tableDataTopOnce.length < 0) {
        this.showListBottom(this.paramsBottom)
      }
      val.forEach(items => {
        if (items.checkOnce) {
          this.tableDataTopOnceItem = items
        }
      })
    },
    handleSelectionChangeAll (val) {
      if (val.length > 0) {
        for (let i of this.tableData) {
          // i.checkOnce = !i.checkOnce
          i.checkOnce = true
        }
      } else {
        for (let i of this.tableData) {
          // i.checkOnce = !i.checkOnce
          i.checkOnce = false
        }
      }
      this.tableDataTopOnce = val
      // for (let i in this.tableDataTopOnce) {
      //   if (!this.tableDataTopOnce[i].checkOnce) {
      //     this.tableDataTopOnce[i].checkOnce = true
      //   }
      // }
    },
    // 上表格行内点击
    handleSelectionClick (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTable.toggleRowSelection(item, true)
        item.checkOnce = true
        this.paramsBottom.page = 1
        this.paramsBottom.rows = 5
        this.paramsBottom.subId = item.id
        this.showListBottom(this.paramsBottom)
      } else {
        this.$refs.multipleTable.toggleRowSelection(item, false)
        item.checkOnce = false
        this.paramsBottom.total = 0
      }
    },
    // 上表格分页点击
    handleCurrentChange (val) {
      this.params.page = val
      this.showList(this.params)
    },
    // 下表格第一级数据
    showListBottom (val) {
      if (this.params.series2) {
        listShengxFilePage(val).then(res => {
          if (res.data.rows.length <= 0) {
            this.$message.error('该案件暂无材料')
            this.tableDataBottom = []
            this.paramsBottom.total = 0
          } else {
            this.tableDataBottom = res.data.rows
            this.paramsBottom.total = res.data.total
            this.tableDataBottomOnce = []
            this.tableDataBottom.forEach(item => {
              item.checkOnce = false
            })
          }
          this.dialogSx18 = false
        })
      }
    },
    // 下表格多选
    handleSelectionChangeBottom (val, item) {
      item.checkOnce = !item.checkOnce
      this.tableDataBottomOnce = val
      if (this.tableDataBottomOnce.length > 1) {
        this.$refs.multipleTableBottom.toggleRowSelection(this.tableDataBottomOnce[0])
      }
    },
    handleSelectionChangeBottomAll (val) {
      this.tableDataBottomOnce = val
      for (let i in this.tableDataBottomOnce) {
        if (!this.tableDataBottomOnce[i].checkOnce) {
          this.tableDataBottomOnce[i].checkOnce = true
        }
      }
    },
    handleSelectionClickBottom (item) {
      this.tableDataBottomOnce = []
      if (!item.checkOnce) {
        this.$refs.multipleTableBottom.toggleRowSelection(item)
        item.checkOnce = true
      } else {
        this.$refs.multipleTableBottom.clearSelection()
        item.checkOnce = false
      }
    },
    // 下表格分页点击
    handleCurrentChangeBottom (val) {
      this.paramsBottom.page = val
      this.showListBottom(this.paramsBottom)
    },

    handleCloseOne () {
      this.dialogSx1 = false
      this.dialogSx2 = false
      this.dialogSx3 = false
      this.dialogSx4 = false
      this.dialogSx5 = false
      this.dialogSx6 = false
      this.dialogSx7 = false
      this.dialogSx8 = false
      this.dialogSx9 = false
      this.dialogSx10 = false
      this.dialogSx11 = false
      this.dialogSx12 = false
      this.dialogSx13 = false
      this.dialogSx14 = false
      this.dialogSx15 = false
      this.dialogSx16 = false
      this.dialogSx17 = false
      this.dialogSx18 = false
    },
    handleCloseTwo () {
      this.dialogSx1Two = false
      this.dialogSx2Two = false
      this.dialogSx5Two = false
      this.dialogSx10Two = false
      this.dialogSx11Two = false
      this.dialogSx12Two = false
      this.dialogSx15Two = false
      this.dialogSx17Two = false
    },

    // 录入
    sxLuRuAdd () {
      // getInitStaffFolder
      getInitStaffFolder({archiveTreeNodeId: this.methodSeries()}).then(res => {
        this.dialogSx1 = true
        this.clearFiles('ruleFormAddSx')
        this.paramsSx = res.data
      })
    },
    sxLuRuAdd1Btn () {
      this.$refs.ruleFormAddSx.validate((valid) => {
        if (valid) {
          this.dialogSx1Two = true
        }
      })
    },
    sxLuRuAdd1BtnTwo () {
      this.paramsSx.fonds = this.params.fonds
      this.paramsSx.series2 = this.params.series2
      // this.paramsSx.bs = 'yz'
      saveShengxFolder(this.paramsSx).then(res => {
        if (res.code == 0) {
          this.$message.success('录入成功')
          this.dialogSx1 = false
          this.dialogSx1Two = false
          this.resetSearch()
          this.showList(this.params)
        } else {
          this.$message.error('录入失败')
          this.dialogSx1 = false
          this.dialogSx1Two = false
        }
      })
    },
    // 编辑
    sxLuRuEdit () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        getShengxFolder({id: this.tableDataTopOnceItem.id}).then(res => {
          this.dialogSx2 = true
          this.clearFiles('ruleFormEditSx')
          this.paramsSx = res.data
        })
      }
    },
    sxLuRuEdit2Btn () {
      this.$refs.ruleFormEditSx.validate((valid) => {
        if (valid) {
          this.dialogSx2Two = true
        }
      })
    },
    sxLuRuEdit2BtnTwo () {
      this.paramsSx.id = this.tableDataTopOnceItem.id
      updateShengxFolder(this.paramsSx).then(res => {
        if (res.code == 0) {
          this.$message.success('修改成功')
          this.dialogSx2 = false
          this.dialogSx2Two = false
          this.resetSearch()
          this.showList(this.params)
        } else {
          this.$message.error('修改失败')
          this.dialogSx2 = false
          this.dialogSx2Two = false
        }
      })
    },
    // 删除
    sxDelete3 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogSx3 = true
      }
    },
    sxDelete3Btn () {
      deleteStaffFolder({ids: this.tableDataTopOnceItem.id}).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogSx3 = false
          this.resetSearch()
          this.showList(this.params)
        } else {
          this.$message.error(res.message)
          this.dialogSx3 = false
        }
      })
    },
    // 下载Excel
    sxDownload4 () {
      this.dialogSx4 = true
    },
    sxDownload4Btn () {
      let params = {
        status: 'sx',
        series2: this.params.series2
      }
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/downloadExcel', params, '声像档案案卷模板.xls', 'get')
      this.dialogSx4 = false
    },
    // 导入目录
    sxDownloadFile5 () {
      this.dialogSx5 = true
      this.clearFilesTwo('sxFileAddOne')
      this.imgVal = []
    },
    sxDownloadFile5Btn () {
      if (this.imgVal.length < 1) {
        this.$message.error('请选择上传文件')
      } else {
        let params = {
          series2: this.params.series2,
          fonds: this.params.fonds,
          imgVal: this.imgVal[0]
        }
        uploadShengxExcel(params).then(res => {
          if (res.code == 0) {
            this.$message.success(res.data.msg)
            this.dialogSx5 = false
            this.resetSearch()
            this.showList(this.params)
          } else {
            this.dialogSx5Two = true
            this.fileErrorMsg = res.data.msg
          }
        })
      }
    },
    sxDownloadFile5BtnTwo () {
      let ids = {excelId: this.fileErrorMsg}
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/exportError', ids, '错误信息.xls', 'get')
      this.dialogSx5 = false
      this.dialogSx5Two = false
    },
    handleChange (file, fileList) {
      if (this.imgVal.length >= 1) {
        this.$message.error('只能上传一个文件')
      } else {
        let formData = new FormData()
        formData.append('picture', file.raw)
        formData.append('name', 'file')
        formData.append('type', 'shengxZl')
        uploadExcelH5(formData).then(res => {
          if (res.code == 0) {
            this.imgVal.push(res.data.msg)
          } else {
            this.$message.error(res.message)
          }
        })
      }
    },
    // 删除上传时的文件
    handleRemove (val, item) {
      this.imgVal.splice(val, 1)
    },
    // 检索
    resetSearch6 () {
      this.params = {
        c10: 1,
        searchType: 1,
        page: 1,
        rows: 10,
        fonds: this.params.fonds,
        series1: this.params.series1,
        series2: this.params.series2,
        series3: this.params.series3,
        officeArchivalCode: null,
        titleProper: null,
        yearCode: null,
        retentionPeriod: null
      }
      this.resetSearch()
      this.dialogSx6 = true
    },
    // 保存
    sxSave7 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogSx7 = true
      }
    },
    sxSave7Btn () {
      saveWrkFolder({id: this.tableDataTopOnceItem.id}).then(res => {
        if (res.code == 0) {
          this.$message.success('保存成功')
          this.dialogSx7 = false
          this.resetSearch()
          this.showList(this.params)
        } else {
          this.$message.error('保存失败')
          this.dialogSx7 = false
          this.resetSearch()
          this.showList(this.params)
        }
      })
    },
    // 打印目录
    sxDownload8 () {
      if (this.tableDataTopOnce.length < 1) {
        this.dialogSx8 = true
      } else {
        let arr = ''
        try {
          for (let i of this.tableDataTopOnce) {
            if (i.itemNo == '' || i.itemNo == null) {
              // throw `案卷号为：${i.folderNo}的数据没有件号，不可以打印脊背!`
              throw `系统提示：没有件号，不可以打印!`
            } else if (i.caseNo == '' || i.caseNo == null) {
              // throw `案卷号为：${i.folderNo}的数据没有盒号，不可以打印脊背!`
              throw `系统提示：没有盒号，不可以打印脊背!`
            } else if (i.retentionPeriod == '' || i.retentionPeriod == null) {
              // throw `案卷号为：${i.folderNo}的数据没有保管期限，不可以打印脊背!`
              throw `系统提示：没有保管期限，不可以打印脊背!`
            } else {
              arr += i.id + ','
              let params = {
                fileIds: arr,
                // fonds: this.params.fonds
              }
              valueIndex().exportFiles('/gdda-new/gdda/archiveZL/print', params, '声像脊背档案.xls', 'get')
            }
          }
        } catch (e) {
          this.$message.info(e)
        }
      }
    },
    sxDownload8Btn () {
      let params = {
        fileIds: 'all',
        fonds: this.params.fonds,
        series: this.methodSeries()
      }
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/print', params, '声像脊背档案.xls', 'get')
      this.dialogSx8 = false
    },
    // 打印脊背
    sxDownload9 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.paramsSx = {scope: ''}
        this.paramsSx.scope = 3
        this.dialogSx9 = true
      }
    },
    sxDownload9Btn () {
      if (this.paramsSx.scope == ''|| this.paramsSx.scope == null) {
        this.$message.error('请选择尺寸')
      } else {
        let arr = ''
        for (let i of this.tableDataTopOnce) {
          arr += i.id + ','
        }
        let params = {
          fileIds: arr,
          scope: this.paramsSx.scope
        }
        valueIndex().exportFiles('/gdda-new/gdda/archiveZL/printAnjianJibei', params, '文书档案脊背.doc', 'get')
        this.dialogSx9 = false
      }
    },

    // 查看（未完成）
    dateShowLookLook () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.dialogSx10 = true
        let params = {
          id: this.tableDataBottomOnce[0].id,
          logo: 'shengx'
        }
        listFileTree(params).then(res => {
          if (res.code == 0) {
            this.treTable = res.data
          }
        })
      }
    },
    handleNodeClick (val) {
      let valId = val.id.substr(0, 4)
      let valIdTwo = val.id.substr(5)
      if (valId == 'root') {
        this.showLookDownload = true
        this.paramsSx = {}
        getShengxFileByView({fileId: valIdTwo}).then(res => {
          this.paramsSx = res.data
        })
      } else {
        this.showLookDownload = false
        powerDocViewByShengx({id: val.id}).then(res => {
          // let ppd = res.data.fileBrowsePath.splice("\")
          if (res.code == 0) {
            if (res.data.data.fileFormat == 'pdf') {
              this.embedOnce = `${BASICURL}/gdda-new/gdda/util/viewPdf?docId=${val.id}`
              this.showLookDownloadId = val
              this.showLookDownloadIdTwo = res.data.data
              this.$forceUpdate()
            } else {
              this.dialogSx10Two = true
              this.showLookDownloadId = val
              this.showLookDownloadIdTwo = res.data.data
              this.$forceUpdate()
            }
          }
        })
      }
    },
    dateShowLookDownload () {
      let params = {
        // id: this.showLookDownloadId,
        id: this.showLookDownloadId.id,
      }
      valueIndex().exportFiles('/gdda-new/gdda/util/downLoadFile', params, `${this.showLookDownloadIdTwo.fileName}.${this.showLookDownloadIdTwo.fileFormat}`, 'get')
      this.dialogSx10Two = false
    },
    // 录入
    sxLuRuAdd11 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.paramsSx = {yearCode: '', c11: '', titleProper: ''}
        getInitShengxFile({subId: this.tableDataTopOnceItem.id}).then(res => {
          this.dialogSx11 = true
          this.clearFiles('ruleFormAddSxTwo')
          this.paramsSx = res.data
        })
      }

    },
    sxLuRuAdd11Btn () {
      this.$refs.ruleFormAddSxTwo.validate((valid) => {
        if (valid) {
          this.dialogSx11Two = true
        }
      })
    },
    sxLuRuAdd11BtnTwo () {
      this.paramsSx.fonds = this.params.fonds
      this.paramsSx.series2 = this.params.series2
      this.paramsSx.subId = this.tableDataTopOnceItem.id
      saveShengxFile(this.paramsSx).then(res => {
        if (res.code == 0) {
          this.$message.success('录入成功')
          this.dialogSx11 = false
          this.dialogSx11Two = false
          this.resetSearchBottom()
          this.showListBottom(this.paramsBottom)
        } else {
          this.$message.error('录入失败')
          this.dialogSx11 = false
          this.dialogSx11Two = false
        }
      })
    },
    // 编辑
    sxLuRuEdit12 () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        getShengxFile({id: this.tableDataBottomOnce[0].id}).then(res => {
          console.log(res);
          this.dialogSx12 = true
          this.clearFiles('ruleFormEditSxTwo')
          this.paramsSx = res.data
        })
      }
    },
    sxLuRuEdit12Btn () {
      this.$refs.ruleFormEditSxTwo.validate((valid) => {
        if (valid) {
          this.dialogSx12Two = true
        }
      })
    },
    sxLuRuEdit12BtnTwo () {
      this.paramsSx.id = this.tableDataBottomOnce[0].id
      updateShengxFile(this.paramsSx).then(res => {
        if (res.code == 0) {
          this.$message.success('修改成功')
          this.dialogSx12 = false
          this.dialogSx12Two = false
          this.resetSearchBottom()
          this.showListBottom(this.paramsBottom)
        } else {
          this.$message.error('修改失败')
          this.dialogSx12 = false
          this.dialogSx12Two = false
        }
      })
    },
    // 删除
    sxDelete13 () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.dialogSx13 = true
      }
    },
    sxDelete13Btn () {
      deleteStaffFile({id: this.tableDataBottomOnce[0].id}).then(res => {
        if (res.code == 0) {
          this.$message.success('删除成功')
          this.dialogSx13 = false
          this.resetSearchBottom()
          this.showListBottom(this.paramsBottom)
        } else {
          this.$message.error('删除失败')
          this.dialogSx13 = false
        }
      })
    },
    // 上传
    sxDownload14 () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.clearFilesTwo('sxFileAddTwo')
        this.imgVal = []
        this.dialogSx14 = true
      }
    },
    sxDownload14Btn () {
      if (this.imgVal.length < 1) {
        this.$message.error('请选择上传文件')
      } else {
        let params = {
          subId: this.tableDataBottomOnce[0].id,
          imgVal: JSON.stringify(this.imgVal)
        }
        saveStaffZlUploadDoc(params).then(res => {
          if (res.code == 500) {
            if (res.data.optFlag == -1) {
              this.$message.error(`上传失败，因为文件${res.data.msg}已上传过了，请重新选择上传文件`)
              this.dialogSx14 = false
              this.resetSearchBottom()
              this.showListBottom(this.paramsBottom)
            } else {
              this.$message.error(`上传失败`)
              this.dialogSx14 = false
              this.resetSearchBottom()
              this.showListBottom(this.paramsBottom)
            }
          } else {
            this.$message.success('上传成功')
            this.dialogSx14 = false
            this.resetSearchBottom()
            this.showListBottom(this.paramsBottom)
          }
        })
      }
    },
    handleChangeTwo (file, fileList) {
      // if (this.imgVal.length >= 1) {
      //   this.$message.error('只能上传一个文件')
      // } else {
      //   let formData = new FormData()
      //   formData.append('picture', file.raw)
      //   formData.append('name', 'file')
      //   formData.append('type', 'shengxZl')
      //   uploadPicture(formData).then(res => {
      //     if (res.code == 0) {
      //       this.imgVal.push(res.data.pathAndMD5)
      //     } else {
      //       this.$message.error(res.message)
      //     }
      //   })
      // }
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('name', 'file')
      formData.append('type', 'shengxZl')
      uploadPicture(formData).then(res => {
        if (res.code == 0) {
          this.imgVal.push(res.data.pathAndMD5)
        } else {
          this.$message.error(res.message)
        }
      })
    },
    // 删除材料
    handleSelectionChangeDeleteFile (val, item) {
      item.checkOnce = !item.checkOnce
      this.tableDataDeleteFileOnce = val
      if (this.tableDataDeleteFileOnce.length > 1 && this.tableDataDeleteFileOnce.length <= 2) {
        this.$refs.multipleTableDeleteFile.toggleRowSelection(this.tableDataDeleteFileOnce[0])
      }
    },
    handleSelectionChangeAllDeleteFile (val) {
      this.tableDataDeleteFileOnce = val
      for (let i in this.tableDataDeleteFileOnce) {
        if (!this.tableDataDeleteFileOnce[i].checkOnce) {
          this.tableDataDeleteFileOnce[i].checkOnce = true
        }
      }
      if (this.tableDataDeleteFileOnce.length > 1 && this.tableDataDeleteFileOnce.length <= 2) {
        this.$refs.multipleTableDeleteFile.toggleRowSelection(this.tableDataDeleteFileOnce[0])
      }
    },
    handleSelectionClickDeleteFile (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTableDeleteFile.toggleRowSelection(item)
        item.checkOnce = true
      } else {
        this.$refs.multipleTableDeleteFile.clearSelection()
        item.checkOnce = false
        this.tableDataDeleteFileOnce = []
      }
    },
    // 删除材料分页点击
    handleCurrentChangeDeleteFile (val) {
      this.paramsDeleteFile.page = val
      listDocumentData(this.paramsDeleteFile).then(res => {
        this.tableDataDeleteFile = res.data.rows
        this.paramsDeleteFile.total = res.data.total
        this.dialogSx15 = true
      })
    },
    fileDelete15 () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.paramsDeleteFile.page = 1
        this.paramsDeleteFile.subId = this.tableDataBottomOnce[0].id
        // let audit = this.paramsDeleteFile || val
        // audit.subId = this.tableDataBottomOnce[0].id
        listDocumentData(this.paramsDeleteFile).then(res => {
          this.tableDataDeleteFile = res.data.rows
          this.paramsDeleteFile.total = res.data.total
          this.dialogSx15 = true
        })
      }
    },
    fileDelete15Btn () {
      let item = this.$onceWay().onceTableList(this.tableDataDeleteFileOnce)
      if (item == 1) {
        this.dialogSx15Two = true
      }
    },
    fileDelete15BtnTwo () {
      deleteDoc({id: this.tableDataDeleteFileOnce[0].id}).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogSx15Two = false
          this.tableDataDeleteFileOnce = []
          this.paramsDeleteFile.page = 1
          listDocumentData(this.paramsDeleteFile).then(res => {
            this.tableDataDeleteFile = res.data.rows
            this.paramsDeleteFile.total = res.data.total
          })
        } else {
          this.$message.error(res.message)
          this.dialogSx15Two = false
        }
      })
    },
    // 下载Excel模板
    sxDownload16 () {
      this.dialogSx16 = true
    },
    sxDownload16Btn () {
      let params = {
        status: 'sxf',
        series2: this.methodSeries()
      }
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/downloadExcel', params, '声像档案卷内模板.xls', 'get')
      this.dialogSx16 = false
    },
    // 导入Excel目录
    sxDownload17 () {
      this.dialogSx17 = true
      this.clearFilesTwo('sxFileAddThree')
      this.imgVal = []
    },
    sxDownload17Btn () {
      if (this.imgVal.length < 1) {
        this.$message.error('请选择上传文件')
      } else {
        let params = {
          series2: this.params.series2,
          fonds: this.params.fonds,
          imgVal: this.imgVal
        }
        uploadShengxExcelFile(params).then(res => {
          if (res.code == 0) {
            this.$message.success(res.data.msg)
            this.dialogSx17 = false
            this.resetSearchBottom()
            this.showListBottom(this.paramsBottom)
          } else {
            this.dialogSx17Two = true
            this.fileErrorMsg = res.data.msg
          }
        })
      }
    },
    // 导出错误
    sxDownload17BtnTwo () {
      let ids = {excelId: this.fileErrorMsg}
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/exportError', ids, '错误信息.xls', 'get')
      this.dialogSx17 = false
      this.dialogSx17Two = false
    },
    handleChangeThree (file, fileList) {
      if (this.imgVal.length >= 1) {
        this.$message.error('只能上传一个文件')
      } else {
        let formData = new FormData()
        formData.append('picture', file.raw)
        formData.append('name', 'file')
        formData.append('type', 'shengxFileZl')
        uploadExcelH5(formData).then(res => {
          if (res.code == 0) {
            this.imgVal.push(res.data.msg)
          } else {
            this.$message.error(res.message)
          }
        })
      }
    },
    // 检索
    sxSearch18 () {
      this.paramsBottom = {
        page: 1,
        total: 0,
        rows: 5,
        subId: this.tableDataTopOnceItem.id,
        itemNo: '',
        titleProper: '',
        yearCode: '',
        searchType: 1,
        openingType: '',
        filingDept: ''
      }
      // this.showListBottom(this.paramsBottom)
      this.dialogSx18 = true
    },

    resetSearch () {
      this.params.page = 1
      this.params.total = 0
    },
    resetSearchBottom () {
      this.paramsBottom.page = 1
      this.paramsBottom.total = 0
      // this.paramsBottom.searchType = 1
    },
    methodSeries () {
      let item = this.params.series3 || this.params.series2 || this.params.series1
      return item
    },
    // 清除掉回调表单验证
    clearFiles (val) {
      if (this.$refs[val]) {
        this.$nextTick(() => {
          this.$refs[val].clearValidate()
        })
      }
    },
    clearFilesTwo (val) {
      if (this.$refs[val]) {
        this.$nextTick(() => {
          this.$refs[val].clearFiles()
        })
      }
    },
  },
  watch: {
    paramsC (val) {
      this.params = val
    },
    tableDataC (val) {
      this.tableData = val
      if (val.length < 1) {
        this.tableDataTopOnce = []
        this.tableDataTopOnceItem = {}
      }
    },
    tableDataBottomC (val) {
      this.tableDataBottom = val
      if (val.length < 1) {
        this.tableDataBottomOnce = []
      }
    }
  },
  created () {
    this.params = this.paramsC
    this.tableData = this.tableDataC
    this.tableDataBottom = this.tableDataBottomC
    listAllDept().then(res => {
      this.filingDept = res.data
    })
  }
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  .search-select {
    float: left;
    margin: 4px 0;
    vertical-align: middle;
    line-height: 40px;
    label {
      font-size: 14px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 143px;
    }
  }
  .search-selectOnce {
    margin: 5px 6px;
    height: 35px;
    border:1px solid #DEDEDE;
    cursor: auto;
  }
  .searchBtn {
    float: left;
    line-height: 47px;
    font-size: 13px;
    cursor: pointer;
    img{
      vertical-align: middle;
      margin-right: 4px;
    }
  }
  .mangeShowLook {
    float: left;
    width: 33%;
    margin-bottom: 20px;
    /deep/.el-input.is-disabled .el-input__inner{
      background-color: #fff!important;
      color: #606266!important;
    }
  }
  .hurdleAllHeHao {
    /deep/.el-dialog__body {
      padding: 0;
    }
  }
  .searchForm {
    /deep/.el-form-item {
      margin-bottom: 10px;
    }
    .el-select {
      width: 100%;
    }
  }

  .showClearLook{
    height: 600px;
    overflow: auto;
  }
</style>
