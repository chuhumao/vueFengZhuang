<!-- 实物 -->
<template>
  <div>
    <!-- 上操作--业务 -->
    <div style="background-color: #F4F4F4;">
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="swLuRuAdd">
        <img src="../../assets/turnOver/lr.png" alt="">
        <span>录入</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="swLuRuEdit">
        <img src="../../assets/turnOver/bj.png" alt="">
        <span>编辑</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="swDelete3">
        <img src="../../assets/turnOver/delete.png" alt="">
        <span>删除</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="swDownFile4">
        <img src="../../assets/turnOver/xz.png" alt="">
        <span>下载Excel模板</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="swDownFile5">
        <img src="../../assets/turnOver/dr.png" alt="">
        <span>导入Excel目录</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="resetSearch6">
        <img src="../../assets/turnOver/js.png" alt="">
        <span>检索</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="swDownFile7">
        <img src="../../assets/turnOver/bc.png" alt="">
        <span>保存</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="swDownFile8">
        <img src="../../assets/turnOver/dy.png" alt="">
        <span>打印目录</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="swDownload11">
        <img src="../../assets/turnOver/dy.png" alt="">
        <span>打印脊背</span>
      </div>
      <div class="clear"></div>
    </div>
    <!-- 上表格--业务 -->
    <div class="all-Table" v-if="this.params.series2 == 1374133285844">
      <el-table
        ref="multipleTable"
        :data="tableData"
        stripe
        border
        @select="handleSelectionChange"
        @select-all="handleSelectionChangeAll"
        @cell-click="handleSelectionClick">
        <el-table-column
          type="index"
          align="center"
          width="60">
        </el-table-column>
        <el-table-column
          type="selection"
          align="center"
          width="60">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="officeArchivalCode"
          label="档号"
          width="150">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="caseNo"
          label="盒号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="itemNo"
          label="件号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="titleProper"
          label="印章名称"
          width="400">
        </el-table-column>
        <el-table-column
          sortable
          show-overflow-tooltip
          prop="dateOfCreation"
          label="日期"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c164"
          label="印章种类"
          width="131">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c73"
          label="印章形状"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c66"
          label="印章状态"
          width='160'>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="seriesCode"
          label="分类号"
          width='160'>
        </el-table-column>
        <el-table-column
          sortable
          show-overflow-tooltip
          prop="retentionPeriod"
          label="保管期限"
          width='160'>
          <template slot-scope="scope">
            <span v-if="scope.row.retentionPeriod == 1">短期</span>
            <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
            <span v-else-if="scope.row.retentionPeriod == 3">永久</span>
            <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
            <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
            <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="all-Table" v-else>
      <el-table
        ref="multipleTable"
        :data="tableData"
        stripe
        border
        @select="handleSelectionChange"
        @select-all="handleSelectionChangeAll"
        @cell-click="handleSelectionClick">
        <el-table-column
          type="index"
          align="center"
          width="60">
        </el-table-column>
        <el-table-column
          type="selection"
          align="center"
          width="60">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="officeArchivalCode"
          label="档案号"
          width="150">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="itemNo"
          label="件号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="titleProper"
          label="名称"
          width="300">
        </el-table-column>
        <el-table-column
          sortable
          show-overflow-tooltip
          prop="dateOfCreation"
          label="日期"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c15"
          label="类别"
          width='141'>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c161"
          label="对方单位"
          width='140'>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c8"
          label="备注"
          width='230'>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="seriesCode"
          label="分类号"
          width='160'>
        </el-table-column>
        <el-table-column
          sortable
          show-overflow-tooltip
          prop="retentionPeriod"
          label="保管期限"
          width='160'>
          <template slot-scope="scope">
            <span v-if="scope.row.retentionPeriod == 1">短期</span>
            <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
            <span v-else-if="scope.row.retentionPeriod == 3">永久</span>
            <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
            <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
            <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <div class="pageLayout">
      <el-pagination
        @current-change="handleCurrentChange"
        :current-page="params.page"
        :page-size="params.rows"
        layout="prev, pager, next, jumper"
        :total="params.total">
      </el-pagination>
    </div>
    <!-- 下操作--业务 -->
    <div style="background-color: #F4F4F4;">
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="dateShowLookLook">
        <img src="../../assets/turnOver/ck.png" alt="">
        <span>查看</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="swFileAdd9">
        <img src="../../assets/turnOver/sc.png" alt="">
        <span>上传</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="swDelete10">
        <img src="../../assets/turnOver/delete.png" alt="">
        <span>删除</span>
      </div>
      <div class="clear"></div>
    </div>
    <!--下表格--业务 -->
    <div class="all-Table">
      <el-table
        ref="multipleTableBottom"
        :data="tableDataBottom"
        stripe
        border
        @select="handleSelectionChangeBottom"
        @select-all="handleSelectionChangeBottomAll"
        @cell-click="handleSelectionClickBottom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="titleProper"
          label="材料名称"
          width="220">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileSize"
          label="大小">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileFormat"
          label="格式">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="officeArchivalCode"
          label="室编档号"
          width="220">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="pageNo"
          label="页号">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="amountOfPages"
          label="页数">
        </el-table-column>
      </el-table>
    </div>
    <!-- 下分页 -->
    <div class="pageLayout">
      <el-pagination
        @current-change="handleCurrentChangeBottom"
        :current-page="paramsBottom.page"
        :page-size="paramsBottom.rows"
        layout="prev, pager, next, jumper"
        :total="paramsBottom.total">
      </el-pagination>
    </div>

    <!-- 录入--添加 -->
    <el-dialog :visible.sync="dialogSw1" width="1111px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        录入文件信息
      </div>
      <el-form :model="paramsSw" :rules="rulesSw" ref="ruleFormAddSw" label-width="116px" class="demo-ruleForm">
        <el-form-item v-if="params.series2 == 1374133285844" label="盒号" prop="caseNo" class="mangeShowLook">
          <el-input v-model="paramsSw.caseNo"></el-input>
        </el-form-item>
        <el-form-item label="件号" prop="itemNo" class="mangeShowLook">
          <el-input v-model="paramsSw.itemNo"></el-input>
        </el-form-item>
        <el-form-item label="年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsSw.yearCode"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <el-form-item label="题名" prop="titleProper" class="" style="width: 99%">
          <el-input v-model="paramsSw.titleProper"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <el-form-item label="责任者" prop="c113" class="mangeShowLook"  style="width: 49.5%">
          <el-input v-model="paramsSw.c113"></el-input>
        </el-form-item>
        <el-form-item label="日期" prop="dateOfCreation" class="mangeShowLook" style="width: 49.5%">
          <el-date-picker
            style="width: 100%;"
            v-model="paramsSw.dateOfCreation"
            type="date"
            format="yyyy-MM-dd"
            value-format="yyyy-MM-dd"
            placeholder="选择时间"
          >
          </el-date-picker>
        </el-form-item>
        <div class="clear"></div>
        <el-form-item label="印章种类" prop="c164" class="mangeShowLook">
          <el-input v-model="paramsSw.c164"></el-input>
        </el-form-item>
        <el-form-item label="印章形状" prop="c73" class="mangeShowLook">
          <el-input v-model="paramsSw.c73"></el-input>
        </el-form-item>
        <el-form-item label="印章状态" prop="c66" class="mangeShowLook">
          <el-input v-model="paramsSw.c66"></el-input>
        </el-form-item>
        <el-form-item label="保管期限" prop="retentionPeriod" class="mangeShowLook">
          <el-select v-model="paramsSw.retentionPeriod" filterable placeholder="请选择" style="width: 100%;">
            <el-option v-for="item in retentionPeriod" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="公开属性" prop="openingType" class="mangeShowLook">
          <el-select v-model="paramsSw.openingType" filterable placeholder="请选择" style="width: 100%;">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="分类号" prop="seriesCode" class="mangeShowLook">
          <el-input v-model="paramsSw.seriesCode" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsSw.filingDeptName" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档人" class="mangeShowLook">
          <el-input v-model="paramsSw.filingUserName" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsSw.filingDate" readonly></el-input>
        </el-form-item>
        <el-form-item label="备注" class="mangeShowLook" style="width: 99%;">
          <el-input type="textarea" v-model="paramsSw.c8"></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="swLuRuAdd1Btn">保存</el-button>
        <el-button @click="swLuRuAdd">重置</el-button>
        <el-button @click="dialogSw1 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 录入--添加确定 -->
    <el-dialog :visible.sync="dialogSw1Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        录入确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="swLuRuAdd1BtnTwo">确定</el-button>
        <el-button @click="dialogSw1Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 录入--编辑 -->
    <el-dialog :visible.sync="dialogSw2" width="1111px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        修改文件信息
      </div>
      <el-form :model="paramsSw" :rules="rulesSw" ref="ruleFormEditSw" label-width="116px" class="demo-ruleForm">
        <el-form-item v-if="params.series2 == 1374133285844" label="盒号" prop="caseNo" class="mangeShowLook">
          <el-input v-model="paramsSw.caseNo"></el-input>
        </el-form-item>
        <el-form-item label="件号" prop="itemNo" class="mangeShowLook">
          <el-input v-model="paramsSw.itemNo"></el-input>
        </el-form-item>
        <el-form-item label="年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsSw.yearCode"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <el-form-item label="题名" prop="titleProper" class="" style="width: 99%">
          <el-input v-model="paramsSw.titleProper"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <el-form-item label="责任者" prop="c113" class="mangeShowLook"  style="width: 49.5%">
          <el-input v-model="paramsSw.c113"></el-input>
        </el-form-item>
        <el-form-item label="日期" prop="dateOfCreation" class="mangeShowLook" style="width: 49.5%">
          <el-date-picker
            style="width: 100%;"
            v-model="paramsSw.dateOfCreation"
            type="date"
            format="yyyy-MM-dd"
            value-format="yyyy-MM-dd"
            placeholder="选择时间"
          >
          </el-date-picker>
        </el-form-item>
        <div class="clear"></div>
        <el-form-item label="印章种类" prop="c164" class="mangeShowLook">
          <el-input v-model="paramsSw.c164"></el-input>
        </el-form-item>
        <el-form-item label="印章形状" prop="c73" class="mangeShowLook">
          <el-input v-model="paramsSw.c73"></el-input>
        </el-form-item>
        <el-form-item label="印章状态" prop="c66" class="mangeShowLook">
          <el-input v-model="paramsSw.c66"></el-input>
        </el-form-item>
        <el-form-item label="保管期限" prop="retentionPeriod" class="mangeShowLook">
          <el-select v-model="paramsSw.retentionPeriod" filterable placeholder="请选择" style="width: 100%;">
            <el-option v-for="item in retentionPeriod" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="公开属性" prop="openingType" class="mangeShowLook">
          <el-select v-model="paramsSw.openingType" filterable placeholder="请选择" style="width: 100%;">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="分类号" prop="seriesCode" class="mangeShowLook">
          <el-input v-model="paramsSw.seriesCode" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsSw.filingDeptName" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档人" class="mangeShowLook">
          <el-input v-model="paramsSw.filingUserName" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsSw.filingDate" readonly></el-input>
        </el-form-item>
        <el-form-item label="备注" class="mangeShowLook" style="width: 99%;">
          <el-input type="textarea" v-model="paramsSw.c8"></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="swLuRuEdit2Btn">保存</el-button>
        <el-button @click="swLuRuEdit">重置</el-button>
        <el-button @click="dialogSw2 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 录入--编辑确定 -->
    <el-dialog :visible.sync="dialogSw2Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        更新确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <div>确定要保存数据吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="swLuRuEdit2BtnTwo">确定</el-button>
        <el-button @click="dialogSw2Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 删除 -->
    <el-dialog :visible.sync="dialogSw3" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要删除该文件吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="swDelete3Btn">确定</el-button>
        <el-button @click="dialogSw3 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 下载Excel表 -->
    <el-dialog :visible.sync="dialogSw4" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要下载该模板吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="swDownFile4Btn">确定</el-button>
        <el-button @click="dialogSw4 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- Excel文件导入（录入） -->
    <el-dialog :visible.sync="dialogSw5" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/dr.png" alt="">
        Excel文件导入
      </div>
      <div class="dia-deleteTwo">
        <label>文件上传：</label>
        <el-upload
          ref="swFileAddOne"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="handleChange"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <div style="text-align: center;margin:10px 0;">
          <span v-for="(item, index) in imgVal" :key="index">
            {{ item }}
            <img @click="handleRemove" style="margin: 0 0 0 10px; vertical-align:middle;cursor: pointer;" src="../../assets/hurdle/hurdleDelete.png" alt="">
          </span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="swDownFile5Btn">确定</el-button>
        <el-button @click="dialogSw5 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 导出错误信息 -->
    <el-dialog :visible.sync="dialogSw5Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>是否要导出错误信息？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="swDownFile5BtnTwo">确定</el-button>
        <el-button @click="dialogSw5Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 检索 -->
    <el-dialog :visible.sync="dialogSw6" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/js.png" alt="">
        检索
      </div>
      <el-form :model="params" ref="ruleFormAjSearch" label-width="100px" class="demo-ruleForm searchForm">
        <el-form-item label="类别">
          <el-input v-model="params.c15" ></el-input>
        </el-form-item>
        <el-form-item label="题名" prop="" class="">
          <el-input v-model="params.titleProper" ></el-input>
        </el-form-item>
        <el-form-item label="颁发单位" prop="titleProper">
          <el-input v-model="params.c20" ></el-input>
        </el-form-item>
        <el-form-item label="颁发时间" prop="titleProper">
          <el-date-picker style="width: 100%;" v-model="params.c24" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" placeholder="选择时间"></el-date-picker>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="showList(params)">确定</el-button>
        <el-button @click="resetSearch6">重置</el-button>
        <el-button @click="dialogSw6 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 保存 -->
    <el-dialog :visible.sync="dialogSw7" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定保存该案件吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="swDownFile7Btn">确定</el-button>
        <el-button @click="dialogSw7 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 打印目录 -->
    <el-dialog :visible.sync="dialogSw8" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>您没有选择要打印的归档文件，是否要打印全部？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="swDownFile8Btn">确定</el-button>
        <el-button @click="dialogSw8 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 上传（下表格） -->
    <el-dialog :visible.sync="dialogSw9" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/dr.png" alt="">
        Excel文件导入
      </div>
      <div class="dia-deleteTwo">
        <label>文件上传：</label>
        <el-upload
          ref="swFileAddTwo"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="handleChangeTwo"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <div style="text-align: center;margin:10px 0;">
          <span v-for="(item, index) in imgVal" :key="index">
            {{ item.path }}
            <img @click="handleRemove" style="margin: 0 0 0 10px; vertical-align:middle;cursor: pointer;" src="../../assets/hurdle/hurdleDelete.png" alt="">
          </span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="swDownFile9Btn">保存</el-button>
        <el-button @click="dialogSw9 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 删除（下表格） -->
    <el-dialog :visible.sync="dialogSw10" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除附件确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要删除此附件吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="swDelete10Btn">确定</el-button>
        <el-button @click="dialogSw10 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 打印脊背（上表格） -->
    <el-dialog :visible.sync="dialogSw11" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        打印
      </div>
      <div class="editorXin">
        <label>选择尺寸：</label>
        <el-select v-model="paramsSw.scope" filterable placeholder="请选择" style="width: 76%;">
          <el-option v-for="item in scopeArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="swDownload11Btn">确定</el-button>
        <el-button @click="dialogSw11 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 查看（下表格） -->
    <el-dialog :visible.sync="dialogSw12" width="1111px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/ck.png" alt="">
        查看材料
      </div>
      <div class="showClearLook">
        <div class="bigDog menuShrink black-tree" style="float: left;height: 100%;min-height: unset;max-height: unset;">
          <el-tree
            :data="treTable"
            :props="defaultProps"
            :check-strictly="true"
            :default-expand-all="true"
            :expand-on-click-node="false"
            :highlight-current="true"
            accordion
            @node-click="handleNodeClick">
          </el-tree>
        </div>
        <div style="float: left;margin-left: 10px;width: 78%; max-height: 600px; overflow: auto;" v-if="showLookDownload">
          <embed :src="embedOnce" type="application/pdf" width="100%" height="600px"/>
          <!--<iframe :src="embedOnce" width="100%" height="600px"></iframe>-->
        </div>
        <div class="clear"></div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button @click="pdfDownload" :disabled="showLookDownload">下载</el-button>
        <el-button @click="dialogSw12 = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {getFonds, listSeriesByFondsAndRole, listSeriesByFonds, BASICURL} from '@/js/turnOverData'
import { valueIndex } from '@/js/transitionText'
import {listArchiveZL, listDoc, listUserByDeptId, listDept, addArchiveZL, findSeriesCode, editFileAnJian, updateFileAnJian,
  updateSpecialFileAnJia, deleteArchiveZL, listAllDept, findArchiveZL, saveCaseNoByBatch, uploadExcelH5, uploadExcel,
  uploadExcelZl, listFileType, listGzdj, listLwxt, coverElectronicSeal, removeElectronicSeal, saveFileWrk, listAnJianTree,
  powerDocView, uploadPicture, saveZlUploadDoc, editDocAnJian, updateDoc, deleteDoc, listPhysicalArchiveZL, getInitPhysicalFile,
  savePhysicalFile, getPhysicalFile, updatePhysicalFile, deletePhysical, uploadPhysicalExcel, listFileDocData, saveStaffZlUploadDoc,
  listAnJianTreeLeft, powerDocViewLeft, listAnJianTreeSwLeft} from '@/js/fileMangeOver'
export default {
  name: 'fileSw',
  props: {
    paramsC: Object,
    tableDataC: Array,
    tableDataBottomC: Array,
  },
  data () {
    const yearCodeAudit = (rules, item, callback) => {
      let reg = /^[0-9]*$/
      if (!reg.test(item)) {
        callback('请输入数字')
      } else if (item.length > 4 || item.length < 4) {
        callback('输入长度为4')
      } else {
        callback()
      }
    }
    return {
      /* 此处表格数据 */
      params: {c0: 6, page: 1, rows: 10, fonds: 1374133141812, series1: 1374133285843}, // 对应 全宗、类型、上一级表格数据
      paramsBottom: {page: 1, rows: 5, total: 0}, // 对应 全宗、类型、上一级表格数据
      paramsSearch: {page: 1, rows: 10, total: 0}, // 按件--批量设置盒号（检索）
      paramsSw: {}, // 录入 or 编辑 or 特殊编辑 or 修改（表格）
      paramsSwEdit: {}, // 按件--编辑

      /* 此处select类型 */
      fullZong: [], // 全宗
      FondsAndRole: [], // 类型一级
      FondsAndRoleTwo: [], // 类型二级
      FondsAndRoleThree: [], // 类型三级

      /* 此处表格 */
      tableData: [], // 上表格第一级
      tableDataBottom: [], // 下表格第一级
      tableDataDialogAJ5: [], // 批量设置盒号

      /* 此处表格多选选择数据 */
      tableDataTopOnce: [], // 上表格第一级
      tableDataTopOnceItem: {}, // 上表格第一级(单个数据）
      tableDataBottomOnce: [], // 下表格第一级

      /* form判断 */
      rulesSw: {
        caseNo: [{required: true, message: '请填写盒号', trigger: 'blur'}],
        itemNo: [{required: true, message: '请填写件号', trigger: 'blur'}],
        yearCode: [{required: true, message: '请填写年度', trigger: 'blur'}, {validator: yearCodeAudit}],
        titleProper: [{required: true, message: '请填写题名', trigger: 'blur'}],
        c113: [{required: true, message: '请填写责任者', trigger: 'blur'}],
        dateOfCreation: [{required: true, message: '请选择日期', trigger: 'change'}],
        c164: [{required: true, message: '请填写印章种类', trigger: 'blur'}],
        c73: [{required: true, message: '请填写印章形状', trigger: 'blur'}],
        c66: [{required: true, message: '请填写印章状态', trigger: 'blur'}],
        retentionPeriod: [{required: true, message: '请选择保管期限', trigger: 'change'}],
        openingType: [{required: true, message: '请选择公开属性', trigger: 'change'}],
      },

      /* select类型 */
      retentionPeriod: [
        {'name': '永久', 'itemValue': '3'},
        {'name': '长期', 'itemValue': '2'},
        {'name': '短期', 'itemValue': '1'},
        {'name': '10年', 'itemValue': '5'},
        {'name': '15年', 'itemValue': '6'},
        {'name': '30年', 'itemValue': '8'}
      ], // 保管期限
      c58: [{'name': '否', 'itemValue': '1'}, {'name': '是', 'itemValue': '0'}], // 是否为原件
      c59: [{'name': '否', 'itemValue': '1'}, {'name': '是', 'itemValue': '0'}], // 是否在库
      c89: [], // 拟稿人
      c90: [], // 拟稿部门
      c92: [], // 来文系统
      c100: [], // 文件类型
      c112: [], // 盖章类型
      openingType: [
        {'name': '内部', 'itemValue': '2'},
        {'name': '公开', 'itemValue': '1'},
        {'name': '受控', 'itemValue': '3'},
        {'name': '广发商密三级', 'itemValue': '4'},
        {'name': '广发商密二级', 'itemValue': '5'},
        {'name': '广发商密一级', 'itemValue': '6'}
      ], // 公开属性
      filingDept: [], // 归档部门
      yjc89Arr: [], // 拟稿人--检索
      scopeArr: [{id: 3, text: '3cm'}, {id: 5, text: '5cm'}], // 打印脊背--尺寸

      /* 单个数据 */
      addCaseNo: '',
      editCaseNo: '',
      imgVal: [],
      fileErrorMsg: '',
      scope: '',
      embedOnce: '',
      showLookDownload: true,
      showLookDownloadId: '',
      // dateShowLook: 2,
      dateShowLook: 2,
      yeWuaActiveName: '案卷层',

      /* tree数据 */
      treTable: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      },

      /* 弹框 */
      dialogSw1: false,
      dialogSw1Two: false,
      dialogSw2: false,
      dialogSw2Two: false,
      dialogSw3: false,
      dialogSw4: false,
      dialogSw5: false,
      dialogSw5Two: false,
      dialogSw6: false,
      dialogSw7: false,
      dialogSw8: false,
      dialogSw9: false,
      dialogSw10: false,
      dialogSw11: false,
      dialogSw12: false,
    }
  },
  methods: {
    // 获取上表格第一级数据
    showList (val) {
      this.tableData = []
      // val.c5 = 2
      if (this.params.series2) {
        listPhysicalArchiveZL(val).then(res => {
          if (res.data.rows.length <= 0) {
            this.$message.error('该条件下查无数据！')
            this.tableData = []
          } else {
            this.tableData = res.data.rows
            this.params.total = res.data.total
            this.tableData.forEach(item => {
              item.checkOnce = false
            })
          }
        })
      }
      this.dialogSw6 = false
      // this.$forceUpdate()
    },
    // 上表格多选
    handleSelectionChange (val, item) {
      this.tableDataBottom = []
      item.checkOnce = !item.checkOnce
      this.tableDataTopOnce = val
      this.tableDataTopOnceItem = {}
      if (this.tableDataTopOnce.length < 0) {
        this.showListBottom(this.paramsBottom)
      }
      val.forEach(items => {
        if (items.checkOnce) {
          this.tableDataTopOnceItem = items
        }
      })
    },
    handleSelectionChangeAll (val) {
      if (val.length > 0) {
        for (let i of this.tableData) {
          // i.checkOnce = !i.checkOnce
          i.checkOnce = true
        }
      } else {
        for (let i of this.tableData) {
          // i.checkOnce = !i.checkOnce
          i.checkOnce = false
        }
      }
      this.tableDataTopOnce = val
      // for (let i in this.tableDataTopOnce) {
      //   if (!this.tableDataTopOnce[i].checkOnce) {
      //     this.tableDataTopOnce[i].checkOnce = true
      //   }
      // }
    },
    handleSelectionClick (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTable.toggleRowSelection(item, true)
        item.checkOnce = true
        this.paramsBottom.page = 1
        this.paramsBottom.rows = 5
        this.paramsBottom.id = item.id
        this.showListBottom(this.paramsBottom)
      } else {
        this.$refs.multipleTable.toggleRowSelection(item, false)
        item.checkOnce = false
      }
    },
    // 上表格分页点击
    handleCurrentChange (val) {
      this.params.page = val
      this.showList(this.params)
    },
    // 下表格第一级数据
    showListBottom (val) {
      if (this.params.series2) {
        listFileDocData(val).then(res => {
          if (res.data.rows.length <= 0) {
            this.$message.error('该案件暂无材料')
            this.tableDataBottom = []
          } else {
            this.tableDataBottom = res.data.rows
            this.paramsBottom.total = res.data.total
            this.tableDataBottom.forEach(item => {
              item.checkOnce = false
            })
          }
        })
      }
    },
    // 下表格多选
    handleSelectionChangeBottom (val, item) {
      item.checkOnce = !item.checkOnce
      this.tableDataBottomOnce = val
      if (this.tableDataBottomOnce.length > 1) {
        this.$refs.multipleTableBottom.toggleRowSelection(this.tableDataBottomOnce[0])
      }
    },
    handleSelectionChangeBottomAll (val) {
      this.tableDataBottomOnce = val
      for (let i in this.tableDataBottomOnce) {
        if (!this.tableDataBottomOnce[i].checkOnce) {
          this.tableDataBottomOnce[i].checkOnce = true
        }
      }
    },
    handleSelectionClickBottom (item) {
      this.tableDataBottomOnce = []
      if (!item.checkOnce) {
        this.$refs.multipleTableBottom.toggleRowSelection(item)
        item.checkOnce = true
      } else {
        this.$refs.multipleTableBottom.clearSelection()
        item.checkOnce = false
      }
    },
    // 下表格分页点击
    handleCurrentChangeBottom (val) {
      this.paramsBottom.page = val
      this.showListBottom(this.paramsBottom)
    },

    /* 弹框关闭 */
    handleCloseOne () {
      this.dialogSw1 = false
      this.dialogSw2 = false
      this.dialogSw3 = false
      this.dialogSw4 = false
      this.dialogSw5 = false
      this.dialogSw6 = false
      this.dialogSw7 = false
      this.dialogSw8 = false
      this.dialogSw9 = false
      this.dialogSw10 = false
      this.dialogSw11 = false
      this.dialogSw12 = false
    },
    handleCloseTwo () {
      this.dialogSw1Two = false
      this.dialogSw2Two = false
      this.dialogSw5Two = false
    },
    // 录入
    swLuRuAdd () {
      getInitPhysicalFile({archiveTreeNodeId: this.methodSeries()}).then(res => {
        this.dialogSw1 = true
        this.clearFiles('ruleFormAddSw')
        this.paramsSw = res.data
      })
    },
    swLuRuAdd1Btn () {
      this.$refs.ruleFormAddSw.validate((valid) => {
        if (valid) {
          this.dialogSw1Two = true
        }
      })
    },
    swLuRuAdd1BtnTwo () {
      this.paramsSw.fonds = this.params.fonds
      this.paramsSw.series2 = this.params.series2
      this.paramsSw.bs = 'yz'
      savePhysicalFile(this.paramsSw).then(res => {
        if (res.code == 0) {
          this.$message.success('录入成功')
          this.dialogSw1 = false
          this.dialogSw1Two = false
          this.resetSearch()
          this.showList(this.params)
        } else {
          this.$message.error('录入失败')
          this.dialogSw1 = false
          this.dialogSw1Two = false
        }
      })
    },
    // 录入编辑
    swLuRuEdit () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        getPhysicalFile({id: this.tableDataTopOnceItem.id}).then(res => {
          this.dialogSw2 = true
          this.clearFiles('ruleFormEditSw')
          this.paramsSw = res.data
        })
      }
    },
    swLuRuEdit2Btn () {
      this.$refs.ruleFormEditSw.validate((valid) => {
        if (valid) {
          this.dialogSw2Two = true
        }
      })
    },
    swLuRuEdit2BtnTwo () {
      this.paramsSw.bs = 'yz'
      this.paramsSw.id = this.tableDataTopOnceItem.id
      updatePhysicalFile(this.paramsSw).then(res => {
        if (res.code == 0) {
          this.$message.success('修改成功')
          this.dialogSw2 = false
          this.dialogSw2Two = false
          this.resetSearch()
          this.showList(this.params)
        } else {
          this.$message.error('修改失败')
          this.dialogSw2 = false
          this.dialogSw2Two = false
        }
      })
    },
    // 删除
    swDelete3 () {
      let item = this.$onceWay().onceTableListTwo(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogSw3 = true
      }
    },
    swDelete3Btn () {
      let arr =''
      for (let i of this.tableDataTopOnce) {
        arr += i.id + ','
      }
      deletePhysical({ids: arr}).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogSw3 = false
          this.resetSearch()
          this.showList(this.params)
        } else {
          this.$message.error(res.message)
          this.dialogSw3 = false
        }
      })
    },
    // 下载Excel模板
    swDownFile4 () {
      this.dialogSw4 = true
    },
    swDownFile4Btn () {
      let params = {
        status: 'swyz',
        series2: this.params.series2
      }
      let title = ''
      if (this.params.series2 == 1374133285844) {
        title = '实物档案--印章.xls'
      } else if (this.params.series2 == 1374133285845) {
        title = '实物档案--奖杯奖牌.xls'
        params.status = 'swqt'
      } else if (this.params.series2 == 1374133285846) {
        title = '实物档案--外事礼品.xls'
        params.status = 'swqt'
      } else if (this.params.series2 == 1374133285847) {
        title = '实物档案--其他.xls'
        params.status = 'swqt'
      } else if (this.params.series2 == 1374133285848) {
        title = '实物档案--证书.xls'
        params.status = 'swqt'
      } else if (this.params.series2 == 1547110001600) {
        title = '实物档案--证照.xls'
        params.status = 'swqt'
      }
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/downloadExcel', params, title, 'get')
      this.dialogSw4 = false
    },
    // 导入Excel目录
    swDownFile5 () {
      this.dialogSw5 = true
      this.clearFilesTwo('swFileAddOne')
      this.imgVal = []
    },
    swDownFile5Btn () {
      if (this.imgVal.length < 1) {
        this.$message.error('请选择上传文件')
      } else {
        let params = {
          series2: this.params.series2,
          fonds: this.params.fonds,
          imgVal: this.imgVal[0]
        }
        uploadPhysicalExcel(params).then(res => {
          if (res.code == 0) {
            this.$message.success(res.data.msg)
            this.dialogSw5 = false
            this.resetSearch()
            this.showList(this.params)
          } else {
            this.dialogSw5Two = true
            this.fileErrorMsg = res.data.msg
          }
        })
      }
    },
    swDownFile5BtnTwo () {
      let ids = {excelId: this.fileErrorMsg}
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/exportError', ids, '错误信息.xls', 'get')
      this.dialogSw5 = false
      this.dialogSw5Two = false
    },
    handleChange (file, fileList) {
      if (this.imgVal.length >= 1) {
        this.$message.error('只能上传一个文件')
      } else {
        let formData = new FormData()
        formData.append('picture', file.raw)
        formData.append('name', 'file')
        formData.append('type', 'physicalZl')
        uploadExcelH5(formData).then(res => {
          if (res.code == 0) {
            this.imgVal.push(res.data.msg)
          } else {
            this.$message.error(res.message)
          }
        })
      }
    },
    // 删除上传时的文件
    handleRemove (val, item) {
      this.imgVal.splice(val, 1)
    },
    // 检索
    resetSearch6 () {
      this.params = {
        c0: 6,
        page: 1,
        total: 0,
        rows: 10,
        fonds: this.params.fonds,
        series1: this.params.series1,
        series2: this.params.series2,
        series3: this.params.series3,
        c15: '',
        titleProper: '',
        c24: '',
        c20: '',
        searchType: 1
      }
      this.dialogSw6 = true
    },
    // 保存
    swDownFile7 () {
      let item = this.$onceWay().onceTableListTwo(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogSw7 = true
      }
    },
    swDownFile7Btn () {
      let arr = ''
      for (let i of this.tableDataTopOnce) {
        arr = i.id + ','
      }
      saveFileWrk({ids: arr}).then(res => {
        if (res.code == 0) {
          this.$message.success('保存成功')
          this.dialogSw7 = false
          this.resetSearch()
          this.showList(this.params)
        } else {
          this.$message.error('保存失败')
          this.dialogSw7 = false
          this.resetSearch()
          this.showList(this.params)
        }
      })
    },

    // 打印目录
    swDownFile8 () {
      if (this.tableDataTopOnce.length < 1) {
        this.dialogSw8 = true
      } else {
        let arr = ''
        for (let i of this.tableDataTopOnce) {
          arr += i.id + ','
        }
        valueIndex().exportFiles('/gdda-new/gdda/archiveZL/print', {fileIds: arr}, '归档文件目录.doc', 'get')
      }
    },
    swDownFile8Btn () {
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/print', {fileIds: 'all'}, '归档文件目录.doc', 'get')
      this.dialogSw8 = false
    },
    // 打印脊背
    swDownload11 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.paramsSw = {}
        this.dialogSw11 = true
        this.paramsSw.scope = 3
      }
    },
    swDownload11Btn () {
      let arr = ''
      for (let i of this.tableDataTopOnce) {
        arr += i.id + ','
      }
      let params = {
        fileIds: arr,
        scope: this.paramsSw.scope
      }
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/printAnjianJibei', params, '文书档案脊背.doc', 'get')
      this.dialogSw11 = false
    },
    // 上传（下表格）
    swFileAdd9 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.clearFilesTwo('swFileAddTwo')
        this.dialogSw9 = true
        this.imgVal = []
      }
    },
    swDownFile9Btn () {
      let params = {
        subId: this.tableDataTopOnceItem.id,
        imgVal: JSON.stringify(this.imgVal)
      }
      saveStaffZlUploadDoc(params).then(res => {
        if (res.code == 500) {
          if (res.data.optFlag == -1) {
            this.$message.error(`上传失败，因为文件${res.data.msg}已上传过了，请重新选择上传文件`)
            this.dialogSw9 = false
            this.resetSearchBottom()
            this.showListBottom(this.paramsBottom)
          } else {
            this.$message.error(`上传失败`)
            this.dialogSw9 = false
            this.resetSearchBottom()
            this.showListBottom(this.paramsBottom)
          }
        } else {
          this.$message.success('上传成功')
          this.dialogSw9 = false
          this.resetSearchBottom()
          this.showListBottom(this.paramsBottom)
        }
      })
    },
    handleChangeTwo (file, fileList) {
      /*if (this.imgVal.length >= 1) {
        this.$message.error('只能上传一个文件')
      } else {
        let formData = new FormData()
        formData.append('picture', file.raw)
        formData.append('name', 'file')
        formData.append('type', 'physicalZl')
        uploadPicture(formData).then(res => {
          if (res.code == 0) {
            this.imgVal.push(res.data.pathAndMD5)
          } else {
            this.$message.error(res.message)
          }
        })
      }*/
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('name', 'file')
      formData.append('type', 'physicalZl')
      uploadPicture(formData).then(res => {
        if (res.code == 0) {
          this.imgVal.push(res.data.pathAndMD5)
        } else {
          this.$message.error(res.message)
        }
      })
    },
    // 删除（下表格）
    swDelete10 () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.dialogSw10 = true
      }
    },
    swDelete10Btn () {
      let params = {id: this.tableDataBottomOnce[0].id}
      deleteDoc(params).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogSw10 = false
          this.resetSearchBottom()
          this.showListBottom(this.paramsBottom)
        } else {
          this.$message.error(res.message)
          this.dialogSw10 = false
          this.resetSearchBottom()
          this.showListBottom(this.paramsBottom)
        }
      })
    },
    // 查看
    dateShowLookLook () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.dialogSw12 = true
        let params = {
          id: this.tableDataTopOnce[0].id,
          bs: 'Wgd'
        }
        listAnJianTreeSwLeft(params).then(res => {
          if (res.code == 0) {
            this.treTable = res.data
          }
        })
      }
    },
    handleNodeClick (val) {
      if (val.id != 0) {
        powerDocViewLeft({id: val.id}).then(res => {
          if (res.code == 0) {
            if (res.data.optFlag == 0) {
              this.embedOnce = `${BASICURL}/gdda-new/gdda/util/viewPdf?docId=${val.id}`
              this.showLookDownload = true
              this.showLookDownloadId = val
              this.$forceUpdate()
            } else if (res.data.optFlag == -1) {
              this.$message.error('对不起，你访问的文件还未扫描')
              this.showLookDownload = true
              this.showLookDownloadId = ''
            } else if (res.data.optFlag == 2) {
              this.$message.info('该文件非PDF文件，是否要进行下载?')
              this.showLookDownload = false
              this.showLookDownloadId = val
            }
          }
          this.$forceUpdate()
        })
      } else {
        this.showLookDownload = true
        this.showLookDownloadId = ''
      }
    },
    pdfDownload () {
      let textNew = this.showLookDownloadId.text.split('.')[1]
      let params = {
        id: this.showLookDownloadId.id,
        mode: 'Wgd'
      }
      valueIndex().exportFiles('/gdda-new/gdda/util/downLoadFile', params, `文件下载.${textNew}`, 'get')
      // this.dialogSw12 = false
    },

    methodSeries () {
      let item = this.params.series3 || this.params.series2 || this.params.series1
      return item
    },
    resetSearch () {
      this.params.page = 1
      this.params.total = 0
    },
    resetSearchBottom () {
      this.paramsBottom.page = 1
      this.paramsBottom.total = 0
      this.paramsBottom.searchType = 1
    },
    // 清除掉回调表单验证
    clearFiles (val) {
      if (this.$refs[val]) {
        this.$nextTick(() => {
          this.$refs[val].clearValidate()
        })
      }
    },
    clearFilesTwo (val) {
      if (this.$refs[val]) {
        this.$nextTick(() => {
          this.$refs[val].clearFiles()
        })
      }
    },
  },
  watch: {
    paramsC (val) {
      this.params = val
    },
    tableDataC (val) {
      this.tableData = val
      if (val.length < 1) {
        this.tableDataTopOnce = []
        this.tableDataTopOnceItem = {}
      }
    },
    tableDataBottomC (val) {
      this.tableDataBottom = val
      if (val.length < 1) {
        this.tableDataBottomOnce = []
      }
    }
  },
  created () {
    this.params = this.paramsC
    this.tableData = this.tableDataC
    this.tableDataBottom = this.tableDataBottomC
    // listAllDept().then(res => {
    //   this.filingDept = res.data
    // })
  }
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  .search-select {
    float: left;
    margin: 4px 0;
    vertical-align: middle;
    line-height: 40px;
    label {
      font-size: 14px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 143px;
    }
  }
  .search-selectOnce {
    margin: 5px 6px;
    height: 35px;
    border:1px solid #DEDEDE;
    cursor: auto;
  }
  .searchBtn {
    float: left;
    line-height: 47px;
    font-size: 13px;
    cursor: pointer;
    img{
      vertical-align: middle;
      margin-right: 4px;
    }
  }
  .mangeShowLook {
    float: left;
    width: 33%;
    margin-bottom: 20px;
    /deep/.el-input.is-disabled .el-input__inner{
      background-color: #fff!important;
      color: #606266!important;
    }
  }
  .hurdleAllHeHao {
    /deep/.el-dialog__body {
      padding: 0;
    }
  }
  .searchForm {
    /deep/.el-form-item {
      margin-bottom: 10px;
    }
    .el-select {
      width: 100%;
    }
  }

  .showClearLook{
    height: 600px;
    overflow: auto;
  }
</style>
