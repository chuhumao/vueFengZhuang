<!-- 业务 -->
<template>
  <div>
    <!-- 上操作--业务 -->
    <div style="background-color: #F4F4F4;">
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="dateShowLookLook('1')">
        <img src="../../assets/turnOver/ck.png" alt="">
        <span>查看</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="searchContent">
        <img src="../../assets/turnOver/js.png" alt="">
        <span>检索</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="addProjectContent">
        <img src="../../assets/turnOver/tj.png" alt="">
        <span>添加项目</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="editProjectContent">
        <img src="../../assets/turnOver/xg.png" alt="">
        <span>修改项目</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="deleteBtn5">
        <img src="../../assets/turnOver/delete.png" alt="">
        <span>删除</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="clearUpBtn6">
        <img src="../../assets/turnOver/zl.png" alt="">
        <span>进行整理</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="FileDownload7">
        <img src="../../assets/turnOver/xz.png" alt="">
        <span>下载Excel录入模板</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="FileAddBtn8">
        <img src="../../assets/turnOver/dr.png" alt="">
        <span>导入Excel目录</span>
      </div>
      <div class="searchBtn search-selectOnce" v-if="showHitch"></div>
      <div class="searchBtn" @click="FileAddBtn9" v-if="showHitch">
        <img src="../../assets/turnOver/zz.png" alt="">
        <span>质检</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="FileAddBtn10">
        <img src="../../assets/turnOver/ck.png" alt="">
        <span>查看挂接信息</span>
      </div>
      <div class="searchBtn search-selectOnce" v-if="showHitch"></div>
      <div class="searchBtn" @click="saveAddBtn11" v-if="showHitch">
        <img src="../../assets/turnOver/bc.png" alt="">
        <span>保存</span>
      </div>
      <div class="clear"></div>
    </div>
    <!-- 上表格--业务 -->
    <div class="all-Table">
      <el-table
        ref="multipleTable"
        :data="tableData"
        stripe
        border
        @select="handleSelectionChange"
        @select-all="handleSelectionChangeAll"
        @cell-click="handleSelectionClick">
        <el-table-column
          type="index"
          align="center"
          width="60">
        </el-table-column>
        <el-table-column
          type="selection"
          align="center"
          width="60">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c5"
          label="状态"
          width="100">
          <template slot-scope="scope">
            <span v-if="scope.row.c5 == 0">已移交</span>
            <span v-else-if="scope.row.c5 == 1">整理中</span>
            <span v-else-if="scope.row.c5 == 2">已挂接</span>
            <span v-else-if="scope.row.c5 == 3">已归档</span>
            <span v-else-if="scope.row.c5 == 4">在库</span>
            <span v-else-if="scope.row.c5 == 5">出库</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c18"
          label="项目编号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="titleProper"
          label="项目名称"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="yearCode"
          label="项目年度"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c20"
          label="项目类型"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c22"
          label="业务类型"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c24"
          label="项目单位全称"
          width='200'>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c10"
          label="股票代码"
          width='140'>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c28"
          label="承做单位"
          width='160'>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="openingType"
          label="公开属性"
          width='120'>
          <template slot-scope="scope">
            <span v-if="scope.row.openingType == 1">公开</span>
            <span v-else-if="scope.row.openingType == 2">内部</span>
            <span v-else-if="scope.row.openingType == 3">受控</span>
            <span v-else-if="scope.row.openingType == 4">广发商密三级</span>
            <span v-else-if="scope.row.openingType == 5">广发商密二级</span>
            <span v-else-if="scope.row.openingType == 6">广发商密一级</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="retentionPeriod"
          label="保管期限"
          width='120'>
          <template slot-scope="scope">
            <span v-if="scope.row.retentionPeriod == 1">短期</span>
            <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
            <span v-else-if="scope.row.retentionPeriod == 3">永久</span>
            <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
            <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
            <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="seriesCode"
          label="分类号"
          width='120'>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="filingDept"
          label="归档部门"
          width='140'>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="filingDate"
          label="归档日期"
          width='140'>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="createDate"
          label="提交时间"
          width='140'>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <div class="pageLayout">
      <el-pagination
        @current-change="handleCurrentChange"
        :current-page="params.page"
        :page-size="params.rows"
        layout="prev, pager, next, jumper"
        :total="params.total">
      </el-pagination>
    </div>
    <!--下表格--业务 -->
    <div>
      <el-tabs  v-model="yeWuActiveName" type="border-card"  @tab-click="yeWuTabsClick">
        <el-tab-pane label="案卷层" name="案卷层">
          <!-- 下操作--业务 -->
          <div style="background-color: #F4F4F4;">
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="dateShowLookLookTwo('2')">
              <img src="../../assets/turnOver/ck.png" alt="">
              <span>查看</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="addBottomContent">
              <img src="../../assets/turnOver/tj.png" alt="">
              <span>添加案卷</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="editBottomContent">
              <img src="../../assets/turnOver/xg.png" alt="">
              <span>修改案卷</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="deleteContent14">
              <img src="../../assets/turnOver/delete.png" alt="">
              <span>删除案卷</span>
            </div>
            <div class="clear"></div>
          </div>
          <div class="all-Table">
            <el-table
              ref="multipleTableBottom"
              :data="tableDataBottom"
              stripe
              border
              @select="handleSelectionChangeBottom"
              @select-all="handleSelectionChangeBottomAll"
              @cell-click="handleSelectionClickBottom">
              <el-table-column
                type="selection"
                align="center"
                width="55">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="c11"
                label="项目名称"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="folderNo"
                label="案卷号"
                width="140">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="titleProper"
                label="案卷题名"
                width="434">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="openingType"
                label="公开属性"
                width="120">
                <template slot-scope="scope">
                  <span v-if="scope.row.openingType == 1">公开</span>
                  <span v-else-if="scope.row.openingType == 2">内部</span>
                  <span v-else-if="scope.row.openingType == 3">受控</span>
                  <span v-else-if="scope.row.openingType == 4">广发商密三级</span>
                  <span v-else-if="scope.row.openingType == 5">广发商密二级</span>
                  <span v-else-if="scope.row.openingType == 6">广发商密一级</span>
                </template>
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="retentionPeriod"
                label="保管期限"
                width="120">
                <template slot-scope="scope">
                  <span v-if="scope.row.retentionPeriod == 1">短期</span>
                  <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
                  <span v-else-if="scope.row.retentionPeriod == 3">永久</span>
                  <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
                  <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
                  <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
                </template>
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="seriesCode"
                label="分类号"
                width="100">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="c19"
                label="编制单位"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="filingDept"
                label="归档部门"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="filingDate"
                label="归档日期"
                width="160">
              </el-table-column>
            </el-table>
          </div>
          <!-- 下分页 -->
          <div class="pageLayout">
            <el-pagination
              @current-change="handleCurrentChangeBottom"
              :current-page="paramsBottom.page"
              :page-size="paramsBottom.rows"
              layout="prev, pager, next, jumper"
              :total="paramsBottom.total">
            </el-pagination>
          </div>
        </el-tab-pane>
        <el-tab-pane label="文件层" name="文件层">
          <!-- 下操作--业务 -->
          <div style="background-color: #F4F4F4;">
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="dateShowLookLookTwoRight('3')">
              <img src="../../assets/turnOver/ck.png" alt="">
              <span>查看</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="addBottomContent15">
              <img src="../../assets/turnOver/tj.png" alt="">
              <span>添加文件</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="addBottomContent16">
              <img src="../../assets/turnOver/xg.png" alt="">
              <span>修改文件</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="deleteContent17">
              <img src="../../assets/turnOver/delete.png" alt="">
              <span>删除文件</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="fileDownload18">
              <img src="../../assets/turnOver/sc.png" alt="">
              <span>上传</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="fileDelete19">
              <img src="../../assets/turnOver/delete.png" alt="">
              <span>删除材料</span>
            </div>
            <div class="searchBtn search-selectOnce" v-if="this.params.series3 != 1567558827500"></div>
            <div class="searchBtn" @click="ajFileDownload20" v-if="this.params.series3 != 1567558827500">
              <img src="../../assets/turnOver/xz.png" alt="">
              <span>下载Excel模板</span>
            </div>
            <div class="searchBtn search-selectOnce" v-if="this.params.series3 != 1567558827500"></div>
            <div class="searchBtn" @click="ywFileAdd21" v-if="this.params.series3 != 1567558827500">
              <img src="../../assets/turnOver/dr.png" alt="">
              <span>导入Excel目录</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="ywFileAdd22">
              <img src="../../assets/turnOver/xg.png" alt="">
              <span>修改脊背题名</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="ywFileDownload23">
              <img src="../../assets/turnOver/dy.png" alt="">
              <span>打印卷内目录</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="ywFileDownload24">
              <img src="../../assets/turnOver/dy.png" alt="">
              <span>打印封面</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="ywFileDownload25">
              <img src="../../assets/turnOver/dy.png" alt="">
              <span>打印脊背</span>
            </div>
            <div class="clear"></div>
          </div>
          <div class="all-Table">
            <el-table
              ref="multipleTableBottomRight"
              :data="tableDataBottom"
              stripe
              border
              @select="handleSelectionChangeBottomTwo"
              @select-all="handleSelectionChangeBottomAllTwo"
              @cell-click="handleSelectionClickBottomTwo">
              <el-table-column
                type="selection"
                align="center"
                width="55">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="c220"
                label="案卷层"
                width="130">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="caseNo"
                label="盒号"
                width="130">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="itemNo"
                label="件号"
                width="130">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="titleProper"
                label="文件题名"
                width="437">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="c72"
                label="章节号"
                width="120">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="dateOfCreation"
                label="文件日期"
                width="120">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="yearCode"
                label="年度"
                width="100">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="c229"
                label="页号"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="seriesCode"
                label="分类号"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="c76"
                label="索引备注"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="c77"
                label="情况说明"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="filingDept"
                label="归档部门"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="filingDate"
                label="归档日期"
                width="160">
              </el-table-column>
            </el-table>
          </div>
          <!-- 下分页 -->
          <div class="pageLayout">
            <el-pagination
              @current-change="handleCurrentChangeBottomTwo"
              :current-page="paramsBottomTwo.page"
              :page-size="paramsBottomTwo.rows"
              layout="prev, pager, next, jumper"
              :total="paramsBottomTwo.total">
            </el-pagination>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>

    <!-- 查看（下表格） -->
    <el-dialog :visible.sync="dialogShowLook" width="1314px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/ck.png" alt="">
        查看材料
      </div>
      <div class="showClearLook">
        <div class="bigDog menuShrink black-tree" style="width: 300px;float: left;height: 100%;min-height: unset;max-height: unset;">
          <el-tree
            ref="lookDataTree"
            :data="treTable"
            :props="defaultProps"
            :check-strictly="true"
            :default-expand-all="true"
            :expand-on-click-node="false"
            :highlight-current="true"
            accordion
            @node-click="handleNodeClick"
            node-key="id">
          </el-tree>
        </div>
        <div style="float: left;margin-left: 10px;width: 72%; max-height: 600px; overflow: auto;">
          <el-tabs v-model="yeWuActiveNameShowLook" type="border-card" @tab-click="yeWuTabsShowLookClick">
            <el-tab-pane label="基本信息" name="基本信息">
              <el-form v-if="lookCheck == 1" :model="paramsYw" label-width="100px" class="demo-ruleForm">
                <el-form-item label="档案类型" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.project.seriesCode"></el-input>
                </el-form-item>
                <el-form-item label="归档部门" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.project.filingDept"></el-input>
                </el-form-item>
                <el-form-item label="项目编号" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.project.c18"></el-input>
                </el-form-item>
                <el-form-item label="年度" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.project.yearCode"></el-input>
                </el-form-item>
                <el-form-item label="股票代码" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.project.c10"></el-input>
                </el-form-item>
                <el-form-item label="项目单位全称" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.project.c24"></el-input>
                </el-form-item>
                <el-form-item label="项目名称" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.project.titleProper"></el-input>
                </el-form-item>
                <el-form-item label="项目类型" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.project.c20"></el-input>
                </el-form-item>
                <el-form-item label="业务类型" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.project.c22"></el-input>
                </el-form-item>
                <el-form-item label="承做单位" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.project.c28"></el-input>
                </el-form-item>
              </el-form>
              <el-form v-if="lookCheck == 2" :model="paramsYw" label-width="100px" class="demo-ruleForm">
                <el-form-item label="项目名称" class="mangeShowLook" style="width: 50%;">
                  <el-input type="text" v-model="paramsYw.folder.c11"></el-input>
                </el-form-item>
                <el-form-item label="保管期限" class="mangeShowLook" style="width: 50%;">
                  <el-select v-model="paramsYw.folder.retentionPeriod" filterable placeholder="请选择">
                    <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="案卷题名">
                  <el-input type="text" v-model="paramsYw.folder.titleProper"></el-input>
                </el-form-item>
                <el-form-item label="编辑单位" class="mangeShowLook" style="width: 50%;">
                  <el-input type="text" v-model="paramsYw.folder.c19"></el-input>
                </el-form-item>
                <div class="clear"></div>
                <el-form-item label="年度" class="mangeShowLook" style="width: 50%;">
                  <el-input type="text" v-model="paramsYw.folder.yearCode"></el-input>
                </el-form-item>
                <el-form-item label="归档日期" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.folder.filingDate"></el-input>
                </el-form-item>
                <el-form-item label="备注">
                  <el-input v-model="paramsYw.folder.folderNote"></el-input>
                </el-form-item>
              </el-form>
              <el-form v-if="lookCheck == 3" :model="paramsYw" label-width="100px" class="demo-ruleForm">
                <el-form-item label="题名">
                  <el-input type="text" v-model="paramsYw.file.titleProper"></el-input>
                </el-form-item>
                <el-form-item label="保管期限" class="mangeShowLook" style="width: 50%;">
                  <el-select v-model="paramsYw.file.retentionPeriod" filterable placeholder="请选择">
                    <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="章节号" class="mangeShowLook" style="width: 50%;">
                  <el-input type="text" v-model="paramsYw.file.c72"></el-input>
                </el-form-item>
                <el-form-item label="年度" class="mangeShowLook" style="width: 50%;">
                  <el-input type="text" v-model="paramsYw.file.yearCode"></el-input>
                </el-form-item>
                <el-form-item label="页号" class="mangeShowLook" style="width: 50%;">
                  <el-input type="text" v-model="paramsYw.file.c229"></el-input>
                </el-form-item>
                <el-form-item label="归档日期" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.file.filingDate"></el-input>
                </el-form-item>
                <el-form-item label="编制单位" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.file.c133"></el-input>
                </el-form-item>
                <el-form-item label="索引备注">
                  <el-input type="textarea" v-model="paramsYw.file.c76"></el-input>
                </el-form-item>
                <el-form-item label="情况说明">
                  <el-input type="textarea" v-model="paramsYw.file.c77"></el-input>
                </el-form-item>
                <el-form-item label="备注">
                  <el-input type="textarea" v-model="paramsYw.file.c8"></el-input>
                </el-form-item>
              </el-form>
            </el-tab-pane>
            <el-tab-pane v-if="showDianZiShu" label="电子全文" name="电子全文">
              <!--<embed :src="embedOnce" type="application/pdf" width="100%" height="600px"/>-->
              <iframe :src="embedOnce" width="100%" height="600px"></iframe>
            </el-tab-pane>
          </el-tabs>
        </div>
        <div class="clear"></div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <!--<el-button @click="pdfDownload">下载</el-button>-->
        <el-button @click="dialogShowLook = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 查看--下载 -->
    <el-dialog :visible.sync="dialogYW1" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/xzqr.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/xz.png" alt="">
        <br>
        <div>该电子全文暂不提供在线浏览，您是否要离线下载此文件？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="yeWuDownLoad1">确定</el-button>
        <el-button @click="dialogYW1 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 检索 -->
    <el-dialog :visible.sync="dialogYW2" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/js.png" alt="">
        检索
      </div>
      <el-form :model="params" ref="ruleFormAjSearch" label-width="100px" class="demo-ruleForm searchForm">
        <!--档案类型-->
        <el-form-item label="档案类型" prop="titleProper">
          <el-input v-model="params.thseriesCode" ></el-input>
        </el-form-item>
        <!--归档部门-->
        <el-form-item label="归档部门" prop="" class="">
          <el-select v-model="params.thfilingDept" filterable placeholder="请选择">
            <el-option v-for="item in filingDept" :key="item.id" :label="item.text" :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <!--项目编号-->
        <el-form-item label="项目编号" prop="titleProper">
          <el-input v-model="params.thc18" ></el-input>
        </el-form-item>
        <!--年度-->
        <el-form-item label="年度" prop="titleProper">
          <el-input v-model="params.thyearCode" ></el-input>
        </el-form-item>
        <!--状态-->
        <el-form-item label="状态" prop="" class="">
          <el-select v-model="params.thc5" placeholder="请选择" filterable reserve-keyword>
            <el-option v-for="item in thc5Arr" :key="item.id" :label="item.text" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <!--股票代码-->
        <el-form-item label="股票代码" prop="" class="">
          <el-input v-model="params.thc10" ></el-input>
        </el-form-item>
        <!--项目单位全称-->
        <el-form-item label="项目单位全称" prop="" class="">
          <el-input v-model="params.thc24" ></el-input>
        </el-form-item>
        <!--项目名称-->
        <el-form-item label="项目名称" prop="" class="">
          <el-input v-model="params.thtitleProper" ></el-input>
        </el-form-item>
        <!--项目类型-->
        <el-form-item label="项目类型" prop="" class="">
          <el-input v-model="params.c117" ></el-input>
        </el-form-item>
        <!--业务类型-->
        <el-form-item label="业务类型" prop="" class="">
          <el-input v-model="params.thc22" ></el-input>
        </el-form-item>
        <!--承做单位-->
        <el-form-item label="承做单位" prop="" class="">
          <el-input v-model="params.thc28" ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="showList(params)">确定</el-button>
        <el-button @click="searchContent">重置</el-button>
        <el-button @click="dialogYW2 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 添加项目 -->
    <el-dialog :visible.sync="dialogYW3" width="888px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/lr.png" alt="">
        <!--录入项目信息-->
        录入案卷信息
      </div>
      <el-form :model="paramsYwEdit" :rules="rulesAj" ref="ruleFormYwAddProjectOne" label-width="110px" class="demo-ruleForm">
        <!--档案类型-->
        <el-form-item label="项目编号" prop="c18" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c18" ></el-input>
        </el-form-item>
        <!--项目编号-->
        <el-form-item label="项目名称" prop="titleProper" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.titleProper" ></el-input>
        </el-form-item>
        <!--年度-->
        <el-form-item label="起止年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.yearCode" ></el-input>
        </el-form-item>
        <!--状态-->
        <el-form-item label="项目类型" prop="c20"  class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c20" ></el-input>
        </el-form-item>
        <!--股票代码-->
        <el-form-item label="业务类型" prop="c22" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c22" ></el-input>
        </el-form-item>
        <!--项目单位全称-->
        <el-form-item label="项目单位全称" prop="c24" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c24" ></el-input>
        </el-form-item>
        <!--项目名称-->
        <el-form-item label="股票代码" prop="c10" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c10" ></el-input>
        </el-form-item>
        <!--项目类型-->
        <el-form-item label="承做单位" prop="c28" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c28" ></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--业务类型-->
        <el-form-item label="公开属性" prop="openingType" class="mangeShowLook">
          <!--<el-input v-model="paramsYwEdit.openingType" ></el-input>-->
          <el-select v-model="paramsYwEdit.openingType" filterable placeholder="请选择">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.retentionPeriod" filterable placeholder="请选择" :disabled="true">
            <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
        <!--分类号-->
        <el-form-item label="分类号" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.seriesCode" readonly></el-input>
        </el-form-item>
        <!--归档部门-->
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDeptName" readonly></el-input>
          <!--<el-select v-model="paramsYwEdit.filingDept" filterable placeholder="请选择" :disabled="true">-->
            <!--<el-option v-for="item in filingDept" :key="item.id" :label="item.text" :value="item.id">-->
            <!--</el-option>-->
          <!--</el-select>-->
        </el-form-item>
        <!--归档人-->
        <el-form-item label="归档人"  class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingUserName" readonly></el-input>
          <!--<el-select v-model="paramsYwEdit.filingUser" filterable placeholder="请选择" :disabled="true">-->
            <!--<el-option v-for="item in filingDept" :key="item.id" :label="item.text" :value="item.id">-->
            <!--</el-option>-->
          <!--</el-select>-->
        </el-form-item>
        <!--归档日期-->
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDate" readonly></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="addProjectContentBtn">保存</el-button>
        <el-button @click="addProjectContent">重置</el-button>
        <el-button @click="dialogYW3 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 添加项目确定 -->
    <el-dialog :visible.sync="dialogYW33" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/lr.png" alt="">
        录入确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="addProjectContentBtn33">确定</el-button>
        <el-button @click="dialogYW33 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 修改项目信息 -->
    <el-dialog :visible.sync="dialogYW4" width="888px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tsbj.png" alt="">
        修改项目信息
      </div>
      <el-form :model="paramsYwEdit" :rules="rulesAj" ref="ruleFormYwEditProject" label-width="110px" class="demo-ruleForm">
        <!--档案类型-->
        <el-form-item label="项目编号" prop="c18" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c18" ></el-input>
        </el-form-item>
        <!--项目编号-->
        <el-form-item label="项目名称" prop="titleProper" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.titleProper" ></el-input>
        </el-form-item>
        <!--年度-->
        <el-form-item label="起止年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.yearCode" ></el-input>
        </el-form-item>
        <!--状态-->
        <el-form-item label="项目类型" prop="c20"  class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c20" ></el-input>
        </el-form-item>
        <!--股票代码-->
        <el-form-item label="业务类型" prop="c22" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c22" ></el-input>
        </el-form-item>
        <!--项目单位全称-->
        <el-form-item label="项目单位全称" prop="c24" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c24" ></el-input>
        </el-form-item>
        <!--项目名称-->
        <el-form-item label="股票代码" prop="c10" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c10" ></el-input>
        </el-form-item>
        <!--项目类型-->
        <el-form-item label="承做单位" prop="c28" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c28" ></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--业务类型-->
        <el-form-item label="公开属性" prop="openingType" class="mangeShowLook">
          <!--<el-input v-model="paramsYwEdit.openingType" ></el-input>-->
          <el-select v-model="paramsYwEdit.openingType" filterable placeholder="请选择">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.retentionPeriod" filterable placeholder="请选择" :disabled="true">
            <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
        <!--分类号-->
        <el-form-item label="分类号" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.seriesCode" readonly></el-input>
        </el-form-item>
        <!--归档部门-->
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDeptName" readonly></el-input>
          <!--<el-select v-model="paramsYwEdit.filingDept" filterable placeholder="请选择" :disabled="true">-->
            <!--<el-option v-for="item in filingDept" :key="item.id" :label="item.text" :value="item.id">-->
            <!--</el-option>-->
          <!--</el-select>-->
        </el-form-item>
        <!--归档人-->
        <el-form-item label="归档人"  class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingUserName" readonly></el-input>
          <!--<el-select v-model="paramsYwEdit.filingUser" filterable placeholder="请选择" :disabled="true">-->
            <!--<el-option v-for="item in filingDept" :key="item.id" :label="item.text" :value="item.id">-->
            <!--</el-option>-->
          <!--</el-select>-->
        </el-form-item>
        <!--归档日期-->
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDate" readonly></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="editProjectContentBtn">保存</el-button>
        <!--<el-button @click="editProjectContent">重置</el-button>-->
        <el-button @click="dialogYW4 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 修改项目信息确定 -->
    <el-dialog :visible.sync="dialogYW44" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <!--<img src="../../assets/dialog/sl.png" alt="">-->
        更新确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="editProjectContentBtn44">确定</el-button>
        <el-button @click="dialogYW44 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 删除 -->
    <el-dialog :visible.sync="dialogYW5" width="480px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除附件确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>删除此项目，将会一并删除项目下的所有案卷、案件、材料，确定吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="deleteBtn55">确定</el-button>
        <el-button @click="dialogYW5 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 进行整理 -->
    <el-dialog :visible.sync="dialogYW6" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        整理确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要将该项目提交到整理状态吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="clearUpBtn66">确定</el-button>
        <el-button @click="dialogYW6 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 下载录入Excel -->
    <el-dialog :visible.sync="dialogYW7" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/xzqr.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/xz.png" alt="">
        <br>
        <div>确定要下载该模板吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="FileDownload77">确定</el-button>
        <el-button @click="dialogYW7 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- Excel文件导入（录入） -->
    <el-dialog :visible.sync="dialogYW8" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/dr.png" alt="">
        Excel文件导入
      </div>
      <div class="dia-deleteTwo">
        <label>文件上传：</label>
        <el-upload
          ref="ywFileAddOne"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="handleChange"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <div style="text-align: center;margin:10px 0;">
          <span v-for="(item, index) in imgVal" :key="index">
            {{ item }}
            <img @click="handleRemove" style="margin: 0 0 0 10px; vertical-align:middle;cursor: pointer;" src="../../assets/hurdle/hurdleDelete.png" alt="">
          </span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="FileAddBtn88">确定</el-button>
        <el-button @click="dialogYW8 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 导出错误信息 -->
    <el-dialog :visible.sync="dialogYW88" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/xzqr.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/xz.png" alt="">
        <br>
        <div>是否要导出错误信息？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="FileErrorBtn88">确定</el-button>
        <el-button @click="dialogYW88 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 质检 -->
    <el-dialog :visible.sync="dialogYW9" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/zj.png" alt="">
        质检
      </div>
      <div class="dia-deleteTwo">
        <label>文件上传：</label>
        <el-upload
          ref="ywFileAddTwo"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="handleChange"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <div style="text-align: center;margin:10px 0;">
          <span v-for="(item, index) in imgVal" :key="index">
            {{ item }}
            <img @click="handleRemove" style="margin: 0 0 0 10px; vertical-align:middle;cursor: pointer;" src="../../assets/hurdle/hurdleDelete.png" alt="">
          </span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="FileAddBtn99">质检</el-button>
        <el-button @click="dialogYW9 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 挂接信息 -->
    <el-dialog :visible.sync="dialogYW10" width="1111px" class="hurdleAll hurdleAllHeHao" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sccl.png" alt="">
        挂接信息
      </div>
      <div>
        <div style="background-color: #F4F4F4;">
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="showHitchTab">
            <img src="../../assets/turnOver/ck.png" alt="">
            <span>查看挂接信息</span>
          </div>
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" style="margin-right: 4px;">
            <!--<el-input type="text" v-model="paramsGuaJie.hangingDate"></el-input>-->
            <el-date-picker
              v-model="paramsGuaJie.hangingDate"
              type="date"
              format="yyyy年MM月dd日"
              value-format="yyyy-MM-dd"
              placeholder="选择时间"
            >
            </el-date-picker>
          </div>
          <div class="searchBtn" @click="FileAddBtn10">
            <img src="../../assets/turnOver/js.png" alt="">
            <span>检索</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 上表格--业务 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableGuaJie"
            :data="tableDataGuaJie"
            stripe
            border
            @select="handleSelectionChangeGuaJie"
            @select-all="handleSelectionChangeAllGuaJie"
            @cell-click="handleSelectionClickGuaJie">
            <el-table-column
              type="index"
              align="center"
              width="60">
            </el-table-column>
            <el-table-column
              type="selection"
              align="center"
              width="60">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="hangingDate"
              label="挂接日期"
              width="183">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="total"
              label="挂接数量"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="successNumber"
              label="成功数量"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="loseNumber"
              label="失败件数"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="repeatNumber"
              label="重复件数"
              width="160">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="createDate"
              label="创建日期"
              width="166">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeGuaJie"
            :current-page="paramsGuaJie.page"
            :page-size="paramsGuaJie.rows"
            layout="prev, pager, next, jumper"
            :total="paramsGuaJie.total">
          </el-pagination>
        </div>
      </div>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;text-align: right">
        <!--<el-button type="primary" @click="saveAddBtn101">确定</el-button>-->
        <el-button @click="dialogYW10 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 挂接信息 -->
    <el-dialog :visible.sync="dialogYW10Two" width="1111px" class="hurdleAll hurdleAllHeHao" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sccl.png" alt="">
        挂接信息
      </div>
      <div>
        <!-- 上表格--业务 -->
        <div class="all-Table">
          <el-table
            :data="tableDataGuaJieTwo"
            stripe
            border>
            <el-table-column
              type="index"
              align="center"
              width="60">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="name"
              label="挂接失败文件名">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="path"
              label="路径">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="remark"
              label="原因">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeGuaJieTwo"
            :current-page="paramsGuaJieTwo.page"
            :page-size="paramsGuaJieTwo.rows"
            layout="prev, pager, next, jumper"
            :total="paramsGuaJieTwo.total">
          </el-pagination>
        </div>
      </div>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;text-align: right">
        <!--<el-button type="primary" @click="saveAddBtn101">确定</el-button>-->
        <el-button @click="dialogYW10Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 保存 -->
    <el-dialog :visible.sync="dialogYW11" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定保存该项目吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="saveAddBtn101">确定</el-button>
        <el-button @click="dialogYW11 = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 案卷层--开始 -->
    <!-- 添加项目确定 -->
    <el-dialog :visible.sync="dialogYW12" width="888px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        录入项目信息
      </div>
      <el-form :model="paramsYwEdit" :rules="rulesAjHitch" ref="ruleFormYwAddProject" label-width="110px" class="demo-ruleForm">
        <!--项目名称-->
        <el-form-item label="项目名称" prop="" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c11" ></el-input>
        </el-form-item>
        <!--案卷号-->
        <el-form-item label="案卷号" prop="folderNo" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.folderNo" ></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--案卷题名-->
        <el-form-item label="案卷题名" prop="titleProper"  class="mangeShowLook" style="width: 66%">
          <el-input v-model="paramsYwEdit.titleProper" ></el-input>
        </el-form-item>
        <!--公开属性-->
        <el-form-item label="公开属性" prop="openingType" class="mangeShowLook">
          <!--<el-input v-model="paramsYwEdit.openingType" ></el-input>-->
          <el-select v-model="paramsYwEdit.openingType" filterable placeholder="请选择">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.retentionPeriod" filterable placeholder="请选择" :disabled="true">
            <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
        <!--分类号-->
        <el-form-item label="分类号" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.seriesCode" readonly></el-input>
        </el-form-item>
        <!--编制单位-->
        <el-form-item label="编制单位" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c19" readonly></el-input>
        </el-form-item>
        <!--归档部门-->
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDeptName" readonly></el-input>
        </el-form-item>
        <!--归档人-->
        <el-form-item label="归档人"  class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingUserName" readonly></el-input>
        </el-form-item>
        <!--归档日期-->
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDate" readonly></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="addProjectContentBtn12">保存</el-button>
        <el-button @click="addBottomContent">重置</el-button>
        <el-button @click="dialogYW12 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 添加项目确定--保存 -->
    <el-dialog :visible.sync="dialogYW12Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        录入确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="addProjectContentBtn12Two">确定</el-button>
        <el-button @click="dialogYW12Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 修改案卷 -->
    <el-dialog :visible.sync="dialogYW13" width="888px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        修改案卷信息
      </div>
      <el-form :model="paramsYwEdit" :rules="rulesAjHitch" ref="ruleFormYwEditProject" label-width="110px" class="demo-ruleForm">
        <!--项目名称-->
        <el-form-item label="项目名称" prop="" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c11" ></el-input>
        </el-form-item>
        <!--案卷号-->
        <el-form-item label="案卷号" prop="folderNo" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.folderNo" ></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--案卷题名-->
        <el-form-item label="案卷题名" prop="titleProper"  class="mangeShowLook" style="width: 66%">
          <el-input v-model="paramsYwEdit.titleProper" ></el-input>
        </el-form-item>
        <!--公开属性-->
        <el-form-item label="公开属性" prop="openingType" class="mangeShowLook">
          <!--<el-input v-model="paramsYwEdit.openingType" ></el-input>-->
          <el-select v-model="paramsYwEdit.openingType" filterable placeholder="请选择">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.retentionPeriod" filterable placeholder="请选择" :disabled="true">
            <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
        <!--分类号-->
        <el-form-item label="分类号" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.seriesCode" readonly></el-input>
        </el-form-item>
        <!--编制单位-->
        <el-form-item label="编制单位" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c19" readonly></el-input>
        </el-form-item>
        <!--归档部门-->
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDeptName" readonly></el-input>
        </el-form-item>
        <!--归档人-->
        <el-form-item label="归档人"  class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingUserName" readonly></el-input>
        </el-form-item>
        <!--归档日期-->
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDate" readonly></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="editBottomContent13">保存</el-button>
        <el-button @click="editBottomContent">重置</el-button>
        <el-button @click="dialogYW13 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 修改案卷--保存 -->
    <el-dialog :visible.sync="dialogYW13Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        更新确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="editBottomContent13Two">确定</el-button>
        <el-button @click="dialogYW13Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 删除 -->
    <el-dialog :visible.sync="dialogYW14" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除附件确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>删除此案卷，将会一并删除案卷下的所有案件、材料，确定吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="deleteContent14Two">确定</el-button>
        <el-button @click="dialogYW14 = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 文件层--开始 -->
    <!-- 添加项目确定 -->
    <el-dialog :visible.sync="dialogYW15" width="888px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        录入项目信息
      </div>
      <el-form :model="paramsYwEdit" :rules="rulesAjHitchTwo" ref="ruleFormYwAddProjectTwo" label-width="110px" class="demo-ruleForm">
        <!--案卷号-->
        <el-form-item label="案卷号" prop="c220" class="mangeShowLook">
          <!--<el-input v-model="paramsYwEdit.openingType" ></el-input>-->
          <el-select v-model="paramsYwEdit.c220" filterable placeholder="请选择" @change="c220ArrChange">
            <!--<el-option v-for="item in c220Arr" :key="item.id" :label="item.folderNo" :value="item.id"></el-option>-->
            <el-option v-for="item in c220Arr" :key="item.id" :label="item.folderNo" :value="item.folderNo"></el-option>
          </el-select>
        </el-form-item>
        <!--案卷题名-->
        <el-form-item label="案卷题名" prop="ownerId" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.ownerId" filterable placeholder="请选择" @change="ownerIdArrChange">
            <el-option v-for="item in ownerIdArr" :key="item.id" :label="item.titleProper" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <!--章节号-->
        <el-form-item label="章节号" prop="c72"  class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c72"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--文件题名-->
        <el-form-item label="文件题名" prop="titleProper" class="" style="width: 99%;">
          <el-input v-model="paramsYwEdit.titleProper"></el-input>
        </el-form-item>
        <!--文件日期-->
        <el-form-item label="文件日期" prop="dateOfCreation" class="mangeShowLook">
          <!--<el-input v-model="paramsYwEdit.dateOfCreation"></el-input>-->
          <el-date-picker
            style="width: 100%;"
            v-model="paramsYwEdit.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间"
          >
          </el-date-picker>
        </el-form-item>
        <!--年度-->
        <el-form-item label="年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.yearCode"></el-input>
        </el-form-item>
        <!--页号-->
        <el-form-item label="页号" prop="c229" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c229"></el-input>
        </el-form-item>
        <!--公开属性-->
        <el-form-item label="公开属性" prop="openingType" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.openingType" filterable placeholder="请选择">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.retentionPeriod" filterable placeholder="请选择" :disabled="true">
            <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
        <!--分类号-->
        <el-form-item label="分类号" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.seriesCode" readonly></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--索引备注-->
        <el-form-item label="索引备注" style="width: 99%;">
          <el-input type="textarea" v-model="paramsYwEdit.c76"></el-input>
        </el-form-item>
        <!--情况说明-->
        <el-form-item label="情况说明" style="width: 99%;">
          <el-input type="textarea" v-model="paramsYwEdit.c77"></el-input>
        </el-form-item>
        <!--归档部门-->
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDeptName" readonly></el-input>
        </el-form-item>
        <!--归档人-->
        <el-form-item label="归档人"  class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingUserName" readonly></el-input>
        </el-form-item>
        <!--归档日期-->
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDate" readonly></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="addProjectContentBtn15">保存</el-button>
        <el-button @click="addBottomContent15">重置</el-button>
        <el-button @click="dialogYW15 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 添加项目确定--保存 -->
    <el-dialog :visible.sync="dialogYW15Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        录入确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="addProjectContentBtn15Two">确定</el-button>
        <el-button @click="dialogYW15Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 修改案卷 -->
    <el-dialog :visible.sync="dialogYW16" width="888px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        修改文件信息
      </div>
      <el-form :model="paramsYwEdit" :rules="rulesAjHitchTwo" ref="ruleFormYwEditProjectTwo" label-width="110px" class="demo-ruleForm">
        <!--案卷号-->
        <el-form-item label="案卷号" prop="c220" class="mangeShowLook">
          <!--<el-input v-model="paramsYwEdit.openingType" ></el-input>-->
          <el-select v-model="paramsYwEdit.c220" filterable placeholder="请选择" @change="c220ArrChange">
            <!--<el-option v-for="item in c220Arr" :key="item.id" :label="item.folderNo" :value="item.id"></el-option>-->
            <el-option v-for="item in c220Arr" :key="item.id" :label="item.folderNo" :value="item.folderNo"></el-option>
          </el-select>
        </el-form-item>
        <!--案卷题名-->
        <el-form-item label="案卷题名" prop="ownerId" class="mangeShowLook" @change="ownerIdArrChange">
          <el-select v-model="paramsYwEdit.ownerId" filterable placeholder="请选择">
            <el-option v-for="item in ownerIdArr" :key="item.id" :label="item.titleProper" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <!--章节号-->
        <el-form-item label="章节号" prop="c72"  class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c72"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--文件题名-->
        <el-form-item label="文件题名" prop="titleProper" class="" style="width: 99%;">
          <el-input v-model="paramsYwEdit.titleProper"></el-input>
        </el-form-item>
        <!--文件日期-->
        <el-form-item label="文件日期" prop="dateOfCreation" class="mangeShowLook">
          <!--<el-input v-model="paramsYwEdit.dateOfCreation"></el-input>-->
          <el-date-picker
            style="width: 100%;"
            v-model="paramsYwEdit.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间"
          >
          </el-date-picker>
        </el-form-item>
        <!--年度-->
        <el-form-item label="年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.yearCode"></el-input>
        </el-form-item>
        <!--页号-->
        <el-form-item label="页号" prop="c229" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c229"></el-input>
        </el-form-item>
        <!--公开属性-->
        <el-form-item label="公开属性" prop="openingType" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.openingType" filterable placeholder="请选择">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.retentionPeriod" filterable placeholder="请选择" :disabled="true">
            <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
        <!--分类号-->
        <el-form-item label="分类号" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.seriesCode" readonly></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--索引备注-->
        <el-form-item label="索引备注" style="width: 99%;">
          <el-input type="textarea" v-model="paramsYwEdit.c76"></el-input>
        </el-form-item>
        <!--情况说明-->
        <el-form-item label="情况说明" style="width: 99%;">
          <el-input type="textarea" v-model="paramsYwEdit.c77"></el-input>
        </el-form-item>
        <!--归档部门-->
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDeptName" readonly></el-input>
        </el-form-item>
        <!--归档人-->
        <el-form-item label="归档人"  class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingUserName" readonly></el-input>
        </el-form-item>
        <!--归档日期-->
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDate" readonly></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="addProjectContentBtn16">保存</el-button>
        <el-button @click="addBottomContent16">重置</el-button>
        <el-button @click="dialogYW16 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 修改案卷--保存 -->
    <el-dialog :visible.sync="dialogYW16Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        更新确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="addProjectContentBtn16Two">确定</el-button>
        <el-button @click="dialogYW16Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 删除 -->
    <el-dialog :visible.sync="dialogYW17" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除案件确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要删除所选数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="deleteContent17Two">确定</el-button>
        <el-button @click="dialogYW17 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- Excel文件上传 -->
    <el-dialog :visible.sync="dialogYW18" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/dr.png" alt="">
        文件上传
      </div>
      <div class="dia-deleteTwo">
        <label>文件上传：</label>
        <el-upload
          ref="ajFileTwo"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="handleChangeTwo"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <div style="text-align: center;margin:10px 0;">
          <span v-for="(item, index) in imgVal" :key="index" style="display:block;">
            {{ item.path }}
            <img @click="handleRemove" style="margin: 0 0 0 10px; vertical-align:middle;cursor: pointer;" src="../../assets/hurdle/hurdleDelete.png" alt="">
          </span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="fileDownload18Two">确定</el-button>
        <el-button @click="dialogYW18 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 删除材料 -->
    <el-dialog :visible.sync="dialogYW19" width="1111px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sccl.png" alt="">
        附件
      </div>
      <div>
        <div style="background-color: #F4F4F4;">
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="fileDelete19Two">
            <img src="../../assets/turnOver/delete.png" alt="">
            <span>删除</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 上表格--业务 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableDeleteFile"
            :data="tableDataDeleteFile"
            stripe
            border
            @select="handleSelectionChangeDeleteFile"
            @select-all="handleSelectionChangeAllDeleteFile"
            @cell-click="handleSelectionClickDeleteFile">
            <el-table-column
              type="index"
              align="center"
              width="60">
            </el-table-column>
            <el-table-column
              type="selection"
              align="center"
              width="60">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="titleProper"
              label="文件标题">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileSize"
              label="文件大小">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileFormat"
              label="文件格式">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeDeleteFile"
            :current-page="paramsDeleteFile.page"
            :page-size="paramsDeleteFile.rows"
            layout="prev, pager, next, jumper"
            :total="paramsDeleteFile.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;text-align: right">
        <!--<el-button type="primary" @click="fileDownload18Two">确定</el-button>-->
        <el-button @click="dialogYW19 = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 删除材料确定 -->
    <el-dialog :visible.sync="dialogYW19Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除案件确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要删除所选数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="deleteContent19Two">确定</el-button>
        <el-button @click="dialogYW19Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 下载录入Excel -->
    <el-dialog :visible.sync="dialogYW20" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要下载该模板吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajFileDownload20Two">确定</el-button>
        <el-button @click="dialogYW20 = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- Excel文件导入 -->
    <el-dialog :visible.sync="dialogYW21" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/dr.png" alt="">
        Excel文件导入
      </div>
      <div class="dia-deleteTwo">
        <label>文件上传：</label>
        <el-upload
          ref="fwFileTwo"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="handleChange"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <div style="text-align: center;margin:10px 0;">
          <span v-for="(item, index) in imgVal" :key="index">
            {{ item }}
            <img @click="handleRemove" style="margin: 0 0 0 10px; vertical-align:middle;cursor: pointer;" src="../../assets/hurdle/hurdleDelete.png" alt="">
          </span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ywFileAdd21Two">确定</el-button>
        <el-button @click="dialogYW21 = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 修改脊背题名 -->
    <el-dialog :visible.sync="dialogYW22" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        修改
      </div>
      <el-form :model="paramsYwEdit" :rules="rulesJb" ref="ruleFormYwEditJiBei" label-width="110px" class="demo-ruleForm">
        <!--盒号-->
        <el-form-item label="盒号" prop="caseNo">
          <!--<el-input v-model="paramsYwEdit.openingType" ></el-input>-->
          <el-select v-model="paramsYwEdit.caseNo" filterable placeholder="请选择" @change="ywFileAdd22Change" style="width: 100%;">
            <el-option v-for="(item, index) in caseNoArr" :key="index" :label="item.caseNo" :value="item.caseNo"></el-option>
          </el-select>
        </el-form-item>
        <!--脊背题名-->
        <el-form-item label="脊背题名" prop="c85">
          <el-input type="textarea" v-model="paramsYwEdit.c85"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ywFileAdd22Btn">确定</el-button>
        <el-button @click="dialogYW22 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 打印卷内目录 -->
    <el-dialog :visible.sync="dialogYW23" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>您没有选择要打印的文件，是否要打印该项目下的全部案件？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ywFileDownload23Btn">确定</el-button>
        <el-button @click="dialogYW23 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 打印封面目录 -->
    <el-dialog :visible.sync="dialogYW24" width="555px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/xzqr.png" alt="">
        打印
      </div>
      <el-form :model="paramsYwEdit" ref="ruleFormYwEditJiBei" label-width="110px" class="demo-ruleForm">
        <!--盒号-->
        <el-form-item label="打印范围:">
          <el-input v-model="paramsYwEdit.caseNo1" style="width: 36%;"></el-input>
          <span>盒，到</span>
          <el-input v-model="paramsYwEdit.caseNo2" style="width: 36%;"></el-input>
          <span>盒</span>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ywFileDownload24Btn">确定</el-button>
        <el-button @click="dialogYW24 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 打印脊背目录 -->
    <el-dialog :visible.sync="dialogYW25" width="555px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/xzqr.png" alt="">
        打印
      </div>
      <el-form :model="paramsYwEdit" ref="ruleFormYwEditJiBei" label-width="110px" class="demo-ruleForm">
        <!--盒号-->
        <el-form-item label="打印范围:">
          <el-input v-model="paramsYwEdit.caseNo1" style="width: 36%;"></el-input>
          <span>盒，到</span>
          <el-input v-model="paramsYwEdit.caseNo2" style="width: 36%;"></el-input>
          <span>盒</span>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ywFileDownload25Btn">确定</el-button>
        <el-button @click="dialogYW25 = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {getFonds, listSeriesByFondsAndRole, listSeriesByFonds, BASICURL} from '@/js/turnOverData'
import { valueIndex } from '@/js/transitionText'
import {listArchiveZL, listDoc, listUserByDeptId, listDept, addArchiveZL, findSeriesCode, editFileAnJian, updateFileAnJian,
  updateSpecialFileAnJia, deleteArchiveZL, listAllDept, findArchiveZL, saveCaseNoByBatch, uploadExcelH5, uploadExcel,
  uploadExcelZl, listFileType, listGzdj, listLwxt, coverElectronicSeal, removeElectronicSeal, saveFileWrk, listAnJianTree,
  powerDocView, uploadPicture, saveZlUploadDoc, editDocAnJian, updateDoc, deleteDoc, listThArchiveZL, listThFolderData,
  listTreeJsonByTh, viewByTh, powerDocViewUtil, listTouHangFileData, listThStatus, getInitJjProject, saveThProject,
  getThProject, updateThProject, deleteThProject, zLingThProject, uploadThExcel, thQuality, saveWrk, listThHangingData, listThHangingDataiData,
  getInitJjFolder, saveThFolder, getJjFolder, updateThFolder, deleteThFolder, getInitJjFile, listThFolderById, listJjFolderByIdAndNo,
  saveThFile, getThFile, updateThFile, deleteThFile, saveThZlUploadDoc, listThDocData, uploadThFileExcel, getCaseNoByC18, getTitleByCaseNo,
  updateJbTitle} from '@/js/fileMangeOver'
export default {
  name: 'fileYeWu',
  props: {
    paramsC: Object,
    tableDataC: Array,
    tableDataBottomC: Array,
  },
  data () {
    const yearCodeAudit = (rules, item, callback) => {
      let reg = /^[0-9]*$/
      if (!reg.test(item)) {
        callback('请输入数字')
      } else if (item.length > 4 || item.length < 4) {
        callback('输入长度为4')
      } else {
        callback()
      }
    }
    return {
      /* 此处表格数据 */
      params: {c5: 2, page: 1, rows: 10, fonds: 1374133141812, series1: 1379482316593, total: 0}, // 对应 全宗、类型、上一级表格数据
      // params: {c0: 6, page: 1, rows: 10, fonds: 1374133141812, series1: 1379482316593, series2: 1388742017297}, // 对应 全宗、类型、上一级表格数据
      paramsBottom: {page: 1, rows: 5, total: 0}, // 对应 全宗、类型、上一级表格数据
      paramsBottomTwo: {page: 1, rows: 5, total: 0}, // 文件层
      paramsSearch: {page: 1, rows: 10, total: 0}, // 按件--批量设置盒号（检索）
      paramsYw: {project: {}, folder: {}, file: {}}, // 查看
      paramsYwEdit: {}, // 按件--编辑
      paramsGuaJie: {page: 1, total: 0, rows: 10}, // 挂接表格数据
      paramsGuaJieTwo: {page: 1, total: 0, rows: 10}, // 挂接表格数据
      paramsDeleteFile: {page: 1, total: 0, rows: 10}, // 删除材料

      /* 此处select类型 */
      fullZong: [], // 全宗
      FondsAndRole: [], // 类型一级
      FondsAndRoleTwo: [], // 类型二级
      FondsAndRoleThree: [], // 类型三级

      /* 此处表格 */
      tableData: [], // 上表格第一级
      tableDataBottom: [], // 下表格第一级
      tableDataDialogAJ5: [], // 批量设置盒号
      tableDataGuaJie: [], // 挂接
      tableDataGuaJieTwo: [], // 挂接
      tableDataDeleteFile: [], // 删除材料

      /* 此处表格多选选择数据 */
      tableDataTopOnce: [], // 上表格第一级
      tableDataTopOnceItem: {}, // 上表格第一级(单个数据）
      tableDataBottomOnce: [], // 下表格第一级
      tableDataGuaJieOnce: [], // 挂接
      tableDataDeleteFileOnce: [], // 删除材料

      /* 表格 */
      dialogShowLook: false,
      dialogYW1: false,
      dialogYW2: false,
      dialogYW3: false,
      dialogYW33: false,
      dialogYW4: false,
      dialogYW44: false,
      dialogYW5: false,
      dialogYW6: false,
      dialogYW7: false,
      dialogYW8: false,
      dialogYW88: false,
      dialogYW9: false,
      dialogYW10: false,
      dialogYW10Two: false,
      dialogYW11: false,
      dialogYW12: false,
      dialogYW12Two: false,
      dialogYW13: false,
      dialogYW13Two: false,
      dialogYW14: false,
      dialogYW15: false,
      dialogYW15Two: false,
      dialogYW16: false,
      dialogYW16Two: false,
      dialogYW17: false,
      dialogYW18: false,
      dialogYW19: false,
      dialogYW19Two: false,
      dialogYW20: false,
      dialogYW21: false,
      dialogYW22: false,
      dialogYW23: false,
      dialogYW24: false,
      dialogYW25: false,

      /* form判断 */
      rulesAj: {
        c18: [{required: true, message: '请填写项目编号', trigger: 'blur'}],
        titleProper: [{required: true, message: '请填写项目名称', trigger: 'blur'}],
        yearCode: [{required: true, message: '请填写起止年度', trigger: 'blur'}],
        c20: [{required: true, message: '请填写项目类型', trigger: 'blur'}],
        c22: [{required: true, message: '请填写业务类型', trigger: 'blur'}],
        c24: [{required: true, message: '请填写项目单位全称', trigger: 'blur'}],
        c10: [{required: true, message: '请填写股票代码', trigger: 'blur'}],
        c28: [{required: true, message: '请填写承做单位', trigger: 'blur'}],
        openingType: [{required: true, message: '请填写公开属性', trigger: 'change'}],
      },
      rulesAjHitch: {
        folderNo: [{required: true, message: '请填写案卷号', trigger: 'blur'}],
        titleProper: [{required: true, message: '请填写案卷题名', trigger: 'blur'}],
        openingType: [{required: true, message: '请选择公开属性', trigger: 'change'}],
      },
      rulesAjHitchTwo: {
        c220: [{required: true, message: '请选择案卷号', trigger: 'change'}],
        ownerId: [{required: true, message: '请选择案卷题名', trigger: 'blur'}],
        c72: [{required: true, message: '请填写章节号', trigger: 'blur'}],
        titleProper: [{required: true, message: '请填写文件题名', trigger: 'blur'}],
        dateOfCreation: [{required: true, message: '请填写文件日期', trigger: 'blur'}],
        yearCode: [
          {required: true, message: '请填写年度', trigger: 'blur'},
          {validator: yearCodeAudit}
        ],
        c229: [{required: true, message: '请填写页号', trigger: 'blur'}],
        openingType: [{required: true, message: '请选择公开属性', trigger: 'change'}]
      },
      rulesJb: {
        caseNo: [{required: true, message: '请选择盒号', trigger: 'change'}],
        c85: [{required: true, message: '脊背题名不能为空', trigger: 'blur'}]
      },

      /* select类型 */
      retentionPeriod: [
        {'name': '永久', 'itemValue': '3'},
        {'name': '长期', 'itemValue': '2'},
        {'name': '短期', 'itemValue': '1'},
        {'name': '10年', 'itemValue': '5'},
        {'name': '15年', 'itemValue': '6'},
        {'name': '30年', 'itemValue': '8'}
      ], // 保管期限
      c58: [{'name': '否', 'itemValue': '1'}, {'name': '是', 'itemValue': '0'}], // 是否为原件
      c59: [{'name': '否', 'itemValue': '1'}, {'name': '是', 'itemValue': '0'}], // 是否在库
      c89: [], // 拟稿人
      c90: [], // 拟稿部门
      c92: [], // 来文系统
      c100: [], // 文件类型
      c112: [], // 盖章类型
      thc5Arr: [], // 状态
      openingType: [
        {'name': '内部', 'itemValue': '2'},
        {'name': '公开', 'itemValue': '1'},
        {'name': '受控', 'itemValue': '3'},
        {'name': '广发商密三级', 'itemValue': '4'},
        {'name': '广发商密二级', 'itemValue': '5'},
        {'name': '广发商密一级', 'itemValue': '6'}
      ], // 公开属性
      filingDept: [], // 归档部门
      yjc89Arr: [], // 拟稿人--检索
      c220Arr: [], // 案卷号
      ownerIdArr: [], // 案卷题名
      scopeArr: [
        {id: 3, text: '3cm'},
        {id: 5, text: '5cm'}
      ], // 打印脊背--尺寸
      caseNoArr: [], // 文件层--盒号

      /* 单个数据 */
      imgVal: [],
      embedOnce: '',
      yeWuActiveName: '案卷层',
      yeWuActiveNameShowLook: '基本信息',
      lookCheck: 1, // 查看基本信息
      showDianZiShu: false, // 查看-右侧是否有电子书
      downLoadId: null, // 查看-左侧是否下载
      fileErrorMsg: '', // 导入错误msg
      showHitch: '', // 是否挂接

      /* tree数据 */
      treTable: [],
      treTableContent: {},
      defaultProps: {
        children: 'children',
        label: 'text'
      }
    }
  },
  methods: {
    // 获取上表格第一级数据
    showList (val) {
      this.tableData = []
      // val.c5 = 2
      if (this.params.series2) {
        listThArchiveZL(val).then(res => {
          if (res.data.rows.length <= 0) {
            this.$message.error('该条件下查无数据！')
            this.tableData = []
          } else {
            this.tableData = res.data.rows
            this.params.total = res.data.total
            this.tableData.forEach(item => {
              item.checkOnce = false
            })
          }
          this.dialogYW2 = false
        })
      }
      // this.$forceUpdate()
    },
    // 上表格多选
    handleSelectionChange (val, item) {
      item.checkOnce = !item.checkOnce
      this.tableDataTopOnce = val
      this.tableDataTopOnceItem = item
      // this.tableDataTopOnceItem = {}
      if (!item.checkOnce) {
        this.tableDataBottom = []
        this.paramsBottom = {page: 1, rows: 5, total: 0}
        this.paramsBottomTwo = {page: 1, rows: 5, total: 0}
      }
      if (this.tableDataTopOnce.length > 0) {
        if (item.checkOnce) {
          if (this.yeWuActiveName == '案卷层') {
            this.paramsBottom.page = 1
            this.showListBottom(this.paramsBottom)
          } else if (this.yeWuActiveName == '文件层') {
            this.paramsBottomTwo.page = 1
            this.showListBottom(this.paramsBottomTwo)
          }
        }
      }
      if (this.tableDataTopOnce.length > 1 && this.tableDataTopOnce.length <= 2) {
        this.$refs.multipleTable.toggleRowSelection(this.tableDataTopOnce[0])
      }
      if (item.c5 == 2) {
        this.showHitch = true
      } else {
        this.showHitch = false
      }
      val.forEach(items => {
        if (items.checkOnce) {
          this.tableDataTopOnceItem = items
        }
      })
    },
    handleSelectionChangeAll (val) {
      if (val.length > 0) {
        for (let i of this.tableData) {
          // i.checkOnce = !i.checkOnce
          i.checkOnce = true
        }
      } else {
        for (let i of this.tableData) {
          // i.checkOnce = !i.checkOnce
          i.checkOnce = false
        }
      }
      this.tableDataTopOnce = val
      // for (let i in this.tableDataTopOnce) {
      //   if (!this.tableDataTopOnce[i].checkOnce) {
      //     this.tableDataTopOnce[i].checkOnce = true
      //   }
      // }
      if (this.tableDataTopOnce.length > 1 && this.tableDataTopOnce.length <= 2) {
        this.$refs.multipleTable.toggleRowSelection(this.tableDataTopOnce[0])
      }
      if (this.tableDataTopOnceItem.c5 == 2) {
        this.showHitch = true
      } else {
        this.showHitch = false
      }
    },
    // 上表格行内点击
    handleSelectionClick (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTable.toggleRowSelection(item, true)
        item.checkOnce = true
        /*if (this.yeWuActiveName == '案卷层') {
          this.paramsBottom.page = 1
          this.showListBottom(this.paramsBottom)
        } else if (this.yeWuActiveName == '文件层') {
          this.paramsBottomTwo.page = 1
          this.showListBottom(this.paramsBottomTwo)
        }*/
      } else {
        this.$refs.multipleTable.toggleRowSelection(item, false)
        item.checkOnce = false
        this.showHitch = false
        this.tableDataTopOnceItem = {}
        this.tableDataTopOnce = []
        this.tableDataBottom = []
        this.paramsBottom.page = 1
        this.paramsBottom.total = 1
        this.paramsBottomTwo.page = 1
        this.paramsBottomTwo.total = 1
      }
      if (this.tableDataTopOnce.length > 1 && this.tableDataTopOnce.length <= 2) {
        this.$refs.multipleTable.toggleRowSelection(this.tableDataTopOnce[0])
      }
      if (this.tableDataTopOnceItem.c5 == 2) {
        this.showHitch = true
      } else {
        this.showHitch = false
      }
    },
    // 上表格分页点击
    handleCurrentChange (val) {
      this.params.page = val
      this.showList(this.params)
    },
    // 下表格第一级数据
    showListBottom (val) {
      this.tableDataBottomOnce = []
      if (this.params.series2) {
        if (this.yeWuActiveName == '案卷层') {
          // this.paramsBottom.subId = this.tableDataTopOnceItem.id
          val.subId = this.tableDataTopOnceItem.id
          listThFolderData(val).then(res => {
            this.tableDataBottom = res.data.rows
            this.paramsBottom.total = res.data.total
          })
        } else if (this.yeWuActiveName == '文件层') {
          // this.paramsBottomTwo.projectId = this.tableDataTopOnceItem.id
          val.projectId = this.tableDataTopOnceItem.id
          listTouHangFileData(val).then(res => {
            this.tableDataBottom = res.data.rows
            this.paramsBottomTwo.total = res.data.total
          })
        }
      }
    },
    // 下表格多选
    handleSelectionChangeBottom (val, item) {
      this.tableDataBottomOnce = []
      item.checkOnce = !item.checkOnce
      this.tableDataBottomOnce = val
      // if (this.tableDataBottomOnce.length > 1 && this.tableDataBottomOnce.length <= 2) {
      //   this.$refs.multipleTableBottom.toggleRowSelection(this.tableDataBottomOnce[0])
      // }
    },
    handleSelectionChangeBottomAll (val) {
      this.tableDataBottomOnce = []
      this.tableDataBottomOnce = val
      for (let i in this.tableDataBottomOnce) {
        if (!this.tableDataBottomOnce[i].checkOnce) {
          this.tableDataBottomOnce[i].checkOnce = true
        }
      }
      // if (this.tableDataBottomOnce.length > 1 && this.tableDataBottomOnce.length <= 2) {
      //   this.$refs.multipleTableBottom.toggleRowSelection(this.tableDataBottomOnce[0])
      // }
    },
    // 下表格行内点击
    handleSelectionClickBottom (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTableBottom.toggleRowSelection(item, true)
        item.checkOnce = true
      } else {
        this.$refs.multipleTableBottom.toggleRowSelection(item, false)
        item.checkOnce = false
        this.tableDataBottomOnce = []
      }
    },
    // 下表格（文件层）多选
    handleSelectionChangeBottomTwo (val, item) {
      item.checkOnce = !item.checkOnce
      this.tableDataBottomOnce = val
      // if (this.tableDataBottomOnce.length > 1 && this.tableDataBottomOnce.length <= 2) {
      //   this.$refs.multipleTableBottomRight.toggleRowSelection(this.tableDataBottomOnce[0])
      // }
    },
    handleSelectionChangeBottomAllTwo (val) {
      this.tableDataBottomOnce = val
      for (let i in this.tableDataBottomOnce) {
        if (!this.tableDataBottomOnce[i].checkOnce) {
          this.tableDataBottomOnce[i].checkOnce = true
        }
      }
      // if (this.tableDataBottomOnce.length > 1 && this.tableDataBottomOnce.length <= 2) {
      //   this.$refs.multipleTableBottomRight.toggleRowSelection(this.tableDataBottomOnce[0])
      // }
    },
    // 下表格行内点击
    handleSelectionClickBottomTwo (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTableBottomRight.toggleRowSelection(item, true)
        item.checkOnce = true
      } else {
        this.$refs.multipleTableBottomRight.clearSelection(item, false)
        item.checkOnce = false
        this.tableDataBottomOnce = []
      }
    },
    // 下表格分页点击
    handleCurrentChangeBottom (val) {
      this.paramsBottom.page = val
      this.showListBottom(this.paramsBottom)
    },
    handleCurrentChangeBottomTwo (val) {
      this.paramsBottomTwo.page = val
      this.showListBottom(this.paramsBottomTwo)
    },

    // 上表格--查看
    dateShowLookLook (val) {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        let params = {
          type: 'p',
          bs: 'th',
          id: this.tableDataTopOnceItem.id
        }
        this.lookRightContentOne(params)
        this.lookCheck = val
      }
    },
    // 查看-树形菜单
    handleNodeClick (val, item) {
      if (val.attributes.type == 'p') {
        this.lookCheck = 1
        let paramsTwo = {
          type: val.attributes.type,
          id: val.id
        }
        this.lookRightContentTwo(paramsTwo)
      } else if (val.attributes.type == 'v') {
        this.lookCheck = 2
        let paramsTwo = {
          type: val.attributes.type,
          id: val.id,
          resourceParentId: val.id
        }
        this.lookRightContentTwo(paramsTwo)
        listTreeJsonByTh({
          type: val.attributes.type,
          id: val.id,
          bs: 'th',
          resourceParentId: val.id
        }).then(res => {
          if (res.code == 500) {
            this.$message.error(res.message)
          } else {
            if (res.data.length >= 1) {
              val.children = res.data
            } else {
              this.$message.error(res.data.message)
            }
          }
        })
      } else if (val.attributes.type == 'f') {
        this.lookCheck = 3
        let paramsTwo = {
          type: val.attributes.type,
          id: val.id,
          resourceParentId: val.id
        }
        this.lookRightContentTwo(paramsTwo)
      }
      this.showDianZiShu = false
      this.yeWuActiveNameShowLook = '基本信息'
      this.judgeShow(val)
    },
    // 获取查看--左，右侧数据
    lookRightContentOne (val) {
      this.paramsYw = {project: {}, folder: {}, file: {}}
      listTreeJsonByTh(val).then(res => {
        this.dialogShowLook = true
        this.treTable = res.data
        let paramsTwo = {
          type: res.data[0].attributes.type,
          id: this.tableDataTopOnceItem.id
        }
        this.lookRightContentTwo(paramsTwo)
        this.showDianZiShu = false
        this.yeWuActiveNameShowLook = '基本信息'
        this.judgeShow(res.data[0])
      })
    },
    lookRightContentTwo (val) {
      this.paramsYw = {project: {}, folder: {}, file: {}}
      viewByTh(val).then(res => {
        this.paramsYw = res.data
      })
    },
    // 判断是否有电子文书
    judgeShow (val) {
      this.showDianZiShu = false
      if (val.attributes.docType) {
        if (val.attributes.docType == 'd') {
          powerDocViewUtil({id: val.attributes.docId}).then(res => {
            if (res.code == 500) {
              this.$message.error(res.message)
            } else {
              if (res.data.optFlag == 0) {
                this.embedOnce = `${BASICURL}/gdda-new/gdda/util/filepreview/viewRangeFile?fileId=${val.attributes.docId}`
                this.showDianZiShu = true
                this.yeWuActiveNameShowLook = '电子全文'
              } else if (res.data.optFlag == 2) {
                this.dialogYW1 = true
                this.downLoadId = val.attributes.docId
              } else {
                this.$message.info('对不起，未找到您需要查看的文件')
                this.lookCheck = 4
              }
            }
          })
        }
      }
    },
    yeWuDownLoad1 () {
      valueIndex().exportFiles('/gdda-new/gdda/util/downLoadFile', {id: this.downLoadId, mode: 'th'}, '虚拟机密码.txt', 'get')
      this.dialogYW1 = false
    },

    yeWuTabsClick (item, val) {
      this.tableDataBottomOnce = []
      this.paramsBottom.page = 1
      this.paramsBottomTwo.page = 1
      if (this.yeWuActiveName == '案卷层') {
        this.paramsBottom.subId = this.tableDataTopOnceItem.id
        this.showListBottom(this.paramsBottom)
      } else if  (this.yeWuActiveName == '文件层') {
        this.paramsBottomTwo.projectId = this.tableDataTopOnceItem.id
        this.showListBottom(this.paramsBottomTwo)
      }
    },
    yeWuTabsShowLookClick (item, val) {
      console.log(item.name);
      console.log(this.yeWuActiveNameShowLook);
    },
    handleCloseOne () {
      this.dialogShowLook = false
      this.dialogYW2 = false
      this.dialogYW3 = false
      this.dialogYW4 = false
      this.dialogYW5 = false
      this.dialogYW6 = false
      this.dialogYW7 = false
      this.dialogYW8 = false
      this.dialogYW9 = false
      this.dialogYW10 = false
      this.dialogYW11 = false
      this.dialogYW12 = false
      this.dialogYW13 = false
      this.dialogYW14 = false
      this.dialogYW15 = false
      this.dialogYW16 = false
      this.dialogYW17 = false
      this.dialogYW18 = false
      this.dialogYW19 = false
      this.dialogYW20 = false
      this.dialogYW21 = false
      this.dialogYW22 = false
      this.dialogYW23 = false
      this.dialogYW24 = false
      this.dialogYW25 = false
    },
    handleCloseTwo () {
      this.dialogYW1 = false
      this.dialogYW33 = false
      this.dialogYW44 = false
      this.dialogYW88 = false
      this.dialogYW10Two = false
      this.dialogYW12Two = false
      this.dialogYW13Two = false
      this.dialogYW15Two = false
      this.dialogYW16Two = false
      this.dialogYW19Two = false
    },
    selectType () {
      listDept().then(res => {
        this.c90 = res.data
      })
      listAllDept().then(res => {
        this.filingDept = res.data
      })
      listFileType().then(res => {
        this.c100 = res.data
      })
      listGzdj().then(res => {
        this.c112 = res.data
      })
      listLwxt().then(res => {
        this.c92 = res.data
      })
      listThStatus().then(res => {
        this.thc5Arr = res.data
      })
    },
    // 下表格--查看
    /* 新 */
    dateShowLookLookTwo (val) {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        // console.log(this.tableDataBottomOnce[0]);
        this.paramsYw = {project: {}, folder: {}, file: {}}
        let params = {
          type: 'p',
          bs: 'jijian',
          id: this.tableDataTopOnceItem.id
        }
        listTreeJsonByTh(params).then(res => {
          this.dialogShowLook = true
          this.treTable = res.data
          this.lookCheck = val
          let params = {
            type: 'v',
            id: this.tableDataBottomOnce[0].id,
            bs: 'jijian',
            resourceParentId: this.tableDataBottomOnce[0].id
          }
          listTreeJsonByTh(params).then(res => {
            if (res.data.length >= 1) {
              this.treTable.forEach(item => {
                item.children.forEach(itemTwo => {
                  if (itemTwo.id == this.tableDataBottomOnce[0].id) {
                    itemTwo.children = res.data
                    this.handleNodeClick(itemTwo)
                    // this.treeArr.push(Number(itemTwo.id))
                    // this.$nextTick(() => {
                    //   this.$refs.lookDataTree.setCheckedKeys(this.treeArr)
                    // })
                  }
                })
              })
            }
          })
          /*let arrOnce = {}
          let arrOnceTroops = null
          this.treTable.forEach(item => {
            item.children.forEach((items, index) => {
              if (items.id == this.tableDataBottomOnce[0].id) {
                arrOnce = items
                // arrOnceTroops.push(items)
                arrOnceTroops = index
              }
            })
          })
          // console.log(this.tableDataBottomOnce)
          let paramsTwo = {
            type: arrOnce.attributes.type,
            id: arrOnce.attributes.id
          }
          let paramsThree = {
            type: arrOnce.attributes.type,
            id: arrOnce.attributes.id,
            resourceParentId: arrOnce.attributes.id,
            bs: 'th'
          }
          listTreeJsonByTh(paramsThree).then(res => {
            // document.getElementsByClassName('el-tree-node.is-current el-tree-node__content')[arrOnceTroops + 1].style.backgroundColor = '#999999'
            // 某行高亮 为写出来。（暂时推后）
            if (res.code == 500) {
              this.$message.error(res.message)
            } else {
              arrOnce.children = res.data
              this.showDianZiShu = false
              this.yeWuActiveNameShowLook = '基本信息'
              this.judgeShow(res.data[0])
            }
            this.lookRightContentTwo(paramsTwo)
          })*/
        })
      }
    },
    dateShowLookLookTwoRight (val) {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        // console.log(this.tableDataBottomOnce[0]);
        this.paramsYw = {project: {}, folder: {}, file: {}}
        let params = {
          type: 'p',
          bs: 'th',
          id: this.tableDataTopOnceItem.id
        }
        listTreeJsonByTh(params).then(res => {
          this.dialogShowLook = true
          this.treTable = res.data
          this.lookCheck = val
          let params = {
            type: 'v',
            id: this.tableDataBottomOnce[0].ownerId,
            bs: 'jijian',
            resourceParentId: this.tableDataBottomOnce[0].ownerId
          }
          listTreeJsonByTh(params).then(res => {
            if (res.data.length >= 1) {
              this.treTable.forEach(item => {
                item.children.forEach(itemTwo => {
                  if (itemTwo.id == this.tableDataBottomOnce[0].ownerId) {
                    itemTwo.children = res.data
                    let params = {
                      type: 'f',
                      id: this.tableDataBottomOnce[0].id,
                      bs: 'jijian',
                      resourceParentId: this.tableDataBottomOnce[0].id
                    }
                    listTreeJsonByTh(params).then(res => {
                      itemTwo.children.forEach(itemThree => {
                        if (itemThree.id == this.tableDataBottomOnce[0].id) {
                          itemThree.children = res.data
                          this.handleNodeClick(itemThree)
                        }
                      })
                    })
                    // itemTwo.children = res.data
                    // this.handleNodeClick(itemTwo)
                    // this.treeArr.push(Number(itemTwo.id))
                    // this.$nextTick(() => {
                    //   this.$refs.lookDataTree.setCheckedKeys(this.treeArr)
                    // })
                  }
                })
              })
            }
          })
          /*let arrOnce = {}
          let arrOnceTroops = null
          this.treTable.forEach(item => {
            item.children.forEach((items, index) => {
              if (items.id == this.tableDataBottomOnce[0].ownerId) {
                arrOnce = items
                // arrOnceTroops.push(items)
                arrOnceTroops = index
              }
            })
          })
          let paramsTwo = {
            type: arrOnce.attributes.type,
            id: arrOnce.attributes.id
          }
          let paramsThree = {
            type: arrOnce.attributes.type,
            id: arrOnce.attributes.id,
            resourceParentId: arrOnce.attributes.id,
            bs: 'th'
          }
          listTreeJsonByTh(paramsThree).then(res => {
            // document.getElementsByClassName('el-tree-node.is-current el-tree-node__content')[arrOnceTroops + 1].style.backgroundColor = '#999999'
            // 某行高亮 为写出来。（暂时推后）
            if (res.code == 500) {
              this.$message.error(res.message)
            } else {
              arrOnce.children = res.data
              this.showDianZiShu = false
              this.yeWuActiveNameShowLook = '基本信息'
              this.judgeShow(res.data[0])
            }
            this.lookRightContentTwo(paramsTwo)
          })*/
        })
      }
    },
    /* 旧 */
    /*dateShowLookLookTwo (val) {
      // console.log(this.tableDataBottomOnce[0]);
      this.paramsYw = {project: {}, folder: {}, file: {}}
      let params = {
        type: 'p',
        bs: 'th',
        id: this.tableDataTopOnceItem.id
      }
      listTreeJsonByTh(params).then(res => {
        this.dialogShowLook = true
        this.treTable = res.data
        this.lookCheck = val
        /!*let arrOnce = {}
        let arrOnceTroops = null
        this.treTable.forEach(item => {
          item.children.forEach((items, index) => {
            if (items.id == this.tableDataBottomOnce[0].id) {
              arrOnce = items
              // arrOnceTroops.push(items)
              arrOnceTroops = index
            }
          })
        })
        console.log(this.tableDataBottomOnce);
        let paramsTwo = {
          type: arrOnce.attributes.type,
          id: arrOnce.attributes.id
        }
        let paramsThree = {
          type: arrOnce.attributes.type,
          id: arrOnce.attributes.id,
          resourceParentId: arrOnce.attributes.id,
          bs: 'th'
        }
        listTreeJsonByTh(paramsThree).then(res => {
          // document.getElementsByClassName('el-tree-node.is-current el-tree-node__content')[arrOnceTroops + 1].style.backgroundColor = '#999999'
          // 某行高亮 为写出来。（暂时推后）
          if (res.code == 500) {
            this.$message.error(res.message)
          } else {
            arrOnce.children = res.data
            this.showDianZiShu = false
            this.yeWuActiveNameShowLook = '基本信息'
            this.judgeShow(res.data[0])
          }
          this.lookRightContentTwo(paramsTwo)
        })*!/
      })
    },*/
    /*dateShowLookLookTwoRight (val){
      // console.log(this.tableDataBottomOnce[0]);
      this.paramsYw = {project: {}, folder: {}, file: {}}
      let params = {
        type: 'p',
        bs: 'th',
        id: this.tableDataTopOnceItem.id
      }
      listTreeJsonByTh(params).then(res => {
        this.dialogShowLook = true
        this.treTable = res.data
        this.lookCheck = val
        /!*let arrOnce = {}
        let arrOnceTroops = null
        this.treTable.forEach(item => {
          item.children.forEach((items, index) => {
            if (items.id == this.tableDataBottomOnce[0].ownerId) {
              arrOnce = items
              // arrOnceTroops.push(items)
              arrOnceTroops = index
            }
          })
        })
        let paramsTwo = {
          type: arrOnce.attributes.type,
          id: arrOnce.attributes.id
        }
        let paramsThree = {
          type: arrOnce.attributes.type,
          id: arrOnce.attributes.id,
          resourceParentId: arrOnce.attributes.id,
          bs: 'th'
        }
        listTreeJsonByTh(paramsThree).then(res => {
          // document.getElementsByClassName('el-tree-node.is-current el-tree-node__content')[arrOnceTroops + 1].style.backgroundColor = '#999999'
          // 某行高亮 为写出来。（暂时推后）
          if (res.code == 500) {
            this.$message.error(res.message)
          } else {
            arrOnce.children = res.data
            this.showDianZiShu = false
            this.yeWuActiveNameShowLook = '基本信息'
            this.judgeShow(res.data[0])
          }
          this.lookRightContentTwo(paramsTwo)
        })*!/
      })
    },*/

    // 检索
    searchContent () {
      this.params = {
        page: 1,
        c5: 2,
        total: 0,
        searchType: 1,
        rows: 10,
        fonds: this.params.fonds,
        series1: this.params.series1,
        series2: this.params.series2,
        series3: this.params.series3,
        thseriesCode: '',
        thfilingDept: '',
        thc18: '',
        thyearCode: '',
        thc10: '',
        thc24: '',
        thtitleProper: '',
        thc20: '',
        thc22: '',
        thc28: '',
        thc5: '',
      }
      this.resetSearch()
      this.dialogYW2 = true
    },

    // 添加项目
    addProjectContent () {
      this.paramsYwEdit = {}
      getInitJjProject({archiveTreeNodeId: this.methodSeries()}).then(res => {
        this.paramsYwEdit = res.data
        if (this.paramsYwEdit.seriesCode == 'H1') {
          this.paramsYwEdit.retentionPeriod = '2'
        }
        this.dialogYW3 = true
        // this.clearFiles('ruleFormYwAddProject')
        this.clearFiles('ruleFormYwAddProjectOne')
      })
    },
    addProjectContentBtn () {
      this.$refs.ruleFormYwAddProjectOne.validate((valid) => {
        if (valid) {
          this.dialogYW33 = true
        }
      })
    },
    addProjectContentBtn33 () {
      this.paramsYwEdit.series2 = this.params.series2
      this.paramsYwEdit.fonds = this.params.fonds
      saveThProject(this.paramsYwEdit).then(res => {
        if (res.code == 0) {
          this.dialogYW3 = false
          this.dialogYW33 = false
          this.$message.success(res.message)
          this.resetSearch()
          this.showList(this.params)
        } else {
          this.$message.error(res.message)
        }
      })
    },
    // 修改项目
    editProjectContent () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.paramsYwEdit = {}
        getThProject({id: this.tableDataTopOnceItem.id}).then(res => {
          this.paramsYwEdit = res.data
          console.log(this.paramsYwEdit);
          this.dialogYW4 = true
          this.clearFiles('ruleFormYwEditProject')
        })
      }
    },
    editProjectContentBtn () {
      this.$refs.ruleFormYwEditProject.validate((valid) => {
        if (valid) {
          this.dialogYW44 = true
        }
      })
    },
    editProjectContentBtn44 () {
      this.paramsYwEdit.subId = this.tableDataTopOnceItem.id
      updateThProject(this.paramsYwEdit).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.resetSearch()
          this.showList(this.params)
          this.dialogYW4 = false
          this.dialogYW44 = false
        } else {
          this.$message.error(res.message)
        }
      })

    },

    // 删除
    deleteBtn5 () {
      let item = this.$onceWay().onceTableListTwo(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogYW5 = true
      }
    },
    deleteBtn55 () {
      deleteThProject({id: this.tableDataTopOnceItem.id, bs: 'th'}).then(res => {
        if (res.code == 500) {
          this.$message.error('接口出现问题')
        } else {
          if (res.data.optFlag == 0) {
            this.$message.success('删除成功')
            this.dialogYW5 = false
            this.resetSearch()
            this.showList(this.params)
          } else if (res.data.optFlag == -1) {
            this.$message.error('删除失败')
            this.dialogYW5 = false
            this.resetSearch()
            this.showList(this.params)
          } else if (res.data.optFlag == -2) {
            this.$message.error('该项目非导入数据，不能删除！')
            this.dialogYW5 = false
            this.resetSearch()
            this.showList(this.params)
          }
        }
      })
    },

    // 整理
    clearUpBtn6 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogYW6 = true
      }
    },
    clearUpBtn66 () {
      zLingThProject({id: this.tableDataTopOnceItem.id}).then(res => {
        console.log(res);
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogYW6 = false
          this.resetSearch()
          this.showList(this.params)
        } else {
          this.$message.error(res.message)
          this.dialogYW6 = false
          this.resetSearch()
          this.showList(this.params)
        }
      })
    },

    // 下载Excel模板
    FileDownload7 () {
      this.dialogYW7 = true
    },
    FileDownload77 () {
      let ids = {status: 'thdg'}
      let title = ''
      if (this.params.series2 == 1388742017297) {
        title = '投行底稿项目模板.xls'
      } else if (this.params.series2 == 1388742017298) {
        title = '债券业务项目模板.xls'
      } else if (this.params.series2 == 1388742017299) {
        title = '资产管理项目模板.xls'
      } else if (this.params.series2 == 1388742017300) {
        title = '其他项目模板.xls'
      } else if (this.params.series2 == 1567990648891) {
        title = '资产托管项目模板.xls'
      }
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/downloadExcel', ids, title, 'get')
      this.dialogYW7 = false
    },
    // 导入Excel
    FileAddBtn8 () {
      this.dialogYW8 = true
      this.clearFilesTwo('ywFileAddOne')
      this.imgVal = []
      // console.log(2);
    },
    handleChange (file, fileList) {
      if (this.imgVal.length >= 1) {
        this.$message.error('只能上传一个文件')
      } else {
        let formData = new FormData()
        formData.append('picture', file.raw)
        formData.append('name', 'file')
        if (this.dialogYW21) {
          formData.append('type', 'thZlFile')
        } else {
          formData.append('type', 'map')
        }
        uploadExcelH5(formData).then(res => {
          if (res.code == 0) {
            this.imgVal.push(res.data.msg)
          } else {
            this.$message.error(res.message)
          }
        })
      }
    },
    handleChangeTwo (file, fileList) {
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('type', 'jjZl')
      formData.append('name', 'file')
      uploadPicture(formData).then(res => {
        if (res.code == 0) {
          this.imgVal.push(res.data.pathAndMD5)
        } else {
          this.$message.error(res.message)
        }
      })
    },
    // 删除上传
    handleRemove (val, item) {
      this.imgVal.splice(val, 1)
    },
    FileAddBtn88 () {
      if (this.imgVal.length < 1) {
        this.$message.error('请选择上传文件')
      } else {
        let params = {
          series2: this.params.series2,
          fonds: this.params.fonds,
          imgVal: this.imgVal
        }
        uploadThExcel(params).then(res => {
          if (res.code == 0) {
            this.$message.success(res.data.msg)
            this.dialogYW8 = false
            this.resetSearch()
            this.showList(this.params)
          } else {
            this.dialogYW88 = true
            this.fileErrorMsg = res.data.msg
          }
        })
      }
    },
    // 导出错误信息
    FileErrorBtn88 () {
      let ids = {excelId: this.fileErrorMsg}
      if (this.dialogYW88) {
        // let ids = {excelId: this.fileErrorMsg}
        valueIndex().exportFiles('/gdda-new/gdda/archiveZL/exportError', ids, '错误信息.xls', 'get')
        this.dialogYW88 = false
        this.dialogYW8 = false
      } else if (this.dialogYW9) {
        valueIndex().exportFiles('/gdda-new/gdda/archiveZL/exportThQualityError', ids, '质检结果.xls', 'get')
        this.dialogYW88 = false
        this.dialogYW9 = false
        this.showHitch = false
      }
    },
    // 质检
    FileAddBtn9 () {
      this.imgVal = []
      this.dialogYW9 = true
      this.clearFilesTwo('ywFileAddTwo')
    },
    FileAddBtn99 () {
      if (this.imgVal.length < 1) {
        this.$message.error('请选择上传文件')
      } else {
        thQuality({subId: this.tableDataTopOnceItem.id, imgVal: this.imgVal}).then(res => {
          if (res.data.optFlag == 0) {
            this.$message.success('质检通过')
            this.dialogYW9 = false
            this.resetSearch()
            this.showList(this.params)
            this.showHitch = false
          } else if (res.data.optFlag == -1) {
            this.dialogYW88 = true
            this.fileErrorMsg = res.data.msg
          } else if (res.data.optFlag == -2) {
            this.$message.error('质检失败')
            this.dialogYW9 = false
            this.resetSearch()
            this.showList(this.params)
            this.showHitch = false
          }
        })
      }
    },

    // 查看挂接
    FileAddBtn10 () {
      this.paramsGuaJie.page = 1
      this.paramsGuaJie.total = 0
      listThHangingData(this.paramsGuaJie).then(res => {
        this.tableDataGuaJie = res.data.rows
        this.paramsGuaJie.total = res.data.total
        this.dialogYW10 = true
      })
    },
    // 挂接
    handleSelectionChangeGuaJie (val, item) {
      item.checkOnce = !item.checkOnce
      this.tableDataGuaJieOnce = val
      if (this.tableDataGuaJieOnce.length > 1 && this.tableDataGuaJieOnce.length <= 2) {
        this.$refs.multipleTableGuaJie.toggleRowSelection(this.tableDataGuaJieOnce[0])
      }
    },
    handleSelectionChangeAllGuaJie (val) {
      this.tableDataGuaJieOnce = val
      for (let i in this.tableDataGuaJieOnce) {
        if (!this.tableDataGuaJieOnce[i].checkOnce) {
          this.tableDataGuaJieOnce[i].checkOnce = true
        }
      }
      if (this.tableDataGuaJieOnce.length > 1 && this.tableDataGuaJieOnce.length <= 2) {
        this.$refs.multipleTableGuaJie.toggleRowSelection(this.tableDataGuaJieOnce[0])
      }
    },
    // 挂接表格行内点击
    handleSelectionClickGuaJie (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTableGuaJie.toggleRowSelection(item)
        item.checkOnce = true
      } else {
        this.$refs.multipleTableGuaJie.clearSelection()
        item.checkOnce = false
      }
    },
    // 第一级分页点击
    handleCurrentChangeGuaJie (val) {
      this.paramsGuaJie.page = val
      listThHangingData(this.paramsGuaJie).then(res => {
        this.tableDataGuaJie = res.data.rows
        this.paramsGuaJie.total = res.data.total
        // this.dialogYW10 = true
      })
    },
    // 第二级表格数据
    showHitchTab () {
      this.paramsGuaJieTwo.hangingDate = this.tableDataGuaJieOnce[0].hangingDate
      this.paramsGuaJieTwo.createDate = this.tableDataGuaJieOnce[0].createDate
      this.paramsGuaJieTwo.page = 1
      listThHangingDataiData(this.paramsGuaJieTwo).then(res => {
        this.tableDataGuaJieTwo = res.data.rows
        this.paramsGuaJieTwo.total = res.data.total
        this.dialogYW10Two = true
      })
    },
    // 第二级分页点击
    handleCurrentChangeGuaJieTwo (val) {
      this.paramsGuaJieTwo.page = val
      listThHangingDataiData(this.paramsGuaJieTwo).then(res => {
        this.tableDataGuaJieTwo = res.data.rows
        this.paramsGuaJieTwo.total = res.data.total
      })
    },
    // 删除材料分页点击
    handleCurrentChangeDeleteFile (val) {
      this.paramsDeleteFile.page = val
      // this.paramsDeleteFile.total = 0
      // this.fileDelete19(this.paramsDeleteFile)
      listThDocData(this.paramsDeleteFile).then(res => {
        this.tableDataDeleteFile = res.data.rows
        this.paramsDeleteFile.total = res.data.total
        this.dialogYW19 = true
      })
      // listThHangingData(this.paramsDeleteFile).then(res => {
      //   this.tableDataDeleteFile = res.data.rows
      //   this.paramsDeleteFile.total = res.data.total
      //   // this.dialogYW10 = true
      // })
    },

    // 保存
    saveAddBtn11 () {
      this.dialogYW11 = true
    },
    saveAddBtn101 () {
      saveWrk({proId: this.tableDataTopOnceItem.id}).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 1) {
            this.$message.success('保存成功')
            this.dialogYW11 = false
            this.resetSearch()
            this.showList(this.params)
          } else if (res.data.optFlag == -1) {
            this.$message.error('保存失败')
            this.dialogYW11 = false
            this.resetSearch()
            this.showList(this.params)
          } else if (res.data.optFlag == -2) {
            this.$message.error('保存失败，项目下案卷或案内目录为空')
            this.dialogYW11 = false
            this.resetSearch()
            this.showList(this.params)
          }
        } else {
          this.$message.error('接口异常')
          this.dialogYW11 = false
          this.resetSearch()
          this.showList(this.params)
        }
        this.showHitch = false
      })
    },

    // 案卷层---添加案卷
    addBottomContent () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.paramsYwEdit = {}
        this.clearFiles('ruleFormYwAddProject')
        getInitJjFolder({subId: this.tableDataTopOnce[0].id}).then(res => {
          this.paramsYwEdit = res.data
          this.dialogYW12 = true
          this.paramsYwEdit.c19 = '档案中心'
        })
      }
    },
    addProjectContentBtn12 () {
      this.$refs.ruleFormYwAddProject.validate((valid) => {
        if (valid) {
          this.dialogYW12Two = true
        }
      })
    },
    addProjectContentBtn12Two () {
      this.paramsYwEdit.subId = this.tableDataTopOnce[0].id
      saveThFolder(this.paramsYwEdit).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogYW12 = false
          this.dialogYW12Two = false
          this.paramsBottom.page = 1
          this.paramsBottom.total = 0
          this.showListBottom(this.paramsBottom)
        } else {
          this.$message.error(res.message)
          this.dialogYW12 = false
          this.dialogYW12Two = false
          this.paramsBottom.page = 1
          this.paramsBottom.total = 0
          this.showListBottom(this.paramsBottom)
        }
      })
    },

    // 案卷层--修改案卷
    editBottomContent () {
      console.log(this.tableDataBottomOnce);
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.clearFiles('ruleFormYwEditProject')
        getJjFolder({id: this.tableDataBottomOnce[0].id}).then(res => {
          this.paramsYwEdit = res.data
          this.dialogYW13 = true
        })
      }
    },
    editBottomContent13 () {
      this.$refs.ruleFormYwEditProject.validate((valid) => {
        if (valid) {
          this.dialogYW13Two = true
        }
      })
    },
    editBottomContent13Two () {
      this.paramsYwEdit.subId = this.tableDataBottomOnce[0].id
      updateThFolder(this.paramsYwEdit).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogYW13 = false
          this.dialogYW13Two = false
          this.paramsBottom.page = 1
          this.paramsBottom.total = 0
          this.showListBottom(this.paramsBottom)
        } else {
          this.$message.error(res.message)
          this.dialogYW13 = false
          this.dialogYW13Two = false
          this.paramsBottom.page = 1
          this.paramsBottom.total = 0
          this.showListBottom(this.paramsBottom)
        }
      })
    },

    // 案卷层--删除
    deleteContent14 () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.dialogYW14 = true
      }
    },
    deleteContent14Two () {
      let params = {
        bs: 'th',
        id: this.tableDataBottomOnce[0].id
      }
      deleteThFolder(params).then(res => {
        if (res.code == 500) {
          this.$message.error(res.data.message)
          this.dialogYW14 = false
        } else {
          if (res.data.optFlag == 0) {
            this.$message.success('删除成功')
            this.dialogYW14 = false
            this.paramsBottom.page = 1
            this.paramsBottom.total = 0
            this.showListBottom(this.paramsBottom)
          } else if (res.data.optFlag == -1) {
            this.$message.error('删除失败')
            this.dialogYW14 = false
          } else if (res.data.optFlag == -2) {
            this.$message.error('该案卷非导入数据，不能删除！')
            this.dialogYW14 = false
          }
        }
      })
    },

    // 文件层--添加案卷
    addBottomContent15 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.paramsYwEdit = {}
        this.clearFiles('ruleFormYwAddProjectTwo')
        getInitJjFile({subId: this.tableDataTopOnceItem.id}).then(res => {
          this.paramsYwEdit = res.data
          this.dialogYW15 = true
        })
        listThFolderById({id: this.tableDataTopOnceItem.id}).then(res => {
          this.c220Arr = res.data
        })
      }
    },
    c220ArrChange (val) {
      this.paramsYwEdit.ownerId = ''
      listJjFolderByIdAndNo({id: this.tableDataTopOnceItem.id, folderNo: val}).then(res => {
        this.ownerIdArr = res.data
      })
    },
    ownerIdArrChange (val) {
      this.paramsYwEdit.ownerId = val
      this.$forceUpdate()
    },
    addProjectContentBtn15 () {
      this.$refs.ruleFormYwAddProjectTwo.validate((valid) => {
        if (valid) {
          this.dialogYW15Two = true
        }
      })
    },
    addProjectContentBtn15Two () {
      saveThFile(this.paramsYwEdit).then(res => {
        if (res.code == 500) {
          this.$message.error(res.message)
          this.dialogYW15 = false
          this.dialogYW15Two = false
        } else {
          this.$message.success(res.message)
          this.dialogYW15 = false
          this.dialogYW15Two = false
          this.paramsBottomTwo.page = 1
          this.paramsBottomTwo.total = 0
          this.showListBottom(this.paramsBottomTwo)
        }
      })
    },

    // 文件层--修改案卷
    addBottomContent16 () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.paramsYwEdit = {}
        this.clearFiles('ruleFormYwEditProjectTwo')
        getThFile({id: this.tableDataBottomOnce[0].id}).then(res => {
          listThFolderById({id: this.tableDataTopOnceItem.id}).then(res => {
            this.c220Arr = res.data
          })
          this.c220ArrChange(res.data.c220)
          this.paramsYwEdit = res.data
          this.paramsYwEdit.ownerId = Number(res.data.ownerId)
          this.dialogYW16 = true
        })
      }
    },
    addProjectContentBtn16 () {
      this.$refs.ruleFormYwEditProjectTwo.validate((valid) => {
        if (valid) {
          this.dialogYW16Two = true
        }
      })
    },
    addProjectContentBtn16Two () {
      this.paramsYwEdit.subId = this.tableDataBottomOnce[0].id
      updateThFile(this.paramsYwEdit).then(res => {
        if (res.code == 500) {
          // this.$message.error('接口错误！')
          this.$message.error(res.message)
          this.dialogYW16 = false
          this.dialogYW16Two = false
        } else {
          // this.$message.success('修改成功')
          this.$message.success(res.message)
          this.dialogYW16 = false
          this.dialogYW16Two = false
          this.paramsBottomTwo.page = 1
          this.paramsBottomTwo.total = 0
          this.showListBottom(this.paramsBottomTwo)
        }
      })
    },

    // 删除文件
    deleteContent17 () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.dialogYW17 = true
      }
    },
    deleteContent17Two () {
      let arr = ''
      for (let i of this.tableDataBottomOnce) {
        arr += i.id + ','
      }
      // deleteThFile({ids: this.tableDataBottomOnce[0].id, bs: 'th'}).then(res => {
      deleteThFile({ids: arr, bs: 'th'}).then(res => {
        if (res.code == 500) {
          this.$message.error('接口错误！')
          this.dialogYW17 = false
        } else {
          this.$message.success('删除成功')
          this.dialogYW17 = false
          this.paramsBottomTwo.page = 1
          this.paramsBottomTwo.total = 0
          this.showListBottom(this.paramsBottomTwo)
        }
      })
    },

    // 上传
    fileDownload18 () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.imgVal = []
        this.clearFilesTwo('ajFileTwo')
        this.dialogYW18 = true
      }
    },
    fileDownload18Two () {
      if (this.imgVal.length < 1) {
        this.$message.error('请选择上传文件')
      } else {
        let params = {
          subId: this.tableDataBottomOnce[0].id,
          imgVal: JSON.stringify(this.imgVal),
          bs: 'th'
        }
        saveThZlUploadDoc(params).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogYW18 = false
            this.paramsBottomTwo.page = 1
            this.paramsBottomTwo.total = 0
            this.showListBottom(this.paramsBottomTwo)
          } else {
            this.$message.error(res.message)
            this.dialogYW18 = false
            this.paramsBottomTwo.page = 1
            this.paramsBottomTwo.total = 0
            this.showListBottom(this.paramsBottomTwo)
          }
        })
      }
    },

    // 删除材料
    handleSelectionChangeDeleteFile (val, item) {
      item.checkOnce = !item.checkOnce
      this.tableDataDeleteFileOnce = val
      if (this.tableDataDeleteFileOnce.length > 1 && this.tableDataDeleteFileOnce.length <= 2) {
        this.$refs.multipleTableDeleteFile.toggleRowSelection(this.tableDataDeleteFileOnce[0])
      }
    },
    handleSelectionChangeAllDeleteFile (val) {
      this.tableDataDeleteFileOnce = val
      for (let i in this.tableDataDeleteFileOnce) {
        if (!this.tableDataDeleteFileOnce[i].checkOnce) {
          this.tableDataDeleteFileOnce[i].checkOnce = true
        }
      }
      if (this.tableDataDeleteFileOnce.length > 1 && this.tableDataDeleteFileOnce.length <= 2) {
        this.$refs.multipleTableDeleteFile.toggleRowSelection(this.tableDataDeleteFileOnce[0])
      }
    },
    handleSelectionClickDeleteFile (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTableDeleteFile.toggleRowSelection(item)
        item.checkOnce = true
      } else {
        this.$refs.multipleTableDeleteFile.clearSelection()
        item.checkOnce = false
        this.tableDataDeleteFileOnce = []
      }
    },
    fileDelete19 (val) {
      // this.tableDataDeleteFile
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.paramsDeleteFile.page = 1
        this.paramsDeleteFile.subId = this.tableDataBottomOnce[0].id
        // let audit = this.paramsDeleteFile || val
        // audit.subId = this.tableDataBottomOnce[0].id
        listThDocData(this.paramsDeleteFile).then(res => {
          this.tableDataDeleteFile = res.data.rows
          this.paramsDeleteFile.total = res.data.total
          this.dialogYW19 = true
        })
      }
    },
    fileDelete19Two () {
      let item = this.$onceWay().onceTableList(this.tableDataDeleteFileOnce)
      if (item == 1) {
        this.dialogYW19Two = true
      }
    },
    deleteContent19Two () {
      let params = {
        id: this.tableDataDeleteFileOnce[0].id,
        bs: 'th'
      }
      deleteDoc(params).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogYW19Two = false
          this.paramsDeleteFile.page = 1
          listThDocData(this.paramsDeleteFile).then(res => {
            this.tableDataDeleteFile = res.data.rows
            this.paramsDeleteFile.total = res.data.total
          })
        } else {
          this.$message.error(res.message)
          this.dialogYW19Two = false
        }
      })
    },
    // 下载Excel录入模板
    ajFileDownload20 () {
      this.dialogYW20 = true
    },
    ajFileDownload20Two () {
      let ids = {status: 'thfile'}
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/downloadExcel', ids, '投行底稿按件模板.xls', 'get')
      this.dialogYW20 = false
    },

    // 导入excel模板
    ywFileAdd21 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogYW21 = true
        this.clearFilesTwo('fwFileTwo')
        this.imgVal = []
      }
    },
    ywFileAdd21Two () {
      let params = {
        subId: this.tableDataTopOnce[0].id,
        imgVal: this.imgVal
      }
      uploadThFileExcel(params).then(res => {
        if (res.code == 500) {
          this.$message.error(res.data.msg)
        } else {
          if (res.data.optFlag == 0) {
            this.$message.success('导入成功')
            this.dialogYW21 = false
            this.paramsBottomTwo.page = 1
            this.paramsBottomTwo.total = 0
            this.showListBottom(this.paramsBottomTwo)
          } else if (res.data.optFlag == -1) {
            this.$message.error('导入失败')
            this.dialogYW21 = false
            this.paramsBottomTwo.page = 1
            this.paramsBottomTwo.total = 0
            this.showListBottom(this.paramsBottomTwo)
          } else {
            this.$message.error('导入失败')
            this.dialogYW21 = false
            this.paramsBottomTwo.page = 1
            this.paramsBottomTwo.total = 0
            this.showListBottom(this.paramsBottomTwo)
          }
        }
      })
    },
    // 修改脊背
    ywFileAdd22 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        getCaseNoByC18({c18: this.tableDataTopOnceItem.c18}).then(res => {
          this.caseNoArr = res.data
          this.dialogYW22 = true
          this.paramsYwEdit = {c85: ''}
          this.clearFiles('ruleFormYwEditJiBei')
        })
      }
    },
    ywFileAdd22Change (val) {
      let params = {
        caseNo: val,
        c18: this.tableDataTopOnceItem.c18
      }
      getTitleByCaseNo(params).then(res => {
        this.paramsYwEdit.c85 = res.data.data
        this.$forceUpdate()
      })
    },
    ywFileAdd22Btn () {
      let params = {
        c18: this.tableDataTopOnceItem.c18,
        caseNo: this.paramsYwEdit.caseNo,
        c85: this.paramsYwEdit.c85
      }
      updateJbTitle(params).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.paramsBottomTwo.page = 1
          this.paramsBottomTwo.total = 0
          this.showListBottom(this.paramsBottomTwo)
          this.dialogYW22 = false
        } else {
          this.$message.error(res.message)
          this.dialogYW22 = false
        }
      })
    },
    // 打印卷内目录
    ywFileDownload23 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        if (this.tableDataBottomOnce.length < 1) {
          this.dialogYW23 = true
        } else {
          let arr = ''
          for (let i in this.tableDataBottomOnce) {
            arr += this.tableDataBottomOnce[i].id + ','
          }
          valueIndex().exportFiles('/gdda-new/gdda/archiveZL/printJnDirectory', {fileIds: arr}, '投行卷内目录.doc', 'get')
          this.dialogYW23 = false
        }
      }
    },
    ywFileDownload23Btn () {
      let params = {
        fileIds: 'all',
        series: this.methodSeries(),
        fonds: this.params.fonds,
        projectId: this.tableDataTopOnceItem.id
      }
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/printJnDirectory', params, '投行卷内目录.doc', 'get')
      this.dialogYW23 = false
    },
    // 打印封面
    ywFileDownload24 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.paramsYwEdit = {}
        this.dialogYW24 = true
      }
    },
    ywFileDownload24Btn () {
      if (this.paramsYwEdit.caseNo1 == '' || this.paramsYwEdit.caseNo1 == undefined) {
        this.$message.error('必填项不能为空！')
      } else if (this.paramsYwEdit.caseNo2 == '' || this.paramsYwEdit.caseNo2 == undefined) {
        this.$message.error('必填项不能为空！')
      } else {
        let params = {
          caseNo1: this.paramsYwEdit.caseNo1,
          caseNo2: this.paramsYwEdit.caseNo2,
          projectId: this.tableDataTopOnceItem.id
        }
        valueIndex().exportFiles('/gdda-new/gdda/archiveZL/printCover', params, '投行档案封面.doc', 'get')
        this.dialogYW24 = false
      }
    },
    // 打印脊背
    ywFileDownload25 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.paramsYwEdit = {}
        this.dialogYW25 = true
      }
    },
    ywFileDownload25Btn () {
      if (this.paramsYwEdit.caseNo1 == '' || this.paramsYwEdit.caseNo1 == undefined) {
        this.$message.error('必填项不能为空！')
      } else if (this.paramsYwEdit.caseNo2 == '' || this.paramsYwEdit.caseNo2 == undefined) {
        this.$message.error('必填项不能为空！')
      } else {
        let params = {
          caseNo1: this.paramsYwEdit.caseNo1,
          caseNo2: this.paramsYwEdit.caseNo2,
          projectId: this.tableDataTopOnceItem.id
        }
        valueIndex().exportFiles('/gdda-new/gdda/archiveZL/printBack', params, '投行档案脊背.doc', 'get')
        this.dialogYW25 = false
      }
    },

    // 判断档案类型哪一级别有值
    methodSeries () {
      let item = this.params.series3 || this.params.series2 || this.params.series1
      return item
    },
    // 按件--检索
    resetSearch () {
      this.params.page = 1
      this.params.total = 0
    },
    // 清除掉回调表单验证
    clearFiles (val) {
      if (this.$refs[val]) {
        this.$nextTick(() => {
          this.$refs[val].clearValidate()
        })
      }
    },
    clearFilesTwo (val) {
      if (this.$refs[val]) {
        this.$nextTick(() => {
          this.$refs[val].clearFiles()
        })
      }
    },
  },
  watch: {
    paramsC (val) {
      this.params = val
      this.params.c0 = null
    },
    tableDataC (val) {
      this.tableData = val
      if (val.length < 1) {
        this.tableDataTopOnce = []
        this.tableDataTopOnceItem = {}
      }
    },
    tableDataBottomC (val) {
      this.tableDataBottom = val
      if (val.length < 1) {
        this.tableDataBottomOnce = []
      }
    }
  },
  created () {
    this.params = this.paramsC
    this.tableData = this.tableDataC
    this.tableDataBottom = this.tableDataBottomC
    this.selectType()
  }
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  .search-select {
    float: left;
    margin: 4px 0;
    vertical-align: middle;
    line-height: 40px;
    label {
      font-size: 14px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 143px;
    }
  }
  .search-selectOnce {
    margin: 5px 6px;
    height: 35px;
    border:1px solid #DEDEDE;
    cursor: auto;
  }
  .searchBtn {
    float: left;
    line-height: 47px;
    font-size: 13px;
    cursor: pointer;
    img{
      vertical-align: middle;
      margin-right: 4px;
    }
  }
  .mangeShowLook {
    float: left;
    width: 33%;
    margin-bottom: 20px;
    /deep/.el-input.is-disabled .el-input__inner{
      background-color: #fff!important;
      color: #606266!important;
    }
  }
  .hurdleAllHeHao {
    /deep/.el-dialog__body {
      padding: 0;
      margin-bottom: 20px;
    }
  }
  .searchForm {
    /deep/.el-form-item {
      margin-bottom: 10px;
    }
    .el-select {
      width: 100%;
    }
  }
</style>
