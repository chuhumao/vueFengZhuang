<!-- 按件 -->
<template>
  <div>
    <!-- 上操作--按件 -->
    <div style="background-color: #F4F4F4;">
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajEnteringOne">
        <img src="../../assets/turnOver/lr.png" alt="">
        <span>录入</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajEditOne">
        <img src="../../assets/turnOver/bj.png" alt="">
        <span>编辑</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajEditTwo">
        <img src="../../assets/turnOver/bj.png" alt="">
        <span>特殊编辑</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajDeleteOne">
        <img src="../../assets/turnOver/delete.png" alt="">
        <span>删除</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajSetHeHaoOne">
        <img src="../../assets/turnOver/pl.png" alt="">
        <span>批量设置盒号</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajFileDownload6">
        <img src="../../assets/turnOver/xz.png" alt="">
        <span>下载Excel录入模板</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajFile7">
        <img src="../../assets/turnOver/dr.png" alt="">
        <span>导入Excel录入目录</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajFileDownload8">
        <img src="../../assets/turnOver/xz.png" alt="">
        <span>下载Excel整理模板</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajFile8">
        <img src="../../assets/turnOver/dr.png" alt="">
        <span>导入Excel整理目录</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="resetSearch">
        <img src="../../assets/turnOver/js.png" alt="">
        <span>检索</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajFileDownload10">
        <img src="../../assets/turnOver/dy.png" alt="">
        <span>打印目录</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajFileDownload11">
        <img src="../../assets/turnOver/dy.png" alt="">
        <span>打印脊背</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajCover">
        <img src="../../assets/turnOver/jg.png" alt="">
        <span>加盖电子归档章</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajRemoveCover">
        <img src="../../assets/turnOver/cx.png" alt="">
        <span>撤销电子归档章</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajSaveShow120">
        <img src="../../assets/turnOver/bc.png" alt="">
        <span>保存</span>
      </div>
      <div class="clear"></div>
    </div>
    <!-- 上表格 -->
    <div class="all-Table" >
      <el-table
        ref="multipleTable"
        :data="tableData"
        stripe
        border
        @select="handleSelectionChange"
        @select-all="handleSelectionChangeAll"
        @cell-click="handleSelectionClick">
        <el-table-column
          type="index"
          align="center"
          width="60">
        </el-table-column>
        <el-table-column
          type="selection"
          align="center"
          width="60">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="itemNo"
          label="件号"
          width="100">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileCode"
          label="文号"
          width="100">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="titleProper"
          label="题名"
          width="200">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="retentionPeriod"
          label="保管期限"
          width="130">
          <template slot-scope="scope">
            <span v-if="scope.row.retentionPeriod == 3">永久</span>
            <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
            <span v-else-if="scope.row.retentionPeriod == 1">短期</span>
            <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
            <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
            <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="openingType"
          label="公开属性"
          width="130">
          <template slot-scope="scope">
            <span v-if="scope.row.openingType == 2">内部</span>
            <span v-else-if="scope.row.openingType == 1">公开</span>
            <span v-else-if="scope.row.openingType == 3">受控</span>
            <span v-else-if="scope.row.openingType == 4">广发商密三级</span>
            <span v-else-if="scope.row.openingType == 5">广发商密二级</span>
            <span v-else-if="scope.row.openingType == 6">广发商密一级</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="caseNo"
          label="文件盒号"
          width="130">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="filingDate"
          label="文件日期"
          width="160">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c92"
          label="来源"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="yearCode"
          label="年度"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="amountOfPages"
          label="页数"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="seriesCode"
          label="分类号"
          width="140">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c58"
          label="是否为原件"
          width="150">
          <template slot-scope="scope">
            <span v-if="scope.row.openingType == 1">否</span>
            <span v-if="scope.row.openingType == 0">是</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c8"
          label="备注"
          width="150">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c100"
          label="文件类型"
          width="150">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c117"
          label="合同号"
          width="150">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c113"
          label="责任者"
          width="150">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="filingDept"
          label="归档部门"
          width="150">
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <div class="pageLayout">
      <el-pagination
        @current-change="handleCurrentChange"
        :current-page="params.page"
        :page-size="params.rows"
        layout="prev, pager, next, jumper"
        :total="params.total">
      </el-pagination>
    </div>
    <!-- 下操作 -->
    <div style="background-color: #F4F4F4;">
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajShowLook">
        <img src="../../assets/turnOver/ck.png" alt="">
        <span>查看</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajFile12">
        <img src="../../assets/turnOver/scTwo.png" alt="">
        <span>上传</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajEdit14">
        <img src="../../assets/turnOver/lr.png" alt="">
        <span>修改</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="ajDelete15">
        <img src="../../assets/turnOver/delete.png" alt="">
        <span>删除</span>
      </div>
      <div class="clear"></div>
    </div>
    <!--下表格--按件 -->
    <div class="all-Table">
      <el-table
        ref="multipleTableBottom"
        :data="tableDataBottom"
        stripe
        border
        @select="handleSelectionChangeBottom"
        @select-all="handleSelectionChangeBottomAll"
        @cell-click="handleSelectionClickBottom">
        <el-table-column
          type="selection"
          align="center"
          width="55">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="titleProper"
          label="材料名称"
          width="220">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileSize"
          label="大小">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="fileFormat"
          label="格式">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="officeArchivalCode"
          label="室编档号"
          width="220">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="pageNo"
          label="页号">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="amountOfPages"
          label="页数">
        </el-table-column>
      </el-table>
    </div>
    <!-- 下分页 -->
    <div class="pageLayout">
      <el-pagination
        @current-change="handleCurrentChangeBottom"
        :current-page="paramsBottom.page"
        :page-size="paramsBottom.rows"
        layout="prev, pager, next, jumper"
        :total="paramsBottom.total">
      </el-pagination>
    </div>

    <!-- 按件--录入 -->
    <el-dialog :visible.sync="dialogAJ1" width="880px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/lraj.png" alt="">
        录入
      </div>
      <el-form :model="paramsAj" :rules="rulesAj" ref="ruleFormAj" label-width="100px" class="demo-ruleForm">
        <!--题名-->
        <el-form-item label="题名" prop="titleProper">
          <el-input v-model="paramsAj.titleProper"></el-input>
        </el-form-item>
        <!--保管期限， 公开属性，文件日期-->
        <el-form-item label="保管期限" prop="retentionPeriod" class="mangeShowLook">
          <el-select v-model="paramsAj.retentionPeriod" filterable placeholder="请选择">
            <el-option
              v-for="item in retentionPeriod"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="公开属性" prop="openingType" class="mangeShowLook">
          <el-select v-model="paramsAj.openingType" filterable placeholder="请选择">
            <el-option
              v-for="item in openingType"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="文件日期" prop="dateOfCreation" class="mangeShowLook">
          <el-date-picker
            style="width: 100%;"
            v-model="paramsAj.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间"
            @change="dateChange"
          >
          </el-date-picker>
        </el-form-item>
        <!--年度， 拟稿部门， 拟稿人-->
        <el-form-item label="年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsAj.yearCode" readonly></el-input>
        </el-form-item>
        <el-form-item label="拟稿部门" prop="c90" class="mangeShowLook">
          <el-select v-model="paramsAj.c90" filterable placeholder="请选择" @change="c90Change">
            <el-option
              v-for="item in c90"
              :key="item.value"
              :label="item.text"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="拟稿人" prop="c89" class="mangeShowLook">
          <el-select v-model="paramsAj.c89" filterable placeholder="请选择">
            <el-option
              v-for="item in c89"
              :key="item.id"
              :label="item.text"
              :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <!--是否为原件， 分类号， 文号-->
        <el-form-item label="是否为原件" prop="c58" class="mangeShowLook">
          <el-select v-model="paramsAj.c58" filterable placeholder="请选择">
            <el-option
              v-for="item in c58"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="分类号"  class="mangeShowLook">
          <el-input v-model="paramsAj.seriesCode" readonly></el-input>
        </el-form-item>
        <el-form-item label="文号" prop="" class="mangeShowLook">
          <el-input v-model="paramsAj.fileCode"></el-input>
        </el-form-item>
        <!--页数， 档号， 责任者-->
        <el-form-item label="页数" prop="" class="mangeShowLook">
          <el-input v-model="paramsAj.amountOfPages"></el-input>
        </el-form-item>
        <el-form-item label="档号" prop="" class="mangeShowLook">
          <el-input v-model="paramsAj.officeArchivalCode"></el-input>
        </el-form-item>
        <el-form-item label="责任者" prop="" class="mangeShowLook">
          <el-input v-model="paramsAj.c113"></el-input>
        </el-form-item>
        <!--来文系统， 文件类型， 公章类型-->
        <el-form-item label="来文系统" prop="" class="mangeShowLook">
          <el-input v-model="paramsAj.c92"></el-input>
        </el-form-item>
        <el-form-item label="文件类型" prop="" class="mangeShowLook">
          <el-input v-model="paramsAj.c100"></el-input>
        </el-form-item>
        <el-form-item label="公章类型" prop="" class="mangeShowLook">
          <el-input v-model="paramsAj.c112"></el-input>
        </el-form-item>
        <!--是否在库， 合同号-->
        <el-form-item label="是否在库" prop="" class="mangeShowLook">
          <el-select v-model="paramsAj.c59" filterable placeholder="请选择">
            <el-option
              v-for="item in c59"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="合同号" prop="" class="mangeShowLook">
          <el-input v-model="paramsAj.c117"></el-input>
        </el-form-item>
        <!--备注-->
        <el-form-item label="备注" prop="" class="mangeShowLook" style="width: 100%;">
          <el-input type="textarea" v-model="paramsAj.c8"></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="ajAdd1">保存</el-button>
        <el-button @click="restBtn">重置</el-button>
        <el-button @click="dialogAJ1 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--编辑 -->
    <el-dialog :visible.sync="dialogAJ2" width="880px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/lr.png" alt="">
        修改案件信息
      </div>
      <el-form :model="paramsAjEdit" :rules="rulesAjEdit" ref="ruleFormAjEdit" label-width="100px" class="demo-ruleForm">
        <!--题名-->
        <el-form-item label="题名" prop="titleProper">
          <el-input v-model="paramsAjEdit.titleProper" readonly></el-input>
        </el-form-item>
        <!--件号-->
        <el-form-item label="件号" prop="itemNo" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.itemNo"></el-input>
        </el-form-item>
        <!--保管期限， 公开属性，文件盒号，文件日期-->
        <el-form-item label="保管期限" prop="retentionPeriod" class="mangeShowLook">
          <el-select v-model="paramsAjEdit.retentionPeriod" filterable placeholder="请选择">
            <el-option
              v-for="item in retentionPeriod"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="公开属性" prop="openingType" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.openingType" readonly></el-input>
          <!--<el-select v-model="paramsAjEdit.openingType" filterable placeholder="请选择">-->
          <!--<el-option-->
          <!--v-for="item in openingType"-->
          <!--:key="item.itemValue"-->
          <!--:label="item.name"-->
          <!--:value="item.itemValue">-->
          <!--</el-option>-->
          <!--</el-select>-->
        </el-form-item>
        <el-form-item label="文件盒号" prop="caseNo" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.caseNo"></el-input>
        </el-form-item>
        <el-form-item label="文件日期" prop="dateOfCreation" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.dateOfCreation" readonly></el-input>
        </el-form-item>
        <!--年度，归档部门， 拟稿部门， 拟稿人-->
        <el-form-item label="年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.yearCode" readonly></el-input>
        </el-form-item>
        <el-form-item label="归档部门" prop="c90" class="mangeShowLook">
          <el-select v-model="paramsAjEdit.c90" filterable placeholder="请选择" @change="c90Change">
            <el-option
              v-for="item in c90"
              :key="item.value"
              :label="item.text"
              :value="item.value">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="拟稿部门" prop="c90" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.filingDeptTwo" readonly></el-input>
        </el-form-item>
        <el-form-item label="拟稿人" prop="c89" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.c89" readonly></el-input>
          <!--<el-select v-model="paramsAjEdit.c89" filterable placeholder="请选择">-->
          <!--<el-option-->
          <!--v-for="item in c89"-->
          <!--:key="item.id"-->
          <!--:label="item.text"-->
          <!--:value="item.id">-->
          <!--</el-option>-->
          <!--</el-select>-->
        </el-form-item>
        <!-- 分类号， 文号-->
        <el-form-item label="分类号"  class="mangeShowLook">
          <el-input v-model="paramsAjEdit.seriesCode" readonly></el-input>
        </el-form-item>
        <el-form-item label="文号" prop="" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.fileCode"></el-input>
        </el-form-item>
        <el-form-item label="存址号" prop="" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.storagePlace"></el-input>
        </el-form-item>
        <!--页数， 档号， 责任者-->
        <el-form-item label="页数" prop="" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.amountOfPages"></el-input>
        </el-form-item>
        <el-form-item label="档号" prop="" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.officeArchivalCode"></el-input>
        </el-form-item>
        <el-form-item label="责任者" prop="" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.c113"></el-input>
        </el-form-item>
        <!--来文系统， 文件类型， 公章类型-->
        <el-form-item label="来文系统" prop="" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.c92" readonly></el-input>
        </el-form-item>
        <el-form-item label="文件类型" prop="" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.c100"></el-input>
        </el-form-item>
        <el-form-item label="公章类型" prop="" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.c112"></el-input>
        </el-form-item>
        <!--是否为原件-->
        <el-form-item label="是否为原件" prop="c58" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.c58" readonly></el-input>
        </el-form-item>
        <!--是否在库， 合同号-->
        <el-form-item label="是否在库" prop="" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.c59" readonly></el-input>
        </el-form-item>
        <el-form-item label="合同号" prop="" class="mangeShowLook">
          <el-input v-model="paramsAjEdit.c117"></el-input>
        </el-form-item>
        <!--备注-->
        <el-form-item label="备注" prop="" class="mangeShowLook" style="width: 100%;">
          <el-input type="textarea" v-model="paramsAjEdit.c8"></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="ajEdit2">保存</el-button>
        <el-button @click="ajEditOne">重置</el-button>
        <el-button @click="dialogAJ2 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--特殊编辑 -->
    <el-dialog :visible.sync="dialogAJ3" width="880px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tsbj.png" alt="">
        修改案件信息
      </div>
      <el-form :model="paramsAj" :rules="rulesAjEdit3" ref="ruleFormAjEdit" label-width="100px" class="demo-ruleForm">
        <!--题名-->
        <el-form-item label="题名" prop="titleProper">
          <el-input v-model="paramsAj.titleProper" readonly></el-input>
        </el-form-item>
        <!--保管期限， 公开属性-->
        <el-form-item label="保管期限" prop="retentionPeriod" class="mangeShowLook" style="width: 50%;">
          <el-select v-model="paramsAj.retentionPeriod" filterable placeholder="请选择" style="width: 100%;">
            <el-option
              v-for="item in retentionPeriod"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="公开属性" prop="openingType" class="mangeShowLook" style="width: 50%;">
          <el-select v-model="paramsAj.openingType" filterable placeholder="请选择" style="width: 100%;">
            <el-option
              v-for="item in openingType"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </el-form-item>
        <!--备注-->
        <el-form-item label="备注" prop="" class="mangeShowLook" style="width: 100%;">
          <el-input type="textarea" v-model="paramsAj.c8"></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="ajEdit3">保存</el-button>
        <el-button @click="dialogAJ3 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--设置盒号 -->
    <el-dialog :visible.sync="dialogAJ5" width="880px" class="hurdleAll hurdleAllHeHao" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sccl.png" alt="">
        批量设置盒号
      </div>
      <div style="background-color: #F4F4F4; padding:10px 0;">
        <div class="searchBtn search-selectOnce"></div>
        <div class="searchBtn" @click="dialogAJSearch5 = true, ajHeHaoSearchReset5()">
          <img src="../../assets/turnOver/js.png" alt="">
          <span>检索</span>
        </div>
        <div class="searchBtn" style="width: 100px; margin-left: 20px;">
          <el-input type="text" v-model="addCaseNo"></el-input>
        </div>
        <div class="searchBtn" @click="ajHeHaoAdd5">
          <img src="../../assets/turnOver/tj.png" alt="">
          <span>一键添加盒号</span>
        </div>
        <div class="searchBtn search-selectOnce"></div>
        <div class="searchBtn" style="width: 100px">
          <el-input type="text" v-model="editCaseNo"></el-input>
        </div>
        <div class="searchBtn" @click="ajHeHaoEdit5">
          <img src="../../assets/turnOver/lr.png" alt="">
          <span>一键修改盒号</span>
        </div>
        <div class="clear"></div>
      </div>
      <div class="all-Table">
        <el-table
          :data="tableDataDialogAJ5"
          stripe
          border>
          <el-table-column
            type="index"
            align="center"
            width="60">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="itemNo"
            label="件号">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="retentionPeriod"
            label="保管期限">
            <template slot-scope="scope">
              <span v-if="scope.row.retentionPeriod == 3">永久</span>
              <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
              <span v-else-if="scope.row.retentionPeriod == 1">短期</span>
              <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
              <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
              <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
            </template>
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="titleProper"
            label="题名"
            width="230">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="caseNo"
            label="文件盒号（原)">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="caseNoTwo"
            label="文件盒号（新)">
            <template slot-scope="scope">
              <el-input v-model="scope.row.caseNoTwo"></el-input>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <!-- 下分页 -->
      <div class="pageLayout">
        <el-pagination
          @current-change="handleCurrentChangeHeHaoSearch"
          :current-page="paramsSearch.page"
          :page-size="paramsSearch.rows"
          layout="prev, pager, next, jumper"
          :total="paramsSearch.total">
        </el-pagination>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="ajHeHaoAddOrEdit">保存</el-button>
        <el-button @click="dialogAJ5 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--设置盒号（检索） -->
    <el-dialog :visible.sync="dialogAJSearch5" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/js.png" alt="">
        检索
      </div>
      <div>
        <el-form :model="paramsSearch" label-width="100px" class="demo-ruleForm">
          <!--题名-->
          <el-form-item label="年度">
            <el-input v-model="paramsSearch.yearCode"></el-input>
          </el-form-item>
          <!--保管期限， 公开属性-->
          <el-form-item label="保管期限">
            <el-select v-model="paramsSearch.retentionPeriod" filterable placeholder="请选择" style="width: 100%;">
              <el-option
                v-for="item in retentionPeriod"
                :key="item.itemValue"
                :label="item.name"
                :value="item.itemValue">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="归档部门">
            <el-select v-model="paramsSearch.filingDept" filterable placeholder="请选择" style="width: 100%;">
              <el-option
                v-for="item in filingDept"
                :key="item.id"
                :label="item.text"
                :value="item.id">
              </el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="件号">
            <el-input v-model="paramsSearch.itemNoStart" style="width: 47%;"></el-input>
            -
            <el-input v-model="paramsSearch.itemNoEnd" style="width: 47%;"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajHeHaoSearch5">确定</el-button>
        <el-button type="primary" @click="ajHeHaoSearchReset5">重置</el-button>
        <el-button @click="dialogAJSearch5 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--Excel文件导入（录入） -->
    <el-dialog :visible.sync="dialogAJ7" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/dr.png" alt="">
        Excel文件导入
      </div>
      <div class="dia-delete" style="text-align: left;">
        <label>文件上传：</label>
        <el-upload
          ref="ajFileOne"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="handleChange"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <div style="text-align: center;margin:10px 0;">
          <span v-for="(item, index) in imgVal" :key="index">
            {{ item }}
            <img @click="handleRemove" style="margin: 0 0 0 10px; vertical-align:middle;cursor: pointer;" src="../../assets/hurdle/hurdleDelete.png" alt="">
          </span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajFileAdd7">确定</el-button>
        <el-button @click="dialogAJ7 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--Excel文件导入（整理） -->
    <el-dialog :visible.sync="dialogAJ8" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/dr.png" alt="">
        Excel文件导入整理目录
      </div>
      <div class="dia-delete" style="text-align: left;">
        <label>文件上传：</label>
        <el-upload
          ref="ajFileTwo"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="handleChange"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <div style="text-align: center;margin:10px 0;">
          <span v-for="(item, index) in imgVal" :key="index">
            {{ item }}
            <img @click="handleRemove" style="margin: 0 0 0 10px; vertical-align:middle;cursor: pointer;" src="../../assets/hurdle/hurdleDelete.png" alt="">
          </span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajFileAdd7">确定</el-button>
        <el-button @click="dialogAJ8 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--检索 -->
    <el-dialog :visible.sync="dialogAJ9" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/js.png" alt="">
        检索
      </div>
      <el-form :model="params" ref="ruleFormAjSearch" label-width="100px" class="demo-ruleForm searchForm showClearLook">
        <!--题名-->
        <el-form-item label="题名" prop="titleProper">
          <el-input v-model="params.titleProper" ></el-input>
        </el-form-item>
        <!--年度-->
        <el-form-item label="年度" prop="titleProper">
          <el-input v-model="params.yearCode" ></el-input>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限" prop="retentionPeriod" class="">
          <el-select v-model="params.retentionPeriod" filterable placeholder="请选择">
            <el-option
              v-for="item in retentionPeriod"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </el-form-item>
        <!--盒号-->
        <el-form-item label="盒号" prop="titleProper">
          <el-input v-model="params.caseNo" ></el-input>
        </el-form-item>
        <!--拟稿部门-->
        <el-form-item label="拟稿部门" prop="retentionPeriod" class="">
          <!--<el-select v-model="params.c90" placeholder="请选择" filterable reserve-keyword>-->
          <el-select v-model="params.c90" placeholder="请选择" filterable reserve-keyword @change="remoteMethodMan">
            <el-option v-for="item in c90" :key="item.value" :label="item.text" :value="item.value"></el-option>
          </el-select>
        </el-form-item>
        <!--拟稿人-->
        <el-form-item label="拟稿人" prop="retentionPeriod" class="">
          <!--<el-select v-model="params.c89" placeholder="请选择" filterable remote reserve-keyword :remote-method="remoteMethodMan">-->
          <!--<el-select v-model="params.c89" placeholder="请选择" filterable remote reserve-keyword>-->
            <!--&lt;!&ndash;<el-option v-for="item in c89" :key="item.id" :label="item.text" :value="item.id"></el-option>&ndash;&gt;-->
            <!--<el-option v-for="item in yjc89Arr" :key="item.id" :label="item.text" :value="item.id"></el-option>-->
          <!--</el-select>-->
          <el-select v-model="params.c89" placeholder="请选择" filterable reserve-keyword remote :remote-method="remoteMethodManTwo">
            <el-option v-for="item in yjc89Arr" :key="item.id" :label="item.text" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <!--责任者-->
        <el-form-item label="责任者" prop="retentionPeriod" class="">
          <el-input v-model="params.c113" ></el-input>
        </el-form-item>
        <!--文号-->
        <el-form-item label="文号" prop="retentionPeriod" class="">
          <el-input v-model="params.fileCode" ></el-input>
        </el-form-item>
        <!--合同号-->
        <el-form-item label="合同号" prop="retentionPeriod" class="">
          <el-input v-model="params.c117" ></el-input>
        </el-form-item>
        <!--文件类型-->
        <el-form-item label="文件类型" prop="retentionPeriod" class="">
          <el-select v-model="params.c100" placeholder="请选择" filterable reserve-keyword>
            <el-option v-for="item in c100" :key="item.id" :label="item.text" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <!--盖章类型-->
        <el-form-item label="盖章类型" prop="retentionPeriod" class="">
          <el-select v-model="params.c112" placeholder="请选择" filterable reserve-keyword>
            <el-option v-for="item in c112" :key="item.id" :label="item.text" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <!--来文系统-->
        <el-form-item label="来文系统" prop="retentionPeriod" class="">
          <el-select v-model="params.c92" placeholder="请选择" filterable reserve-keyword>
            <el-option v-for="item in c92" :key="item.id" :label="item.text" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <!--归档日期-->
        <el-form-item label="归档日期" prop="retentionPeriod" class="">
          <el-date-picker
            style="width: 100%;"
            v-model="params.filingDate"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </el-form-item>
        <!--备注-->
        <el-form-item label="备注" prop="retentionPeriod" class="">
          <el-input v-model="params.c8" ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="showList(params)">确定</el-button>
        <el-button @click="resetSearch">重置</el-button>
        <el-button @click="dialogAJ9 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--查看（下表格） -->
    <el-dialog :visible.sync="dialogShowLook" width="1111px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/ck.png" alt="">
        查看材料
      </div>
      <div class="showClearLook">
        <div class="bigDog menuShrink black-tree" style="float: left;height: 100%;min-height: unset;max-height: unset;">
          <el-tree
            :data="treTable"
            :props="defaultProps"
            :check-strictly="true"
            :default-expand-all="true"
            :expand-on-click-node="false"
            :highlight-current="true"
            accordion
            @node-click="handleNodeClick">
          </el-tree>
        </div>
        <div style="float: left;margin-left: 10px;width: 78%; max-height: 600px; overflow: auto;">
          <!--<embed :src="embedOnce" width="100%" height="600px"/>-->
          <iframe :src="embedOnce" width="100%" height="600px"></iframe>
        </div>
        <div class="clear"></div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button @click="pdfDownload" :disabled="showLookDownload">下载</el-button>
        <el-button @click="dialogShowLook = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--上传（下表格） -->
    <el-dialog :visible.sync="dialogAJ13" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sc.png" alt="">
        文件上传
      </div>
      <div class="dia-delete" style="text-align: left;">
        <label>上传：</label>
        <el-upload
          ref="ajFileThree"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="handleChangeThree"
          :on-remove="handleRemoveThree"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <div style="text-align: center;margin:10px 0;">
          <span v-for="(item, index) in imgVal" :key="index" style="display: block;">
            {{ item.path }}
            <img @click="handleRemove" style="margin: 0 0 0 10px; vertical-align:middle;cursor: pointer;" src="../../assets/hurdle/hurdleDelete.png" alt="">
          </span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajFileAdd12">确定</el-button>
        <el-button @click="dialogAJ13 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--修改（下表格） -->
    <el-dialog :visible.sync="dialogAJ14" width="666px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        修改案件信息
      </div>
      <el-form :model="paramsAj" label-width="100px" class="demo-ruleForm">
        <!--材料名称-->
        <el-form-item label="材料名称">
          <el-input v-model="paramsAj.titleProper"></el-input>
        </el-form-item>
        <!--室编档号-->
        <el-form-item label="室编档号">
          <el-input v-model="paramsAj.officeArchivalCode"></el-input>
        </el-form-item>
        <!--页号，页数-->
        <el-form-item label="页号" class="mangeShowLook" style="width: 50%;">
          <el-input v-model="paramsAj.pageNo"></el-input>
        </el-form-item>
        <el-form-item label="页数" class="mangeShowLook" style="width: 50%;">
          <el-input v-model="paramsAj.amountOfPages"></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="ajEditDate14">保存</el-button>
        <el-button @click="dialogAJ14 = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 按件--录入确定 -->
    <el-dialog :visible.sync="dialogAJ11" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        新增案件确认
      </div>
      <div style="text-align: center">
        <div>
          <img src="../../assets/dialog/wh.png" alt="">
        </div>
        <div class="dia-delete">
          确定要保存数据吗？
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajAdd11">确定</el-button>
        <el-button @click="dialogAJ11 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--编辑确定 -->
    <el-dialog :visible.sync="dialogAJ22" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        修改案件确认
      </div>
      <div style="text-align: center">
        <div>
          <img src="../../assets/dialog/wh.png" alt="">
        </div>
        <div class="dia-delete">
          确定要保存数据吗？
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajEdit22">确定</el-button>
        <el-button @click="dialogAJ22 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--编辑确定 -->
    <el-dialog :visible.sync="dialogAJ33" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        修改案件确认
      </div>
      <div style="text-align: center">
        <div>
          <img src="../../assets/dialog/wh.png" alt="">
        </div>
        <div class="dia-delete">
          确定要保存数据吗？
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajEdit33">确定</el-button>
        <el-button @click="dialogAJ33 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--删除确定 -->
    <el-dialog :visible.sync="dialogAJ44" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除案件确认
      </div>
      <div style="text-align: center">
        <div>
          <img src="../../assets/dialog/wh.png" alt="">
        </div>
        <div class="dia-delete">
          确定要删除此数据吗？
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajDeleteOne44">确定</el-button>
        <el-button @click="dialogAJ44 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--设置盒号确定 -->
    <el-dialog :visible.sync="dialogAJ55" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div style="text-align: center">
        <div>
          <img src="../../assets/dialog/wh.png" alt="">
        </div>
        <div class="dia-delete">
          您确定要保存数据吗？
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajHeHaoAdd55">确定</el-button>
        <el-button @click="dialogAJ55 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--下载录入Excel -->
    <el-dialog :visible.sync="dialogAJ66" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/xzqr.png" alt="">
        系统提示
      </div>
      <div style="text-align: center">
        <div>
          <img src="../../assets/dialog/xz.png" alt="">
        </div>
        <div class="dia-delete">
          确定要下载该模板吗？
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajFileDownload66">确定</el-button>
        <el-button @click="dialogAJ66 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--导入Excel录入上传失败 -->
    <el-dialog :visible.sync="dialogAJ77" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/xzqr.png" alt="">
        系统提示
      </div>
      <div style="text-align: center">
        <div>
          <img src="../../assets/dialog/xz.png" alt="">
        </div>
        <div class="dia-delete">
          是否要导出错误信息？
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajFileError">确定</el-button>
        <el-button @click="dialogAJ77 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--下载整理Excel -->
    <el-dialog :visible.sync="dialogAJ88" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/xzqr.png" alt="">
        系统提示
      </div>
      <div style="text-align: center">
        <div>
          <img src="../../assets/dialog/xz.png" alt="">
        </div>
        <div class="dia-delete">
          将会下载并导出查询结果用于整理，确定要下载吗？
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajFileDownload88">确定</el-button>
        <el-button @click="dialogAJ88 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--打印目录按钮 -->
    <el-dialog :visible.sync="dialogAJ100" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/xzqr.png" alt="">
        系统提示
      </div>
      <div style="text-align: center">
        <div>
          <img src="../../assets/dialog/xz.png" alt="">
        </div>
        <div class="dia-delete">
          您没有选择要打印的归档文件，是否要打印全部？
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajFileDownload100">确定</el-button>
        <el-button @click="dialogAJ100 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--打印脊背按钮 -->
    <el-dialog :visible.sync="dialogAJ110" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/xzqr.png" alt="">
        系统提示
      </div>
      <div class="dia-delete" style="text-align: center;">
        <label>选择尺寸:</label>
        <!--<el-select v-model="scope" placeholder="请选择" filterable remote reserve-keyword :remote-method="remoteMethodMan">-->
        <el-select v-model="scope" placeholder="请选择" filterable :remote-method="remoteMethodMan">
          <el-option v-for="item in scopeArr" :key="item.id" :label="item.text" :value="item.id"></el-option>
        </el-select>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajFileDownload110">确定</el-button>
        <el-button @click="dialogAJ110 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--保存 -->
    <el-dialog :visible.sync="dialogAJ120" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/xzqr.png" alt="">
        系统提示
      </div>
      <div style="text-align: center">
        <div>
          <img src="../../assets/dialog/wh.png" alt="">
        </div>
        <div class="dia-delete">
          确定保存该案件吗？
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajSave120">确定</el-button>
        <el-button @click="dialogAJ120 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--查看--下载 -->
    <el-dialog :visible.sync="dialogShowLook1" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/xzqr.png" alt="">
        下载确认
      </div>
      <div style="text-align: center">
        <div>
          <img src="../../assets/dialog/xz.png" alt="">
        </div>
        <div class="dia-delete">
          确定要进行下载吗？
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajShowLook11">确定</el-button>
        <el-button @click="dialogShowLook1 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--删除 -->
    <el-dialog :visible.sync="dialogAJ150" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除附件确认
      </div>
      <div style="text-align: center">
        <div>
          <img src="../../assets/dialog/wh.png" alt="">
        </div>
        <div class="dia-delete">
          确定要删除此材料吗?？
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="ajDelete150">确定</el-button>
        <el-button @click="dialogAJ150 = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {listArchiveZL, listDoc, listUserByDeptId, listDept, addArchiveZL, findSeriesCode, editFileAnJian, updateFileAnJian,
  updateSpecialFileAnJia, deleteArchiveZL, listAllDept, findArchiveZL, saveCaseNoByBatch, uploadExcelH5, uploadExcel,
  uploadExcelZl, listFileType, listGzdj, listLwxt, coverElectronicSeal, removeElectronicSeal, saveFileWrk, listAnJianTree,
  powerDocView, uploadPicture, saveZlUploadDoc, editDocAnJian, updateDoc, deleteDoc, listThArchiveZL, findUser} from '@/js/fileMangeOver'
import {getFonds, listSeriesByFondsAndRole, listSeriesByFonds, BASICURL} from '@/js/turnOverData'
import { valueIndex } from '@/js/transitionText'
export default {
  name: 'fileAj',
  props: {
    paramsC: Object,
    tableDataC: Array,
    tableDataBottomC: Array,
  },
  data: function () {
    return {
      /* 此处表格数据 */
      params: {c0: 6, page: 1, rows: 10, fonds: 1374133141812, series1: 1379482316593}, // 对应 全宗、类型、上一级表格数据
      paramsBottom: {page: 1, rows: 10, total: 0}, // 对应 全宗、类型、上一级表格数据
      paramsSearch: {page: 1, rows: 10, total: 0}, // 按件--批量设置盒号（检索）
      paramsAj: {}, // 按件--录入 or 编辑 or 特殊编辑 or 修改（下表格）
      paramsAjEdit: {}, // 按件--编辑

      /* 此处select类型 */
      fullZong: [], // 全宗
      FondsAndRole: [], // 类型一级
      FondsAndRoleTwo: [], // 类型二级
      FondsAndRoleThree: [], // 类型三级

      /* 此处表格 */
      tableData: [], // 上表格第一级
      tableDataBottom: [], // 下表格第一级
      tableDataDialogAJ5: [], // 批量设置盒号

      /* 此处表格多选选择数据 */
      tableDataTopOnce: [], // 上表格第一级
      tableDataTopOnceItem: {}, // 上表格第一级(单个数据）
      tableDataBottomOnce: [], // 下表格第一级
      /* 按件弹框 */
      dialogAJ1: false,
      dialogAJ2: false,
      dialogAJ3: false,
      dialogAJ5: false,
      dialogAJ66: false,
      dialogAJ7: false,
      dialogAJ88: false,
      dialogAJ8: false,
      dialogAJ9: false,
      dialogAJ100: false,
      dialogAJ110: false,
      dialogAJ120: false,
      dialogShowLook: false,
      dialogAJ13: false,
      dialogAJ14: false,
      dialogAJ150: false,

      dialogAJ11: false,
      dialogAJ22: false,
      dialogAJ33: false,
      dialogAJ44: false,
      dialogAJSearch5: false,
      dialogAJ55: false,
      dialogAJ77: false,
      dialogShowLook1: false,

      /* form判断 */
      rulesAj: {
        titleProper: [{required: true, message: '请填写题名', trigger: 'blur'}],
        retentionPeriod: [{required: true, message: '请选择保管期限', trigger: 'change'}],
        openingType: [{required: true, message: '请选择公开属性', trigger: 'change'}],
        dateOfCreation: [{required: true, message: '请选择文件日期', trigger: 'change'}],
        yearCode: [{required: true, message: '请注意年度', trigger: 'change'}],
        c90: [{required: true, message: '请选择拟稿部门', trigger: 'change'}],
        c89: [{required: true, message: '请选择拟稿人', trigger: 'change'}],
        c58: [{required: true, message: '请选择是否为原件', trigger: 'change'}]
      },
      rulesAjEdit: {
        itemNo: [{required: true, message: '请填写件号', trigger: 'blur'}],
        retentionPeriod: [{required: true, message: '请选择保管期限', trigger: 'change'}],
        caseNo: [{required: true, message: '请填写文件盒号', trigger: 'change'}],
      },
      rulesAjEdit3: {
        retentionPeriod: [{required: true, message: '请选择保管期限', trigger: 'change'}],
        openingType: [{required: true, message: '请选择公开属性', trigger: 'change'}],
      },

      /* select类型 */
      retentionPeriod: [
        {'name': '永久', 'itemValue': '3'},
        {'name': '长期', 'itemValue': '2'},
        {'name': '短期', 'itemValue': '1'},
        {'name': '10年', 'itemValue': '5'},
        {'name': '15年', 'itemValue': '6'},
        {'name': '30年', 'itemValue': '8'}
      ], // 保管期限
      c58: [{'name': '否', 'itemValue': '1'}, {'name': '是', 'itemValue': '0'}], // 是否为原件
      c59: [{'name': '否', 'itemValue': '1'}, {'name': '是', 'itemValue': '0'}], // 是否在库
      c89: [], // 拟稿人
      c90: [], // 拟稿部门
      c92: [], // 来文系统
      c100: [], // 文件类型
      c112: [], // 盖章类型
      openingType: [
        {'name': '内部', 'itemValue': '2'},
        {'name': '公开', 'itemValue': '1'},
        {'name': '受控', 'itemValue': '3'},
        {'name': '广发商密三级', 'itemValue': '4'},
        {'name': '广发商密二级', 'itemValue': '5'},
        {'name': '广发商密一级', 'itemValue': '6'}
      ], // 公开属性
      filingDept: [], // 归档部门
      yjc89Arr: [], // 拟稿人--检索
      scopeArr: [
        {id: 3, text: '3cm'},
        {id: 5, text: '5cm'}
      ], // 打印脊背--尺寸

      /* 单个数据 */
      addCaseNo: '',
      editCaseNo: '',
      imgVal: [],
      fileErrorMsg: '',
      scope: '',
      embedOnce: '',
      showLookDownload: true,
      showLookDownloadId: '',
      // dateShowLook: 2,
      dateShowLook: 2,
      yeWuaActiveName: '案卷层',

      /* tree数据 */
      treTable: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      },
    }
  },
  methods: {
    // 获取上表格第一级数据
    showList (val) {
      listArchiveZL(val).then(res => {
        if (res.data.rows.length <= 0) {
          this.$message.error('该条件下查无数据！')
          this.tableData = []
        } else {
          this.tableData = res.data.rows
          this.params.total = res.data.total
          this.tableData.forEach(item => {
            item.checkOnce = false
          })
        }
        this.dialogAJ9 = false
        this.dateShowLook = 1
      })
    },
    // 上表格多选
    handleSelectionChange (val, item) {
      this.tableDataBottom = []
      this.tableDataTopOnceItem = {}
      item.checkOnce = !item.checkOnce
      this.tableDataTopOnce = val
      if (!item.checkOnce) {
        this.tableDataBottom = []
      }
      if (this.tableDataTopOnce.length > 0) {
        if (item.checkOnce) {
          this.paramsBottom.page = 1
          this.paramsBottom.rows = 5
          this.paramsBottom.fileId = item.id
          this.showListBottom(this.paramsBottom)
        }
      }
      val.forEach(items => {
        if (items.checkOnce) {
          this.tableDataTopOnceItem = items
        }
      })
    },
    handleSelectionChangeAll (val) {
      if (val.length > 0) {
        for (let i of this.tableData) {
          // i.checkOnce = !i.checkOnce
          i.checkOnce = true
        }
      } else {
        for (let i of this.tableData) {
          // i.checkOnce = !i.checkOnce
          i.checkOnce = false
        }
      }
      this.tableDataTopOnce = val

      // for (let i in this.tableDataTopOnce) {
      //   if (!this.tableDataTopOnce[i].checkOnce) {
      //     this.tableDataTopOnce[i].checkOnce = true
      //   }
      // }
    },
    // 上表格行内点击
    handleSelectionClick (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTable.toggleRowSelection(item, true)
        item.checkOnce = true
      } else {
        this.$refs.multipleTable.toggleRowSelection(item, false)
        item.checkOnce = false
        this.tableDataBottom = []
      }
    },
    // 上表格分页点击
    handleCurrentChange (val) {
      this.params.page = val
      this.showList(this.params)
    },
    // 下表格第一级数据
    showListBottom (val) {
      listDoc(val).then(res => {
        if (res.data.rows.length <= 0) {
          this.$message.error('该案件暂无材料')
          this.tableDataBottom = []
        } else {
          this.tableDataBottom = res.data.rows
          this.paramsBottom.total = res.data.total
          this.tableDataBottom.forEach(item => {
            item.checkOnce = false
          })
        }
      })
    },
    // 下表格多选
    handleSelectionChangeBottom (val, item) {
      item.checkOnce = !item.checkOnce
      this.tableDataBottomOnce = val
      if (this.tableDataBottomOnce.length > 1) {
        this.$refs.multipleTableBottom.toggleRowSelection(this.tableDataBottomOnce[0])
      }
    },
    handleSelectionChangeBottomAll (val) {
      this.tableDataBottomOnce = val
      for (let i in this.tableDataBottomOnce) {
        if (!this.tableDataBottomOnce[i].checkOnce) {
          this.tableDataBottomOnce[i].checkOnce = true
        }
      }
    },
    // 下表格行内点击
    handleSelectionClickBottom (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTableBottom.toggleRowSelection(item)
        item.checkOnce = true
      } else {
        this.$refs.multipleTableBottom.clearSelection()
        item.checkOnce = false
        this.tableDataBottomOnce = []
      }
    },
    // 下表格分页点击
    handleCurrentChangeBottom (val) {
      this.paramsBottom.page = val
      this.showListBottom(this.paramsBottom)
    },
    // 获取全宗 档案类型第一级
    showSearchData () {
      getFonds().then(res => {
        this.fullZong = res.data
      })
      listSeriesByFondsAndRole({id: 1374133141812}).then(res => {
        // listSeriesByFondsAndRole({id: this.params.fonds}).then(res => {
        // console.log(res)
        this.FondsAndRole = res.data
        listSeriesByFonds({id: this.params.series1}).then(res => {
          this.FondsAndRoleTwo = res.data
        })
        // this.searchSeries(1379482316593)
      })
    },
    // 档案类型第二级
    searchSeries (val) {
      listSeriesByFonds({id: val}).then(res => {
        this.FondsAndRoleTwo = res.data
      })
      this.resetParams()
      // this.params.page = 1
      // this.params.rows = 10
      // this.params.total = 0
      this.params.series2 = null
      this.params.series3 = null
      if (this.params.series1 == 1388742017296 || this.params.series1 == 1379398885203 || this.params.series1 == 1374133285843) {
        this.tableData = []
      } else {
        this.showList(this.params)
      }
    },
    // 档案类型第三级
    searchSeriesTwo (val) {
      listSeriesByFonds({id: val}).then(res => {
        this.FondsAndRoleThree = res.data
      })
      this.resetParams()
      // this.params.page = 1
      // this.params.rows = 10
      // this.params.total = 0
      this.params.series3 = null
      this.showList(this.params)
    },
    // 档案类型第三级获取数据
    searchSeriesThree (val) {
      this.resetParams()
      // this.params.series3 = val
      this.showList(this.params)
      // this.$forceUpdate()
    },
    // 全宗
    yjTypeBtn (val) {
      this.params.series1 = null
      this.params.series2 = null
      this.params.series3 = null
      this.FondsAndRole = []
      this.FondsAndRoleTwo = []
      this.FondsAndRoleThree = []
      listSeriesByFondsAndRole({id: val}).then(res => {
        this.FondsAndRole = res.data
      })
      this.resetParams()
      this.showList(this.params)
    },

    /* 弹框开始 */
    handleCloseOne () {
      this.dialogAJ1 = false
      this.dialogAJ2 = false
      this.dialogAJ3 = false
      this.dialogAJ44 = false
      this.dialogAJ5 = false
      this.dialogAJ66 = false
      this.dialogAJ7 = false
      this.dialogAJ8 = false
      this.dialogAJ88 = false
      this.dialogAJ9 = false
      this.dialogAJ100 = false
      this.dialogAJ110 = false
      this.dialogAJ120 = false
      this.dialogShowLook = false
      this.dialogAJ13 = false
      this.dialogAJ14 = false
      this.dialogAJ150 = false
    },
    handleCloseTwo () {
      this.dialogAJ11 = false
      this.dialogAJ22 = false
      this.dialogAJ33 = false
      this.dialogAJ55 = false
      this.dialogAJ77 = false
      this.dialogAJSearch5 = false
      this.dialogShowLook1 = false
    },
    // 重置
    restBtn () {
      this.paramsAj = {
        seriesCode: this.paramsAj.seriesCode
      }
    },
    /* 获取拟稿部门，拟稿人 */
    c90Change (val) {
      this.c89Type(val)
    },
    c89Type (val) {
      listUserByDeptId({deptId: val}).then(res => {
        this.c89 = res.data
      })
    },
    selectType () {
      listDept().then(res => {
        this.c90 = res.data
      })
      listAllDept().then(res => {
        this.filingDept = res.data
      })
      listFileType().then(res => {
        this.c100 = res.data
      })
      listGzdj().then(res => {
        this.c112 = res.data
      })
      listLwxt().then(res => {
        this.c92 = res.data
      })
    },
    // 分类号
    findSeriesCodeOnce () {
      // let item = this.params.series3 || this.params.series2 || this.params.series1
      findSeriesCode({archiveTreeNodeId: this.methodSeries()}).then(res => {
        this.paramsAj.seriesCode = res.data.seriesCode
      })
    },
    // 按件--录入
    ajEnteringOne () {
      this.paramsAj = {
        seriesCode: this.paramsAj.seriesCode
      }
      this.dialogAJ1 = true
      // let item = this.params.series3 || this.params.series2 || this.params.series1
      this.findSeriesCodeOnce()
      // this.paramsAj.series = item
      this.paramsAj.series = this.methodSeries()
      this.paramsAj.fonds = this.params.fonds
      this.clearFiles('ruleFormAj')
      this.$forceUpdate()
    },
    ajAdd1 () {
      this.$refs.ruleFormAj.validate((valid) => {
        if (valid) {
          this.dialogAJ11 = true
        }
      })
    },
    ajAdd11 () {
      addArchiveZL(this.paramsAj).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogAJ1 = false
          this.dialogAJ11 = false
        } else {
          this.$message.error(res.message)
          this.dialogAJ1 = false
          this.dialogAJ11 = false
        }
      })
    },
    dateChange () {
      this.paramsAj.yearCode = this.paramsAj.dateOfCreation.split('-')[0]
      this.$forceUpdate()
    },
    // 按件--编辑
    ajEditOne () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.paramsAjEdit = {itemNo: ''}
        editFileAnJian({fileId: this.tableDataTopOnceItem.id}).then(res => {
          this.dialogAJ2 = true
          this.clearFiles('ruleFormAjEdit')
          // this.paramsAjEdit = JSON.parse(JSON.stringify(res.data))
          this.paramsAjEdit = res.data
          this.c90.forEach(item => {
            if (res.data.filingDept == item.value) {
              this.paramsAjEdit.filingDeptTwo = item.text
            }
          })
          this.openingType.forEach(item => {
            if (res.data.openingType == item.itemValue) {
              this.paramsAjEdit.openingType = item.name
            }
          })
          this.$forceUpdate()
        })
      }
    },
    ajEdit2 () {
      this.$refs.ruleFormAjEdit.validate((valid) => {
        if (valid) {
          this.dialogAJ22 = true
        }
      })
    },
    ajEdit22 () {
      updateFileAnJian(this.paramsAjEdit).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogAJ2 = false
          this.dialogAJ22 = false
          this.resetParams()
          this.showList(this.params)
        } else {
          this.$message.error(res.message)
          this.dialogAJ2 = false
          this.dialogAJ22 = false
        }
      })
    },
    // 按件--特殊编辑
    ajEditTwo () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.paramsAj = {}
        editFileAnJian({fileId: this.tableDataTopOnce[0].id}).then(res => {
          this.paramsAj = res.data
          this.dialogAJ3 = true
          this.clearFiles('ruleFormAjEdit')
        })
      }
    },
    ajEdit3 () {
      this.$refs.ruleFormAjEdit.validate((valid) => {
        if (valid) {
          this.dialogAJ33 = true
        }
      })
    },
    ajEdit33 () {
      updateSpecialFileAnJia(this.paramsAj).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogAJ3 = false
          this.dialogAJ33 = false
        } else {
          this.$message.error(res.message)
          this.dialogAJ3 = false
          this.dialogAJ33 = false
        }
      })
    },
    // 按件--删除
    ajDeleteOne () {
      let item = this.$onceWay().onceTableListTwo(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogAJ44 = true
      }
    },
    ajDeleteOne44 () {
      let deleteArr = ''
      for (let i in this.tableDataTopOnce) {
        deleteArr += this.tableDataTopOnce[i].id + ','
      }
      deleteArchiveZL({ids: deleteArr}).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogAJ44 = false
          this.resetParams()
          this.showList(this.params)
        } else {
          this.$message.error(res.message)
          this.dialogAJ44 = false
        }
      })
    },
    // 按件--设置盒号
    ajSetHeHaoOne () {
      let arr = ''
      this.tableDataTopOnce.forEach((item) => {
        arr += item.id + ','
      })
      this.paramsSearch.ids = arr
      findArchiveZL(this.paramsSearch).then(res => {
        this.tableDataDialogAJ5 = res.data.rows
        this.paramsSearch.total = res.data.total
        this.addCaseNo = ''
        this.editCaseNo = ''
        this.dialogAJ5 = true
      })
    },
    ajHeHaoAddOrEdit () {
      this.dialogAJ55 = true
    },
    ajHeHaoAdd55 () {
      let arr = ''
      this.tableDataDialogAJ5.forEach((item) => {
        arr += `${item.id}-${item.caseNo}-${item.caseNoTwo?item.caseNoTwo: ''};`
      })
      saveCaseNoByBatch({params: arr}).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogAJ55 = false
          this.ajHeHaoSearch5()
        } else {
          this.$message.error(res.message)
          this.dialogAJ55 = false
        }
      })
    },
    // 盒号--检索
    ajHeHaoSearch5 () {
      this.paramsSearch.fonds = this.params.fonds
      this.paramsSearch.series = this.methodSeries()
      findArchiveZL(this.paramsSearch).then(res => {
        this.tableDataDialogAJ5 = res.data.rows
        this.paramsSearch.total = res.data.total
        this.dialogAJSearch5 = false
      })
    },
    // 盒号--检索重置
    ajHeHaoSearchReset5 () {
      this.paramsSearch = {}
      this.paramsSearch.fonds = this.params.fonds
      this.paramsSearch.series = this.methodSeries()
      this.paramsSearch.page = 1
      this.paramsSearch.rows = 5
      this.paramsSearch.total = 0
    },
    handleCurrentChangeHeHaoSearch (val) {
      this.paramsSearch.page = val
      this.ajHeHaoSearch5()
    },
    // 盒号--一键添加
    ajHeHaoAdd5 () {
      this.tableDataDialogAJ5.forEach((item, index) => {
        if (item.caseNo == undefined || item.caseNo == '') {
          item.caseNoTwo = this.addCaseNo
        }
      })
      this.tableDataDialogAJ5 = JSON.parse(JSON.stringify(this.tableDataDialogAJ5))
    },
    // 盒号--一键编辑
    ajHeHaoEdit5 () {
      this.tableDataDialogAJ5.forEach((item) => {
        if (item.caseNo == undefined || item.caseNo == '') {
          item.caseNoTwo = null
        } else {
          item.caseNoTwo = this.editCaseNo
        }
      })
      this.tableDataDialogAJ5 = JSON.parse(JSON.stringify(this.tableDataDialogAJ5))
    },

    // 下载Excel录入模板
    ajFileDownload6 () {
      this.dialogAJ66 = true
    },
    ajFileDownload66 () {
      let ids = {status: 'aj'}
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/downloadExcel', ids, '档案整理模板.xls', 'get')
      this.dialogAJ66 = false
    },

    // Excel导入（录入）
    ajFile7 () {
      this.imgVal = []
      this.clearFilesTwo('ajFileOne')
      this.dialogAJ7 = true
    },
    handleChange (file, fileList) {
      if (this.imgVal.length >= 1) {
        this.$message.error('只能上传一个文件')
      } else {
        let formData = new FormData()
        formData.append('picture', file.raw)
        formData.append('type', 'map')
        formData.append('name', 'file')
        uploadExcelH5(formData).then(res => {
          if (res.code == 0) {
            this.imgVal.push(res.data.msg)
          } else {
            this.$message.error(res.message)
          }
        })
      }
    },
    // 删除上传
    handleRemove (val, item) {
      this.imgVal.splice(val, 1)
    },
    ajFileAdd7 () {
      if (this.imgVal.length < 1) {
        this.$message.error('请选择上传文件')
      } else {
        if (this.dialogAJ7) {
          let params = {
            series1: this.params.series1,
            fonds: this.params.fonds,
            imgVal: this.imgVal[0]
          }
          uploadExcel(params).then(res => {
            if (res.code == 1) {
              this.$message.success(res.data.msg)
              this.dialogAJ7 = false
              this.imgVal = []
            } else {
              // alert('导入失败')
              this.dialogAJ77 = true
              this.fileErrorMsg = res.data.msg
            }
          })
        }
        else if (this.dialogAJ8) {
          let params = {
            series1: this.params.series1,
            fonds: this.params.fonds,
            imgVal: this.imgVal[0]
          }
          uploadExcelZl(params).then(res => {
            if (res.code == 0) {
              this.$message.success(res.data.msg)
              this.dialogAJ8 = false
              this.imgVal = []
            } else {
              if (res.data.optFlag == -1) {
                // alert('导入失败')
                this.dialogAJ77 = true
                this.fileErrorMsg = res.data.msg
              } else {
                this.$message.error(res.message)
              }
            }
          })
        }
      }
    },
    // 上传失败
    ajFileError () {
      if (this.dialogAJ7) {
        let ids = {excelId: this.fileErrorMsg}
        valueIndex().exportFiles('/gdda-new/gdda/archiveZL/exportError', ids, '错误信息.xls', 'get')
        this.dialogAJ77 = false
      } else if (this.dialogAJ8) {
        let ids = {excelId: this.fileErrorMsg}
        valueIndex().exportFiles('/gdda-new/gdda/archiveZL/exportError', ids, '错误信息.xls', 'get')
        this.dialogAJ77 = false
      }
      // this.imgVal = []
    },

    // 下载
    ajFileDownload8 () {
      this.dialogAJ88 = true
    },
    ajFileDownload88 () {
      let ids = {
        c0: 6,
        fonds: this.params.fonds,
        series1: this.params.series1,
        series2: this.params.series2,
        series3: this.params.series3
      }
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/downloadExcelZl', ids, '文书档案整理模板.xls', 'get')
      this.dialogAJ88 = false
    },
    // Excel导入（整理）
    ajFile8 () {
      this.imgVal = []
      this.clearFilesTwo('ajFileTwo')
      this.dialogAJ8 = true
    },

    // 按件--检索
    resetSearch () {
      this.dialogAJ9 = true
      this.params = {
        c0: 6,
        rows: 10,
        fonds: this.params.fonds,
        series1: this.params.series1,
        series2: this.params.series2,
        series3: this.params.series3,
        total: this.params.total,
        c89: '',
      }
      this.params.page = 1
        // -10000
    },
    // 监所内的搜索--拟稿人
    remoteMethodMan (val) {
      let params = {
        // orgFlag1: -10000,
        deptId: val
      }
      listUserByDeptId(params).then(res => {
        this.yjc89Arr = res.data
        this.params.c89 = ''
      })
    },
    // 监所内的搜索--拟稿人按件搜索
    remoteMethodManTwo (val) {
      let params = {
        orgFlag1: -10000,
        q: val
      }
      findUser(params).then(res => {
        this.yjc89Arr = res.data
      })
    },

    // 打印目录
    ajFileDownload10 () {
      if (this.tableDataTopOnce.length <= 0) {
        this.dialogAJ100 = true
      } else {
        let arr = ''
        try {
          this.tableDataTopOnce.forEach((item, index) => {
            if (item.itemNo == null || item.itemNo == '') {
              // throw(`行号：${index + 1}没有件号，无法打印`)
              // throw(`题名：${item.titleProper} 没有件号，无法打印`)
              throw(`系统提示： 没有件号，无法打印`)
            } else {
              arr += item.id + ','
              let ids = {fileIds: arr}
              valueIndex().exportFiles('/gdda-new/gdda/archiveZL/print', ids, '归档文件目录.doc', 'get')
            }
          })
        } catch (e) {
          this.$message.error(e)
        }
      }
    },
    ajFileDownload100 () {
      let ids = {fileIds: 'all', series: this.methodSeries(), fonds: this.params.fonds}
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/print', ids, '归档文件目录.doc', 'get')
      this.dialogAJ100 = false
    },

    // 打印脊背
    ajFileDownload11 () {
      let item = this.$onceWay().onceTableListTwo(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogAJ110 = true
        this.scope = 3
      }
    },
    ajFileDownload110 () {
      let arr = ''
      this.tableDataTopOnce.forEach(item => {
        arr += item.id
      })
      let ids = {scope: this.scope, fileIds: arr}
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/printAnjianJibei', ids, '文书档案脊背.doc', 'get')
      this.dialogAJ110 = false
    },

    // 加盖电子章
    ajCover () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        let arr = ''
        this.tableDataTopOnce.forEach(item => {
          arr += item.id + ','
        })
        let params = {
          ids: arr,
          fonds: this.params.fonds,
          archiveType: this.params.series1
        }
        coverElectronicSeal(params).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.resetParams()
            this.showList(this.params)
          } else {
            this.$message.error(res.message)
          }
        })
      }
    },
    // 撤销电子章
    ajRemoveCover () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        let arr = ''
        this.tableDataTopOnce.forEach(item => {
          arr += item.id + ','
        })
        let params = {ids: arr}
        removeElectronicSeal(params).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.resetParams()
            this.showList(this.params)
          } else {
            this.$message.error(res.message)
          }
        })
      }
    },
    // 按件--保存
    ajSaveShow120 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogAJ120 = true
      }
    },
    ajSave120 () {
      let arr = ''
      this.tableDataTopOnce.forEach(item => {
        arr += item.id + ','
      })
      saveFileWrk({ids: arr}).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogAJ120 = false
          this.resetParams()
          this.showList(this.params)
        } else {
          this.$message.error(res.message)
          this.dialogAJ120 = false
          this.resetParams()
          this.showList(this.params)
        }
      })
    },

    // 按件--查看
    ajShowLook () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.dialogShowLook = true
        this.embedOnce = ''
        let params = {
          id: this.tableDataTopOnce[0].id,
          bs: 'anjian'
        }
        listAnJianTree(params).then(res => {
          this.treTable = res.data
        })
      }
    },
    handleNodeClick (val) {

      if (val.id != 0) {
        powerDocView({id: val.id}).then(res => {
          if (res.data.optFlag == 0) {
            this.embedOnce = `${BASICURL}/gdda-new/gdda/util/filepreview/viewRangeFile?fileId=${val.id}`
            this.showLookDownload = false
            this.showLookDownloadId = val.id
            this.$forceUpdate()
          } else if (res.data.optFlag == -1) {
            this.$message.error('对不起，你访问的文件还未扫描')
            this.showLookDownload = true
            this.showLookDownloadId = ''
          } else if (res.data.optFlag == 2) {
            this.$message.info('该文件非PDF文件，是否要进行下载?')
            this.showLookDownload = false
            this.showLookDownloadId = val.id
          }
        })
      } else {
        this.showLookDownload = true
        this.showLookDownloadId = ''
      }
    },
    // 按件--查看下载（下表格）
    pdfDownload () {
      this.dialogShowLook1 = true
    },
    ajShowLook11 () {
      let ids = {id: this.showLookDownloadId, mode: 'anjian'}
      valueIndex().exportFiles('/gdda-new/gdda/util/downLoadFile', ids, '文件', 'get')
    },

    // 按件--上传（下表格）
    ajFile12 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.clearFilesTwo('ajFileThree')
        this.imgVal = []
        this.dialogAJ13 = true
      }
    },
    handleChangeThree (file, fileList) {
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('type', 'zl')
      formData.append('name', 'file')
      uploadPicture(formData).then(res => {
        if (res.code == 0) {
          this.imgVal.push(res.data.pathAndMD5)
        } else {
          this.$message.error(res.message)
        }
      })
    },
    // 按件--删除上传（下表格）
    handleRemoveThree (val, item) {
      this.imgVal.splice(val, 1)
    },
    ajFileAdd12 () {
      if (this.imgVal.length < 1) {
        this.$message.error('请选择上传文件')
      } else {
        let formData = new FormData()
        formData.append('subId', this.tableDataTopOnceItem.id)
        formData.append('imgVal', JSON.stringify(this.imgVal))
        formData.append('bs', 'anjian')
        saveZlUploadDoc(formData).then(res => {
          if (res.data.optFlag == -1) {
            this.$message.error('导入失败')
          } else if (res.data.optFlag == 1) {
            this.$message.error('请重新选择文件')
          } else if (res.data.optFlag == -2) {
            this.$message.error('系统错误或者 请重新选择要导入的Excel!')
          } else {
            this.$message.success('导入成功')
            this.paramsBottom.page = 1
            this.showListBottom(this.paramsBottom)
            this.dialogAJ13 = false
          }
        })
      }
    },
    // 按件--修改（下表格）
    ajEdit14 () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.paramsAj = {}
        editDocAnJian({docId: this.tableDataBottomOnce[0].id}).then(res => {
          this.paramsAj = res.data
          this.dialogAJ14 = true
        })
      }
    },
    ajEditDate14 () {
      this.paramsAj.bs = 'anjian'
      this.paramsAj.id = this.tableDataBottomOnce[0].id
      updateDoc(this.paramsAj).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogAJ14 = false
          this.paramsAj = {}
          this.paramsBottom.page = 1
          this.showListBottom(this.paramsBottom)
        } else {
          this.$message.error('修改失败')
        }
      })
    },

    // 按件--删除（下表格）
    ajDelete15 () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.dialogAJ150 = true
      }
    },
    ajDelete150 () {
      let params = {
        id: this.tableDataBottomOnce[0].id,
        bs: 'anjian'
      }
      deleteDoc(params).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogAJ150 = false
          this.paramsBottom.page = 1
          this.showListBottom(this.paramsBottom)
        } else {
          this.$message.error(res.message)
          this.dialogAJ150 = false
        }
      })
    },

    /* 业务---开始 */
    dateShowLookLook () {

    },
    yeWuTabsClick (item, val) {
      console.log(this.yeWuaActiveName);
    },

    // params清空，重来
    resetParams () {
      this.params.page = 1
      this.params.total = 0
    },
    methodSeries () {
      let item = this.params.series3 || this.params.series2 || this.params.series1
      return item
    },
    // 清除掉回调表单验证
    clearFiles (val) {
      if (this.$refs[val]) {
        this.$nextTick(() => {
          this.$refs[val].clearValidate()
        })
      }
    },
    clearFilesTwo (val) {
      if (this.$refs[val]) {
        this.$nextTick(() => {
          this.$refs[val].clearFiles()
        })
      }
    },
  },
  watch: {
    paramsC (val) {
      this.params = val
    },
    tableDataC (val) {
      this.tableData = val
      if (val.length < 1) {
        this.tableDataTopOnce = []
        this.tableDataTopOnceItem = {}
      }
    },
    tableDataBottomC (val) {
      this.tableDataBottom = val
      if (val.length < 1) {
        this.tableDataBottomOnce = []
      }
    }
  },
  created () {
    this.params = this.paramsC
    this.tableData = this.tableDataC
    this.tableDataBottom = this.tableDataBottomC
    // console.log(this.paramsC);
    // this.showSearchData()
    // this.showList(this.params)
    this.selectType()
    // this.$forceUpdate()
  },
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  .search-select {
    float: left;
    margin: 4px 0;
    vertical-align: middle;
    line-height: 40px;
    label {
      font-size: 14px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 143px;
    }
  }
  .search-selectOnce {
    margin: 5px 6px;
    height: 35px;
    border:1px solid #DEDEDE;
    cursor: auto;
  }
  .searchBtn {
    float: left;
    line-height: 47px;
    font-size: 13px;
    cursor: pointer;
    img{
      vertical-align: middle;
      margin-right: 4px;
    }
  }
  .mangeShowLook {
    float: left;
    width: 33%;
    margin-bottom: 20px;
    /deep/.el-input.is-disabled .el-input__inner{
      background-color: #fff!important;
      color: #606266!important;
    }
  }
  .hurdleAllHeHao {
    /deep/.el-dialog__body {
      padding: 0;
    }
  }
  .searchForm {
    /deep/.el-form-item {
      margin-bottom: 10px;
    }
    .el-select {
      width: 100%;
    }
  }
  .dia-delete {
    /*text-align: left;*/
    img {
      margin-left: 36%;
      margin-bottom: 12px;
    }

    div {
      text-align: center;
      font-size: 14px;
      color: #282828;
    }
  }
</style>
