<!-- 会计 -->
<template>
  <div>
    <!-- 上操作--业务 -->
    <div style="background-color: #F4F4F4;">
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="jjLuRu1">
        <img src="../../assets/turnOver/lr.png" alt="">
        <span>录入</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="jjLuRu2">
        <img src="../../assets/turnOver/bj.png" alt="">
        <span>编辑</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="jjDelete3">
        <img src="../../assets/turnOver/delete.png" alt="">
        <span>删除</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="resetSearch">
        <img src="../../assets/turnOver/js.png" alt="">
        <span>检索</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="jjAdd5">
        <img src="../../assets/turnOver/bc.png" alt="">
        <span>保存</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="jjDownload6">
        <img src="../../assets/turnOver/dy.png" alt="">
        <span>打印目录</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="jjDownload7">
        <img src="../../assets/turnOver/dy.png" alt="">
        <span>打印脊背</span>
      </div>
      <div class="clear"></div>
    </div>
    <!-- 上表格--业务 -->
    <div class="all-Table">
      <el-table
        ref="multipleTable"
        :data="tableData"
        stripe
        border
        @select="handleSelectionChange"
        @select-all="handleSelectionChangeAll"
        @cell-click="handleSelectionClick">
        <el-table-column
          type="index"
          align="center"
          width="60">
        </el-table-column>
        <el-table-column
          type="selection"
          align="center"
          width="60">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="officeArchivalCode"
          label="档号"
          width="150">
        </el-table-column>
        <el-table-column
          sortable
          show-overflow-tooltip
          prop="c220"
          label="案卷号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="titleProper"
          label="卷（册、袋）标题"
          width="160">
        </el-table-column>
        <el-table-column
          sortable
          show-overflow-tooltip
          prop="yearCode"
          label="年度"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c163"
          label="分类号"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c113"
          label="所属部门"
          width="120">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c15"
          label="类别"
          width='160'>
        </el-table-column>
        <el-table-column
          sortable
          show-overflow-tooltip
          prop="dateOfCreation"
          label="开始时间"
          width='140'>
        </el-table-column>
        <el-table-column
          sortable
          show-overflow-tooltip
          prop="dateOfEnd"
          label="结束时间"
          width='160'>
        </el-table-column>
        <el-table-column
          sortable
          show-overflow-tooltip
          prop="c160"
          label="起"
          width='120'>
        </el-table-column>
        <el-table-column
          sortable
          show-overflow-tooltip
          prop="c162"
          label="止"
          width='120'>
        </el-table-column>
        <el-table-column
          sortable
          show-overflow-tooltip
          prop="retentionPeriod"
          label="保管期限"
          width='120'>
          <template slot-scope="scope">
            <span v-if="scope.row.retentionPeriod == 1">短期</span>
            <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
            <span v-else-if="scope.row.retentionPeriod == 3">永久</span>
            <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
            <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
            <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="amountOfPages"
          label="卷内张数"
          width='140'>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c8"
          label="备考"
          width='140'>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <div class="pageLayout">
      <el-pagination
        @current-change="handleCurrentChange"
        :current-page="params.page"
        :page-size="params.rows"
        layout="prev, pager, next, jumper"
        :total="params.total">
      </el-pagination>
    </div>
    <!-- 下操作--业务 -->
    <div style="background-color: #F4F4F4;">
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="dateShowLookLook">
        <img src="../../assets/turnOver/ck.png" alt="">
        <span>查看</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="jjFileAdd8">
        <img src="../../assets/turnOver/sc.png" alt="">
        <span>上传</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="jjFileEdit9">
        <img src="../../assets/turnOver/xg.png" alt="">
        <span>修改</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="jjDelete10">
        <img src="../../assets/turnOver/delete.png" alt="">
        <span>删除</span>
      </div>
      <div class="clear"></div>
    </div>
    <!--下表格--业务 -->
    <div>
      <div class="all-Table">
        <el-table
          ref="multipleTableBottom"
          :data="tableDataBottom"
          stripe
          border
          @select="handleSelectionChangeBottom"
          @select-all="handleSelectionChangeBottomAll"
          @cell-click="handleSelectionClickBottom">
          <el-table-column
            type="selection"
            align="center"
            width="55">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="titleProper"
            label="材料名称"
            width="220">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="fileSize"
            label="大小">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="fileFormat"
            label="格式">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="officeArchivalCode"
            label="室编档号"
            width="220">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="pageNo"
            label="页号">
          </el-table-column>
          <el-table-column
            show-overflow-tooltip
            prop="amountOfPages"
            label="页数">
          </el-table-column>
        </el-table>
      </div>
    </div>
    <!-- 下分页 -->
    <div class="pageLayout">
      <el-pagination
        @current-change="handleCurrentChangeBottom"
        :current-page="paramsBottom.page"
        :page-size="paramsBottom.rows"
        layout="prev, pager, next, jumper"
        :total="paramsBottom.total">
      </el-pagination>
    </div>

    <!-- 录入--添加 -->
    <el-dialog :visible.sync="dialogJj1" width="1255px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/lr.png" alt="">
        录入案件信息
      </div>
      <el-form :model="paramsJj" :rules="rulesJj" ref="ruleFormAddJj" label-width="116px" class="demo-ruleForm">
        <!--案卷号-->
        <el-form-item label="案卷号" prop="c220" class="mangeShowLook">
          <el-input v-model="paramsJj.c220"></el-input>
        </el-form-item>
        <!--类别-->
        <el-form-item label="类别" prop="c15" class="mangeShowLook">
          <el-input v-model="paramsJj.c15"></el-input>
        </el-form-item>
        <!--卷(册、袋)标题-->
        <el-form-item label="卷(册、袋)标题" prop="titleProper" class="mangeShowLook">
          <el-input v-model="paramsJj.titleProper"></el-input>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限" prop="retentionPeriod" class="mangeShowLook">
          <el-select v-model="paramsJj.retentionPeriod" filterable placeholder="请选择" style="width: 100%;">
            <el-option
              v-for="item in retentionPeriod"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </el-form-item>
        <!--凭证起号， 凭证止号， 起止日期-->
        <el-form-item label="凭证起号" prop="c160" class="mangeShowLook">
          <el-input v-model="paramsJj.c160" ></el-input>
        </el-form-item>
        <el-form-item label="凭证止号" prop="c162" class="mangeShowLook">
          <el-input v-model="paramsJj.c162" ></el-input>
        </el-form-item>
        <el-form-item label="起止日期" class="mangeShowLook editorXin">
          <el-date-picker
            style="width: 47%;"
            v-model="paramsJj.dateOfCreation"
            type="date"
            format="yyyy-MM-dd"
            value-format="yyyy-MM-dd"
            placeholder="选择时间"
          >
          </el-date-picker>
          --
          <el-date-picker
            style="width: 47%;"
            v-model="paramsJj.dateOfEnd"
            type="date"
            format="yyyy-MM-dd"
            value-format="yyyy-MM-dd"
            placeholder="选择时间"
          >
          </el-date-picker>

        </el-form-item>
        <!--年度， 卷内张数， 所属部门-->
        <el-form-item label="年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsJj.yearCode" ></el-input>
        </el-form-item>
        <el-form-item label="卷内张数" class="mangeShowLook">
          <el-input v-model="paramsJj.amountOfPages"></el-input>
        </el-form-item>
        <el-form-item label="所属部门" prop="c113" class="mangeShowLook">
          <el-input v-model="paramsJj.c113"></el-input>
        </el-form-item>
        <!--分类号-->
        <el-form-item label="分类号" prop="c163" class="mangeShowLook">
          <el-input v-model="paramsJj.c163"></el-input>
        </el-form-item>
        <!--备注-->
        <el-form-item label="备注" class="mangeShowLook" style="width: 100%;">
          <el-input type="textarea" v-model="paramsJj.c8"></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button type="primary" @click="jjLuRuAdd1Btn">保存</el-button>
        <el-button @click="restBtn">重置</el-button>
        <el-button @click="dialogJj1 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 录入--编辑 -->
    <el-dialog :visible.sync="dialogJj2" width="1255px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tsbj.png" alt="">
        修改案件信息
      </div>
      <el-form :model="paramsJj" :rules="rulesJj" ref="ruleFormEditJj" label-width="116px" class="demo-ruleForm">
        <!--案卷号-->
        <el-form-item label="案卷号" prop="c220" class="mangeShowLook">
          <el-input v-model="paramsJj.c220"></el-input>
        </el-form-item>
        <!--类别-->
        <el-form-item label="类别" prop="c15" class="mangeShowLook">
          <el-input v-model="paramsJj.c15"></el-input>
        </el-form-item>
        <!--卷(册、袋)标题-->
        <el-form-item label="卷(册、袋)标题" prop="titleProper" class="mangeShowLook">
          <el-input v-model="paramsJj.titleProper"></el-input>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限" prop="retentionPeriod" class="mangeShowLook">
          <el-select v-model="paramsJj.retentionPeriod" filterable placeholder="请选择" style="width: 100%;">
            <el-option
              v-for="item in retentionPeriod"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </el-form-item>
        <!--凭证起号， 凭证止号， 起止日期-->
        <el-form-item label="凭证起号" prop="c160" class="mangeShowLook">
          <el-input v-model="paramsJj.c160" ></el-input>
        </el-form-item>
        <el-form-item label="凭证止号" prop="c162" class="mangeShowLook">
          <el-input v-model="paramsJj.c162" ></el-input>
        </el-form-item>
        <el-form-item label="起止日期" class="mangeShowLook editorXin">
          <el-date-picker
            style="width: 47%;"
            v-model="paramsJj.dateOfCreation"
            type="date"
            format="yyyy-MM-dd"
            value-format="yyyy-MM-dd"
            placeholder="选择时间"
          >
          </el-date-picker>
          --
          <el-date-picker
            style="width: 47%;"
            v-model="paramsJj.dateOfEnd"
            type="date"
            format="yyyy-MM-dd"
            value-format="yyyy-MM-dd"
            placeholder="选择时间"
          >
          </el-date-picker>

        </el-form-item>
        <!--年度， 卷内张数， 所属部门-->
        <el-form-item label="年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsJj.yearCode" ></el-input>
        </el-form-item>
        <el-form-item label="卷内张数" class="mangeShowLook">
          <el-input v-model="paramsJj.amountOfPages"></el-input>
        </el-form-item>
        <el-form-item label="所属部门" prop="c113" class="mangeShowLook">
          <el-input v-model="paramsJj.c113"></el-input>
        </el-form-item>
        <!--分类号-->
        <el-form-item label="分类号" prop="c163" class="mangeShowLook">
          <el-input v-model="paramsJj.c163"></el-input>
        </el-form-item>
        <!--备注-->
        <el-form-item label="备注" class="mangeShowLook" style="width: 100%;">
          <el-input type="textarea" v-model="paramsJj.c8"></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="jjLuRuEdit2Btn">保存</el-button>
        <el-button @click="jjLuRu2">重置</el-button>
        <el-button @click="dialogJj2 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 删除 -->
    <el-dialog :visible.sync="dialogJj3" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除按件确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要删除此数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="jjDelete3Btn">确定</el-button>
        <el-button @click="dialogJj3 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 检索 -->
    <el-dialog :visible.sync="dialogJj4" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/js.png" alt="">
        检索
      </div>
      <el-form style="height: 600px;overflow: auto;" :model="params" ref="ruleFormAjSearch" label-width="100px" class="demo-ruleForm searchForm showClearLook">
        <!--题名-->
        <el-form-item label="题名" prop="titleProper">
          <el-input v-model="params.titleProper" ></el-input>
        </el-form-item>
        <!--年度-->
        <el-form-item label="年度" prop="titleProper">
          <el-input v-model="params.yearCode" ></el-input>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限" prop="retentionPeriod" class="">
          <el-select v-model="params.retentionPeriod" filterable placeholder="请选择">
            <el-option
              v-for="item in retentionPeriod"
              :key="item.itemValue"
              :label="item.name"
              :value="item.itemValue">
            </el-option>
          </el-select>
        </el-form-item>
        <!--盒号-->
        <el-form-item label="盒号" prop="titleProper">
          <el-input v-model="params.caseNo" ></el-input>
        </el-form-item>
        <!--拟稿部门-->
        <el-form-item label="拟稿部门" prop="" class="">
          <el-select v-model="params.c90" placeholder="请选择" filterable reserve-keyword>
            <el-option v-for="item in c90" :key="item.value" :label="item.text" :value="item.value"></el-option>
          </el-select>
        </el-form-item>
        <!--拟稿人-->
        <el-form-item label="拟稿人" prop="" class="">
          <el-select v-model="params.c89" placeholder="请选择" filterable remote reserve-keyword :remote-method="remoteMethodMan">
            <el-option v-for="item in c89" :key="item.id" :label="item.text" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <!--责任者-->
        <el-form-item label="责任者" prop="" class="">
          <el-input v-model="params.c113" ></el-input>
        </el-form-item>
        <!--文号-->
        <el-form-item label="文号" prop="" class="">
          <el-input v-model="params.fileCode" ></el-input>
        </el-form-item>
        <!--合同号-->
        <el-form-item label="合同号" prop="" class="">
          <el-input v-model="params.c117" ></el-input>
        </el-form-item>
        <!--文件类型-->
        <el-form-item label="文件类型" prop="" class="">
          <el-select v-model="params.c100" placeholder="请选择" filterable reserve-keyword>
            <el-option v-for="item in c100" :key="item.id" :label="item.text" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <!--盖章类型-->
        <el-form-item label="盖章类型" prop="" class="">
          <el-select v-model="params.c112" placeholder="请选择" filterable reserve-keyword>
            <el-option v-for="item in c112" :key="item.id" :label="item.text" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <!--来文系统-->
        <el-form-item label="来文系统" prop="" class="">
          <el-select v-model="params.c92" placeholder="请选择" filterable reserve-keyword>
            <el-option v-for="item in c92" :key="item.id" :label="item.text" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <!--归档日期-->
        <el-form-item label="归档日期" prop="" class="">
          <el-date-picker
            style="width: 100%;"
            v-model="params.filingDate"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间">
          </el-date-picker>
        </el-form-item>
        <!--备注-->
        <el-form-item label="备注" prop="" class="">
          <el-input v-model="params.c8" ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="showList(params)">检索</el-button>
        <el-button @click="resetSearch">重置</el-button>
        <el-button @click="dialogJj4 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 保存 -->
    <el-dialog :visible.sync="dialogJj5" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定保存该案件吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="jjAdd5Btn">确定</el-button>
        <el-button @click="dialogJj5 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 打印目录 -->
    <el-dialog :visible.sync="dialogJj6" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/xz.png" alt="">
        <br>
        <div>您没有选择要打印的归档文件，是否要打印全部？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="jjDownload6Btn">确定</el-button>
        <el-button @click="dialogJj6 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 打印脊背 -->
    <el-dialog :visible.sync="dialogJj7" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="editorXin">
        <label>尺寸：</label>
        <el-input type="text" v-model="paramsJj.scope"></el-input>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="jjDownload7Btn">确定</el-button>
        <el-button @click="dialogJj7 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 上传（下表格） -->
    <el-dialog :visible.sync="dialogJj8" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sc.png" alt="">
        文件上传
      </div>
      <div class="dia-deleteTwo">
        <label>上传：</label>
        <el-upload
          ref="jjFileOne"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="handleChangeOne"
          :on-remove="handleRemoveOne"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <div style="text-align: center;margin:10px 0;">
          <span v-for="(item, index) in imgVal" :key="index" style="display: block;">
            {{ item.path }}
            <img @click="handleRemoveOne" style="margin: 0 0 0 10px; vertical-align:middle;cursor: pointer;" src="../../assets/hurdle/hurdleDelete.png" alt="">
          </span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="jjFileAdd8Btn">确定</el-button>
        <el-button @click="dialogJj8 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 修改（下表格） -->
    <el-dialog :visible.sync="dialogJj9" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tsbj.png" alt="">
        修改案件信息
      </div>
      <el-form :model="paramsJj" label-width="86px" class="demo-ruleForm">
        <!--材料名称-->
        <el-form-item label="材料名称" prop="" class="">
          <el-input v-model="paramsJj.titleProper"></el-input>
        </el-form-item>
        <!--室编档号-->
        <el-form-item label="室编档号" prop="" class="">
          <el-input v-model="paramsJj.officeArchivalCode"></el-input>
        </el-form-item>
        <!--页号-->
        <el-form-item label="页号" prop="pageNo" class="mangeShowLook" style="width: 50%">
          <el-input v-model="paramsJj.pageNo"></el-input>
        </el-form-item>
        <!--页数-->
        <el-form-item label="页数" prop="amountOfPages" class="mangeShowLook" style="width: 50%">
          <el-input v-model="paramsJj.amountOfPages"></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="jjFileEdit9Btn">保存</el-button>
        <el-button @click="jjFileEdit9">重置</el-button>
        <el-button @click="dialogJj9 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 删除 -->
    <el-dialog :visible.sync="dialogJj10" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除按件确认
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要删除此数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="jjDelete10Btn">确定</el-button>
        <el-button @click="dialogJj10 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 按件--查看（下表格） -->
    <el-dialog :visible.sync="dialogJj11" width="1111px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/ck.png" alt="">
        查看材料
      </div>
      <div class="showClearLook">
        <div class="bigDog menuShrink black-tree" style="float: left;height: 100%;min-height: unset;max-height: unset;">
          <el-tree
            :data="treTable"
            :props="defaultProps"
            :check-strictly="true"
            :default-expand-all="true"
            :expand-on-click-node="false"
            :highlight-current="true"
            accordion
            @node-click="handleNodeClick">
          </el-tree>
        </div>
        <div style="float: left;margin-left: 10px;width: 78%; max-height: 600px; overflow: auto;">
          <!--<embed :src="embedOnce" width="100%" height="600px"/>-->
          <iframe :src="embedOnce" width="100%" height="600px"></iframe>
        </div>
        <div class="clear"></div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <el-button @click="pdfDownload" :disabled="showLookDownload">下载</el-button>
        <el-button @click="dialogJj11 = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {getFonds, listSeriesByFondsAndRole, listSeriesByFonds, BASICURL} from '@/js/turnOverData'
import { valueIndex } from '@/js/transitionText'
import {listArchiveZL, listDoc, listUserByDeptId, listDept, addArchiveZL, findSeriesCode, editFileAnJian, updateFileAnJian,
  updateSpecialFileAnJia, deleteArchiveZL, listAllDept, findArchiveZL, saveCaseNoByBatch, uploadExcelH5, uploadExcel,
  uploadExcelZl, listFileType, listGzdj, listLwxt, coverElectronicSeal, removeElectronicSeal, saveFileWrk, listAnJianTree,
  powerDocView, uploadPicture, saveZlUploadDoc, editDocAnJian, updateDoc, deleteDoc, listThArchiveZL, listAccountArchiveZL,
  saveAccountFile, getAccountFile, updateAccountFile, listAnJianTreeLeft, powerDocViewLeft} from '@/js/fileMangeOver'
export default {
  name: 'fileKj',
  props: {
    paramsC: Object,
    tableDataC: Array,
    tableDataBottomC: Array,
  },
  data () {
    const yearCodeAudit = (rules, item, callback) => {
      let reg = /^[0-9]*$/
      if (!reg.test(item)) {
        callback('请输入数字')
      } else if (item.length > 4 || item.length < 4) {
        callback('输入长度为4')
      } else {
        callback()
      }
    }
    const c220Audit = (rules, item, callback) => {
      let reg = /^[0-9]*$/
      if (!reg.test(item)) {
        callback('请输入数字')
      } else {
        callback()
      }
    }
    return {
      /* 此处表格数据 */
      params: {c0: 6, page: 1, rows: 10, fonds: 1374133141812, series1: 1379482316593}, // 对应 全宗、类型、上一级表格数据
      paramsBottom: {page: 1, rows: 1, total: 0}, // 对应 全宗、类型、上一级表格数据
      paramsSearch: {page: 1, rows: 10, total: 0}, // 按件--批量设置盒号（检索）
      paramsJj: {}, // 按件--录入 or 编辑 or 特殊编辑 or 修改（下表格）
      paramsJjEdit: {}, // 按件--编辑

      /* 此处select类型 */
      fullZong: [], // 全宗
      FondsAndRole: [], // 类型一级
      FondsAndRoleTwo: [], // 类型二级
      FondsAndRoleThree: [], // 类型三级

      /* 此处表格 */
      tableData: [], // 上表格第一级
      tableDataBottom: [], // 下表格第一级
      tableDataDialogAJ5: [], // 批量设置盒号

      /* 此处表格多选选择数据 */
      tableDataTopOnce: [], // 上表格第一级
      tableDataTopOnceItem: {}, // 上表格第一级(单个数据）
      tableDataBottomOnce: [], // 下表格第一级

      /* form判断 */
      rulesJj: {
        c220: [{required: true, message: '请填写案卷号', trigger: 'blur'}, {validator: c220Audit}],
        c15: [{required: true, message: '请填写类别', trigger: 'blur'}],
        titleProper: [{required: true, message: '请填写卷（册、袋）标题', trigger: 'blur'}],
        c160: [{required: true, message: '请填写凭证起号', trigger: 'blur'}],
        c162: [{required: true, message: '请填写凭证止号', trigger: 'blur'}],
        yearCode: [{required: true, message: '请填写年度', trigger: 'blur'}, {validator: yearCodeAudit}],
        c113: [{required: true, message: '请填写所属部门', trigger: 'blur'}],
        c163: [{required: true, message: '请填写分类号', trigger: 'blur'}],
        retentionPeriod: [{required: true, message: '请选择保管期限', trigger: 'change'}],
        dateOfCreation: [{required: true, message: '请选择开始日期', trigger: 'change'}],
        dateOfEnd: [{required: true, message: '请选择结束日期', trigger: 'change'}],
      },

      /* select类型 */
      retentionPeriod: [
        {'name': '永久', 'itemValue': '3'},
        {'name': '长期', 'itemValue': '2'},
        {'name': '短期', 'itemValue': '1'},
        {'name': '10年', 'itemValue': '5'},
        {'name': '15年', 'itemValue': '6'},
        {'name': '30年', 'itemValue': '8'}
      ], // 保管期限
      c58: [{'name': '否', 'itemValue': '1'}, {'name': '是', 'itemValue': '0'}], // 是否为原件
      c59: [{'name': '否', 'itemValue': '1'}, {'name': '是', 'itemValue': '0'}], // 是否在库
      c89: [], // 拟稿人
      c90: [], // 拟稿部门
      c92: [], // 来文系统
      c100: [], // 文件类型
      c112: [], // 盖章类型
      openingType: [
        {'name': '内部', 'itemValue': '2'},
        {'name': '公开', 'itemValue': '1'},
        {'name': '受控', 'itemValue': '3'},
        {'name': '广发商密三级', 'itemValue': '4'},
        {'name': '广发商密二级', 'itemValue': '5'},
        {'name': '广发商密一级', 'itemValue': '6'}
      ], // 公开属性
      filingDept: [], // 归档部门
      yjc89Arr: [], // 拟稿人--检索
      scopeArr: [
        {id: 3, text: '3cm'},
        {id: 5, text: '5cm'}
      ], // 打印脊背--尺寸

      /* 单个数据 */
      addCaseNo: '',
      editCaseNo: '',
      imgVal: [],
      fileErrorMsg: '',
      scope: '',
      embedOnce: '',
      showLookDownload: true,
      showLookDownloadId: '',
      // dateShowLook: 2,
      dateShowLook: 2,

      /* tree数据 */
      treTable: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      /* 弹框 */
      dialogJj1: false,
      dialogJj2: false,
      dialogJj3: false,
      dialogJj4: false,
      dialogJj5: false,
      dialogJj6: false,
      dialogJj7: false,
      dialogJj8: false,
      dialogJj9: false,
      dialogJj10: false,
      dialogJj11: false,
    }
  },
  methods: {
    // 获取上表格第一级数据
    showList (val) {
      this.tableData = []
      // val.c5 = 2
      if (this.params.series2) {
        listAccountArchiveZL(val).then(res => {
          if (res.data.rows.length <= 0) {
            this.$message.error('该条件下查无数据！')
            this.tableData = []
          } else {
            this.tableData = res.data.rows
            this.params.total = res.data.total
            this.tableData.forEach(item => {
              item.checkOnce = false
            })
            this.dialogJj4 = false
          }
        })
      }
      // this.$forceUpdate()
    },
    // 上表格多选
    handleSelectionChange (val, item) {
      this.tableDataBottom = []
      item.checkOnce = !item.checkOnce
      this.tableDataTopOnce = val
      this.tableDataTopOnceItem = {}
      if (this.tableDataTopOnce.length < 0) {
        this.showListBottom(this.paramsBottom)
      }
      val.forEach(items => {
        if (items.checkOnce) {
          this.tableDataTopOnceItem = items
        }
      })
    },
    handleSelectionChangeAll (val) {
      if (val.length > 0) {
        for (let i of this.tableData) {
          // i.checkOnce = !i.checkOnce
          i.checkOnce = true
        }
      } else {
        for (let i of this.tableData) {
          // i.checkOnce = !i.checkOnce
          i.checkOnce = false
        }
      }
      this.tableDataTopOnce = val
      // for (let i in this.tableDataTopOnce) {
      //   if (!this.tableDataTopOnce[i].checkOnce) {
      //     this.tableDataTopOnce[i].checkOnce = true
      //   }
      // }
    },
    // 上表格行内点击
    handleSelectionClick (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTable.toggleRowSelection(item, true)
        item.checkOnce = true
        this.paramsBottom.page = 1
        this.paramsBottom.rows = 5
        this.paramsBottom.fileId = item.id
        this.showListBottom(this.paramsBottom)
      } else {
        this.$refs.multipleTable.toggleRowSelection(item, false)
        item.checkOnce = false
      }
    },
    // 上表格分页点击
    handleCurrentChange (val) {
      this.params.page = val
      this.showList(this.params)
    },
    // 下表格第一级数据
    showListBottom (val) {
      listDoc(val).then(res => {
        if (res.data.rows.length <= 0) {
          this.$message.error('该案件暂无材料')
          this.tableDataBottom = []
        } else {
          this.tableDataBottom = res.data.rows
          this.paramsBottom.total = res.data.total
          this.tableDataBottom.forEach(item => {
            item.checkOnce = false
          })
        }
      })
    },
    // 下表格多选
    handleSelectionChangeBottom (val, item) {
      item.checkOnce = !item.checkOnce
      this.tableDataBottomOnce = val
      if (this.tableDataBottomOnce.length > 1) {
        this.$refs.multipleTableBottom.toggleRowSelection(this.tableDataBottomOnce[0])
      }
    },
    handleSelectionChangeBottomAll (val) {
      this.tableDataBottomOnce = val
      for (let i in this.tableDataBottomOnce) {
        if (!this.tableDataBottomOnce[i].checkOnce) {
          this.tableDataBottomOnce[i].checkOnce = true
        }
      }
    },
    // 下表格行内点击
    handleSelectionClickBottom (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTableBottom.toggleRowSelection(item)
        item.checkOnce = true
      } else {
        this.$refs.multipleTableBottom.clearSelection()
        item.checkOnce = false
      }
    },
    // 下表格分页点击
    handleCurrentChangeBottom (val) {
      this.paramsBottom.page = val
      this.showListBottom(this.paramsBottom)
    },

    /* 弹框开始 */
    handleCloseOne () {
      this.dialogJj1 = false
      this.dialogJj2 = false
      this.dialogJj3 = false
      this.dialogJj4 = false
      this.dialogJj5 = false
      this.dialogJj6 = false
      this.dialogJj7 = false
      this.dialogJj8 = false
      this.dialogJj9 = false
      this.dialogJj10 = false
      this.dialogJj11 = false
    },
    handleCloseTwo () {
    },
    // 录入
    jjLuRu1 () {
      this.clearFiles('ruleFormAddJj')
      this.paramsJj = {}
      this.dialogJj1 = true
    },
    jjLuRuAdd1Btn () {
      this.$refs.ruleFormAddJj.validate((valid) => {
        if (valid) {
          if (this.paramsJj.dateOfCreation == '' || this.paramsJj.dateOfCreation == undefined
            || this.paramsJj.dateOfEnd == '' || this.paramsJj.dateOfEnd == undefined) {
            this.$message.error('请选择起止时间')
          } else {
            this.paramsJj.series2 = this.params.series2
            this.paramsJj.fonds = this.params.fonds
            saveAccountFile(this.paramsJj).then(res => {
              if (res.code == 0) {
                this.$message.success(res.message)
                this.dialogJj1 = false
                this.resetParams()
                this.showList(this.params)
              } else {
                this.$message.error(res.message)
                this.dialogJj1 = false
              }
            })
          }
        }
      })
    },
    // 编辑
    jjLuRu2 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        getAccountFile({id: this.tableDataTopOnceItem.id}).then(res => {
          this.paramsJj = res.data
          this.dialogJj2 = true
          this.clearFiles('ruleFormEditJj')
        })
      }
    },
    jjLuRuEdit2Btn () {
      this.$refs.ruleFormEditJj.validate((valid) => {
        if (valid) {
          this.paramsJj.series2 = this.params.series2
          this.paramsJj.fonds = this.params.fonds
          updateAccountFile(this.paramsJj).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message)
              this.dialogJj2 = false
              this.resetParams()
              this.showList(this.params)
            } else {
              this.$message.error(res.message)
              this.dialogJj2 = false
            }
          })
        }
      })
    },
    // 删除
    jjDelete3 () {
      let item = this.$onceWay().onceTableListTwo(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogJj3 = true
      }
    },
    jjDelete3Btn () {
      let arr = ''
      for (let i of this.tableDataTopOnce) {
        arr += i.id + ','
      }
      deleteArchiveZL({ids: arr}).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogJj3 = false
          this.resetParams()
          this.showList(this.params)
        } else {
          this.$message.error(res.message)
          this.dialogJj3 = false
        }
      })
    },
    // 检索
    resetSearch () {
      this.dialogJj4 = true
      this.params = {
        c0: 6,
        rows: 10,
        fonds: this.params.fonds,
        series1: this.params.series1,
        series2: this.params.series2,
        series3: this.params.series3,
        total: this.params.total
      }
      this.params.page = 1
    },
    // 监所内的搜索--拟稿人
    remoteMethodMan (val) {
      let params = {
        orgFlag1: -10000,
        q: val
      }
      listUserByDeptId(params).then(res => {
        this.yjc89Arr = res
      })
    },
    // 保存
    jjAdd5 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogJj5 = true
      }
    },
    jjAdd5Btn () {
      let arr = ''
      for (let i of this.tableDataTopOnce) {
        arr += i.id + ','
      }
      saveFileWrk({ids: arr}).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogJj5 = false
          this.resetParams()
          this.showList(this.params)
        } else {
          this.$message.error(res.message)
          this.dialogJj5 = false
          this.resetParams()
          this.showList(this.params)
        }
      })
    },
    // 打印目录
    jjDownload6 () {
      if (this.tableDataTopOnce.length < 1) {
        this.dialogJj6 = true
      } else {
        try {
          for (let i in this.tableDataTopOnce) {
            if (this.tableDataTopOnce[i].itemNo == null || this.tableDataTopOnce[i].itemNo == '') {
              // throw(`系统提示, "行号为："${(Number(i) + 1)}"的数据没有件号，不可以打印!`)
              throw(`系统提示, 没有件号，不可以打印!`)
            } else if (this.tableDataTopOnce[i].caseNo == null || this.tableDataTopOnce[i].caseNo == '') {
              // throw(`系统提示, "行号为："${(Number(i) + 1)}"的数据没有盒号，不可以打印!`)
              throw(`系统提示, 没有盒号，不可以打印!`)
            } else if (this.tableDataTopOnce[i].retentionPeriod == null || this.tableDataTopOnce[i].retentionPeriod == '') {
              // throw(`系统提示, "行号为："${(Number(i) + 1)}"的数据没有保管期限，不可以打印!`)
              throw(`系统提示, 没有保管期限，不可以打印!`)
            } else {
              let arr = ''
              arr += this.tableDataTopOnce[i].id + ','
              let params = {
                fileIds: arr,
                series: this.params.series2,
                fonds: this.params.fonds
              }
              valueIndex().exportFiles('/gdda-new/gdda/archiveZL/print', params, '归档文件目录.doc', 'get')
            }
          }
        } catch (e) {
          this.$message.error(e)
        }
      }
    },
    jjDownload6Btn () {
      let params = {
        fileIds: 'all',
        series: this.params.series2,
        fonds: this.params.fonds
      }
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/print', params, '归档文件目录.doc', 'get')
      this.dialogJj6 = false
    },
    // 打印脊背
    jjDownload7 () {
      let item = this.$onceWay().onceTableListTwo(this.tableDataTopOnce)
      if (item == 1) {
        this.paramsJj = {}
        try {
          for (let i in this.tableDataTopOnce) {
            if (this.tableDataTopOnce[i].itemNo == null || this.tableDataTopOnce[i].itemNo == '') {
              // throw(`系统提示, "行号为："${(Number(i) + 1)}"的数据没有件号，不可以打印!`)
              throw(`系统提示, 没有件号，不可以打印!`)
            } else if (this.tableDataTopOnce[i].caseNo == null || this.tableDataTopOnce[i].caseNo == '') {
              // throw(`系统提示, "行号为："${(Number(i) + 1)}"的数据没有盒号，不可以打印!`)
              throw(`系统提示, 没有盒号，不可以打印!`)
            } else if (this.tableDataTopOnce[i].retentionPeriod == null || this.tableDataTopOnce[i].retentionPeriod == '') {
              // throw(`系统提示, "行号为："${(Number(i) + 1)}"的数据没有保管期限，不可以打印!`)
              throw(`系统提示, 没有保管期限，不可以打印!`)
            } else {
              this.dialogJj7 = true
              // let arr = ''
              // arr += this.tableDataTopOnce[i].id + ','
              // let params = {
              //   fileIds: arr,
              //   series: this.params.series2,
              //   fonds: this.params.fonds
              // }
              // valueIndex().exportFiles('/gdda-new/gdda/archiveZL/printAnjianJibei', params, '归档文件目录.doc', 'get')
            }
          }
        } catch (e) {
          this.$message.error(e)
        }
      }
    },
    jjDownload7Btn () {
      let arr = ''
      for (let i of this.tableDataTopOnce) {
        arr += i.id + ','
      }
      let params = {
        fileIds: arr,
        scope: this.paramsJj.scope
      }
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/printAnjianJibei', params, '脊背文件目录.doc', 'get')
      this.dialogJj7 = false
    },

    /* 上传--下表格 */
    jjFileAdd8 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogJj8 = true
        this.imgVal = []
        this.clearFilesTwo('jjFileOne')
      }
    },
    handleChangeOne (file, fileList) {
      if (this.imgVal.length >= 1) {
        this.$message.error('只能上传一个文件')
      } else {
        let formData = new FormData()
        formData.append('picture', file.raw)
        formData.append('type', 'zl')
        formData.append('name', 'file')
        uploadPicture(formData).then(res => {
          if (res.code == 0) {
            this.imgVal.push(res.data.pathAndMD5)
          } else {
            this.$message.error(res.message)
          }
        })
      }
    },
    // 删除上传
    handleRemoveOne (val, item) {
      this.imgVal.splice(val, 1)
    },
    jjFileAdd8Btn () {
      let formData = new FormData()
      formData.append('subId', this.tableDataTopOnceItem.id)
      formData.append('imgVal', JSON.stringify(this.imgVal))
      formData.append('bs', 'anjian')
      saveZlUploadDoc(formData).then(res => {
        if (res.code == 0) {
          this.$message.success('上传成功')
          this.paramsBottom.page = 1
          this.paramsBottom.total = 0
          this.showListBottom(this.paramsBottom)
          this.dialogJj8 = false
        } else {
          if (res.data.optFlag == -1) {
            this.$message.error(`重复文件：${res.data.msg}；上传失败！`)
            this.dialogJj8 = false
          } else {
            this.$message.error(res.data.msg)
            this.dialogJj8 = false
          }
        }
      })
    },
    // 修改
    jjFileEdit9 () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.paramsJj = {}
        editDocAnJian({docId: this.tableDataBottomOnce[0].id}).then(res => {
          this.dialogJj9 = true
          this.paramsJj = res.data
          // this.clearFiles('rulesJjEdit')
        })
      }
    },
    jjFileEdit9Btn () {
      let reg = /^[0-9]*$/
      if (this.paramsJj.pageNo == null || this.paramsJj.pageNo == '' || this.paramsJj.amountOfPages == null || this.paramsJj.amountOfPages == '') {
        this.paramsJj.bs = 'anjian'
        this.paramsJj.id = this.tableDataBottomOnce[0].id
        updateDoc(this.paramsJj).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogJj9 = false
            this.paramsBottom.page = 1
            this.paramsBottom.total = 0
            this.showListBottom(this.paramsBottom)
          } else {
            this.$message.error('修改失败')
            this.dialogJj9 = false
          }
        })
      } else {
        if (!reg.test(this.paramsJj.pageNo)) {
          this.$message.error('页号请输入数字')
        } else if (!reg.test(this.paramsJj.amountOfPages)) {
          this.$message.error('页数请输入数字')
        } else {
          this.paramsJj.bs = 'anjian'
          this.paramsJj.id = this.tableDataBottomOnce[0].id
          updateDoc(this.paramsJj).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message)
              this.dialogJj9 = false
              this.paramsBottom.page = 1
              this.paramsBottom.total = 0
              this.showListBottom(this.paramsBottom)
            } else {
              this.$message.error('修改失败')
              this.dialogJj9 = false
            }
          })
        }
      }
    },
    // 删除
    jjDelete10 () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.dialogJj10 = true
      }
    },
    jjDelete10Btn () {
      let prams = {
        id: this.tableDataBottomOnce[0].id,
        bs: 'anjian'
      }
      deleteDoc(prams).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogJj10 = false
          this.paramsBottom.page = 1
          this.showListBottom(this.paramsBottom)
        } else {
          this.$message.error(res.message)
          this.dialogJj10 = false
        }
      })
    },

    // 查看
    dateShowLookLook () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.dialogJj11 = true
        let params = {
          id: this.tableDataTopOnce[0].id,
          bs: 'anjian'
        }
        listAnJianTreeLeft(params).then(res => {
          if (res.code == 0) {
            this.treTable = res.data
          }
        })
      }
    },
    handleNodeClick (val) {
      if (val.attributes) {
        powerDocViewLeft({id: val.attributes.id}).then(res => {
          if (res.code == 0) {
            if (res.data.optFlag == 0) {
              this.embedOnce = `${BASICURL}/gdda-new/gdda/util/viewPdf?docId=${val.id}`
              this.showLookDownload = true
              this.showLookDownloadId = val
              this.$forceUpdate()
            } else if (res.data.optFlag == -1) {
              this.$message.error('对不起，你访问的文件还未扫描')
              this.showLookDownload = true
              this.showLookDownloadId = ''
            } else if (res.data.optFlag == 2) {
              this.$message.info('该文件非PDF文件，是否要进行下载?')
              this.showLookDownload = false
              this.showLookDownloadId = val
            }
          }
        })
      } else {
        this.showLookDownload = true
        this.showLookDownloadId = ''
      }
    },
    pdfDownload () {
      let textNew = this.showLookDownloadId.text.split('.')[1]
      let params = {
        id: this.showLookDownloadId.id,
        mode: 'anjian'
      }
      valueIndex().exportFiles('/gdda-new/gdda/util/downLoadFile', params, `文件下载.${textNew}`, 'get')
    },
    // 重置
    restBtn () {
      this.paramsJj = {}
    },
    methodSeries () {
      let item = this.params.series3 || this.params.series2 || this.params.series1
      return item
    },
    // 清除掉回调表单验证
    clearFiles (val) {
      if (this.$refs[val]) {
        this.$nextTick(() => {
          this.$refs[val].clearValidate()
        })
      }
    },
    clearFilesTwo (val) {
      if (this.$refs[val]) {
        this.$nextTick(() => {
          this.$refs[val].clearFiles()
        })
      }
    },
    // params清空，重来
    resetParams () {
      this.params.page = 1
      this.params.total = 0
    },
  },
  watch: {
    paramsC (val) {
      this.params = val
    },
    tableDataC (val) {
      this.tableData = val
      if (val.length < 1) {
        this.tableDataTopOnce = []
        this.tableDataTopOnceItem = {}
      }
    },
    tableDataBottomC (val) {
      this.tableDataBottom = val
      if (val.length < 1) {
        this.tableDataBottomOnce = []
      }
    }
  },
  created () {
    this.params = this.paramsC
    this.tableData = this.tableDataC
    this.tableDataBottom = this.tableDataBottomC
    // listAllDept().then(res => {
    //   this.filingDept = res.data
    // })
  }
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  .search-select {
    float: left;
    margin: 4px 0;
    vertical-align: middle;
    line-height: 40px;
    label {
      font-size: 14px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 143px;
    }
  }
  .search-selectOnce {
    margin: 5px 6px;
    height: 35px;
    border:1px solid #DEDEDE;
    cursor: auto;
  }
  .searchBtn {
    float: left;
    line-height: 47px;
    font-size: 13px;
    cursor: pointer;
    img{
      vertical-align: middle;
      margin-right: 4px;
    }
  }
  .mangeShowLook {
    float: left;
    width: 33%;
    margin-bottom: 20px;
    /deep/.el-input.is-disabled .el-input__inner{
      background-color: #fff!important;
      color: #606266!important;
    }
  }
  .hurdleAllHeHao {
    /deep/.el-dialog__body {
      padding: 0;
    }
  }
  .searchForm {
    /deep/.el-form-item {
      margin-bottom: 10px;
    }
    .el-select {
      width: 100%;
    }
  }

  .showClearLook{
    height: 600px;
    overflow: auto;
  }
</style>
