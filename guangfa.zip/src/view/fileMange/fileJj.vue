<!-- 基建 -->
<template>
  <div>
    <!-- 上操作--基建 -->
    <div style="background-color: #F4F4F4;">
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="dateShowLookLook('1')">
        <img src="../../assets/turnOver/ck.png" alt="">
        <span>查看</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="searchContent">
        <img src="../../assets/turnOver/js.png" alt="">
        <span>检索</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="addProjectContent">
        <img src="../../assets/turnOver/tj.png" alt="">
        <span>添加项目</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="editProjectContent">
        <img src="../../assets/turnOver/xg.png" alt="">
        <span>修改项目</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="deleteBtn5">
        <img src="../../assets/turnOver/delete.png" alt="">
        <span>删除</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="FileDownload6">
        <img src="../../assets/turnOver/xz.png" alt="">
        <span>下载录入Excel目录模板</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="FileAdd7">
        <img src="../../assets/turnOver/dr.png" alt="">
        <span>导入Excel目录</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="FileGui8">
        <img src="../../assets/turnOver/gt.png" alt="">
        <span>归档</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="FileDownload8">
        <img src="../../assets/turnOver/dy.png" alt="">
        <span>打印脊背</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="fileDownload9">
        <img src="../../assets/turnOver/dy.png" alt="">
        <span>打印卷内目录</span>
      </div>
      <div class="searchBtn search-selectOnce"></div>
      <div class="searchBtn" @click="addSave10">
        <img src="../../assets/turnOver/bc.png" alt="">
        <span>保存</span>
      </div>
      <div class="clear"></div>
    </div>
    <!-- 上表格--基建 -->
    <div class="all-Table">
      <el-table
        ref="multipleTable"
        :data="tableData"
        stripe
        border
        @select="handleSelectionChange"
        @select-all="handleSelectionChangeAll"
        @cell-click="handleSelectionClick">
        <el-table-column
          type="index"
          align="center"
          width="60">
        </el-table-column>
        <el-table-column
          type="selection"
          align="center"
          width="60">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c0"
          label="项目代号">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="c11"
          label="项目名称">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="projectSite"
          label="工程地点">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="openingType"
          label="公开属性">
          <template slot-scope="scope">
            <span v-if="scope.row.openingType == 1">公开</span>
            <span v-else-if="scope.row.openingType == 2">内部</span>
            <span v-else-if="scope.row.openingType == 3">受控</span>
            <span v-else-if="scope.row.openingType == 4">广发商密三级</span>
            <span v-else-if="scope.row.openingType == 5">广发商密二级</span>
            <span v-else-if="scope.row.openingType == 6">广发商密一级</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="retentionPeriod"
          label="保管期限">
          <template slot-scope="scope">
            <span v-if="scope.row.retentionPeriod == 1">短期</span>
            <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
            <span v-else-if="scope.row.retentionPeriod == 3">永久</span>
            <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
            <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
            <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
          </template>
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="seriesCode"
          label="分类号">
        </el-table-column>
        <el-table-column
          show-overflow-tooltip
          prop="filingDept"
          label="归档部门">
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <div class="pageLayout">
      <el-pagination
        @current-change="handleCurrentChange"
        :current-page="params.page"
        :page-size="params.rows"
        layout="prev, pager, next, jumper"
        :total="params.total">
      </el-pagination>
    </div>
    <!--下表格--基建 -->
    <div>
      <el-tabs  v-model="yeWuActiveName" type="border-card"  @tab-click="yeWuTabsClick">
        <el-tab-pane label="案卷层" name="案卷层">
          <!-- 下操作--基建 -->
          <div style="background-color: #F4F4F4;">
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="dateShowLookLookTwo('2')">
              <img src="../../assets/turnOver/ck.png" alt="">
              <span>查看</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="searchBottom">
              <img src="../../assets/turnOver/js.png" alt="">
              <span>检索</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="addBottomContent">
              <img src="../../assets/turnOver/tj.png" alt="">
              <span>添加案卷</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="editBottomContent">
              <img src="../../assets/turnOver/xg.png" alt="">
              <span>修改案卷</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="deleteBottomContent">
              <img src="../../assets/turnOver/delete.png" alt="">
              <span>删除案卷</span>
            </div>
            <div class="clear"></div>
          </div>
          <div class="all-Table">
            <el-table
              ref="multipleTableBottom"
              :data="tableDataBottom"
              stripe
              border
              @select="handleSelectionChangeBottom"
              @select-all="handleSelectionChangeBottomAll"
              @cell-click="handleSelectionClickBottom">
              <el-table-column
                type="selection"
                align="center"
                width="55">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="officeArchivalCode"
                label="档号"
                width="200">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="folderNo"
                label="案卷号"
                width="140">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="yearCode"
                label="年度"
                width="140">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="titleProper"
                label="案卷题名"
                width="300">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="c11"
                label="项目名称"
                width="140">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="openingType"
                label="公开属性"
                width="120">
                <template slot-scope="scope">
                  <span v-if="scope.row.openingType == 1">公开</span>
                  <span v-else-if="scope.row.openingType == 2">内部</span>
                  <span v-else-if="scope.row.openingType == 3">受控</span>
                  <span v-else-if="scope.row.openingType == 4">广发商密三级</span>
                  <span v-else-if="scope.row.openingType == 5">广发商密二级</span>
                  <span v-else-if="scope.row.openingType == 6">广发商密一级</span>
                </template>
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="retentionPeriod"
                label="保管期限"
                width="120">
                <template slot-scope="scope">
                  <span v-if="scope.row.retentionPeriod == 1">短期</span>
                  <span v-else-if="scope.row.retentionPeriod == 2">长期</span>
                  <span v-else-if="scope.row.retentionPeriod == 3">永久</span>
                  <span v-else-if="scope.row.retentionPeriod == 5">10年</span>
                  <span v-else-if="scope.row.retentionPeriod == 6">15年</span>
                  <span v-else-if="scope.row.retentionPeriod == 8">30年</span>
                </template>
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="seriesCode"
                label="分类号"
                width="100">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="filingDept"
                label="归档部门"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="filingUser"
                label="归档人"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="filingDate"
                label="归档日期"
                width="160">
              </el-table-column>
            </el-table>
          </div>
          <!-- 下分页 -->
          <div class="pageLayout">
            <el-pagination
              @current-change="handleCurrentChangeBottom"
              :current-page="paramsBottom.page"
              :page-size="paramsBottom.rows"
              layout="prev, pager, next, jumper"
              :total="paramsBottom.total">
            </el-pagination>
          </div>
        </el-tab-pane>
        <el-tab-pane label="文件层" name="文件层">
          <!-- 下操作--基建 -->
          <div style="background-color: #F4F4F4;">
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="dateShowLookLookTwoRight('3')">
              <img src="../../assets/turnOver/ck.png" alt="">
              <span>查看</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="searchBottomTwo">
              <img src="../../assets/turnOver/js.png" alt="">
              <span>检索</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="addBottomContent16">
              <img src="../../assets/turnOver/tj.png" alt="">
              <span>添加案卷</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="editBottomContent17">
              <img src="../../assets/turnOver/xg.png" alt="">
              <span>修改案卷</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="deleteBottomContent18">
              <img src="../../assets/turnOver/delete.png" alt="">
              <span>删除文件</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="fileDownload19">
              <img src="../../assets/turnOver/sc.png" alt="">
              <span>上传</span>
            </div>
            <div class="searchBtn search-selectOnce"></div>
            <div class="searchBtn" @click="fileDelete20">
              <img src="../../assets/turnOver/delete.png" alt="">
              <span>删除材料</span>
            </div>
            <div class="clear"></div>
          </div>
          <div class="all-Table">
            <el-table
              ref="multipleTableBottomRight"
              :data="tableDataBottom"
              stripe
              border
              @select="handleSelectionChangeBottomTwo"
              @select-all="handleSelectionChangeBottomAllTwo"
              @cell-click="handleSelectionClickBottomTwo">
              <el-table-column
                type="selection"
                align="center"
                width="55">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="c220"
                label="案卷号"
                width="130">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="itemNo"
                label="序号"
                width="130">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="c3"
                label="文件编号"
                width="437">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="titleProper"
                label="文件题名"
                width="120">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="c113"
                label="责任者"
                width="120">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="dateOfCreation"
                label="日期"
                width="100">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="pageNo"
                label="页号"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="openingType"
                label="公开属性"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="retentionPeriod"
                label="保管期限"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="seriesCode"
                label="分类号"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="filingDept"
                label="归档部门"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="filingUser"
                label="归档人"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="filingDate"
                label="归档日期"
                width="160">
              </el-table-column>
              <el-table-column
                show-overflow-tooltip
                prop="c8"
                label="备注"
                width="160">
              </el-table-column>
            </el-table>
          </div>
          <!-- 下分页 -->
          <div class="pageLayout">
            <el-pagination
              @current-change="handleCurrentChangeBottomTwo"
              :current-page="paramsBottomTwo.page"
              :page-size="paramsBottomTwo.rows"
              layout="prev, pager, next, jumper"
              :total="paramsBottomTwo.total">
            </el-pagination>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>

    <!-- 查看（下表格） -->
    <el-dialog :visible.sync="dialogShowLook" width="1314px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/ck.png" alt="">
        查看材料
      </div>
      <div class="showClearLook">
        <div class="bigDog menuShrink black-tree" style="width: 300px;float: left;height: 100%;min-height: unset;max-height: unset;">
          <el-tree
            ref="lookDataTree"
            :data="treTable"
            :props="defaultProps"
            :check-strictly="true"
            :default-expand-all="true"
            :expand-on-click-node="false"
            :highlight-current="true"
            accordion
            @node-click="handleNodeClick"
            node-key="id">
          </el-tree>
        </div>
        <div style="float: left;margin-left: 10px;width: 72%; max-height: 600px; overflow: auto;">
          <el-tabs v-model="yeWuActiveNameShowLook" type="border-card" @tab-click="yeWuTabsShowLookClick">
            <el-tab-pane label="基本信息" name="基本信息">
              <el-form v-if="lookCheck == 1" :model="paramsYw" label-width="100px" class="demo-ruleForm">
                <el-form-item label="项目代号" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.project.c0"></el-input>
                </el-form-item>
                <el-form-item label="项目名称" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.project.c11"></el-input>
                </el-form-item>
                <el-form-item label="工程地点">
                  <el-input v-model="paramsYw.project.projectSite"></el-input>
                </el-form-item>
                <div class="clear"></div>
                <el-form-item label="归档部门" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.project.filingDept"></el-input>
                </el-form-item>
                <el-form-item label="归档人" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.project.filingUser"></el-input>
                </el-form-item>
                <el-form-item label="归档日期" class="mangeShowLook" style="width: 50%;">
                  <el-date-picker v-model="paramsYw.project.filingDate" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" placeholder="选择时间"></el-date-picker>
                </el-form-item>
                <el-form-item label="分类号" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.project.seriesCode"></el-input>
                </el-form-item>
              </el-form>
              <el-form v-if="lookCheck == 2" :model="paramsYw" label-width="100px" class="demo-ruleForm">
                <el-form-item label="项目名称" class="mangeShowLook" style="width: 50%;">
                  <el-input type="text" v-model="paramsYw.folder.c11"></el-input>
                </el-form-item>
                <el-form-item label="分类号" class="mangeShowLook" style="width: 50%;">
                  <el-input type="text" v-model="paramsYw.folder.seriesCode"></el-input>
                </el-form-item>
                <el-form-item label="案卷题名">
                  <el-input type="text" v-model="paramsYw.folder.titleProper"></el-input>
                </el-form-item>
                <div class="clear"></div>
                <el-form-item label="案卷号" class="mangeShowLook" style="width: 50%;">
                  <el-input type="text" v-model="paramsYw.folder.folderNo"></el-input>
                </el-form-item>
                <el-form-item label="年度" class="mangeShowLook" style="width: 50%;">
                  <el-input type="text" v-model="paramsYw.folder.yearCode"></el-input>
                </el-form-item>
                <el-form-item label="归档人" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.folder.filingUser"></el-input>
                </el-form-item>
                <el-form-item label="归档日期" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.folder.filingDate"></el-input>
                </el-form-item>
                <el-form-item label="归档部门" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.folder.filingDept"></el-input>
                </el-form-item>
                <el-form-item label="保管期限" class="mangeShowLook" style="width: 50%;">
                  <el-select v-model="paramsYw.folder.retentionPeriod" filterable placeholder="请选择" style="width: 100%;">
                    <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="备注">
                  <el-input v-model="paramsYw.folder.folderNote"></el-input>
                </el-form-item>
                <el-form-item label="档号" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.folder.officeArchivalCode"></el-input>
                </el-form-item>
                <el-form-item label="项目代号" class="mangeShowLook" style="width: 50%;">
                  <el-input v-model="paramsYw.folder.c0"></el-input>
                </el-form-item>
              </el-form>
              <el-form v-if="lookCheck == 3" :model="paramsYw" label-width="100px" class="demo-ruleForm">
                <el-form-item label="序号" class="mangeShowLook" style="width: 33%;">
                  <el-input type="text" v-model="paramsYw.file.itemNo"></el-input>
                </el-form-item>
                <el-form-item label="文件编号" class="mangeShowLook" style="width: 33%;">
                  <el-input type="text" v-model="paramsYw.file.c3"></el-input>
                </el-form-item>
                <el-form-item label="责任者" class="mangeShowLook" style="width: 33%;">
                  <el-input type="text" v-model="paramsYw.file.c113"></el-input>
                </el-form-item>
                <el-form-item label="文件题名">
                  <el-input type="text" v-model="paramsYw.file.titleProper"></el-input>
                </el-form-item>
                <div class="clear"></div>
                <el-form-item label="页号" class="mangeShowLook" style="width: 33%;">
                  <el-input type="text" v-model="paramsYw.file.pageNo"></el-input>
                </el-form-item>
                <el-form-item label="保管期限" class="mangeShowLook" style="width: 33%;">
                  <el-select v-model="paramsYw.file.retentionPeriod" filterable placeholder="请选择">
                    <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="分类号" class="mangeShowLook" style="width: 33%;">
                  <el-input type="text" v-model="paramsYw.file.seriesCode"></el-input>
                </el-form-item>
                <el-form-item label="日期" class="mangeShowLook" style="width: 33%;">
                  <el-input type="text" v-model="paramsYw.file.dateOfCreation"></el-input>
                </el-form-item>
                <el-form-item label="公开属性" class="mangeShowLook" style="width: 33%;">
                  <el-select v-model="paramsYw.file.openingType" filterable placeholder="请选择">
                    <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
                  </el-select>
                </el-form-item>
                <el-form-item label="档号" class="mangeShowLook" style="width: 33%;">
                  <el-input v-model="paramsYw.file.officeArchivalCode"></el-input>
                </el-form-item>
                <el-form-item label="归档人" class="mangeShowLook" style="width: 33%;">
                  <el-input v-model="paramsYw.file.filingUser"></el-input>
                </el-form-item>
                <el-form-item label="归档部门" class="mangeShowLook" style="width: 33%;">
                  <el-input v-model="paramsYw.file.filingDept"></el-input>
                </el-form-item>
                <el-form-item label="归档日期" class="mangeShowLook" style="width: 33%;">
                  <el-input v-model="paramsYw.file.filingDate"></el-input>
                </el-form-item>
                <el-form-item label="备注">
                  <el-input type="textarea" v-model="paramsYw.file.c8"></el-input>
                </el-form-item>
              </el-form>
            </el-tab-pane>
            <el-tab-pane v-if="showDianZiShu" label="电子全文" name="电子全文">
              <!--<embed :src="embedOnce" type="application/pdf" width="100%" height="600px"/>-->
              <iframe :src="embedOnce" width="100%" height="600px"></iframe>
            </el-tab-pane>
          </el-tabs>
        </div>
        <div class="clear"></div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="text-align: right">
        <!--<el-button @click="pdfDownload">下载</el-button>-->
        <el-button @click="dialogShowLook = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 查看--下载 -->
    <el-dialog :visible.sync="dialogYW1" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/xz.png" alt="">
        <br>
        <div>该电子全文暂不提供在线浏览，您是否要离线下载此文件？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="yeWuDownLoad1">确定</el-button>
        <el-button @click="dialogYW1 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 检索 -->
    <el-dialog :visible.sync="dialogYW2" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/js.png" alt="">
        检索
      </div>
      <el-form :model="params" ref="ruleFormAjSearch" label-width="100px" class="demo-ruleForm searchForm">
        <!--档案类型-->
        <el-form-item label="档案类型" prop="titleProper">
          <el-input v-model="params.thseriesCode" ></el-input>
        </el-form-item>
        <!--归档部门-->
        <el-form-item label="归档部门" prop="retentionPeriod" class="">
          <el-select v-model="params.thfilingDept" filterable placeholder="请选择">
            <el-option v-for="item in filingDept" :key="item.id" :label="item.text" :value="item.id">
            </el-option>
          </el-select>
        </el-form-item>
        <!--项目编号-->
        <el-form-item label="项目编号" prop="titleProper">
          <el-input v-model="params.thc18" ></el-input>
        </el-form-item>
        <!--年度-->
        <el-form-item label="年度" prop="titleProper">
          <el-input v-model="params.thyearCode" ></el-input>
        </el-form-item>
        <!--状态-->
        <el-form-item label="状态" prop="retentionPeriod" class="">
          <el-select v-model="params.thc5" placeholder="请选择" filterable reserve-keyword>
            <el-option v-for="item in thc5Arr" :key="item.id" :label="item.text" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <!--股票代码-->
        <el-form-item label="股票代码" prop="retentionPeriod" class="">
          <el-input v-model="params.thc10" ></el-input>
        </el-form-item>
        <!--项目单位全称-->
        <el-form-item label="项目单位全称" prop="retentionPeriod" class="">
          <el-input v-model="params.thc24" ></el-input>
        </el-form-item>
        <!--项目名称-->
        <el-form-item label="项目名称" prop="retentionPeriod" class="">
          <el-input v-model="params.thtitleProper" ></el-input>
        </el-form-item>
        <!--项目类型-->
        <el-form-item label="项目类型" prop="retentionPeriod" class="">
          <el-input v-model="params.c117" ></el-input>
        </el-form-item>
        <!--基建类型-->
        <el-form-item label="基建类型" prop="retentionPeriod" class="">
          <el-input v-model="params.thc22" ></el-input>
        </el-form-item>
        <!--承做单位-->
        <el-form-item label="承做单位" prop="retentionPeriod" class="">
          <el-input v-model="params.thc28" ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="showList(params)">确定</el-button>
        <el-button @click="resetSearch">重置</el-button>
        <el-button @click="dialogYW2 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 添加项目 -->
    <el-dialog :visible.sync="dialogYW3" width="888px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        录入项目信息
      </div>
      <el-form :model="paramsYwEdit" :rules="rulesAj" ref="ruleFormYwAddProject" label-width="110px" class="demo-ruleForm">
        <!--项目代号-->
        <el-form-item label="项目代号" prop="c0" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c0" ></el-input>
        </el-form-item>
        <!--项目名称-->
        <el-form-item label="项目名称" prop="c11" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c11" ></el-input>
        </el-form-item>
        <!--工程地点-->
        <el-form-item label="工程地点" prop="projectSite" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.projectSite" ></el-input>
        </el-form-item>
        <!--公开属性-->
        <el-form-item label="公开属性" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.openingType" filterable placeholder="请选择"  :disabled="true">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限"  class="mangeShowLook">
          <el-select v-model="paramsYwEdit.retentionPeriod" filterable placeholder="请选择" :disabled="true">
            <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
        <!--分类号-->
        <el-form-item label="分类号" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.seriesCode" readonly></el-input>
        </el-form-item>
        <!--归档部门-->
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDeptName" readonly></el-input>
        </el-form-item>
        <!--归档人-->
        <el-form-item label="归档人" prop="" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingUserName" readonly></el-input>
        </el-form-item>
        <!--归档日期-->
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDate" readonly></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="addProjectContentBtn">保存</el-button>
        <el-button @click="addProjectContent">重置</el-button>
        <el-button @click="dialogYW3 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 添加项目确定 -->
    <el-dialog :visible.sync="dialogYW33" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        录入确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="addProjectContentBtn33">确定</el-button>
        <el-button @click="dialogYW33 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 修改项目 -->
    <el-dialog :visible.sync="dialogYW4" width="888px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        录入项目信息
      </div>
      <el-form :model="paramsYwEdit" :rules="rulesAj" ref="ruleFormYwEditProject" label-width="110px" class="demo-ruleForm">
        <!--项目代号-->
        <el-form-item label="项目代号" prop="c0" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c0" ></el-input>
        </el-form-item>
        <!--项目名称-->
        <el-form-item label="项目名称" prop="c11" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c11" ></el-input>
        </el-form-item>
        <!--工程地点-->
        <el-form-item label="工程地点" prop="projectSite" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.projectSite" ></el-input>
        </el-form-item>
        <!--公开属性-->
        <el-form-item label="公开属性" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.openingType" filterable placeholder="请选择" :disabled="true">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限"  class="mangeShowLook">
          <el-select v-model="paramsYwEdit.retentionPeriod" filterable placeholder="请选择" :disabled="true">
            <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
        <!--分类号-->
        <el-form-item label="分类号" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.seriesCode" readonly></el-input>
        </el-form-item>
        <!--归档部门-->
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDeptName" readonly></el-input>
        </el-form-item>
        <!--归档人-->
        <el-form-item label="归档人" prop="" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingUserName" readonly></el-input>
        </el-form-item>
        <!--归档日期-->
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDate" readonly></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="editProjectContentBtn4">保存</el-button>
        <el-button @click="editProjectContent">重置</el-button>
        <el-button @click="dialogYW4 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 修改项目确定 -->
    <el-dialog :visible.sync="dialogYW4Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        录入确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="EditProjectContentBtn4Two">确定</el-button>
        <el-button @click="dialogYW4Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 录入确定 -->
    <el-dialog :visible.sync="dialogYW5" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        录入确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="deleteBtn5Two">确定</el-button>
        <el-button @click="dialogYW5 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 下载录入Excel -->
    <el-dialog :visible.sync="dialogYW6" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/xz.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/xz.png" alt="">
        <br>
        <div>确定要下载该模板吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="FileDownload6Btn">确定</el-button>
        <el-button @click="dialogYW6 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- Excel文件导入（录入） -->
    <el-dialog :visible.sync="dialogYW7" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/dr.png" alt="">
        Excel文件导入
      </div>
      <div class="dia-deleteTwo">
        <label>文件上传：</label>
        <el-upload
          ref="ywFileAddOne"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="handleChange"
          :on-remove="handleRemove"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <div style="text-align: center;margin:10px 0;">
          <span v-for="(item, index) in imgVal" :key="index">
            {{ item }}
            <img @click="handleRemove" style="margin: 0 0 0 10px; vertical-align:middle;cursor: pointer;" src="../../assets/hurdle/hurdleDelete.png" alt="">
          </span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="FileAdd7Btn">确定</el-button>
        <el-button @click="dialogYW7 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 上传失败 -->
    <el-dialog :visible.sync="dialogYW7Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>是否要导出错误信息？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="FileErrorBtn7Two">确定</el-button>
        <el-button @click="dialogYW7Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 打印脊背 -->
    <el-dialog :visible.sync="dialogYW8" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        打印
      </div>
      <div class="editorXin" style="text-align: center;">
        <label>选择尺寸:</label>
        <el-select v-model="paramsYw.scope" filterable placeholder="请选择">
          <el-option v-for="(item, index) in scopeArr" :key="index" :value="item.id" :label="item.text"></el-option>
        </el-select>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="FileDownload8Btn">确定</el-button>
        <el-button @click="dialogYW8 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 打印卷内目录 -->
    <el-dialog :visible.sync="dialogYW9" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        录入确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="fileDownload9Btn">确定</el-button>
        <el-button @click="dialogYW9 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 打印卷内目录 -->
    <el-dialog :visible.sync="dialogYW10" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        系统提示
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定保存该项目吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="addSave10Btn">确定</el-button>
        <el-button @click="dialogYW10 = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 案卷--检索 -->
    <el-dialog :visible.sync="dialogYW11" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/js.png" alt="">
        检索
      </div>
      <el-form :model="params" ref="ruleFormAjSearch" label-width="100px" class="demo-ruleForm searchForm">
        <!--档案类型-->
        <el-form-item label="案卷题名" prop="titleProper">
          <el-input v-model="paramsBottom.jjTitleProper" ></el-input>
        </el-form-item>
        <!--档案类型-->
        <el-form-item label="年度" prop="titleProper">
          <el-input v-model="paramsBottom.jjyearCode" ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="showListBottom(paramsBottom)">确定</el-button>
        <el-button @click="resetSearchBottom">重置</el-button>
        <el-button @click="dialogYW11 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 案卷--添加案卷 -->
    <el-dialog :visible.sync="dialogYW12" width="888px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        录入项目信息
      </div>
      <el-form :model="paramsYwEdit" :rules="rulesJjAdd" ref="ruleFormYwAddProjectTwo" label-width="110px" class="demo-ruleForm">
        <!--项目代号-->
        <el-form-item label="案卷题名" prop="titleProper">
          <el-input v-model="paramsYwEdit.titleProper" ></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--案卷号-->
        <el-form-item label="案卷号" prop="folderNo" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.folderNo" ></el-input>
        </el-form-item>
        <!--年度-->
        <el-form-item label="年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.yearCode" ></el-input>
        </el-form-item>
        <!--项目名称-->
        <el-form-item label="项目名称" prop="c11" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c11" readonly></el-input>
        </el-form-item>
        <!--公开属性-->
        <el-form-item label="公开属性" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.openingType" filterable placeholder="请选择" :disabled="true">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限"  class="mangeShowLook">
          <el-select v-model="paramsYwEdit.retentionPeriod" filterable placeholder="请选择" :disabled="true">
            <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
        <!--分类号-->
        <el-form-item label="分类号" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.seriesCode" readonly></el-input>
        </el-form-item>
        <!--归档部门-->
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDeptName" readonly></el-input>
        </el-form-item>
        <!--归档人-->
        <el-form-item label="归档人" prop="" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingUserName" readonly></el-input>
        </el-form-item>
        <!--归档日期-->
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDate" readonly></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="addBottomContent12Btn">保存</el-button>
        <el-button @click="addBottomContent">重置</el-button>
        <el-button @click="dialogYW12 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 添加项目确定 -->
    <el-dialog :visible.sync="dialogYW12Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        录入确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="addBottomContent12BtnTwo">确定</el-button>
        <el-button @click="dialogYW12Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 案卷--修改案卷 -->
    <el-dialog :visible.sync="dialogYW13" width="888px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        录入项目信息
      </div>
      <el-form :model="paramsYwEdit" :rules="rulesJjEdit" ref="ruleFormYwEditProjectTwo" label-width="110px" class="demo-ruleForm">
        <!--项目代号-->
        <el-form-item label="案卷题名" prop="titleProper">
          <el-input v-model="paramsYwEdit.titleProper" ></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--案卷号-->
        <el-form-item label="案卷号" prop="folderNo" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.folderNo" ></el-input>
        </el-form-item>
        <!--年度-->
        <el-form-item label="年度" prop="yearCode" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.yearCode" ></el-input>
        </el-form-item>
        <!--项目名称-->
        <el-form-item label="项目名称" prop="c11" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c11" readonly></el-input>
        </el-form-item>
        <!--公开属性-->
        <el-form-item label="公开属性" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.openingType" filterable placeholder="请选择" :disabled="true">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限"  class="mangeShowLook">
          <el-select v-model="paramsYwEdit.retentionPeriod" filterable placeholder="请选择" :disabled="true">
            <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
        <!--分类号-->
        <el-form-item label="分类号" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.seriesCode" readonly></el-input>
        </el-form-item>
        <!--归档部门-->
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDeptName" readonly></el-input>
        </el-form-item>
        <!--归档人-->
        <el-form-item label="归档人" prop="" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingUserName" readonly></el-input>
        </el-form-item>
        <!--归档日期-->
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDate" readonly></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="editBottomContent13Btn">保存</el-button>
        <el-button @click="editBottomContent">重置</el-button>
        <el-button @click="dialogYW13 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 案卷--添加项目确定 -->
    <el-dialog :visible.sync="dialogYW13Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        更新确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="editBottomContent13BtnTwo">确定</el-button>
        <el-button @click="dialogYW13Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 案卷--删除 -->
    <el-dialog :visible.sync="dialogYW14" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除附件确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>删除此案卷，将会一并删除案卷下的所有案件、材料，确定吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="deleteBottomContent14Btn">确定</el-button>
        <el-button @click="dialogYW14 = false">取消</el-button>
      </div>
    </el-dialog>

    <!-- 文件层--检索 -->
    <el-dialog :visible.sync="dialogYW15" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/js.png" alt="">
        检索
      </div>
      <el-form :model="params" ref="ruleFormAjSearch" label-width="100px" class="demo-ruleForm searchForm">
        <!--文件题名-->
        <el-form-item label="文件题名" prop="">
          <el-input v-model="paramsBottomTwo.titleProper" ></el-input>
        </el-form-item>
        <!--文件编号-->
        <el-form-item label="文件编号" prop="">
          <el-input v-model="paramsBottomTwo.c3" ></el-input>
        </el-form-item>
        <!--责任者-->
        <el-form-item label="责任者" prop="">
          <el-input v-model="paramsBottomTwo.c113" ></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="showListBottom(paramsBottomTwo)">确定</el-button>
        <el-button @click="resetSearchBottom">重置</el-button>
        <el-button @click="dialogYW15 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 文件层--添加项目 -->
    <el-dialog :visible.sync="dialogYW16" width="888px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        录入项目信息
      </div>
      <el-form :model="paramsYwEdit" :rules="rulesAjHitch" ref="ruleFormYwAddProjectThree" label-width="110px" class="demo-ruleForm">
        <!--案卷号-->
        <el-form-item label="案卷号" prop="c220" class="mangeShowLook">
          <!--<el-input v-model="paramsYwEdit.openingType" ></el-input>-->
          <el-select v-model="paramsYwEdit.c220" filterable placeholder="请选择" @change="c220ArrChange">
            <!--<el-option v-for="item in c220Arr" :key="item.id" :label="item.folderNo" :value="item.id"></el-option>-->
            <el-option v-for="item in c220Arr" :key="item.id" :label="item.folderNo" :value="item.folderNo"></el-option>
          </el-select>
        </el-form-item>
        <!--序号-->
        <el-form-item label="序号" prop="itemNo"  class="mangeShowLook">
          <el-input v-model="paramsYwEdit.itemNo" @keyup.native="itemNoDown(paramsYwEdit)"></el-input>
        </el-form-item>
        <!--文件编号-->
        <el-form-item label="文件编号" prop="c3" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c3"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--案卷题名-->
        <el-form-item label="案卷题名" prop="ownerId" class="" style="width: 99%;">
          <el-select v-model="paramsYwEdit.ownerId" filterable placeholder="请选择" @change="ownerIdArrChange" style="width: 100%;">
            <el-option v-for="item in ownerIdArr" :key="item.id" :label="item.titleProper" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <div class="clear"></div>
        <!--文件题名-->
        <el-form-item label="文件题名" prop="titleProper" class="" style="width: 99%;">
          <el-input v-model="paramsYwEdit.titleProper"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--责任者-->
        <el-form-item label="责任者" prop="c113" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c113"></el-input>
        </el-form-item>
        <!--文件日期-->
        <el-form-item label="日期" prop="dateOfCreation" class="mangeShowLook">
          <!--<el-input v-model="paramsYwEdit.dateOfCreation"></el-input>-->
          <el-date-picker
            style="width: 100%;"
            v-model="paramsYwEdit.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间"
          >
          </el-date-picker>
        </el-form-item>
        <!--页号-->
        <el-form-item label="页号" prop="pageNo" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.pageNo"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--公开属性-->
        <el-form-item label="公开属性" prop="openingType" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.openingType" filterable placeholder="请选择">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.retentionPeriod" filterable placeholder="请选择" :disabled="true">
            <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
        <!--分类号-->
        <el-form-item label="分类号" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.seriesCode" readonly></el-input>
        </el-form-item>
        <!--归档部门-->
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDeptName" readonly></el-input>
        </el-form-item>
        <!--归档人-->
        <el-form-item label="归档人"  class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingUserName" readonly></el-input>
        </el-form-item>
        <!--归档日期-->
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDate" readonly></el-input>
        </el-form-item>
        <!--索引备注-->
        <el-form-item label="备注" style="width: 99%;">
          <el-input type="textarea" v-model="paramsYwEdit.c8"></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="addProjectContent16Btn">保存</el-button>
        <el-button @click="addBottomContent16">重置</el-button>
        <el-button @click="dialogYW16 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 文件层--添加项目确定 -->
    <el-dialog :visible.sync="dialogYW16Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        录入确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="addProjectContent16BtnTwo">确定</el-button>
        <el-button @click="dialogYW16Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 文件层--修改项目 -->
    <el-dialog :visible.sync="dialogYW17" width="888px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/tj.png" alt="">
        录入项目信息
      </div>
      <el-form :model="paramsYwEdit" :rules="rulesAjHitchEdit" ref="ruleFormYwEditProjectThree" label-width="110px" class="demo-ruleForm">
        <!--案卷号-->
        <el-form-item label="案卷号" prop="c220" class="mangeShowLook">
          <!--<el-input v-model="paramsYwEdit.openingType" ></el-input>-->
          <el-select v-model="paramsYwEdit.c220" filterable placeholder="请选择" @change="c220ArrChange">
            <!--<el-option v-for="item in c220Arr" :key="item.id" :label="item.folderNo" :value="item.id"></el-option>-->
            <el-option v-for="item in c220Arr" :key="item.id" :label="item.folderNo" :value="item.folderNo"></el-option>
          </el-select>
        </el-form-item>
        <!--序号-->
        <el-form-item label="序号" prop="itemNo"  class="mangeShowLook">
          <el-input v-model="paramsYwEdit.itemNo" @keyup.native="itemNoDown(paramsYwEdit)"></el-input>
        </el-form-item>
        <!--文件编号-->
        <el-form-item label="文件编号" prop="c3" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c3"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--案卷题名-->
        <el-form-item label="案卷题名" prop="ownerId" class="" style="width: 99%;">
          <el-select v-model="paramsYwEdit.ownerId" filterable placeholder="请选择" @change="ownerIdArrChange" style="width: 100%;">
            <el-option v-for="item in ownerIdArr" :key="item.id" :label="item.titleProper" :value="item.id"></el-option>
          </el-select>
        </el-form-item>
        <div class="clear"></div>
        <!--文件题名-->
        <el-form-item label="文件题名" prop="titleProper" class="" style="width: 99%;">
          <el-input v-model="paramsYwEdit.titleProper"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--责任者-->
        <el-form-item label="责任者" prop="c113" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.c113"></el-input>
        </el-form-item>
        <!--文件日期-->
        <el-form-item label="日期" prop="dateOfCreation" class="mangeShowLook">
          <!--<el-input v-model="paramsYwEdit.dateOfCreation"></el-input>-->
          <el-date-picker
            style="width: 100%;"
            v-model="paramsYwEdit.dateOfCreation"
            type="date"
            format="yyyy年MM月dd日"
            value-format="yyyy-MM-dd"
            placeholder="选择时间"
          >
          </el-date-picker>
        </el-form-item>
        <!--页号-->
        <el-form-item label="页号" prop="pageNo" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.pageNo"></el-input>
        </el-form-item>
        <div class="clear"></div>
        <!--公开属性-->
        <el-form-item label="公开属性" prop="openingType" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.openingType" filterable placeholder="请选择">
            <el-option v-for="item in openingType" :key="item.itemValue" :label="item.name" :value="item.itemValue"></el-option>
          </el-select>
        </el-form-item>
        <!--保管期限-->
        <el-form-item label="保管期限" class="mangeShowLook">
          <el-select v-model="paramsYwEdit.retentionPeriod" filterable placeholder="请选择" :disabled="true">
            <el-option v-for="(item, index) in retentionPeriod" :key="index" :value="item.itemValue" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
        <!--分类号-->
        <el-form-item label="分类号" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.seriesCode" readonly></el-input>
        </el-form-item>
        <!--归档部门-->
        <el-form-item label="归档部门" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDeptName" readonly></el-input>
        </el-form-item>
        <!--归档人-->
        <el-form-item label="归档人"  class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingUserName" readonly></el-input>
        </el-form-item>
        <!--归档日期-->
        <el-form-item label="归档日期" class="mangeShowLook">
          <el-input v-model="paramsYwEdit.filingDate" readonly></el-input>
        </el-form-item>
        <!--索引备注-->
        <el-form-item label="备注" style="width: 99%;">
          <el-input type="textarea" v-model="paramsYwEdit.c8"></el-input>
        </el-form-item>
      </el-form>
      <div class="clear"></div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="editProjectContent17Btn">保存</el-button>
        <el-button @click="editBottomContent17">重置</el-button>
        <el-button @click="dialogYW17 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 文件层--添加项目确定 -->
    <el-dialog :visible.sync="dialogYW17Two" width="444px" class="hurdleAll" :before-close="handleCloseTwo">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sl.png" alt="">
        更新确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要保存数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="editProjectContent17BtnTwo">确定</el-button>
        <el-button @click="dialogYW17Two = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 文件层--删除 -->
    <el-dialog :visible.sync="dialogYW18" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除按件确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要删除所选数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="deleteBottomContent18Btn">确定</el-button>
        <el-button @click="dialogYW18 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 文件层--上传 -->
    <el-dialog :visible.sync="dialogYW19" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sc.png" alt="">
        文件上传
      </div>
      <div class="dia-deleteTwo">
        <label>文件上传：</label>
        <el-upload
          ref="ywFileAddTwo"
          class="upload-demo"
          action="#"
          :multiple="false"
          :auto-upload="false"
          :show-file-list="false"
          :on-change="handleChangeTwo"
          :on-remove="handleRemoveTwo"
        >
          <el-button size="small" type="primary">点击上传</el-button>
        </el-upload>
        <div style="text-align: center;margin:10px 0;">
          <span v-for="(item, index) in imgVal" :key="index">
            {{ item.path }}
            <img @click="handleRemove" style="margin: 0 0 0 10px; vertical-align:middle;cursor: pointer;" src="../../assets/hurdle/hurdleDelete.png" alt="">
          </span>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="fileDownload19Btn">确定</el-button>
        <el-button @click="dialogYW19 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 文件层--删除材料 -->
    <el-dialog :visible.sync="dialogYW20" width="1111px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/sccl.png" alt="">
        附件
      </div>
      <div>
        <div style="background-color: #F4F4F4;">
          <div class="searchBtn search-selectOnce"></div>
          <div class="searchBtn" @click="fileDelete20Two">
            <img src="../../assets/turnOver/delete.png" alt="">
            <span>删除</span>
          </div>
          <div class="clear"></div>
        </div>
        <!-- 上表格--业务 -->
        <div class="all-Table">
          <el-table
            ref="multipleTableDeleteFile"
            :data="tableDataDeleteFile"
            stripe
            border
            @select="handleSelectionChangeDeleteFile"
            @select-all="handleSelectionChangeAllDeleteFile"
            @cell-click="handleSelectionClickDeleteFile">
            <el-table-column
              type="index"
              align="center"
              width="60">
            </el-table-column>
            <el-table-column
              type="selection"
              align="center"
              width="60">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="titleProper"
              label="文件标题">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileSize"
              label="文件大小">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="fileFormat"
              label="文件格式">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeDeleteFile"
            :current-page="paramsDeleteFile.page"
            :page-size="paramsDeleteFile.rows"
            layout="prev, pager, next, jumper"
            :total="paramsDeleteFile.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;text-align: right">
        <el-button @click="dialogYW20 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 文件层--删除材料--删除确定 -->
    <el-dialog :visible.sync="dialogYW20Two" width="444px" class="hurdleAll" :before-close="handleCloseOne">
      <div slot="title" class="dialog-title">
        <img src="../../assets/dialog/deleteTwo.png" alt="">
        删除确定
      </div>
      <div class="dia-deleteTwo">
        <img src="../../assets/dialog/wh.png" alt="">
        <br>
        <div>确定要删除所选数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="deleteContent20Two">确定</el-button>
        <el-button @click="dialogYW20Two = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import {getFonds, listSeriesByFondsAndRole, listSeriesByFonds, BASICURL} from '@/js/turnOverData'
import { valueIndex } from '@/js/transitionText'
import {listArchiveZL, listDoc, listUserByDeptId, listDept, addArchiveZL, findSeriesCode, editFileAnJian, updateFileAnJian,
  updateSpecialFileAnJia, deleteArchiveZL, listAllDept, findArchiveZL, saveCaseNoByBatch, uploadExcelH5, uploadExcel,
  uploadExcelZl, listFileType, listGzdj, listLwxt, coverElectronicSeal, removeElectronicSeal, saveFileWrk, listAnJianTree,
  powerDocView, uploadPicture, saveZlUploadDoc, editDocAnJian, updateDoc, deleteDoc, listThArchiveZL, listJjFolderData,
  listTreeJsonByTh, viewByJj, powerDocViewUtil, listJijianFileData, listThStatus, getInitJjProject, saveJjProject,
  getJjProject, updateJjProject, deleteThProject, zLingThProject, uploadThExcel, thQuality, saveWrk, listThHangingData, listThHangingDataiData,
  getInitJjFolder, saveThFolder, getJjFolder, updateThFolder, deleteThFolder, getInitJjFile, listThFolderById, listJjFolderByIdAndNo,
  saveThFile, getThFile, updateThFile, deleteThFile, saveThZlUploadDoc, listDocumentData, uploadThFileExcel, getCaseNoByC18, getTitleByCaseNo,
  updateJbTitle, listJijianArchiveZL, downloadExcel, uploadJjExcel, gdJijianPro, printJijianJibei, printJijianJn, listTreeJsonByJj,
  saveJjFolder, updateJjFolder, getItemNoByFid, saveJjFile, getJjFile, updateJjFile, saveStaffZlUploadDoc} from '@/js/fileMangeOver'
export default {
  name: 'fileJj',
  props: {
    paramsC: Object,
    tableDataC: Array,
    tableDataBottomC: Array,
  },
  data () {
    const yearCodeAudit = (rules, item, callback) => {
      let reg = /^[0-9]*$/
      if (!reg.test(item)) {
        callback('请输入数字')
      } else if (item.length > 4 || item.length < 4) {
        callback('输入长度为4')
      } else {
        callback()
      }
    }
    return {
      /* 此处表格数据 */
      params: {c5: 1, page: 1, rows: 10, fonds: 1374133141812, series1: 1379482316593, total: 0}, // 对应 全宗、类型、上一级表格数据
      paramsBottom: {page: 1, rows: 5, total: 0, jjTitleProper: '', jjyearCode: '', searchType: 1}, // 对应 全宗、类型、上一级表格数据
      paramsBottomTwo: {page: 1, rows: 5, total: 0, searchType: 1, titleProper: '', c113: '', c3: ''}, // 文件层
      paramsYw: {project: {}, folder: {}, file: {}}, // 查看
      paramsYwEdit: {}, // 添加，编辑
      paramsDeleteFile: {page: 1, total: 0, rows: 10}, // 删除材料

      /* 此处select类型 */
      fullZong: [], // 全宗
      FondsAndRole: [], // 类型一级
      FondsAndRoleTwo: [], // 类型二级
      FondsAndRoleThree: [], // 类型三级

      /* 此处表格 */
      tableData: [], // 上表格第一级
      tableDataBottom: [], // 下表格第一级
      tableDataDeleteFile: [], // 删除材料

      /* 此处表格多选选择数据 */
      tableDataTopOnce: [], // 上表格第一级
      tableDataTopOnceItem: {}, // 上表格第一级(单个数据）
      tableDataBottomOnce: [], // 下表格第一级
      tableDataDeleteFileOnce: [], // 删除材料

      /* 表格 */
      dialogShowLook: false,
      dialogYW1: false,
      dialogYW2: false,
      dialogYW3: false,
      dialogYW33: false,
      dialogYW4: false,
      dialogYW4Two: false,
      dialogYW5: false,
      dialogYW6: false,
      dialogYW7: false,
      dialogYW7Two: false,
      dialogYW8: false,
      dialogYW9: false,
      dialogYW10: false,
      dialogYW11: false,
      dialogYW12: false,
      dialogYW12Two: false,
      dialogYW13: false,
      dialogYW13Two: false,
      dialogYW14: false,
      dialogYW15: false,
      dialogYW16: false,
      dialogYW16Two: false,
      dialogYW17: false,
      dialogYW17Two: false,
      dialogYW18: false,
      dialogYW19: false,
      dialogYW20: false,
      dialogYW20Two: false,

      /* form判断 */
      rulesAj: {
        c0: [{required: true, message: '请填写项目代号', trigger: 'blur'}],
        c11: [{required: true, message: '请填写项目名称', trigger: 'blur'}],
        projectSite: [{required: true, message: '请填写工程地点', trigger: 'blur'}],
      },
      rulesJjAdd: {
        yearCode: [{required: true, message: '请填写年度', trigger: 'blur'}, {validator: yearCodeAudit}],
        folderNo: [{required: true, message: '请填写案卷号', trigger: 'blur'}],
        titleProper: [{required: true, message: '请填写案卷题名', trigger: 'blur'}],
      },
      rulesJjEdit: {
        yearCode: [{required: true, message: '请填写年度', trigger: 'blur'}, {validator: yearCodeAudit}],
        folderNo: [{required: true, message: '请填写案卷号', trigger: 'blur'}],
        titleProper: [{required: true, message: '请填写案卷题名', trigger: 'blur'}],
      },
      rulesAjHitch: {
        c220: [{required: true, message: '请选择案卷号', trigger: 'change'}],
        ownerId: [{required: true, message: '请选择案卷题名', trigger: 'blur'}],
        itemNo: [{required: true, message: '请填写序号', trigger: 'blur'}],
        titleProper: [{required: true, message: '请填写文件题名', trigger: 'blur'}],
        c113: [{required: true, message: '请填写责任者', trigger: 'blur'}],
        pageNo: [{required: true, message: '请填写页号', trigger: 'blur'}],
        dateOfCreation: [{required: true, message: '请选择日期', trigger: 'blur'}]
      },
      rulesAjHitchEdit: {
        c220: [{required: true, message: '请选择案卷号', trigger: 'change'}],
        ownerId: [{required: true, message: '请选择案卷题名', trigger: 'blur'}],
        itemNo: [{required: true, message: '请填写序号', trigger: 'blur'}],
        titleProper: [{required: true, message: '请填写文件题名', trigger: 'blur'}],
        c113: [{required: true, message: '请填写责任者', trigger: 'blur'}],
        pageNo: [{required: true, message: '请填写页号', trigger: 'blur'}],
        dateOfCreation: [{required: true, message: '请选择日期', trigger: 'blur'}]
      },

      /* select类型 */
      retentionPeriod: [
        {'name': '永久', 'itemValue': '3'},
        {'name': '长期', 'itemValue': '2'},
        {'name': '短期', 'itemValue': '1'},
        {'name': '10年', 'itemValue': '5'},
        {'name': '15年', 'itemValue': '6'},
        {'name': '30年', 'itemValue': '8'}
      ], // 保管期限
      c58: [{'name': '否', 'itemValue': '1'}, {'name': '是', 'itemValue': '0'}], // 是否为原件
      c59: [{'name': '否', 'itemValue': '1'}, {'name': '是', 'itemValue': '0'}], // 是否在库
      c89: [], // 拟稿人
      c90: [], // 拟稿部门
      c92: [], // 来文系统
      c100: [], // 文件类型
      c112: [], // 盖章类型
      thc5Arr: [], // 状态
      openingType: [
        {'name': '内部', 'itemValue': '2'},
        {'name': '公开', 'itemValue': '1'},
        {'name': '受控', 'itemValue': '3'},
        {'name': '广发商密三级', 'itemValue': '4'},
        {'name': '广发商密二级', 'itemValue': '5'},
        {'name': '广发商密一级', 'itemValue': '6'}
      ], // 公开属性
      filingDept: [], // 归档部门
      yjc89Arr: [], // 拟稿人--检索
      c220Arr: [], // 案卷号
      ownerIdArr: [], // 案卷题名
      scopeArr: [
        {id: 5, text: '5cm'}
      ], // 打印脊背--尺寸
      caseNoArr: [], // 文件层--盒号

      /* 单个数据 */
      imgVal: [],
      embedOnce: '',
      yeWuActiveName: '案卷层',
      yeWuActiveNameShowLook: '基本信息',
      lookCheck: 1, // 查看基本信息
      showDianZiShu: false, // 查看-右侧是否有电子书
      downLoadId: null, // 查看-左侧是否下载
      fileErrorMsg: '', // 导入错误msg
      showHitch: '', // 是否挂接

      /* tree数据 */
      treTable: [],
      treeArr: [],
      treTableContent: {},
      defaultProps: {
        children: 'children',
        label: 'text'
      }
    }
  },
  methods: {
    // 获取上表格第一级数据
    showList (val) {
      this.tableData = []
      listJijianArchiveZL(val).then(res => {
        if (res.data.rows.length <= 0) {
          this.$message.error('该条件下查无数据！')
          this.tableData = []
        } else {
          this.tableData = res.data.rows
          this.params.total = res.data.total
          this.tableData.forEach(item => {
            item.checkOnce = false
          })
        }
        this.dialogYW2 = false
      })
    },
    // 上表格多选
    handleSelectionChange (val, item) {
      item.checkOnce = !item.checkOnce
      this.tableDataTopOnce = val
      this.tableDataTopOnceItem = {}
      if (!item.checkOnce) {
        this.tableDataBottom = []
        this.paramsBottom = {page: 1, rows: 5, total: 0, jjTitleProper: '', jjyearCode: '', searchType: 1}
        this.paramsBottomTwo = {page: 1, rows: 5, total: 0, searchType: 1}
      }
      if (this.tableDataTopOnce.length > 0) {
        if (item.checkOnce) {
          if (this.yeWuActiveName == '案卷层') {
            this.paramsBottom.page = 1
            this.showListBottom(this.paramsBottom)
          } else if (this.yeWuActiveName == '文件层') {
            this.paramsBottomTwo.page = 1
            this.showListBottom(this.paramsBottomTwo)
          }
        }
      }
      if (this.tableDataTopOnce.length > 1 && this.tableDataTopOnce.length <= 2) {
        this.$refs.multipleTable.toggleRowSelection(this.tableDataTopOnce[0])
      }
      val.forEach(items => {
        if (items.checkOnce) {
          this.tableDataTopOnceItem = items
        }
      })
      if (item.c5 == 2) {
        this.showHitch = true
      } else {
        this.showHitch = false
      }
    },
    handleSelectionChangeAll (val) {
      this.tableDataTopOnce = val
      if (val.length > 0) {
        for (let i of this.tableData) {
          // i.checkOnce = !i.checkOnce
          i.checkOnce = true
        }
      } else {
        for (let i of this.tableData) {
          // i.checkOnce = !i.checkOnce
          i.checkOnce = false
        }
      }
      // for (let i in this.tableDataTopOnce) {
      //   if (!this.tableDataTopOnce[i].checkOnce) {
      //     this.tableDataTopOnce[i].checkOnce = true
      //   }
      // }
      // if (this.tableDataTopOnce.length > 1 && this.tableDataTopOnce.length <= 2) {
      if (this.tableDataTopOnce.length > 1 && this.tableDataTopOnce.length <= 1) {
        this.$refs.multipleTable.toggleRowSelection(this.tableDataTopOnce[0])
      }
      if (this.tableDataTopOnceItem.c5 == 2) {
        this.showHitch = true
      } else {
        this.showHitch = false
      }
    },
    // 上表格行内点击
    handleSelectionClick (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTable.toggleRowSelection(item, true)
        item.checkOnce = true
        // if (this.yeWuActiveName == '案卷层') {
        //   this.paramsBottom.page = 1
        //   this.showListBottom(this.paramsBottom)
        // } else if (this.yeWuActiveName == '文件层') {
        //   this.paramsBottomTwo.page = 1
        //   this.showListBottom(this.paramsBottomTwo)
        // }
      } else {
        this.$refs.multipleTable.toggleRowSelection(item, false)
        item.checkOnce = false
        this.tableDataBottom = []
        this.paramsBottom.page = 1
        this.paramsBottom.total = 1
        this.paramsBottomTwo.page = 1
        this.paramsBottomTwo.total = 1
      }
      if (this.tableDataTopOnce.length > 1 && this.tableDataTopOnce.length <= 2) {
        this.$refs.multipleTable.toggleRowSelection(this.tableDataTopOnce[0])
      }
      if (this.tableDataTopOnceItem.c5 == 2) {
        this.showHitch = true
      } else {
        this.showHitch = false
      }
    },
    // 上表格分页点击
    handleCurrentChange (val) {
      this.params.page = val
      this.showList(this.params)
    },
    // 下表格第一级数据
    showListBottom (val) {
      this.tableDataBottomOnce = []
      // this.paramsBottom.page = 1
      // this.paramsBottomTwo.page = 1
      if (this.yeWuActiveName == '案卷层') {
        this.paramsBottom.subId = this.tableDataTopOnceItem.id
        listJjFolderData(val).then(res => {
          this.tableDataBottom = res.data.rows
          this.paramsBottom.total = res.data.total
          this.dialogYW11 = false
        })
      } else if (this.yeWuActiveName == '文件层') {
        this.paramsBottomTwo.projectId = this.tableDataTopOnceItem.id
        listJijianFileData(val).then(res => {
          this.tableDataBottom = res.data.rows
          this.paramsBottomTwo.total = res.data.total
          this.dialogYW15 = false
        })
      }
    },
    // 下表格多选
    handleSelectionChangeBottom (val, item) {
      this.tableDataBottomOnce = []
      item.checkOnce = !item.checkOnce
      this.tableDataBottomOnce = val
      // if (this.tableDataBottomOnce.length > 1 && this.tableDataBottomOnce.length <= 2) {
      //   this.$refs.multipleTableBottom.toggleRowSelection(this.tableDataBottomOnce[0])
      // }
    },
    handleSelectionChangeBottomAll (val) {
      this.tableDataBottomOnce = []
      this.tableDataBottomOnce = val
      for (let i in this.tableDataBottomOnce) {
        if (!this.tableDataBottomOnce[i].checkOnce) {
          this.tableDataBottomOnce[i].checkOnce = true
        }
      }
      // if (this.tableDataBottomOnce.length > 1 && this.tableDataBottomOnce.length <= 2) {
      //   this.$refs.multipleTableBottom.toggleRowSelection(this.tableDataBottomOnce[0])
      // }
    },
    // 下表格行内点击
    handleSelectionClickBottom (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTableBottom.toggleRowSelection(item, true)
        item.checkOnce = true
      } else {
        this.$refs.multipleTableBottom.toggleRowSelection(item, false)
        item.checkOnce = false
        this.tableDataBottomOnce = []
      }
    },
    // 下表格（文件层）多选
    handleSelectionChangeBottomTwo (val, item) {
      item.checkOnce = !item.checkOnce
      this.tableDataBottomOnce = val
      // if (this.tableDataBottomOnce.length > 1 && this.tableDataBottomOnce.length <= 2) {
      //   this.$refs.multipleTableBottomRight.toggleRowSelection(this.tableDataBottomOnce[0])
      // }
    },
    handleSelectionChangeBottomAllTwo (val) {
      this.tableDataBottomOnce = val
      for (let i in this.tableDataBottomOnce) {
        if (!this.tableDataBottomOnce[i].checkOnce) {
          this.tableDataBottomOnce[i].checkOnce = true
        }
      }
      // if (this.tableDataBottomOnce.length > 1 && this.tableDataBottomOnce.length <= 2) {
      //   this.$refs.multipleTableBottomRight.toggleRowSelection(this.tableDataBottomOnce[0])
      // }
    },
    // 下表格行内点击
    handleSelectionClickBottomTwo (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTableBottomRight.toggleRowSelection(item, true)
        item.checkOnce = true
      } else {
        this.$refs.multipleTableBottomRight.clearSelection(item, false)
        item.checkOnce = false
        this.tableDataBottomOnce = []
      }
    },
    // 下表格分页点击
    handleCurrentChangeBottom (val) {
      this.paramsBottom.page = val
      this.showListBottom(this.paramsBottom)
    },
    handleCurrentChangeBottomTwo (val) {
      this.paramsBottomTwo.page = val
      this.showListBottom(this.paramsBottomTwo)
    },

    // 上表格--查看
    dateShowLookLook (val) {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        let params = {
          type: 'p',
          bs: 'jijian',
          id: this.tableDataTopOnceItem.id
        }
        this.lookRightContentOne(params)
        this.lookCheck = val
      }
    },
    // 查看-树形菜单
    handleNodeClick (val, item) {
      if (val.attributes.type == 'p') {
        this.lookCheck = 1
        let paramsTwo = {
          type: val.attributes.type,
          id: val.id
        }
        this.lookRightContentTwo(paramsTwo)
      } else if (val.attributes.type == 'v') {
        this.lookCheck = 2
        let paramsTwo = {type: val.attributes.type, id: val.id, resourceParentId: val.id}
        this.lookRightContentTwo(paramsTwo)
        listTreeJsonByJj({type: val.attributes.type, id: val.id, bs: 'jijian', resourceParentId: val.id}).then(res => {
          if (res.code == 500) {
            this.$message.error(res.message)
          } else {
            if (res.data.length >= 1) {
              val.children = res.data
            } else {
              this.$message.error(res.data.message)
            }
          }
        })
      } else if (val.attributes.type == 'f') {
        this.lookCheck = 3
        let paramsTwo = {type: val.attributes.type, id: val.id, resourceParentId: val.id}
        this.lookRightContentTwo(paramsTwo)
        listTreeJsonByJj({type: val.attributes.type, id: val.id, bs: 'jijian', resourceParentId: val.id}).then(res => {
          if (res.code == 500) {
            this.$message.error(res.message)
          } else {
            if (res.data.length >= 1) {
              val.children = res.data
            } else {
              this.$message.error(res.data.message)
            }
          }
        })
      } else if (val.attributes.type == 'd') {
        this.judgeShow(val)
      }
      this.showDianZiShu = false
      this.yeWuActiveNameShowLook = '基本信息'
    },
    // 获取查看--左，右侧数据
    lookRightContentOne (val) {
      this.paramsYw = {project: {}, folder: {}, file: {}}
      listTreeJsonByJj(val).then(res => {
        this.dialogShowLook = true
        this.treTable = res.data
        let paramsTwo = {
          type: res.data[0].attributes.type,
          id: this.tableDataTopOnceItem.id
        }
        this.lookRightContentTwo(paramsTwo)
        this.showDianZiShu = false
        this.yeWuActiveNameShowLook = '基本信息'
        // this.judgeShow(res.data[0])
      })
    },
    lookRightContentTwo (val) {
      this.paramsYw = {project: {}, folder: {}, file: {}}
      viewByJj(val).then(res => {
        this.paramsYw = res.data
      })
    },
    // 判断是否有电子文书
    judgeShow (val) {
      this.showDianZiShu = false
      powerDocView({id: val.attributes.id}).then(res => {
        if (res.code == 500) {
          this.$message.error(res.message)
        } else {
          if (res.data.optFlag == 0) {
            this.embedOnce = `${BASICURL}/gdda-new/gdda/util/filepreview/viewRangeFile?fileId=${val.attributes.docId}`
            this.showDianZiShu = true
            this.yeWuActiveNameShowLook = '电子全文'
          } else if (res.data.optFlag == 2) {
            this.dialogYW1 = true
            this.downLoadId = val.attributes.docId
          } else {
            this.$message.info('对不起，未找到您需要查看的文件')
            this.lookCheck = 4
          }
        }
      })
      /*if (val.attributes.docType) {
        if (val.attributes.docType == 'd') {
          powerDocView({id: val.attributes.docId}).then(res => {
            if (res.code == 500) {
              this.$message.error(res.message)
            } else {
              if (res.data.optFlag == 0) {
                this.embedOnce = `${BASICURL}/gdda-new/gdda/util/filepreview/viewRangeFile?fileId=${val.attributes.docId}`
                this.showDianZiShu = true
                this.yeWuActiveNameShowLook = '电子全文'
              } else if (res.data.optFlag == 2) {
                this.dialogYW1 = true
                this.downLoadId = val.attributes.docId
              } else {
                this.$message.info('对不起，未找到您需要查看的文件')
              }
            }
          })
        }
      }*/
    },
    yeWuDownLoad1 () {
      valueIndex().exportFiles('/gdda-new/gdda/util/downLoadFile', {id: this.downLoadId, mode: 'th'}, '虚拟机密码.txt', 'get')
      this.dialogYW1 = false
    },

    yeWuTabsClick (item, val) {
      this.tableDataBottomOnce = []
      this.paramsBottom.page = 1
      this.paramsBottomTwo.page = 1
      if (this.yeWuActiveName == '案卷层') {
        this.paramsBottom.subId = this.tableDataTopOnceItem.id
        this.showListBottom(this.paramsBottom)
      } else if (this.yeWuActiveName == '文件层') {
        this.paramsBottomTwo.projectId = this.tableDataTopOnceItem.id
        this.showListBottom(this.paramsBottomTwo)
      }
    },
    yeWuTabsShowLookClick (item, val) {
      console.log(item.name)
      console.log(this.yeWuActiveNameShowLook)
    },
    handleCloseOne () {
      this.dialogShowLook = false
      this.dialogYW2 = false
      this.dialogYW3 = false
      this.dialogYW4 = false
      this.dialogYW5 = false
      this.dialogYW6 = false
      this.dialogYW7 = false
      this.dialogYW8 = false
      this.dialogYW9 = false
      this.dialogYW10 = false
      this.dialogYW11 = false
      this.dialogYW12 = false
      this.dialogYW13 = false
      this.dialogYW14 = false
      this.dialogYW15 = false
      this.dialogYW16 = false
      this.dialogYW17 = false
      this.dialogYW18 = false
      this.dialogYW19 = false
      this.dialogYW20 = false
    },
    handleCloseTwo () {
      this.dialogYW1 = false
      this.dialogYW33 = false
      this.dialogYW4Two = false
      this.dialogYW7Two = false
      this.dialogYW12Two = false
      this.dialogYW13Two = false
      this.dialogYW16Two = false
      this.dialogYW17Two = false
      this.dialogYW20Two = false
    },
    selectType () {
      listDept().then(res => {
        this.c90 = res.data
      })
      listAllDept().then(res => {
        this.filingDept = res.data
      })
      listFileType().then(res => {
        this.c100 = res.data
      })
      listGzdj().then(res => {
        this.c112 = res.data
      })
      listLwxt().then(res => {
        this.c92 = res.data
      })
      listThStatus().then(res => {
        this.thc5Arr = res.data
      })
    },
    // 下表格--查看
    dateShowLookLookTwo (val) {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        // console.log(this.tableDataBottomOnce[0]);
        this.paramsYw = {project: {}, folder: {}, file: {}}
        let params = {
          type: 'p',
          bs: 'jijian',
          id: this.tableDataTopOnceItem.id
        }
        listTreeJsonByJj(params).then(res => {
          this.dialogShowLook = true
          this.treTable = res.data
          this.lookCheck = val
          let params = {
            type: 'v',
            id: this.tableDataBottomOnce[0].id,
            bs: 'jijian',
            resourceParentId: this.tableDataBottomOnce[0].id
          }
          listTreeJsonByJj(params).then(res => {
            if (res.data.length >= 1) {
              this.treTable.forEach(item => {
                item.children.forEach(itemTwo => {
                  if (itemTwo.id == this.tableDataBottomOnce[0].id) {
                    itemTwo.children = res.data
                    this.handleNodeClick(itemTwo)
                    this.treeArr.push(Number(itemTwo.id))
                    this.$nextTick(() => {
                      this.$refs.lookDataTree.setCheckedKeys(this.treeArr)
                    })
                  }
                })
              })
            }
          })
          /*let arrOnce = {}
          let arrOnceTroops = null
          this.treTable.forEach(item => {
            item.children.forEach((items, index) => {
              if (items.id == this.tableDataBottomOnce[0].id) {
                arrOnce = items
                // arrOnceTroops.push(items)
                arrOnceTroops = index
              }
            })
          })
          // console.log(this.tableDataBottomOnce)
          let paramsTwo = {
            type: arrOnce.attributes.type,
            id: arrOnce.attributes.id
          }
          let paramsThree = {
            type: arrOnce.attributes.type,
            id: arrOnce.attributes.id,
            resourceParentId: arrOnce.attributes.id,
            bs: 'th'
          }
          listTreeJsonByTh(paramsThree).then(res => {
            // document.getElementsByClassName('el-tree-node.is-current el-tree-node__content')[arrOnceTroops + 1].style.backgroundColor = '#999999'
            // 某行高亮 为写出来。（暂时推后）
            if (res.code == 500) {
              this.$message.error(res.message)
            } else {
              arrOnce.children = res.data
              this.showDianZiShu = false
              this.yeWuActiveNameShowLook = '基本信息'
              this.judgeShow(res.data[0])
            }
            this.lookRightContentTwo(paramsTwo)
          })*/
        })
      }
    },
    dateShowLookLookTwoRight (val) {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        // console.log(this.tableDataBottomOnce[0]);
        this.paramsYw = {project: {}, folder: {}, file: {}}
        let params = {
          type: 'p',
          bs: 'th',
          id: this.tableDataTopOnceItem.id
        }
        listTreeJsonByJj(params).then(res => {
          this.dialogShowLook = true
          this.treTable = res.data
          this.lookCheck = val
          let params = {
            type: 'v',
            id: this.tableDataBottomOnce[0].ownerId,
            bs: 'jijian',
            resourceParentId: this.tableDataBottomOnce[0].ownerId
          }
          listTreeJsonByJj(params).then(res => {
            if (res.data.length >= 1) {
              this.treTable.forEach(item => {
                item.children.forEach(itemTwo => {
                  if (itemTwo.id == this.tableDataBottomOnce[0].ownerId) {
                    itemTwo.children = res.data
                    let params = {
                      type: 'f',
                      id: this.tableDataBottomOnce[0].id,
                      bs: 'jijian',
                      resourceParentId: this.tableDataBottomOnce[0].id
                    }
                    listTreeJsonByJj(params).then(res => {
                      itemTwo.children.forEach(itemThree => {
                        if (itemThree.id == this.tableDataBottomOnce[0].id) {
                          itemThree.children = res.data
                          this.handleNodeClick(itemThree)
                        }
                      })
                    })
                    // itemTwo.children = res.data
                    // this.handleNodeClick(itemTwo)
                    // this.treeArr.push(Number(itemTwo.id))
                    // this.$nextTick(() => {
                    //   this.$refs.lookDataTree.setCheckedKeys(this.treeArr)
                    // })
                  }
                })
              })
            }
          })
          /*let arrOnce = {}
          let arrOnceTroops = null
          this.treTable.forEach(item => {
            item.children.forEach((items, index) => {
              if (items.id == this.tableDataBottomOnce[0].ownerId) {
                arrOnce = items
                // arrOnceTroops.push(items)
                arrOnceTroops = index
              }
            })
          })
          let paramsTwo = {
            type: arrOnce.attributes.type,
            id: arrOnce.attributes.id
          }
          let paramsThree = {
            type: arrOnce.attributes.type,
            id: arrOnce.attributes.id,
            resourceParentId: arrOnce.attributes.id,
            bs: 'th'
          }
          listTreeJsonByTh(paramsThree).then(res => {
            // document.getElementsByClassName('el-tree-node.is-current el-tree-node__content')[arrOnceTroops + 1].style.backgroundColor = '#999999'
            // 某行高亮 为写出来。（暂时推后）
            if (res.code == 500) {
              this.$message.error(res.message)
            } else {
              arrOnce.children = res.data
              this.showDianZiShu = false
              this.yeWuActiveNameShowLook = '基本信息'
              this.judgeShow(res.data[0])
            }
            this.lookRightContentTwo(paramsTwo)
          })*/
        })
      }
    },

    // 检索
    searchContent () {
      this.resetSearch()
      this.params.searchType = 1
      this.params.page = 1
      this.params.total = 0
      this.params.c5 = 1
      this.dialogYW2 = true
    },

    // 添加项目
    addProjectContent () {
      if (this.params.series2) {
        this.paramsYwEdit = {c0: '', c11: '', projectSite: ''}
        getInitJjProject({archiveTreeNodeId: this.params.series2}).then(res => {
          this.paramsYwEdit = res.data
          if (this.paramsYwEdit.seriesCode == 'B1') {
            this.paramsYwEdit.retentionPeriod = '2'
          } else if (this.paramsYwEdit.seriesCode == 'B2' || this.paramsYwEdit.seriesCode == 'B3') {
            this.paramsYwEdit.retentionPeriod = '3'
          } else if (this.paramsYwEdit.seriesCode == 'B1') {
            this.paramsYwEdit.retentionPeriod = '1'
          }
          this.paramsYwEdit.openingType = '2'
          this.dialogYW3 = true
          this.clearFiles('ruleFormYwAddProject')
        })
      }
    },
    addProjectContentBtn () {
      this.$refs.ruleFormYwAddProject.validate((valid) => {
        if (valid) {
          this.dialogYW33 = true
        }
      })
    },
    addProjectContentBtn33 () {
      this.paramsYwEdit.series2 = this.params.series2
      this.paramsYwEdit.fonds = this.params.fonds
      saveJjProject(this.paramsYwEdit).then(res => {
        if (res.code == 0) {
          this.dialogYW3 = false
          this.dialogYW33 = false
          this.$message.success(res.message)
          this.resetSearch()
          this.showList(this.params)
        } else {
          this.$message.error(res.message)
        }
      })
    },
    // 修改项目
    editProjectContent () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.paramsYwEdit = {}
        getJjProject({id: this.tableDataTopOnceItem.id}).then(res => {
          this.paramsYwEdit = res.data
          this.dialogYW4 = true
          this.clearFiles('ruleFormYwEditProject')
        })
      }
    },
    editProjectContentBtn4 () {
      this.$refs.ruleFormYwEditProject.validate((valid) => {
        if (valid) {
          this.dialogYW4Two = true
        }
      })
    },
    EditProjectContentBtn4Two () {
      this.paramsYwEdit.subId = this.tableDataTopOnceItem.id
      updateJjProject(this.paramsYwEdit).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.resetSearch()
          this.showList(this.params)
          this.dialogYW4 = false
          this.dialogYW4Two = false
        } else {
          this.$message.error(res.message)
        }
      })
    },
    // 删除
    deleteBtn5 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogYW5 = true
      }
    },
    deleteBtn5Two () {
      deleteThProject({id: this.tableDataTopOnceItem.id, bs: 'jijian'}).then(res => {
        if (res.code == 500) {
          this.$message.error('接口出现问题')
        } else {
          if (res.data.optFlag == 0) {
            this.$message.success('删除成功')
            this.dialogYW5 = false
            this.resetSearch()
            this.showList(this.params)
          } else if (res.data.optFlag == -1) {
            this.$message.error('删除失败')
            this.dialogYW5 = false
            this.resetSearch()
            this.showList(this.params)
          } else if (res.data.optFlag == -2) {
            this.$message.error('该项目非导入数据，不能删除！')
            this.dialogYW5 = false
            this.resetSearch()
            this.showList(this.params)
          }
        }
      })
    },
    // 下载Excel
    FileDownload6 () {
      if (this.params.series2) {
        this.dialogYW6 = true
      }
    },
    FileDownload6Btn () {
      let ids = {
        status: 'jj',
        series2: this.params.series2
      }
      let title = ''
      if (this.params.series2 == 1384966177248) {
        title = '基建档案-办公楼.xls'
      } else if (this.params.series3 == 1384966177250) {
        title = '基建档案-建筑工程.xls'
      } else if (this.params.series3 == 1384966177249) {
        title = '基建档案-房改房.xls'
      } else if (this.params.series3 == 1384966177251) {
        title = '基建档案-装修装饰工程.xls'
      }
      valueIndex().exportFiles(`${downloadExcel}`, ids, title, 'get')
      this.dialogYW6 = false
    },
    // 导入Excel
    FileAdd7 () {
      if (this.params.series2) {
        this.clearFilesTwo('ywFileAddOne')
        this.imgVal = []
        this.dialogYW7 = true
      }
    },
    handleChange (file, fileList) {
      if (this.imgVal.length >= 1) {
        this.$message.error('只能上传一个文件')
      } else {
        let formData = new FormData()
        formData.append('picture', file.raw)
        formData.append('name', 'file')
        formData.append('type', 'map')
        uploadExcelH5(formData).then(res => {
          if (res.code == 0) {
            this.imgVal.push(res.data.msg)
          } else {
            this.$message.error(res.message)
          }
        })
      }
    },
    // 删除上传
    handleRemove (val, item) {
      this.imgVal.splice(val, 1)
    },
    FileAdd7Btn () {
      let params = {
        series2: this.params.series2,
        fonds: this.params.fonds,
        imgVal: this.imgVal,
      }
      uploadJjExcel(params).then(res => {
        console.log(res);
        if (res.code == 0) {
          this.$message.success(res.data.msg)
          this.dialogYW7 = false
          this.resetSearch()
          this.showList(this.params)
        } else {
          if (res.data.optFlag == -2) {
            this.$message.error(res.data.msg)
          } else {
            this.dialogYW7Two = true
            this.fileErrorMsg = res.data.msg
          }
        }
      })
    },
    FileErrorBtn7Two () {
      let ids = {excelId: this.fileErrorMsg}
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/exportError', ids, '错误信息.xls', 'get')
      this.dialogYW7 = false
      this.dialogYW7Two = false
    },
    // 归档
    FileGui8 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        gdJijianPro({ids: this.tableDataTopOnceItem.id}).then(res => {
          if (res.code == 0) {
            if (res.data.optFlag == 0) {
              this.$message.success('归档成功')
              this.resetSearch()
              this.showList(this.params)
            } else {
              this.$message.error('归档失败')
              this.resetSearch()
              this.showList(this.params)
            }
          } else {
            this.$message.error('接口出错')
            this.resetSearch()
            this.showList(this.params)
          }
        })
      }
    },
    // 打印脊背
    FileDownload8 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.paramsYw = {project: {}, folder: {}, file: {}}
        this.paramsYw.scope = 5
        this.dialogYW8 = true
      }
    },
    FileDownload8Btn () {
      let params = {
        scope: this.paramsYw.scope,
        fileIds: this.tableDataTopOnceItem.id
      }
      valueIndex().exportFiles(printJijianJibei, params, '基建档案脊背.doc', 'get')
      this.dialogYW8 = false
    },
    // 打印卷内目录
    fileDownload9 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogYW9 = true
      }
    },
    fileDownload9Btn () {
      let params = {
        fileIds: this.tableDataTopOnceItem.id
      }
      valueIndex().exportFiles(printJijianJn, params, '基建档案卷内目录.doc', 'get')
      this.dialogYW9 = false
    },
    // 保存
    addSave10 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.dialogYW10 = true
      }
    },
    addSave10Btn () {
      saveWrk({proId: this.tableDataTopOnceItem.id}).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 1) {
            this.$message.success('保存成功')
            this.dialogYW10 = false
            this.resetSearch()
            this.showList(this.params)
          } else if (res.data.optFlag == -1) {
            this.$message.error('保存失败')
            this.dialogYW10 = false
            this.resetSearch()
            this.showList(this.params)
          } else if (res.data.optFlag == -2) {
            this.$message.error('保存失败，项目下案卷或案内目录为空')
            this.dialogYW10 = false
            this.resetSearch()
            this.showList(this.params)
          }
        } else {
          this.$message.error('接口异常')
          this.dialogYW10 = false
          this.resetSearch()
          this.showList(this.params)
        }
      })
    },

    // 案卷层--检索
    searchBottom () {
      this.dialogYW11 = true
      this.resetSearch()
      this.paramsBottom.subId = this.tableDataTopOnceItem.id
    },
    // 案卷层--添加案卷
    addBottomContent () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        getInitJjFolder({subId: this.tableDataTopOnceItem.id}).then(res => {
          this.paramsYwEdit = res.data
          this.dialogYW12 = true
          this.clearFiles('ruleFormYwAddProjectTwo')
        })
      }
    },
    addBottomContent12Btn () {
      this.$refs.ruleFormYwAddProjectTwo.validate((valid) => {
        if (valid) {
          this.dialogYW12Two = true
        }
      })
    },
    addBottomContent12BtnTwo () {
      this.paramsYwEdit.subId = this.tableDataTopOnceItem.id
      saveJjFolder(this.paramsYwEdit).then(res => {
        if (res.code == 0) {
          this.$message.success('添加成功')
          this.resetSearchBottom(1)
          this.showListBottom(this.paramsBottom)
          this.dialogYW12 = false
          this.dialogYW12Two = false
        } else {
          this.$message.error(res.data.msg)
          this.resetSearchBottom(1)
          this.showListBottom(this.paramsBottom)
          this.dialogYW12 = false
          this.dialogYW12Two = false
        }
      })
    },
    // 案卷层--修改案卷
    editBottomContent () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        getJjFolder({id: this.tableDataBottomOnce[0].id}).then(res => {
          this.paramsYwEdit = res.data
          this.dialogYW13 = true
          this.clearFiles('ruleFormYwEditProjectTwo')
        })
      }
    },
    editBottomContent13Btn () {
      this.$refs.ruleFormYwEditProjectTwo.validate((valid) => {
        if (valid) {
          this.dialogYW13Two = true
        }
      })
    },
    editBottomContent13BtnTwo () {
      this.paramsYwEdit.subId = this.tableDataBottomOnce[0].id
      updateJjFolder(this.paramsYwEdit).then(res => {
        console.log(res);
        if (res.code == 0) {
          this.$message.success('修改成功')
          this.resetSearchBottom(1)
          this.showListBottom(this.paramsBottom)
          this.dialogYW13 = false
          this.dialogYW13Two = false
        } else {
          this.$message.error('修改失败')
          this.resetSearchBottom(1)
          this.showListBottom(this.paramsBottom)
          this.dialogYW13 = false
          this.dialogYW13Two = false
        }
      })
    },
    // 案卷层--删除案卷
    deleteBottomContent () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.dialogYW14 = true
      }
    },
    deleteBottomContent14Btn () {
      let params = {
        bs: 'jijian',
        id: this.tableDataBottomOnce[0].id
      }
      deleteThFolder(params).then(res => {
        if (res.code == 500) {
          this.$message.error(res.data.message)
          this.dialogYW14 = false
        } else {
          if (res.data.optFlag == 0) {
            this.$message.success('删除成功')
            this.dialogYW14 = false
            this.resetSearchBottom(1)
            this.showListBottom(this.paramsBottom)
          } else if (res.data.optFlag == -1) {
            this.$message.error('删除失败')
            this.dialogYW14 = false
          } else if (res.data.optFlag == -2) {
            this.$message.error('该案卷非导入数据，不能删除！')
            this.dialogYW14 = false
          }
        }
      })
    },

    // 文件层--检索
    searchBottomTwo () {
      this.dialogYW15 = true
      this.resetSearchBottom(2)
      this.paramsBottomTwo.subId = this.tableDataTopOnceItem.id
    },
    // 文件层--添加
    addBottomContent16 () {
      let item = this.$onceWay().onceTableList(this.tableDataTopOnce)
      if (item == 1) {
        this.paramsYwEdit = {}
        this.clearFiles('ruleFormYwAddProjectThree')
        getInitJjFile({subId: this.tableDataTopOnceItem.id}).then(res => {
          this.paramsYwEdit = res.data
          listThFolderById({id: this.tableDataTopOnceItem.id}).then(res => {
            this.c220Arr = res.data
            this.dialogYW16 = true
          })
        })
      }
    },
    addProjectContent16Btn () {
      this.$refs.ruleFormYwAddProjectThree.validate((valid) => {
        if (valid) {
          this.dialogYW16Two = true
        }
      })
    },
    addProjectContent16BtnTwo () {
      let params = {
        c220: this.paramsYwEdit.c220,
        ownerId: this.paramsYwEdit.ownerId,
        itemNo: this.paramsYwEdit.itemNo,
        titleProper: this.paramsYwEdit.titleProper,
        c113: this.paramsYwEdit.c113,
        dateOfCreation: this.paramsYwEdit.dateOfCreation,
        pageNo: this.paramsYwEdit.pageNo,
        c8: this.paramsYwEdit.c8,
      }
      saveJjFile(this.paramsYwEdit).then(res => {
      // saveJjFile(params).then(res => {
        if (res.code == 0) {
          this.$message.success('添加完成')
          this.resetSearchBottom(2)
          this.showListBottom(this.paramsBottomTwo)
          this.dialogYW16 = false
          this.dialogYW16Two = false
        } else {
          this.$message.error('添加失败')
          this.resetSearchBottom(2)
          this.showListBottom(this.paramsBottomTwo)
          this.dialogYW16 = false
          this.dialogYW16Two = false
        }
      })
    },
    // 案卷号change
    c220ArrChange (val) {
      this.paramsYwEdit.ownerId = ''
      this.paramsYwEdit.itemNo = ''
      listJjFolderByIdAndNo({id: this.tableDataTopOnceItem.id, folderNo: val}).then(res => {
        this.ownerIdArr = res.data
        // this.paramsYwEdit.ownerId = res.data[0].titleProper
        this.paramsYwEdit.ownerId = res.data[0].id
        getItemNoByFid({id: res.data[0].id}).then(res => {
          this.paramsYwEdit.itemNo = res.data.itemNo
          this.$forceUpdate()
        })
      })
    },
    ownerIdArrChange (val) {
      this.paramsYwEdit.ownerId = val
      this.$forceUpdate()
    },
    itemNoDown (val) {
      this.paramsYwEdit.itemNo = val.itemNo
      this.$forceUpdate()
    },

    // 文件层--修改
    editBottomContent17 () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.paramsYwEdit = {}
        this.clearFiles('ruleFormYwEditProjectThree')
        getJjFile({id: this.tableDataBottomOnce[0].id}).then(res => {
          this.paramsYwEdit = res.data.data
          listThFolderById({id: this.tableDataTopOnceItem.id}).then(res => {
            this.c220Arr = res.data
            listJjFolderByIdAndNo({id: this.tableDataTopOnceItem.id, folderNo: this.paramsYwEdit.c220}).then(res => {
              this.ownerIdArr = res.data
              this.paramsYwEdit.ownerId = res.data[0].id
              getItemNoByFid({id: this.paramsYwEdit.ownerId}).then(res => {
                this.paramsYwEdit.itemNo = res.data.itemNo
                this.dialogYW17 = true
                this.$forceUpdate()
              })
            })
          })
        })
      }
    },
    editProjectContent17Btn () {
      this.$refs.ruleFormYwEditProjectThree.validate((valid) => {
        if (valid) {
          this.dialogYW17Two = true
        }
      })
    },
    editProjectContent17BtnTwo () {
      this.paramsYwEdit.subId = this.tableDataBottomOnce[0].id
      // this.paramsYwEdit.id = this.tableDataBottomOnce[0].id
      let params = {
        subId: this.tableDataBottomOnce[0].id,
        c220: this.paramsYwEdit.c220,
        ownerId: this.paramsYwEdit.ownerId,
        itemNo: this.paramsYwEdit.itemNo,
        c3: this.paramsYwEdit.c3,
        titleProper: this.paramsYwEdit.titleProper,
        c113: this.paramsYwEdit.c113,
        dateOfCreation: this.paramsYwEdit.dateOfCreation,
        pageNo: this.paramsYwEdit.pageNo,
        c8: this.paramsYwEdit.c8,
      }
      // updateJjFile(this.paramsYwEdit).then(res => {
      updateJjFile(params).then(res => {
        if (res.code == 0) {
          this.$message.success('修改成功')
          this.resetSearchBottom(2)
          this.showListBottom(this.paramsBottomTwo)
          this.dialogYW17 = false
          this.dialogYW17Two = false
        } else {
          this.$message.error('修改失败')
          this.resetSearchBottom(2)
          this.showListBottom(this.paramsBottomTwo)
          this.dialogYW17 = false
          this.dialogYW17Two = false
        }
      })
    },
    // 文件层--删除
    deleteBottomContent18 () {
      let item = this.$onceWay().onceTableListTwo(this.tableDataBottomOnce)
      if (item == 1) {
        this.dialogYW18 = true
      }
    },
    deleteBottomContent18Btn () {
      let arr = ''
      for (let i of this.tableDataBottomOnce) {
        arr += i.id + ','
      }
      deleteThFile({ids: arr}).then(res => {
        if (res.code == 500) {
          this.$message.error('接口错误！')
          this.dialogYW18 = false
        } else {
          this.$message.success('删除成功')
          this.dialogYW18 = false
          this.resetSearchBottom(2)
          this.showListBottom(this.paramsBottomTwo)
        }
      })
    },
    // 文件层--上传
    handleChangeTwo (file, fileList) {
      if (this.imgVal.length >= 1) {
        this.$message.error('只能上传一个文件')
      } else {
        let formData = new FormData()
        formData.append('picture', file.raw)
        formData.append('name', 'file')
        formData.append('type', 'jjZl')
        uploadPicture(formData).then(res => {
          if (res.code == 0) {
            this.imgVal.push(res.data.pathAndMD5)
          } else {
            this.$message.error(res.message)
          }
        })
      }
    },
    // 文件层--上传
    handleRemoveTwo (val, item) {
      this.imgVal.splice(val, 1)
    },
    fileDownload19 () {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.clearFilesTwo('ywFileAddTwo')
        this.imgVal = []
        this.dialogYW19 = true
      }
    },
    fileDownload19Btn () {
      if (this.imgVal.length < 1) {
        this.$message.error('请选择上传文件')
      } else {
        let params = {
          subId: this.tableDataBottomOnce[0].id,
          imgVal: JSON.stringify(this.imgVal),
          bs: 'jijian'
        }
        saveStaffZlUploadDoc(params).then(res => {
          if (res.code == 500) {
            if (res.data.optFlag == -1) {
              this.$message.error(`上传失败，因为文件${res.data.msg}已上传过了，请重新选择上传文件`)
              this.dialogYW19 = false
              this.resetSearchBottom(2)
              this.showListBottom(this.paramsBottomTwo)
            } else {
              this.$message.error(`上传失败`)
              this.dialogYW19 = false
              this.resetSearchBottom(2)
              this.showListBottom(this.paramsBottomTwo)
            }
          } else {
            this.$message.success('上传成功')
            this.dialogYW19 = false
            this.resetSearchBottom(2)
            this.showListBottom(this.paramsBottomTwo)
          }
        })
      }
    },
    // 文件层--删除上传材料
    fileDelete20 (val) {
      let item = this.$onceWay().onceTableList(this.tableDataBottomOnce)
      if (item == 1) {
        this.paramsDeleteFile.page = 1
        this.paramsDeleteFile.subId = this.tableDataBottomOnce[0].id
        listDocumentData(this.paramsDeleteFile).then(res => {
          this.tableDataDeleteFile = res.data.rows
          this.paramsDeleteFile.total = res.data.total
          this.dialogYW20 = true
        })
      }
    },
    // 文件层--删除材料表格点击
    handleSelectionChangeDeleteFile (val, item) {
      item.checkOnce = !item.checkOnce
      this.tableDataDeleteFileOnce = val
      if (this.tableDataDeleteFileOnce.length > 1 && this.tableDataDeleteFileOnce.length <= 2) {
        this.$refs.multipleTableDeleteFile.toggleRowSelection(this.tableDataDeleteFileOnce[0])
      }
    },
    handleSelectionChangeAllDeleteFile (val) {
      this.tableDataDeleteFileOnce = val
      for (let i in this.tableDataDeleteFileOnce) {
        if (!this.tableDataDeleteFileOnce[i].checkOnce) {
          this.tableDataDeleteFileOnce[i].checkOnce = true
        }
      }
      if (this.tableDataDeleteFileOnce.length > 1 && this.tableDataDeleteFileOnce.length <= 2) {
        this.$refs.multipleTableDeleteFile.toggleRowSelection(this.tableDataDeleteFileOnce[0])
      }
    },
    handleSelectionClickDeleteFile (item) {
      if (!item.checkOnce) {
        this.$refs.multipleTableDeleteFile.toggleRowSelection(item)
        item.checkOnce = true
      } else {
        this.$refs.multipleTableDeleteFile.clearSelection()
        item.checkOnce = false
      }
    },
    // 文件层--删除材料分页点击
    handleCurrentChangeDeleteFile (val) {
      this.paramsDeleteFile.page = val
      listDocumentData(this.paramsDeleteFile).then(res => {
        this.tableDataDeleteFile = res.data.rows
        this.paramsDeleteFile.total = res.data.total
      })
    },
    // 文件层--删除弹框
    fileDelete20Two () {
      let item = this.$onceWay().onceTableList(this.tableDataDeleteFileOnce)
      if (item == 1) {
        this.dialogYW20Two = true
      }
    },
    deleteContent20Two () {
      let params = {
        id: this.tableDataDeleteFileOnce[0].id,
        bs: 'jijian'
      }
      deleteDoc(params).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogYW20Two = false
          this.paramsDeleteFile.page = 1
          this.paramsDeleteFile.total = 0
          listDocumentData(this.paramsDeleteFile).then(res => {
            this.tableDataDeleteFile = res.data.rows
            this.paramsDeleteFile.total = res.data.total
            // this.dialogYW20 = true
          })
        } else {
          this.$message.error(res.message)
          this.dialogYW20Two = false
        }
      })
    },

    // 判断档案类型哪一级别有值
    methodSeries () {
      let item = this.params.series3 || this.params.series2 || this.params.series1
      return item
    },
    // 检索
    resetSearch () {
      this.params.page = 1
      this.params.total = 0
    },
    // 检索
    resetSearchBottom (val) {
      if (val == 2) {
        this.paramsBottomTwo.page = 1
        this.paramsBottomTwo.total = 0
        this.paramsBottom.searchType = 1
        this.paramsBottomTwo.titleProper = ''
        this.paramsBottomTwo.c113 = ''
        this.paramsBottomTwo.c3 = ''
      } else {
        this.paramsBottom.page = 1
        this.paramsBottom.total = 0
        this.paramsBottom.searchType = 1
        this.paramsBottom.jjTitleProper = ''
        this.paramsBottom.jjyearCode = ''
      }
    },
    // 清除掉回调表单验证
    clearFiles (val) {
      if (this.$refs[val]) {
        this.$nextTick(() => {
          this.$refs[val].clearValidate()
        })
      }
    },
    clearFilesTwo (val) {
      if (this.$refs[val]) {
        this.$nextTick(() => {
          this.$refs[val].clearFiles()
        })
      }
    }
  },
  watch: {
    paramsC (val) {
      this.params = val
      this.params.c0 = null
    },
    tableDataC (val) {
      this.tableData = val
      if (val.length < 1) {
        this.tableDataTopOnce = []
        this.tableDataTopOnceItem = {}
      }
    },
    tableDataBottomC (val) {
      this.tableDataBottom = val
      if (val.length < 1) {
        this.tableDataBottomOnce = []
      }
    }
  },
  created () {
    this.params = this.paramsC
    this.tableData = this.tableDataC
    this.tableDataBottom = this.tableDataBottomC
    this.selectType()
  }
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  .search-select {
    float: left;
    margin: 4px 0;
    vertical-align: middle;
    line-height: 40px;
    label {
      font-size: 14px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 143px;
    }
  }
  .search-selectOnce {
    margin: 5px 6px;
    height: 35px;
    border:1px solid #DEDEDE;
    cursor: auto;
  }
  .searchBtn {
    float: left;
    line-height: 47px;
    font-size: 13px;
    cursor: pointer;
    img{
      vertical-align: middle;
      margin-right: 4px;
    }
  }
  .mangeShowLook {
    float: left;
    width: 33%;
    margin-bottom: 20px;
    /deep/.el-input.is-disabled .el-input__inner{
      background-color: #fff!important;
      color: #606266!important;
    }
  }
  .hurdleAllHeHao {
    /deep/.el-dialog__body {
      padding: 0;
      margin-bottom: 20px;
    }
  }
  .searchForm {
    /deep/.el-form-item {
      margin-bottom: 10px;
    }
    .el-select {
      width: 100%;
    }
  }

  .showClearLook{
    height: 600px;
    overflow: auto;
  }
</style>
