<!-- 综合档案管理 -->
<template>
  <div style="background-color: #fff">
    <!-- 搜索 -->
    <div style="padding: 10px 0;">
      <div class="search-select search-selectOnce"></div>
      <div class="search-select">
        <label>全宗：</label>
        <el-select v-model="params.fonds" filterable placeholder="请选择" @change="yjTypeBtn">
          <el-option
            v-for="item in fullZong"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
      </div>
      <div class="search-select search-selectOnce"></div>
      <div class="search-select">
        <label>档案类型：</label>
        <el-select v-model="params.series1" filterable placeholder="请选择" @change="searchSeries">
          <el-option
            v-for="item in FondsAndRole"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
        <el-select v-model="params.series2" filterable placeholder="请选择" @change="searchSeriesTwo">
          <el-option
            v-for="item in FondsAndRoleTwo"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
        <el-select v-model="params.series3" filterable placeholder="请选择" @change="searchSeriesThree">
          <el-option
            v-for="item in FondsAndRoleThree"
            :key="item.id"
            :label="item.name"
            :value="item.id">
          </el-option>
        </el-select>
      </div>
      <span style="display: inline-block;margin-left: 20px;line-height: 40px;">
        <arrangement></arrangement>
      </span>
      <div class="clear"></div>
    </div>
    <file-aj v-if="dateShowLook == 1" :paramsC="params" :tableDataC="tableData" :tableDataBottomC="tableDataBottom"></file-aj>
    <file-ye-wu v-else-if="dateShowLook == 2" :paramsC="params" :tableDataC="tableData" :tableDataBottomC="tableDataBottom"></file-ye-wu>
    <file-kj v-else-if="dateShowLook == 3" :paramsC="params" :tableDataC="tableData" :tableDataBottomC="tableDataBottom"></file-kj>
    <file-jj v-else-if="dateShowLook == 4" :paramsC="params" :tableDataC="tableData" :tableDataBottomC="tableDataBottom"></file-jj>
    <file-sw v-else-if="dateShowLook == 6" :paramsC="params" :tableDataC="tableData" :tableDataBottomC="tableDataBottom"></file-sw>
    <file-sx v-else-if="dateShowLook == 7" :paramsC="params" :tableDataC="tableData" :tableDataBottomC="tableDataBottom"></file-sx>
    <div v-else></div>
  </div>
</template>

<script>
import {listArchiveZL, listDoc, listUserByDeptId, listDept, addArchiveZL, findSeriesCode, editFileAnJian, updateFileAnJian,
  updateSpecialFileAnJia, deleteArchiveZL, listAllDept, findArchiveZL, saveCaseNoByBatch, uploadExcelH5, uploadExcel,
  uploadExcelZl, listFileType, listGzdj, listLwxt, coverElectronicSeal, removeElectronicSeal, saveFileWrk, listAnJianTree,
  powerDocView, uploadPicture, saveZlUploadDoc, editDocAnJian, updateDoc, deleteDoc, listThArchiveZL, listAccountArchiveZL,
  listJijianArchiveZL, listPhysicalArchiveZL, listShengxArchiveZL} from '@/js/fileMangeOver'
import {getFonds, listSeriesByFondsAndRole, listSeriesByFonds, BASICURL} from '@/js/turnOverData'
import fileYeWu from './fileYeWu'
import fileAj from './fileAj'
import fileKj from './fileKj'
import fileJj from './fileJj'
import fileSw from './fileSw'
import fileSx from './fileSx'
import arrangement from '../../components/specialScheme/arrangement'
export default {
  name: 'fileMange',
  components: {
    fileYeWu,
    fileAj,
    fileKj,
    fileJj,
    fileSw,
    fileSx,
    arrangement,
  },
  data: function () {
    return {
      /* 此处表格数据 */
      params: {c0: 6, page: 1, rows: 10, fonds: 1374133141812, series1: 1379482316593}, // 对应 全宗、类型、上一级表格数据
      // params: {page: 1, rows: 10, fonds: 1374133141812, series1: 1374133285828, series2: 1374133285829}, // 对应 全宗、类型、上一级表格数据（书写会计时用的）
      paramsBottom: {page: 1, rows: 10}, // 对应 全宗、类型、上一级表格数据
      paramsSearch: {page: 1, rows: 10}, // 按件--批量设置盒号（检索）
      paramsAj: {}, // 按件--录入 or 编辑 or 特殊编辑 or 修改（下表格）

      /* 此处select类型 */
      fullZong: [], // 全宗
      FondsAndRole: [], // 类型一级
      FondsAndRoleTwo: [], // 类型二级
      FondsAndRoleThree: [], // 类型三级

      /* 此处表格 */
      tableData: [], // 上表格第一级
      tableDataBottom: [], // 下表格第一级
      tableDataDialogAJ5: [], // 批量设置盒号

      /* 此处表格多选选择数据 */
      tableDataTopOnce: [], // 上表格第一级
      tableDataTopOnceItem: {}, // 上表格第一级(单个数据）
      tableDataBottomOnce: [], // 下表格第一级
      dateShowLook: 1
    }
  },
  methods: {
    // 获取上表格第一级数据
    showList (val) {
      if (this.params.series1 == 1379482316593 || this.params.series1 == 1383033168454) {
        listArchiveZL(val).then(res => {
          if (res.data.rows.length <= 0) {
            this.$message.error('该条件下查无数据！')
            this.tableData = []
          } else {
            this.tableData = res.data.rows
            this.params.total = res.data.total
            this.tableData.forEach(item => {
              item.checkOnce = false
            })
          }
          this.dateShowLook = 1
        })
      }
      else if (this.params.series1 == 1388742017296) {
        this.tableData = []
        // val.c5 = 2
        if (this.params.series2) {
          this.params.c0 = null
          this.params.c5 = 2
          listThArchiveZL(val).then(res => {
            if (res.data.rows.length <= 0) {
              this.$message.error('该条件下查无数据！')
              this.tableData = []
            } else {
              this.tableData = res.data.rows
              this.params.total = res.data.total
              this.tableData.forEach(item => {
                item.checkOnce = false
              })
            }
            this.dateShowLook = 2
          })
        }
      }
      else if (this.params.series1 == 1388742017269) {
        this.tableData = []
        if (this.params.series2) {
          listAccountArchiveZL(val).then(res => {
            if (res.data.rows.length <= 0) {
              this.$message.error('该条件下查无数据！')
              this.tableData = []
            } else {
              this.tableData = res.data.rows
              this.params.total = res.data.total
              this.tableData.forEach(item => {
                item.checkOnce = false
              })
            }
          })
          this.dateShowLook = 3
        }
      }
      else if (this.params.series1 == 1384966177247) {
        this.tableData = []
        val.c5 = 1
        val.c0 = null
        val.c10 = null
        listJijianArchiveZL(val).then(res => {
          if (res.data.rows.length <= 0) {
            this.$message.error('该条件下查无数据！')
            this.tableData = []
          } else {
            this.tableData = res.data.rows
            this.params.total = res.data.total
            this.tableData.forEach(item => {
              item.checkOnce = false
            })
          }
        })
        this.dateShowLook = 4
      }
      else if (this.params.series1 == 1379398885203) {
        this.dateShowLook = 5
      }
      else if (this.params.series1 == 1374133285843) {
        this.tableData = []
        if (this.params.series2) {
          val.c0 = 6
          val.c5 = null
          val.c10 = null
          listPhysicalArchiveZL(val).then(res => {
            if (res.data.rows.length <= 0) {
              this.$message.error('该条件下查无数据！')
              this.tableData = []
            } else {
              this.tableData = res.data.rows
              this.params.total = res.data.total
              this.tableData.forEach(item => {
                item.checkOnce = false
              })
            }
          })
          this.dateShowLook = 6
        }
      }
      else if (this.params.series1 == 1374133285828) {
        this.tableData = []
        if (this.params.series2) {
          val.c10 = 1
          val.c0 = null
          val.c5 = null
          listShengxArchiveZL(val).then(res => {
            if (res.data.rows.length <= 0) {
              this.$message.error('该条件下查无数据！')
              this.tableData = []
            } else {
              this.tableData = res.data.rows
              this.params.total = res.data.total
              this.tableData.forEach(item => {
                item.checkOnce = false
              })
            }
          })
          this.dateShowLook = 7
        }
      }
      this.tableDataBottom = []
    },
    // 获取全宗 档案类型第一级
    showSearchData () {
      getFonds().then(res => {
        this.fullZong = res.data
      })
      // listSeriesByFondsAndRole({id: 1374133141812}).then(res => {
      listSeriesByFondsAndRole({id: this.params.fonds}).then(res => {
        // console.log(res)
        this.FondsAndRole = res.data
        listSeriesByFonds({id: this.params.series1}).then(res => {
          this.FondsAndRoleTwo = res.data
        })
        // this.searchSeries(1379482316593)
      })
      this.selectShowAudit()
    },
    // 档案类型第二级
    searchSeries (val) {
      this.FondsAndRoleThree = []
      listSeriesByFonds({id: val}).then(res => {
        this.FondsAndRoleTwo = res.data
      })
      this.resetParams()
      this.dateShowLook = -1
      this.params.series2 = null
      this.params.series3 = null
      if (this.params.series1 == 1388742017296 || this.params.series1 == 1379398885203 || this.params.series1 == 1374133285843) {
        this.tableData = []
      } else {
        this.showList(this.params)
      }
      // this.selectShowAudit()
      this.tableDataBottom = []
      this.$forceUpdate()
    },
    // 档案类型第三级
    searchSeriesTwo (val) {
      listSeriesByFonds({id: val}).then(res => {
        this.FondsAndRoleThree = res.data
      })
      this.resetParams()
      this.params.series3 = null
      this.showList(this.params)
      this.selectShowAudit()
      this.tableDataBottom = []
      this.$forceUpdate()
    },
    // 档案类型第三级获取数据
    searchSeriesThree (val) {
      this.resetParams()
      // this.params.series3 = val
      this.showList(this.params)
      this.selectShowAudit()
      this.tableDataBottom = []
      this.$forceUpdate()
    },
    // 全宗
    yjTypeBtn (val) {
      [this.params.series1, this.params.series2, this.params.series3, this.FondsAndRole, this.FondsAndRoleTwo, this.FondsAndRoleThree] = [null, null, null, [], [], []]
      // this.params.series1 = null
      // this.params.series2 = null
      // this.params.series3 = null
      // this.FondsAndRole = []
      // this.FondsAndRoleTwo = []
      // this.FondsAndRoleThree = []
      listSeriesByFondsAndRole({id: val}).then(res => {
        this.FondsAndRole = res.data
      })
      this.resetParams()
      this.showList(this.params)
    },
    // 状态值
    selectType () {
      listDept().then(res => {
        this.c90 = res.data
      })
      listAllDept().then(res => {
        this.filingDept = res.data
      })
      listFileType().then(res => {
        this.c100 = res.data
      })
      listGzdj().then(res => {
        this.c112 = res.data
      })
      listLwxt().then(res => {
        this.c92 = res.data
      })
    },

    // params清空，重来
    resetParams () {
      [this.params.page, this.params.total] = [1, 0]
      // this.params.page = 1
      // this.params.total = 0
    },
    // 状态判断谁显示
    selectShowAudit () {
      if (this.params.series1 == 1379482316593 || this.params.series1 == 1383033168454) { // 按件
        this.dateShowLook = 1
      } else if (this.params.series1 == 1388742017296) { // 业务
        this.dateShowLook = 2
      } else if (this.params.series1 == 1388742017269) { // 会计
        this.dateShowLook = 3
      } else if (this.params.series1 == 1384966177247) { // 基建
        this.dateShowLook = 4
      } else if (this.params.series1 == 1379398885203) { // 员工档案
        this.dateShowLook = 5
      } else if (this.params.series1 == 1374133285843) { // 实物档案
        this.dateShowLook = 6
      } else if (this.params.series1 == 1374133285828) { // 声像档案
        this.dateShowLook = 7
      }
      this.tableDataBottom = []
    }
  },
  created () {
    this.showSearchData()
    this.showList(this.params)
    this.selectType()
  },
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  .search-select {
    float: left;
    margin: 4px 0;
    vertical-align: middle;
    line-height: 40px;
    label {
      font-size: 14px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 143px;
    }
  }
  .search-selectOnce {
    margin: 5px 6px;
    height: 35px;
    border:1px solid #DEDEDE;
    cursor: auto;
  }
  .searchBtn {
    float: left;
    line-height: 47px;
    font-size: 13px;
    cursor: pointer;
    img{
      vertical-align: middle;
      margin-right: 4px;
    }
  }
  .mangeShowLook {
    float: left;
    width: 33%;
    margin-bottom: 20px;
    /deep/.el-input.is-disabled .el-input__inner{
      background-color: #fff!important;
      color: #606266!important;
    }
  }
  .hurdleAllHeHao {
    /deep/.el-dialog__body {
      padding: 0;
    }
  }
  .searchForm {
    /deep/.el-form-item {
      margin-bottom: 10px;
    }
    .el-select {
      width: 100%;
    }
  }

  .showClearLook{
    height: 600px;
    overflow: auto;
  }
</style>
