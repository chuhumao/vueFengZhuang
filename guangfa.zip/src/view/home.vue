<template>
  <div class="main">
    <el-aside class="left-aside">
      <Menu></Menu>
    </el-aside>
    <el-container class="containerLeft">
      <el-header class="headerTop">
        <HeaderTop></HeaderTop>
      </el-header>
      <el-main class="MainRight">
        <router-view />
      </el-main>
    </el-container>
    <div style="clear: both;"></div>
    <el-footer style="padding: 0;height:37px;">
      <div class="home-footer">
        <p>
          <span class="span1">档案系统服务热线：测试：1891000000</span>
          <span class="span2">请使用IE10或以上版本、火狐、谷歌浏览器　　　综合档案管理系统　版权所有 @ 2015-2020<span class="span3">使用帮助</span></span>
        </p>
      </div>
    </el-footer>
  </div>
</template>
<script>
import Menu from '../components/menu/menuList'
import HeaderTop from '../components/common/HeaderTop'
export default {
  name: 'HelloWorld',
  components: {
    Menu,
    HeaderTop
  },
  data() {
    return {
      tableData: [{
        date: '2016-05-02'
      }, {
        date: '2016-05-04'
      }, {
        date: '2016-05-01'
      }, {
        date: '2016-05-03'
      }],
      activeName: 'second',
    }
  },
  mounted() {
    this.msgObj()
  },
  methods: {
    handleClick(tab, event) {
      console.log(tab, event)
    },
    msgObj() {
      // console.log(1)else {
      let params = sessionStorage.getItem('routeName') || 'HomePage'
      this.$router.push({ name: params })
    },
  },
  watch: {
    $route(to, form) {
      sessionStorage.setItem('routeName', to.name)
    }
  }
}

</script>
<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="less">
.main {
  position: absolute;
  width: 100%;
  height: 100%;
}

.left-aside {
  width: 249px !important;
  height: 100%;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 21;
  transition: width .3s;
  transition: width .3s;
  background: #333333;
}

h1,
h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}

.containerLeft {
  /*   float: left;
width: 87%; */
  /*min-height: 907px;*/
}

.headerTop {
  padding: 0;
  padding-left: 120px;
  background-color: #004892;
  height: 51px !important;
  line-height: 51px;
  box-sizing: border-box;
  position: fixed;
  display: block;
  width: 100%;
  z-index: 20;
  transition: padding .3s;

}

.home-footer {
  width: 100%;
  height: 37px;
  background-color: #D2EFFF;
  border: 1px solid #0273B4;
  font-size: 12px;
  color: #282828;
  line-height: 37px;
  clear: both;
  position: fixed;
  bottom: 0;
  left: 0;
  z-index: 1299;

  .span1 {
    float: left;
    margin-left: 11px;
  }

  .span2 {
    float: right;
    margin-right: 20px;

    .span3 {
      margin-left: 20px;
      color: #515BED;
    }
  }
}

.MainRight {
  background-color: #E8EDF4;
  /*width: 100%;*/
  bottom: 30px;
  position: absolute;
  top: 48px;
  right: 0;
  bottom: 0;
  overflow: auto;
  transition: left .3s;
  left: 249px;
  padding: 14px;
}

</style>
