<template>
  <div>
    <!-- 上方 -->
    <div class="login-top">
      <p><img class="top-img" src="../assets/login/logo.png" alt="" /><span class="top-span">欢迎登录</span></p>
    </div>
    <!-- 下方 -->
    <div class="login-bottom">
      <p class="p1">广发证券</p>
      <p class="p2">综合档案管理系统</p>
      <!-- 用户名密码登录 -->
      <!-- <div class="login-form">
        <el-form class="login-form-new">
          <el-form-item class="login-item">
            <span><img src="../assets/login/icon1.png" alt="" /></span>
            <el-input type="text" placeholder="请输入账号" class="login-input"></el-input>
          </el-form-item>
          <el-form-item class="login-item">
            <span><img src="../assets/login/icon2.png" alt="" /></span>
            <el-input type="password" placeholder="请输入密码" class="login-input"></el-input>
          </el-form-item>
          <el-form-item class="login-item1">
            <el-input type="text" placeholder="请输入验证码" class="login-input1"></el-input>
            <img src="../assets/login/icon3.png" alt="" />
          </el-form-item>
          <el-form-item>
            <el-button class="login-button">登录</el-button>
          </el-form-item>
        </el-form>
      </div> -->
      <!-- 角色登录 -->
      <div class="login-form">
        <el-form class="login-form-two">
          <el-form-item>
            <el-select class="form-select" v-model="loginParams.singleDeptId" @change="$forceUpdate()">
              <el-option v-for="item in deptArr" :key="item.code" :value="item.code" :label="item.name"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item>
            <p class="login-p">选择角色</p>
            <el-select class="form-select" v-model="loginParams.singleRoleId" @change="$forceUpdate()">
              <el-option v-for="item in roleArr" :key="item.roleId" :value="item.roleId" :label="item.roleName"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item>
            <el-button class="form-two-btn1" @click="clickLogin">确认登录</el-button>
            <el-button class="form-two-btn2">关闭窗口</el-button>
          </el-form-item>
        </el-form>
      </div>
      <p class="login-note">请将本站设为可信任站点，并使用谷歌、火狐、IE10或以上版本浏览器</p>
    </div>
  </div>
</template>
<script>
import { erpLogin, getRole, selectLogin, allLogin } from '@/js/getData.js'
export default {
  name: 'login',
  data() {
    return {
      loginParams: {},
      roleArr: [],
      deptArr: []
    }
  },
  methods: {
    //REP登录
    loginErp() {
      let erpArr = window.location.href.split("?");
      let erpParams = {
        /*  erp: erpArr[1]*/
        erp: '0a7ff96e4fa7c92a13ccab013d580930'
      };
      erpLogin(erpParams).then(res => {
        if (res.code == 0) {
          if (res.data == 2) {
            this.getAll();
          }
        } else this.$message.error(res.message)
      })
    },
    //获取角色/部门
    getAll() {
      getRole().then(res => {
        if (res.code == 0) {
          this.roleArr = res.data.newRole;
          this.deptArr = res.data.newDept;
          this.roleArr.unshift({ "roleId": "all", "roleName": "---所有角色---" });
          this.loginParams.singleDeptId = this.deptArr[0].code;
          this.loginParams.singleRoleId = this.roleArr[0].roleId;
        } else this.$message.error(res.message)
      })

    },
    clickLogin() {
      selectLogin(this.loginParams).then(res => {
        if (res.code == 0) {
            this.totalLogin()
        } else this.$message.error(res.message)
      })
    },
    //最终登录
    totalLogin() {
      allLogin().then(res => {
        if (res.code == 0) {
          this.$router.push({ name: 'Home' })
        } else this.$message.error(res.message)
      })
    }

  },
  created() {
    this.loginErp();
  }
}

</script>
<style scoped lang="less">
.login-top {
  width: 100%;
  height: 77px;
  line-height: 77px;

  .top-img {
    margin-left: 18.8%;
    vertical-align: middle;
  }

  .top-span {
    font-size: 20px;
    color: #7F7F7F;
    margin-left: 35px;
    vertical-align: middle;
  }
}

.login-bottom {
  position: relative;
  width: 100%;
/*   max-width: 1920px;
min-width: 1400px; */
  overflow: hidden;
  height: 867px;
  background: url('../assets/login/bg.png') no-repeat 50% 0;

  .p1 {
    font-size: 50px;
    color: #EA3C40;
    margin-left: 20.9%;
    margin-top: 164px;
    font-weight: bold;
  }

  .p2 {
    font-size: 50px;
    color: #0173B3;
    margin-left: 20.9%;
    font-weight: bold;
  }

  .login-form {
    display: inline-block;
    width: 343px;
    height: 348px;
    background: url('../assets/login/form.png') no-repeat;
    position: absolute;
    right: 20.1%;
    top: 96px;

    .login-form-new {
      margin-top: 61px;

      .login-item {
        margin-bottom: 10px;

        img {
          margin-left: 35px;
          height: 42px;
        }

        .login-input {
          width: 239px;
          line-height: 42px;
          position: absolute;
        }
      }

      .login-item1 {
        .login-input1 {
          margin-left: 35px;
          width: 167px;
          position: absolute;
        }

        img {
          width: 101px;
          height: 33px;
          margin-left: 214px;
          margin-top: 3px;

        }
      }

      .login-button {
        margin-left: 35px;
        width: 279px;
        height: 38px;
        border-radius: 24px;
        margin-left: 36px;
        background-image: linear-gradient(to right, #038aff, #4d3cfc);
        color: #fff;
        font-size: 20px;
        line-height: 13px;
      }
    }

    .login-form-two {
      margin-top: 81px;
      margin-left: 31px;

      .form-select {
        margin-bottom: 20px;
        width: 281px;
        line-height: 42px;
      }

      .form-two-btn1 {
        width: 130px;
        height: 38px;
        border-radius: 24px;
        margin-right: 6px;
        font-size: 18px;
        line-height: 15px;
        color: #fff;
        background-image: linear-gradient(to right, #038aff, #4d3cfc);
      }

      .form-two-btn2 {
        width: 130px;
        height: 38px;
        border-radius: 24px;
        color: #fff;
        font-size: 18px;
        line-height: 15px;
        background-color: #EA3C40;
      }
    }
  }

  .login-note {
    font-size: 14px;
    margin-left: 57.5%;
    position: absolute;
    bottom: 1px;
    color: #fff;
    line-height: 48px;
  }

  .login-p {
    font-size: 14px;
    color: #0778BE;
    margin-bottom: 4px;
    width: 281px;
    text-align: center;
    margin-top: -36px;
  }
}

</style>
