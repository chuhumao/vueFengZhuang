<!-- 移交申请 -->
<template>
  <el-container style="background-color: #fff;">
    <el-main style="padding:0;">
      <!--<el-header class="menuHeaderTop" style="padding:0;height:30px;">
        <img src="../../assets/home/childrenHurdle.png" alt="">
        用户列表
      </el-header>-->
      <div class="contentPadding tableShrink">
        <!--新增，编辑，删除-->
        <div class="headerBtn">
          <span @click="showDigBtn"><img src="../../assets/hurdle/p7.png" alt=""><span>移交</span></span>
          <span @click="showDigBtnTwo"><img src="../../assets/hurdle/p7.png" alt=""><span>发起移交申请</span></span>
          <span @click="showDigBtnThree"><img src="../../assets/hurdle/p7.png" alt=""><span>重发移交申请待办</span></span>
        </div>
        <!-- 表格 -->
        <div class="all-Table">
          <el-table
            :data="tableData"
            stripe
            border
            @selection-change="handleSelectionChange"
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              prop="status"
              label="申请状态">
              <template slot-scope="scope">
                <span v-if="scope.row.status == 1">移交申请</span>
                <span v-else-if="scope.row.status == 2">移交申请审核</span>
                <span v-else-if="scope.row.status == 3">已完成</span>
                <span v-else-if="scope.row.status == 4">已作废</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="serialNumber"
              label="申请号">
            </el-table-column>
            <el-table-column
              prop="applyUser"
              label="申请人姓名">
            </el-table-column>
            <el-table-column
              prop="applyDept"
              label="申请部门">
            </el-table-column>
            <el-table-column
              prop="applyDate"
              label="申请时间">
            </el-table-column>
            <el-table-column
              prop="tagName"
              label="档案类型">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChange"
            :current-page="params.page"
            :page-size="params.rows"
            layout="prev, pager, next, jumper"
            :total="params.total">
          </el-pagination>
        </div>
      </div>
      <!--移交申请-->
      <el-dialog
        :visible.sync="dialogShowContent"
        width="1111px"
        class="hurdleAll"
        :before-close="handleClose">
        <div slot="title" class="dialog-title">移交申请</div>
        <div>
          <!--上-->
          <ul class="mangeShow">
            <li>
              <label>申请人姓名：</label>
              <el-input v-model="showEdit.applyUser" placeholder="请输入内容" readonly></el-input>
            </li>
            <li>
              <label>申请部门：</label>
              <el-input v-model="showEdit.applyDept" placeholder="请输入内容" readonly></el-input>
            </li>
            <!--<li>-->
              <!--<label>操作指引：</label>-->
              <!--<el-button type="primary">下载</el-button>-->
            <!--</li>-->
            <div class="clear"></div>
          </ul>
          <!--中-->
          <ul class="mangeShow">
            <li>
              <label>全宗：</label>
              <el-select v-model="showEdit.fonds"  placeholder="请选择" filterable>
                <el-option
                  v-for="item in sqFondsList"
                  :key="item.itemValue"
                  :label="item.name"
                  :value="item.itemValue">
                </el-option>
              </el-select>
            </li>
            <li>
              <label>档案类型：</label>
              <el-select v-model="showEdit.series"  placeholder="请选择" filterable @change="selectTypeRight">
                <!--<el-option v-for="(item, index) in selectTypeList" :label="item.name" :value="item.id" :key="index"></el-option>-->
                <el-option v-for="(item, index) in selectTypeListLeft" :label="item.name" :value="item.id" :key="index"></el-option>
              </el-select>
            </li>
            <li>
              <el-select v-model="showEdit.series1"  placeholder="请选择" filterable>
                <!--<el-option v-for="(item, index) in selectTypeList" :label="item.name" :value="item.id" :key="index"></el-option>-->
                <el-option v-for="(item, index) in selectTypeListRight" :label="item.name" :value="item.id" :key="index"></el-option>
              </el-select>
            </li>
            <div class="clear"></div>
          </ul>
          <!--申请人意见-->
          <div class="mangeShowList">
            <label>申请人意见：</label>
            <el-input
              type="textarea"
              :rows="2"
              placeholder="提醒：请在申请意见中写明需移交档案内容及数量，点击“确认”即可。
 例：申请移交历史部门印章登记表，共6册，请档案中心评估接收。"
              v-model="showEdit.applyRemarkCopy">
            </el-input>
          </div>
          <!--下-列表-->
          <div class="mangeShowList">
            <p>意见详情：</p>
            <div class="showReadOnlyContent" v-if="showEdit.isOldDate == 0">
              <div v-html="showEdit.applyRemark"></div>
            </div>
            <!-- 表格 -->
            <div class="all-Table" v-else-if="showEdit.isOldDate == 1" style="width: 83%;max-height: 300px;overflow: auto;margin: 0 auto;">
              <el-table
                :data="tableDataTwo"
                stripe
                border
                style="width: 100%">
                <!--@selection-change="handleSelectionChange"-->
                <!--<el-table-column-->
                <!--type="selection"-->
                <!--width="55">-->
                <!--</el-table-column>-->
                <el-table-column
                  show-overflow-tooltip
                  prop="applyRemark"
                  label="意见内容">
                </el-table-column>
                <el-table-column
                  prop="date"
                  label="时间">
                </el-table-column>
                <el-table-column
                  prop="sendName"
                  label="操作人">
                </el-table-column>
              </el-table>
            </div>
          </div>
          <!--操作指引-下载-->
          <div style="text-align: right;width: 91%;margin-top: 16px;color: #4A90E2;">
            <span>
              《操作指引》
              <span
                style="width: 68px;display: inline-block;text-align: center;background: #4A90E2;color: #fff;border-radius: 4px;cursor: pointer;"
                @click="wordBtn"
              >点击下载</span>
            </span>
          </div>
        </div>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="mangeBtn">确定</el-button>
          <el-button @click="dialogShowContent = false">取消</el-button>
        </div>

      </el-dialog>
      <!--移交申请审核-->
      <el-dialog
        :visible.sync="dialogShowContentTwo"
        width="1111px"
        class="hurdleAll"
        :before-close="handleClose">
        <div slot="title" class="dialog-title">移交申请单</div>
        <div>
          <!--上-->
          <ul class="mangeShow">
            <li class="editorXin">
              <label>申请人姓名：</label>
              <el-select
                v-model="showEdit.applyUser"
                placeholder="请选择"
                filterable
                remote
                reserve-keyword
                :remote-method="userSearch">
                <el-option
                  v-for="(item, index) in userSearchList"
                  :key="index"
                  :label="item.text"
                  :value="item.id">
                </el-option>
              </el-select>
              <!--<el-input v-model="showEdit.applyUserAndApplyDept" placeholder="请输入内容"></el-input>-->
            </li>
            <li class="editorXin">
              <label>申请时间：</label>
              <el-input v-model="showEdit.applyDate" placeholder="请输入内容" readonly></el-input>
            </li>
            <div class="clear"></div>
          </ul>
          <!--中-->
          <ul class="mangeShow">
            <li class="editorXin">
              <label>全宗：</label>
              <el-select v-model="showEdit.fonds"  placeholder="请选择" filterable>
                <el-option
                  v-for="item in sqFondsList"
                  :key="item.itemValue"
                  :label="item.name"
                  :value="item.itemValue">
                </el-option>
              </el-select>
            </li>
            <li class="editorXin">
              <label>档案类型：</label>
              <el-select v-model="showEdit.series"  placeholder="请选择" filterable @change="selectTypeRight">
                <!--<el-option v-for="(item, index) in selectTypeList" :label="item.name" :value="item.id" :key="index"></el-option>-->
                <el-option v-for="(item, index) in selectTypeListLeft" :label="item.name" :value="item.id" :key="index"></el-option>
              </el-select>
            </li>
            <li>
              <el-select v-model="showEdit.series1"  placeholder="请选择" filterable>
                <!--<el-option v-for="(item, index) in selectTypeList" :label="item.name" :value="item.id" :key="index"></el-option>-->
                <el-option v-for="(item, index) in selectTypeListRight" :label="item.name" :value="item.id" :key="index"></el-option>
              </el-select>
            </li>
            <div class="clear"></div>
          </ul>
          <!--申请人意见-->
          <div class="mangeShowList editorXin" >
            <label>申请人意见：</label>
            <el-input
              type="textarea"
              :rows="2"
              placeholder="提醒：请在申请意见中写明需移交档案内容及数量，点击“确认”即可。
 例：申请移交历史部门印章登记表，共6册，请档案中心评估接收。"
              v-model="showEdit.applyRemarkCopy">
            </el-input>
          </div>
          <!--操作指引-下载-->
          <div class="downloadBtn">
            <span>
              《操作指引》
              <span
                style="width: 68px;display: inline-block;text-align: center;background: #4A90E2;color: #fff;border-radius: 4px;cursor: pointer;"
                @click="wordBtn"
              >点击下载</span>
            </span>
          </div>
        </div>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="mangeBtnTwo">确定</el-button>
          <el-button @click="dialogShowContentTwo = false">取消</el-button>
        </div>

      </el-dialog>
      <!-- 确定弹框 -->
      <el-dialog :visible.sync="getDataViewDialog" width="444px" class="hurdleAll" :before-close="handleClose">
        <div slot="title" class="dialog-title">
          <!--<img src="../../assets/hurdle/topicDel.png" alt="">-->
          {{ paramsContent.title }}
        </div>
        <div class="dia-delete">
          <!--<img src="../../assets/hurdle/delete.png" alt="">-->
          <div>{{ paramsContent.content }}</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
          <el-button type="primary" @click="submitFormTax">确定</el-button>
          <el-button @click="getDataViewDialog = false">取消</el-button>
        </div>
      </el-dialog>
    </el-main>

  </el-container>
</template>

<script>
import editor from '../../components/quillEditor/readOnlyEditor'
import { listHandOverSqData, ListSeriesList, showGetYjSqShInitInfo, showListSeriesByFondsAndRole, showListSeriesByFonds,
  btnYjSqSave, getYjSqInitInfo, findChangeUser, btnSendYjSqOa, btnSendYjSqDb, oldListSeriesByFondsAndRole } from '@/js/getData'
import { wordPull } from '../../js/wordDerive'
export default {
  name: 'applyForList',
  components: {
    editor
  },
  data () {
    return {
      dialogShowContent: false,
      dialogShowContentTwo: false,
      getDataViewDialog: false,
      tableData: [],
      onceTable: [],
      userSearchList: [],
      params: {
        status: 1,
        page: 1,
        rows: 10
      },
      selectTypeList: [],
      selectTypeListLeft: [],
      selectTypeListRight: [],
      showEdit: {
        fonds: '1374133141812'
      },
      sqFondsList: [{name: '新广发证券股份有限公司', itemValue: '1374133141812'}],
      tableDataTwo: [],
      paramsContent: ''
    }
  },
  methods: {
    showList () {
      ListSeriesList().then(res => {
        this.selectTypeList = res.data
        listHandOverSqData(this.params).then(res => {
          this.tableData = res.data.rows
          this.params.total = res.data.total
          for (let s in this.tableData) {
            for (let i in this.selectTypeList) {
              if (this.tableData[s].tag == this.selectTypeList[i].tag) {
                this.tableData[s].tagName = this.selectTypeList[i].name
              }
            }
          }
        })
      })
    },
    showDigBtn () {
      let item = this.$onceWay().onceTableList(this.onceTable)
      if (item === 1) {
        this.selectTypeListLeft = []
        this.selectTypeListRight = []
        showGetYjSqShInitInfo({cid: this.onceTable[0].cid}).then(res => {
          this.showEdit = res.data
          this.showEdit.series = this.showEdit.series ? Number(this.showEdit.series) : null
          this.showEdit.series1 = this.showEdit.series1 ? Number(this.showEdit.series1) : null
          this.tableDataTwo = this.showEdit.isOldDate == 1 ? JSON.parse(this.showEdit.applyRemark) : []
          this.selectListOnce(this.showEdit.fonds, this.showEdit.series)
          this.dialogShowContent = true
        })
      }
    },
    // 获取左侧类型 和 右侧类型
    selectListOnce (val, item) {
      this.selectTypeListLeft = []
      // showListSeriesByFondsAndRole({id: val}).then(res => {
      oldListSeriesByFondsAndRole({id: val}).then(res => {
      //   this.selectTypeListLeft = res.data
        let item = res.data.data.split(',')
        for (let i in this.selectTypeList) {
          for (let s in item) {
            if (item[s] == this.selectTypeList[i].id) {
              this.selectTypeListLeft.push(this.selectTypeList[i])
            }
          }
        }
      })
      showListSeriesByFonds({id: item}).then(response => {
        this.selectTypeListRight = response.data
      })
    },
    // 点击左侧 获取右侧数据
    selectTypeRight (val) {
      this.selectTypeListRight = []
      this.showEdit.series1 = null
      showListSeriesByFonds({id: val}).then(res => {
        this.selectTypeListRight = res.data
      })
    },
    mangeBtn () {
      if (this.showEdit.series == null) {
        this.$message.error('请选择档案类型')
      } else if (this.showEdit.series1 == null) {
        this.$message.error('请选择档案类型')
      } else if (this.showEdit.applyRemarkCopy == '' || this.showEdit.applyRemarkCopy == undefined) {
        this.$message.error('请输入申请人意见')
      } else {
        this.getDataViewDialog = true
        this.paramsContent = {
          title: '申请确认',
          content: '确定要提交该数据移交申请吗？',
          val: 1
        }
      }
    },
    showDigBtnTwo () {
      // let item = this.$onceWay().onceTableList(this.onceTable)
      // if (item == 1) {
      // }
      getYjSqInitInfo().then(res => {
        console.log(res);
        this.showEdit = res.data
        this.showEdit.applyUser = ''
        this.showEdit.fonds = '1374133141812'
        this.selectListOnce('1374133141812', null)
        this.dialogShowContentTwo = true
      })
    },
    showDigBtnThree () {
      let item = this.$onceWay().onceTableList(this.onceTable)
      if (item == 1) {
        this.getDataViewDialog = true
        this.paramsContent = {
          title: '待办发送确认',
          content: '确定要提交该数据重新发送该移交申请代办给移交人吗？',
          val: 3
        }
      }
    },
    userSearch (val) {
      let item = {
        q: val,
        orgFlag1: -10000
      }
      findChangeUser(item).then(res => {
        this.userSearchList = res.data
      })
    },
    mangeBtnTwo () {
      console.log(this.showEdit.applyUser);
      if (this.showEdit.applyUser == null || this.showEdit.applyUser == '') {
        this.$message.error('请填写申请人名字')
      } else if (this.showEdit.fonds == null || this.showEdit.fonds == '') {
        this.$message.error('请选择全宗')
      } else if (this.showEdit.series == null || this.showEdit.series == '') {
        this.$message.error('请选择档案类型')
      } else if (this.showEdit.series1 == null || this.showEdit.series1 == '') {
        this.$message.error('请选择档案类型')
      } else if (this.showEdit.applyRemarkCopy == '' || this.showEdit.applyRemarkCopy == undefined) {
        this.$message.error('请输入申请人意见')
      } else {
        this.getDataViewDialog = true
        this.paramsContent = {
          title: '申请确认',
          content: '确定要提交该数据移交申请吗？',
          val: 2
        }
      }
    },
    submitFormTax () {
      this.showEdit.applyRemark = this.showEdit.applyRemarkCopy
      if (this.paramsContent.val == 1) {
        let params = {
          subId: this.onceTable[0].cid,
          gid: this.showEdit.gid,
          fonds: this.showEdit.fonds,
          series: this.showEdit.series,
          series1: this.showEdit.series1,
          applyRemark: this.showEdit.applyRemark
        }
        btnYjSqSave(params).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.getDataViewDialog = false
            this.dialogShowContent = false
            this.showList()
          } else {
            this.$message.error(res.message)
          }
        })
      } else if (this.paramsContent.val == 2) {
        let params = {
          // subId: this.onceTable[0].cid || '',
          gid: this.showEdit.gid,
          fonds: this.showEdit.fonds,
          series: this.showEdit.series,
          series1: this.showEdit.series1,
          // applyRemark: this.showEdit.applyRemark,
          yjApplyRemark: this.showEdit.applyRemark,
          applyUserAndDept: this.showEdit.applyUser
        }
        btnSendYjSqOa(params).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.handleClose()
            this.showList()
          } else {
            this.$message.error(res.message)
            this.handleClose()
          }
        })
      } else if (this.paramsContent.val == 3) {
        btnSendYjSqDb({id: this.onceTable[0].cid}).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.handleClose()
            this.showList()
          } else {
            this.$message.error(res.message)
            this.handleClose()
            this.showList()
          }
        })
      }
    },
    // word文档下载
    wordBtn () {
      wordPull(`gdda-new/gdda/archiveYjSq/downLoadCzZy`, '操作指引下载')
    },
    // 多选选择数据
    handleSelectionChange (val) {
      this.onceTable = val
    },
    // 分页
    handleCurrentChange (val) {
      this.params.page = val
      this.showList()
    },
    // 关闭弹框
    handleClose () {
      this.dialogShowContent = false
      this.dialogShowContentTwo = false
      this.getDataViewDialog = false
    }
  },
  created () {
    this.showList()
  }
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  .mangeShow{
    margin-bottom: 10px;
    li{
      float: left;
      width: 356px;
      .el-input{
        width: 59%;
      }
      label{
        display: inline-block;
        width: 96px;
        text-align: right;
      }
      /deep/.el-input.is-disabled .el-input__inner{
        background-color: #fff!important;
        color: #606266!important;
      }
    }
  }
  .mangeShowList{
    >p{
      width: 86px;
      text-align: right;
    }
    >label{
      display: inline-block;
      width: 96px;
      text-align: right;
      vertical-align: top;
    }
    .el-textarea{
      width: 83%;
    }
  }
  .showReadOnlyContent {
    width: 82%;
    margin: 0 auto;
    border: 1px solid #E4E7ED;
    min-height: 200px;
    padding: 6px;
    max-height: 200px;
    overflow: auto;
  }
  .downloadBtn{
    width: 92%;
    margin-top: 16px;
    color: #4A90E2;
    text-align: right;
  }
</style>
