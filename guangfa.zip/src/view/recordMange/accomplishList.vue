<!-- 移交已完成 -->
<template>
  <el-container style="background-color: #fff;">
    <el-main style="padding:0;">
      <!--<el-header class="menuHeaderTop" style="padding:0;height:30px;">
        <img src="../../assets/home/childrenHurdle.png" alt="">
        用户列表
      </el-header>-->
      <div class="contentPadding tableShrink">
        <!--新增，编辑，删除-->
        <div class="headerBtn">
          <span @click="showDigBtn"><img src="../../assets/hurdle/p7.png" alt=""><span>查看</span></span>
        </div>
        <!-- 表格 -->
        <div class="all-Table">
          <el-table
            :data="tableData"
            stripe
            border
            @selection-change="handleSelectionChange"
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              prop="status"
              label="申请状态">
              <template slot-scope="scope">
                <span v-if="scope.row.status == 1">移交申请</span>
                <span v-else-if="scope.row.status == 2">移交申请审核</span>
                <span v-else-if="scope.row.status == 3">已完成</span>
                <span v-else-if="scope.row.status == 4">已作废</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="serialNumber"
              label="申请号">
            </el-table-column>
            <el-table-column
              prop="applyUser"
              label="申请人姓名">
            </el-table-column>
            <el-table-column
              prop="applyDept"
              label="申请部门">
            </el-table-column>
            <el-table-column
              prop="applyDate"
              label="申请时间">
            </el-table-column>
            <el-table-column
              prop="tagName"
              label="档案类型">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChange"
            :current-page="params.page"
            :page-size="params.rows"
            layout="prev, pager, next, jumper"
            :total="params.total">
          </el-pagination>
        </div>
      </div>
      <!--查看数据赋权-->
      <el-dialog
        :visible.sync="dialogShowContent"
        width="1111px"
        class="hurdleAll"
        :before-close="handleClose">
        <div slot="title" class="dialog-title">查看</div>
        <div>
          <!--上-->
          <ul class="mangeShow">
            <li>
              <label>申请人姓名：</label>
              <el-input v-model="showEdit.applyUser" placeholder="请输入内容" readonly></el-input>
            </li>
            <li>
              <label>申请部门：</label>
              <el-input v-model="showEdit.applyDept" placeholder="请输入内容" readonly></el-input>
            </li>
            <li>
              <label>申请时间：</label>
              <el-input v-model="showEdit.applyDate" placeholder="请输入内容" readonly></el-input>
            </li>
            <div class="clear"></div>
          </ul>
          <!--中-->
          <ul class="mangeShow">
            <li>
              <label>全宗：</label>
              <el-select v-model="showEdit.fonds"  placeholder="请选择" disabled>
                <el-option
                  v-for="item in sqFondsList"
                  :key="item.itemValue"
                  :label="item.name"
                  :value="item.itemValue">
                </el-option>
              </el-select>
            </li>
            <li>
              <label>档案类型：</label>
              <el-select v-model="showEdit.series"  placeholder="请选择" disabled>
                <el-option v-for="(item, index) in selectTypeList" :label="item.name" :value="item.id" :key="index"></el-option>
              </el-select>
            </li>
            <li>
              <el-select v-model="showEdit.series1"  placeholder="请选择" disabled>
                <el-option v-for="(item, index) in selectTypeList" :label="item.name" :value="item.id" :key="index"></el-option>
              </el-select>
            </li>
            <div class="clear"></div>
          </ul>
          <!--下-列表-->
          <div class="mangeShowList">
            <p>意见详情：</p>
            <div class="showReadOnlyContent" v-if="showEdit.isOldDate == 0">
              <div v-html="showEdit.applyRemark"></div>
            </div>
            <!-- 表格 -->
            <div class="all-Table" v-else-if="showEdit.isOldDate == 1" style="width: 83%;max-height: 300px;overflow: auto;margin: 0 auto;">
              <el-table
                :data="tableDataTwo"
                stripe
                border
                style="width: 100%">
                <!--@selection-change="handleSelectionChange"-->
                <!--<el-table-column-->
                  <!--type="selection"-->
                  <!--width="55">-->
                <!--</el-table-column>-->
                <el-table-column
                  prop="applyRemark"
                  label="意见内容">
                </el-table-column>
                <el-table-column
                  prop="date"
                  label="时间">
                </el-table-column>
                <el-table-column
                  prop="sendName"
                  label="操作人">
                </el-table-column>
              </el-table>
            </div>
          </div>
        </div>

      </el-dialog>
    </el-main>

  </el-container>
</template>

<script>
import editor from '../../components/quillEditor/readOnlyEditor'
import { listHandOverSqData, ListSeriesList, showGetYjSqShInitInfo, showListSeriesByFondsAndRole, showListSeriesByFonds } from '@/js/getData'
export default {
  name: 'accomplishList',
  components: {
    editor
  },
  data () {
    return {
      dialogShowContent: false,
      tableData: [],
      onceTable: [],
      params: {
        status: 3,
        page: 1,
        rows: 10
      },
      selectTypeList: [],
      showEdit: {},
      sqFondsList: [{name: '新广发证券股份有限公司', itemValue: '1374133141812'}],
      tableDataTwo: []
    }
  },
  methods: {
    showList () {
      ListSeriesList().then(res => {
        this.selectTypeList = res.data
        listHandOverSqData(this.params).then(res => {
          this.tableData = res.data.rows
          this.params.total = res.data.total
          for (let s in this.tableData) {
            for (let i in this.selectTypeList) {
              if (this.tableData[s].tag == this.selectTypeList[i].tag) {
                this.tableData[s].tagName = this.selectTypeList[i].name
              }
            }
          }
        })
      })
    },
    showDigBtn () {
      let item = this.$onceWay().onceTableList(this.onceTable)
      if (item === 1) {
        showGetYjSqShInitInfo({cid: this.onceTable[0].cid}).then(res => {
          this.showEdit = res.data
          this.showEdit.series = this.showEdit.series ? Number(this.showEdit.series) : null
          this.showEdit.series1 = this.showEdit.series1 ? Number(this.showEdit.series1) : null
          this.tableDataTwo = this.showEdit.isOldDate == 1 ? JSON.parse(this.showEdit.applyRemark) : []
          this.dialogShowContent = true
        })
      }
    },
    // 点击选择数据
    handleSelectionChange (val) {
      this.onceTable = val
    },
    // 分页
    handleCurrentChange (val) {
      this.params.page = val
      this.showList()
    },
    // 关闭弹框
    handleClose () {
      this.dialogShowContent = false
    }
  },
  created () {
    this.showList()
  }
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  .mangeShow{
    margin-bottom: 10px;
    li{
      float: left;
      width: 356px;
      .el-input{
        width: 59%;
      }
      label{
        display: inline-block;
        width: 86px;
        text-align: right;
      }
      /deep/.el-input.is-disabled .el-input__inner{
        background-color: #fff!important;
        color: #606266!important;
      }
    }
  }
  .mangeShowList{
    >p{
      width: 86px;
      text-align: right;
    }
  }
  .showReadOnlyContent {
    width: 82%;
    margin: 0 auto;
    border: 1px solid #E4E7ED;
    min-height: 200px;
    padding: 6px;
    max-height: 200px;
    overflow: auto;
  }
</style>
