<!-- 栏目管理 -->
<template>
  <el-container style="background-color: #fff;">
    <div class="bigDog menuShrink black-tree">
      <PinDao></PinDao>
      <el-tree
        :data="treTable"
        :props="defaultProps"
        :check-strictly="true"
        :default-expand-all="true"
        :expand-on-click-node="false"
        :highlight-current="true"
        accordion
        @node-click="handleNodeClick">
        <span class="custom-tree-node"  slot-scope="{ node, data }">
          <span class="treeSpan" :dataType="data.type">
            <img src="../../assets/hurdle/hurdleNew.png" alt="">
            {{ node.label }}
          </span>
        </span>
      </el-tree>
    </div>
    <el-main style="padding:0;">
      <el-header class="menuHeaderTop" style="padding:0;height:30px;">
        <img src="../../assets/home/childrenHurdle.png" alt="">
        子栏目列表
      </el-header>
      <div class="contentPadding tableShrink">
        <!--新增，编辑，删除-->
        <div class="headerBtn">
          <span @click="showDigBtn(1)"><img src="../../assets/hurdle/hurdleAdd.png" alt=""><span>新增</span></span>
          <span @click="showDigBtn(2)"><img src="../../assets/hurdle/hurdleAudit.png" alt=""><span>编辑</span></span>
          <span @click="showDigBtn(3)"><img src="../../assets/hurdle/hurdleDelete.png" alt=""><span>删除</span></span>
        </div>
        <!-- 表格 -->
        <div class="all-Table">
          <el-table
            :data="tableData"
            stripe
            border=""
            @selection-change="handleSelectionChange"
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <!--<el-table-column-->
            <!--prop="id"-->
            <!--label="ID"-->
            <!--width="80">-->
            <!--</el-table-column>-->
            <el-table-column
              prop="columnName"
              label="栏目名称"
              width="180">
            </el-table-column>
            <el-table-column
              prop="columnType"
              label="栏目类型"
              width="180">
              <template slot-scope="scope">
                <span v-if="scope.row.columnType == '100'">栏目组别</span>
                <span v-else-if="scope.row.columnType == '1'">内容页</span>
                <span v-else-if="scope.row.columnType == '2'">信息列表页</span>
                <span v-else-if="scope.row.columnType == '3'">图片列表页</span>
                <span v-else-if="scope.row.columnType == '4'">视频列表</span>
                <span v-else-if="scope.row.columnType == '99'">外部模块</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="columnUrl"
              label="外部模块地址">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChange"
            :current-page="paramsTwo.page"
            :page-size="paramsTwo.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo.total">
          </el-pagination>
        </div>
      </div>
      <!-- 新增弹框 -->
      <el-dialog
        :visible.sync="dialogAdd"
        width="444px"
        class="hurdleAll"
        :before-close="handleClose">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          新增
        </div>
        <el-form :model="paramsAdd" :rules="rulesAudit" ref="ruleFormAdd" label-width="120px" class="demo-ruleForm">
          <el-form-item label="栏目名称：" prop="columnName">
            <el-input v-model="paramsAdd.columnName"></el-input>
          </el-form-item>
          <el-form-item label="栏目类型：" prop="columnType">
            <el-select v-model="paramsAdd.columnType" @change="urlFillIn">
              <el-option v-for="(item, index) in selectTypeList" :label="item.name" :value="item.id" :key="index"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="外部模块URL：" prop="columnUrl">
            <el-input v-model="paramsAdd.columnUrl"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="submitFormAdd">保存</el-button>
          <el-button @click="resetForm('1')">重置</el-button>
        </div>
      </el-dialog>
      <!-- 编辑弹框 -->
      <el-dialog
        :visible.sync="dialogEdit"
        width="444px"
        class="hurdleAll"
        :before-close="handleClose">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          编辑
        </div>
        <el-form :model="paramsEdit" :rules="rulesAudit" ref="ruleFormEdit" label-width="120px" class="demo-ruleForm">
          <el-form-item label="栏目名称：" prop="columnName">
            <el-input v-model="paramsEdit.columnName" maxlength="20"></el-input>
          </el-form-item>
          <el-form-item label="栏目类型：" prop="columnType">
            <el-select v-model="paramsEdit.columnType" @change="urlFillIn">
              <el-option v-for="(item, index) in selectTypeList" :label="item.name" :value="item.id" :key="index">{{ item.name }}</el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="外部模块URL：" prop="columnUrl">
            <el-input v-model="paramsEdit.columnUrl"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="submitFormEdit">保存</el-button>
          <el-button @click="resetForm('2')">重置</el-button>
        </div>
      </el-dialog>
      <!-- 删除弹框 -->
      <el-dialog :visible.sync="dialogDelete" width="444px" class="hurdleAll" :before-close="handleClose">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicDel.png" alt="">
          删除
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要删除此专题吗？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
          <el-button type="primary" @click="submitFormDelete">确定</el-button>
          <el-button @click="dialogDelete = false">取消</el-button>
        </div>
      </el-dialog>
    </el-main>
  </el-container>
</template>

<script>
import { listColumnTreeData, hurdleList, saveColumnAdd, deleteColumnOnce, updateColumnEdit } from '@/js/getData'
import PinDao from '../../components/menuChildren/pinDao'
export default {
  name: 'hurdleManage',
  components: {
    PinDao
  },
  data () {
    const minLengthReg = (value, item, callback) => {
      if (item.length < 4 || item.length > 20) {
        callback('长度不得小于4且不得大于20')
      } else {
        callback()
      }
    }
    const minUrlLengthReg = (valu, item, callback) => {
      if (item.length < 10 || item.length > 50) {
        callback('长度不得小于10且大于50')
      } else {
        callback()
      }
    }
    return {
      params: {
        total: 0,
        rows: 10,
        page: 1
      },
      paramsTwo: {
        total: 0,
        rows: 10,
        page: 1
      },
      onceTable: [],
      tableData: [],
      selectTypeList: [
        { id: 1, name: '内容页'},
        { id: 2, name: '信息列表页'},
        { id: 3, name: '图片列表页'},
        { id: 4, name: '视频列表'},
        { id: 99, name: '外部模块'},
        { id: 100, name: '栏目组别'}
      ],

      paramsAdd: {
        columnUrl: ''
      },
      dialogAdd: false,
      paramsEdit: {
        columnUrl: ''
      },
      dialogEdit: false,
      dialogDelete: false,

      rulesAudit: {
        columnName: [
          { required: true, message: '请输入栏目名称', trigger: 'blur'},
          { validator: minLengthReg, trigger: 'blur' }
        ],
        columnType: [{ required: true, message: '请选择栏目类型', trigger: 'blur'}],
        columnUrl: [{ required: true, message: '请输入外部模块URL', trigger: 'blur'}]
      },
      treTable: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      }
    }
  },
  methods: {
    handleNodeClick (val) {
      // this.paramsTwo.columnPid = val.id
      this.paramsTwo = {
        page: 1,
        rows: 10,
        total: 0,
        orgFlag1: null,
        columnPid: val.id
      }
      listColumnTreeData({columnPid: val.id, id: val.id}).then(res => {
        if (res.data) {
          val.children = [...res.data]
        }
      })
      this.showListTwo()
    },
    showList () {
      listColumnTreeData(this.params).then(res => {
        this.treTable.push(res.data[0])
        this.showListTwo()
      })
    },
    showListTwo () {
      hurdleList(this.paramsTwo).then(res => {
        this.tableData = res.data.rows
        this.paramsTwo.total = res.data.total == 0 ? 0 : res.data.total
      })
    },
    handleSelectionChange (val) {
      this.onceTable = val
    },
    // 单页面点击
    handleCurrentChange (val) {
      this.paramsTwo.page = val
      this.showListTwo()
      // console.log(`当前页: ${val}`)
    },
    showDigBtn (val) {
      if (val == 1) {
        if (this.paramsTwo.columnPid) {
          this.dialogAdd = true
          this.paramsAdd = {}
          this.$nextTick(() => {
            this.$refs['ruleFormAdd'].clearValidate()
          })
        } else {
          this.$message.error('请你先在部门机构树中选中一项作为上级部门')
        }
      } else if (val == 2) {
        let item = this.$onceWay().onceTableList(this.onceTable)
        if (item == 1) {
          this.paramsEdit = JSON.parse(JSON.stringify(this.onceTable[0]))
          // if (this.paramsEdit.columnType == 99) {
          //   this.paramsEdit.columnUrl = `http://${JSON.parse(JSON.stringify(this.paramsEdit.columnUrl))}`
          // }
          this.dialogEdit = true
          this.$nextTick(() => {
            this.$refs['ruleFormEdit'].clearValidate()
          })
        }
      } else if (val == 3) {
        let item = this.$onceWay().onceTableList(this.onceTable)
        if (item == 1) {
          this.dialogDelete = true
        }
      }
    },
    submitFormAdd () {
      this.$refs['ruleFormAdd'].validate((valid) => {
        if (valid) {
          this.paramsAdd.columnPid = this.paramsTwo.columnPid
          saveColumnAdd(this.paramsAdd).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message)
              this.dialogAdd = false
              this.showListTwo()
            } else {
              this.$message.error(res.message)
            }
          })
        }
      })
    },
    submitFormEdit () {
      this.$refs['ruleFormEdit'].validate((valid) => {
        if (valid) {
          updateColumnEdit(this.paramsEdit).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message)
              this.dialogEdit = false
              this.showListTwo()
            } else {
              this.$message.error(res.message)
            }
          })
        }
      })
    },
    submitFormDelete () {
      let params = {
        columnIds: this.onceTable[0].id
      }
      deleteColumnOnce(params).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogDelete = false
          this.showListTwo()
        } else {
          this.$message.error(res.message)
        }
      })
    },
    /* 重置 */
    resetForm (val) {
      if (val == 1) {
        this.$refs['ruleFormAdd'].clearValidate()
        this.paramsAdd = {columnUrl: ''}
      } else if (val == 2) {
        this.$refs['ruleFormEdit'].clearValidate()
        this.paramsEdit = {
          id: this.paramsEdit.id,
          columnPid: this.paramsEdit.columnPid,
          columnUrl: ''
        }
      }
    },
    /* 关闭弹框 */
    handleClose () {
      this.dialogAdd = false
      this.dialogEdit = false
      this.dialogDelete = false
    },
    urlFillIn (val) {
      if (val == 99) {
        this.paramsEdit.columnUrl = 'http://'
      }
    }
  },
  created () {
    this.showList()
  },
  beforeUpdate () {
    // this.handleNodeClick()
    // console.log(this.paramsTwo);
  },
  watch: {
    paramsTwo (val, item) {
      this.paramsTwo = val
      console.log(val)
    }
  }
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  .el-dialog{
    .el-select{
      width: 100%;
    }
  }
  .dialog-title {
    background-color: #0067AD;
    img{
      vertical-align: middle;
    }
  }
</style>
