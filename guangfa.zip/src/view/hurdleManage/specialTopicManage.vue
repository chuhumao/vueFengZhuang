<!-- 专题管理 -->
<template>
  <div>
    <div class="contentPadding" style="background-color: #fff">
      <!--新增，编辑，删除-->
      <div class="headerBtn">
        <span @click="showDigBtn(1)"><img src="../../assets/hurdle/hurdleAdd.png" alt="">新增</span>
        <span @click="showDigBtn(2)"><img src="../../assets/hurdle/hurdleDelete.png" alt="">删除</span>
      </div>
      <!-- 表格 -->
      <div class="all-Table">
        <el-table :data="tableData" stripe border @selection-change="handleSelectionChange" style="width: 100%">
          <el-table-column type="selection" width="55">
          </el-table-column>
          <el-table-column prop="titleProper" label="题名">
          </el-table-column>
          <el-table-column prop="createUser" label="创建人">
          </el-table-column>
          <el-table-column prop="createDate" label="创建时间">
          </el-table-column>
          <el-table-column prop="lastUser" label="最后修改人">
          </el-table-column>
          <el-table-column prop="lastDate" label="最后修改时间">
          </el-table-column>
          <el-table-column prop="itemCount" label="附件数">
          </el-table-column>
          <el-table-column label="操作" align="center">
            <template slot-scope="scope">
              <el-button size="mini" class="table-botton" @click="openDetail(scope.row)">查看
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <!-- 分页 -->
      <div class="pageLayout">
        <el-pagination @current-change="currChange" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.totals">
        </el-pagination>
      </div>
    </div>
    <!-- 新增弹框 -->
    <el-dialog :visible.sync="dialogAdd" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicAdd.png" alt="">
        录入专题信息
      </div>
      <el-form :model="paramsAdd" :rules="rulesAudit" ref="paramsAdd" label-width="120px">
        <el-form-item label="题名：" prop="titleProper">
          <el-input v-model="paramsAdd.titleProper"></el-input>
        </el-form-item>
        <el-form-item label="专题图片：" prop="showName" class="input-uploads">
          <el-input v-model="paramsAdd.showName" disabled></el-input>
          <el-upload class="upload-demo upload-show" action="#" accept="image/jpeg,image/png,image/jpg,image/gif,image/bmp" :http-request="httpRequest" :show-file-list="false" :on-exceed="handleExceed1" :on-change="handleChange1">
            <el-button size="small" type="primary">点击上传</el-button>
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="submitFormAdd">保存</el-button>
        <el-button @click="dialogAdd = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 删除弹框 -->
    <el-dialog :visible.sync="dialogDelete" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicDel.png" alt="">
        删除
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要删除此专题吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="clickDel">确定</el-button>
        <el-button @click="dialogDelete = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 查看弹框 -->
    <el-dialog :visible.sync="detailFlag" width="1100px" class="hurdleAll" :before-close="closeDetail">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicShow.png" alt="">
        专题(题名)
      </div>
      <div class="headerBtn" style="margin-top: -14px;">
        <span @click="openUpload"><img src="../../assets/hurdle/topicUpload.png" alt="">上传</span>
        <span @click="openDelete"><img src="../../assets/hurdle/hurdleDelete.png" alt="">删除</span>
      </div>
      <div>
        <!-- 表格 -->
        <div class="all-Table">
          <el-table :data="tableDetail" stripe border @selection-change="detailChange" style="width: 100%">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="titleProper" label="题名">
            </el-table-column>
            <el-table-column prop="fileSize" label="文件大小">
            </el-table-column>
            <el-table-column prop="fileFormat" label="文件格式">
            </el-table-column>
            <el-table-column prop="createUser" label="创始人">
            </el-table-column>
            <el-table-column prop="createDate" label="创建时间">
            </el-table-column>
            <el-table-column label="操作" align="center">
              <template slot-scope="scope">
                <el-button size="mini" class="table-botton" @click="openSee(scope.row)">查看
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="detailCurrChange" :current-page="detailParams.page" :page-size="detailParams.rows" layout="prev, pager, next, jumper" :total="detailParams.totals">
          </el-pagination>
        </div>
      </div>
    </el-dialog>
    <!-- 详情--上传弹框 -->
    <el-dialog :visible.sync="diaUpload" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicUpload.png" alt="">
        文件上传
      </div>
      <el-form label-width="120px" :rules="rulesUpload" ref="uploadParams" :model="uploadParams">
        <el-form-item label="上传：" class="input-uploads" prop="uploadName">
          <el-input v-model="uploadParams.uploadName" disabled></el-input>
          <el-upload class="upload-demo upload-show" action="#" :show-file-list="false" :auto-upload="false" accept=".pdf,.PDF" :on-exceed="handleExceed" :on-change="handleChange">
            <el-button size="small" type="primary">选择</el-button>
          </el-upload>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="clicSave">保存</el-button>
        <el-button @click="diaUpload = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 详情--删除弹框 -->
    <el-dialog :visible.sync="deleteFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicDel.png" alt="">
        删除附件材料确认
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要删除当前材料吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="detailDelete">确定</el-button>
        <el-button @click="deleteFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 详情---查看弹框 -->
    <el-dialog :visible.sync="seeFlag" width="1100px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicShow.png" alt="">
        查看材料
      </div>
      <div class="see">
        <div class="see-left">
          <el-tree class="filter-tree" :expand-on-click-node="false" :data="dataShow" default-expand-all :props="defaultProps" @node-click="handleNodeClick">
          </el-tree>
        </div>
        <div class="see-right">
          <embed :src='showUrl' type="application/pdf" width="100%" height="100%">
        </div>
      </div>
    </el-dialog>
    <!-- 该文件非PDF,是否需要进行下载(查看失败) -->
    <el-dialog :visible.sync="notShow1" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle1.png" alt="">
        下载确认
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/nShow1.png" alt="">
        <div>该文档非PDF文件，是否要进行下载？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="clickDown">确定</el-button>
        <el-button @click="notShow1 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 对不起，您访问的材料还未扫描。(查看失败) -->
    <el-dialog :visible.sync="notShow2" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/nShow2.png" alt="">
        <div>对不起，您访问的材料还未扫描。</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="notShow2 = false">确定</el-button>
        <el-button @click="notShow2 = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import qs from 'qs'
import axios from 'axios';
import { BASICURL, topicList, topicAdd, topicDel, topicDetail, detailDel, detailTree, detailDoc, downDoc, viewPdf, saveUpload } from '@/js/getData';
import { valueIndex } from '@/js/transitionText'
import { topicUpload } from '../../js/uploadImg'
export default {
  name: 'specialTopicManage',
  data() {
    return {
      dataShow: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      params: {
        totals: 0,
        rows: 13,
        page: 1
      },
      onceTable: [],
      tableData: [],
      paramsAdd: {
        showName: ''
      },
      dialogAdd: false,
      paramsEdit: {},
      dialogEdit: false,
      dialogDelete: false,
      rulesAudit: {
        titleProper: [
          { required: true, message: '题名不能为空！', trigger: 'blur' },
        ],
        showName: [
          { required: true, message: '专题图片不能为空！', trigger: 'change' },
        ]
      },
      detailFlag: false,
      detailParams: {
        totals: 0,
        rows: 8,
        page: 1
      },
      tableDetail: [],
      detailArr: [],
      selectArr: [],
      diaUpload: false,
      uploadParams: {
        uploadName: ''
      },
      rulesUpload: {
        uploadName: [
          { required: true, message: '上传文件不能为空！', trigger: 'change' },
        ]
      },
      deleteFlag: false,
      seeFlag: false,
      topicId: null,
      notShow1: false,
      notShow2: false,
      pdfId: null,
      showUrl: '',
      downName: '',
      fileList: {},
    }
  },
  methods: {
    //查询专题列表
    oneSearch() {
      this.params.page = 1;
      this.searchList();
    },
    searchList() {
      topicList(this.params).then(res => {
        if (res.code == 0) {
          this.tableData = res.data.rows;
          this.params.totals = res.data.total;
        } else this.$message.error(res.message);
      })
    },
    // 列表单页面点击
    currChange(val) {
      this.params.page = val;
      this.searchList();
    },
    handleSelectionChange(val) {
      this.onceTable = val
    },
    //打开专题新增/删除
    showDigBtn(val) {
      if (val == 1) {
        this.paramsAdd = {
          showName: ''
        }
        this.dialogAdd = true;
        if (this.$refs['paramsAdd']) {
          this.$nextTick(() => {
            this.$refs['paramsAdd'].clearValidate();
          })
        }
      } else if (val == 2) {
        this.selectLength()
      }
    },
    //选择条目
    selectLength() {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.onceTable.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        this.dialogDelete = true;
      }
    },
    //专题删除
    clickDel() {
      let ids = this.onceTable[0].id;
      topicDel({ id: ids }).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.dialogDelete = false;
          this.oneSearch();
        } else this.$message.error(res.message);
      })
    },
    //打开详情页面
    openDetail(val) {
      this.topicId = this.detailParams.id = val.id;
      this.oneDetailSelect();
      this.detailFlag = true;
    },
    oneDetailSelect() {
      this.detailParams.page = 1;
      this.detailSelect();
    },
    detailSelect() {
      topicDetail(this.detailParams).then(res => {
        if (res.code == 0) {
          this.tableDetail = res.data.rows;
          this.detailParams.totals = res.data.total;
        } else this.$message.error(res.message);
      })
    },
    detailCurrChange(val) {
      this.detailParams.page = val;
      this.detailSelect();
    },
    detailChange(val) {
      this.detailArr = val;
    },
    //关闭详情页面
    closeDetail() {
      this.detailFlag = false;
      this.oneSearch()
    },
    //专题新增
    // 文件超过1个时提示
    handleExceed1(file, fileList) {
      this.$message.warning(`当前只能选择 1 个文件，本次已选择了 ${file.length} 个文件`)
    },
    handleChange1(file, fileList) {
      this.paramsAdd.showName = file.name;
    },
    httpRequest(data) {
      let _this = this
      _this.paramsAdd.uploadPicture = data.file
    },
    submitFormAdd() {
      this.$refs['paramsAdd'].validate((valid) => {
        if (valid) {
          let formData = new FormData()
          formData.append('uploadPicture', this.paramsAdd.uploadPicture)
          formData.append('titleProper', this.paramsAdd.titleProper)
          axios({
            url: BASICURL + '/gdda-new/rewrite/cms/subject/saveSubject',
            method: 'post',
            data: formData,
            header: {
              'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryifZvuMMCEDoSb64E'
            }
          }).then((res) => {
            if (res.data.code == 0) {
              this.dialogAdd = false;
              this.$message.success(res.data.message);
              this.oneSearch();
            } else this.$message.error(res.data.message);
          })
        }
      })

    },
    //弹框删除
    openDelete() {
      if (this.detailArr.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.detailArr.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        this.deleteFlag = true;
      }
    },
    detailDelete() {
      let ids = this.detailArr[0].id;
      detailDel({ id: ids }).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.deleteFlag = false;
          this.oneDetailSelect();
        } else this.$message.error(res.message);
      })
    },
    //弹框-查看
    openSee(val) {
      this.pdfId = val.id;
      this.getTree();
      this.seeFlag = true;
    },
    //点击专题树
    handleNodeClick(val) {
      this.downName = val.text
      this.showUrl = '';
      detailDoc({ id: val.id }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 2) { //页面会显示 该文件非PDF,是否需要进行下载
            this.notShow1 = true;
          } else if (res.data.optFlag == -1) { //会显示 对不起，你访问的文件还未扫描
            this.notShow2 = true;
          } else {
            this.showUrl = BASICURL + '/gdda-new/cms/subject/viewPdf?docId=' + val.id;
          }
        } else this.$message.error(res.message);
      })
    },
    //获取专题树
    getTree() {
      detailTree({ id: this.topicId }).then(res => {
        if (res.code == 0) {
          this.dataShow = res.data;
        } else this.$message.error(res.message);
      })
    },
    //下载文件
    clickDown() {
      let ids = {
        id: this.pdfId
      };
      valueIndex().exportFiles('/gdda-new/cms/subject/downLoadFile', ids, this.downName,'get');
      this.notShow1 = false;
    },
    //弹框--上传文件
    handleChange(file, fileList) {
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('type', 'sub')
      formData.append('name', 'file')
      axios({
        url: topicUpload,
        method: 'post',
        data: formData,
        header: {
          'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryifZvuMMCEDoSb64E'
        }
      }).then((res) => {
        if (res.data.data.result == 1) {
          let imgs = [{
            path: res.data.data.pathAndMD5.path,
            md5: res.data.data.pathAndMD5.md5
          }];
          this.fileList.imgVal = JSON.stringify(imgs)
          this.uploadParams.uploadName = file.name;
        } else this.$message.error(res.data.message);
      })
    },
    // 文件超过1个时提示
    handleExceed(file, fileList) {
      this.$message.warning(`当前只能选择 1 个文件，本次已选择了 ${file.length} 个文件`)
    },
    //上传保存按钮
    openUpload() {
      this.fileList = {};
      this.uploadParams = {
        uploadName: ''
      };
      this.diaUpload = true;
      if (this.$refs['uploadParams']) {
        this.$nextTick(() => {
          this.$refs['uploadParams'].clearValidate();
        })

      }
    },
    clicSave() {
      this.$refs['uploadParams'].validate((valid) => {
        if (valid) {
          this.fileList.subjectId = this.topicId; //父专题ID
          saveUpload(this.fileList).then(res => {
            if (res.data.optFlag == -1) {
              this.$message.error("上传失败，因为文件" + res.data.msg + "已上传过了，请重新选择上传文件");
            } else if (res.data.optFlag == 1) {
              this.$message.error("上传失败" + res.data.msg, );
            } else {
              this.diaUpload = false;
              this.oneDetailSelect();
            }

          })
        }
      })

    }
  },
  created() {
    this.searchList();
  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.see {
  width: 100%;
  clear: both;
  height: 500px;
  margin-top: -30px;

  .see-left {
    width: 40%;
    float: left;
    overflow: auto;
    height: 100%;
    padding-top: 20px;

    .filter-tree {
      display: inline-block;
    }
  }

  .see-right {
    width: 59%;
    float: left;
    padding-top: 20px;
    border-left: 3px solid #1982BF;
    height: 100%;
  }
}

.input-uploads {
  .el-input {
    width: 70%;
  }

  .upload-show {
    display: inline-block;

    .el-button--primary {
      height: 36px;
      background: #0067AD;
      border-color: #0067AD;
    }
  }
}

.mt-31 {
  margin-top: -31px;
}

.table-botton {
  width: 80%;
  background: #08A9E6;
  color: #fff;
}

.headerBtn {
  margin-bottom: 10px;

  span {
    display: inline-block;
    font-size: 12px;
    color: #282828;
    margin-right: 20px;
    cursor: pointer;

    img {
      vertical-align: middle;
      margin-right: 4px;
    }
  }
}

.el-dialog {
  .el-select {
    width: 100%;
  }
}

.dialog-title {
  background-color: #0067AD;

  img {
    vertical-align: middle;
  }
}

/deep/.hurdleAll>div>div:first-child {
  padding: 0 !important;

  >div {
    height: 30px;
    line-height: 30px;
    text-indent: 10px;
    font-size: 14px;
    color: #fff;
  }

  button {
    top: 8px;

    i {
      color: #fff;
    }
  }
}

</style>
