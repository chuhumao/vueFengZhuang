<!-- 新闻管理 -->
<template>
  <el-container style="background-color: #fff;">
    <div class="bigDog menuShrink black-tree">
      <PinDao></PinDao>
      <el-tree
        :data="treTable"
        :props="defaultProps"
        :check-strictly="true"
        :default-expand-all="true"
        :expand-on-click-node="false"
        :highlight-current="true"
        accordion
        @node-click="handleNodeClick">
        <span class="custom-tree-node"  slot-scope="{ node, data }">
          <span class="treeSpan" :dataType="data.type">
            <img src="../../assets/hurdle/hurdleNew.png" alt="">
            {{ node.label }}
          </span>
        </span>
      </el-tree>
    </div>
    <el-main style="padding:0; width: 86%;">
      <div class="contentPadding tableShrink">
        <!--新增，编辑，删除-->
        <div class="headerBtn">
          <p class="shuSpan">|</p>
          <p @click="showDigBtn(1)"><img src="../../assets/hurdle/hurdleAdd.png" alt=""><span>新增</span></p>
          <p @click="showDigBtn(2)"><img src="../../assets/hurdle/hurdleAudit.png" alt=""><span>编辑</span></p>
          <p @click="showDigBtn(12)"><img src="../../assets/hurdle/issueBtn.png" alt=""><span>发布</span></p>
          <p @click="showDigBtn(3)"><img src="../../assets/hurdle/hurdleDelete.png" alt=""><span>删除</span></p>
          <p v-if="columnShowId">
            <span class="shuSpan" style="display: inline-block;width: 30px">|</span>
            <span class="double">
            <img src="../../assets/hurdle/showYuan.png" alt="">
            <span @click="showDigBtn(4)">公开</span>&nbsp;&nbsp;&nbsp;
            <span @click="showDigBtn(5)">隐藏</span>
          </span>
            <span class="shuSpan" style="display: inline-block;width: 30px">|</span>
            <span class="double">
            <img src="../../assets/hurdle/topJian.png" alt="">
            <span @click="showDigBtn(6)">置顶</span>&nbsp;&nbsp;&nbsp;
            <span @click="showDigBtn(7)">取消</span>
          </span>
            <span class="shuSpan" style="display: inline-block;width: 30px">|</span>
            <span class="double">
            <img src="../../assets/hurdle/cuBtn.png" alt="">
            <span @click="showDigBtn(8)">加粗</span>&nbsp;&nbsp;&nbsp;
            <span @click="showDigBtn(9)">取消</span>
          </span>
            <span class="shuSpan" style="display: inline-block;width: 30px">|</span>
            <span class="double">
            <img src="../../assets/hurdle/redBtn.png" alt="">
            <span @click="showDigBtn(10)">红标</span>&nbsp;&nbsp;&nbsp;
            <span @click="showDigBtn(11)">取消</span>
          </span>
          </p>
          <p class="shuSpan">|</p>
          <p class="issueBtn">
            <img src="../../assets/hurdle/issueBtn.png" alt="">
            <span @click="sendBranch">发送部门大事记代办</span>
          </p>
          <p class="searchInput">
            标题名称：
            <el-input v-model="paramsTwo.newsTitle" placeholder="请输入内容"></el-input>
            <span class="searchBtn" @click="titleBtnList"><img src="../../assets/hurdle/searchBtn.png" alt="">搜索</span>
          </p>
          <p style="width: 230px;" v-if="branchShow">
            部门名称：
            <el-select v-model="paramsTwo.orgFlag1" filterable placeholder="请选择" style="width: 60%" @change="branchChang">
              <el-option
                v-for="(item, index) in branchListContent"
                :key="index"
                :label="item.flag1+' '+item.organizeName"
                :value="item.flag1"
              >
              </el-option>
            </el-select>
          </p>
          <p style="width: 230px;" v-if="branchShow">
            <img src="../../assets/system/pullWord.png" alt="">
            <span @click="wordBtn">导出word文档</span>
          </p>
        </div>
        <!-- 表格 -->
        <div class="all-Table">
          <el-table
            :data="tableData"
            stripe
            border
            @selection-change="handleSelectionChange">
            <el-table-column
              type="selection"
              align="center"
              width="55">
            </el-table-column>
            <el-table-column
              v-if="paramsTwo.columnId == '4028b88160904f760160905ad73001b8'"
              prop="userName"
              label="姓名"
              width="163">
            </el-table-column>
            <el-table-column
              v-if="columnShow"
              show-overflow-tooltip
              prop="newsTitle"
              label="新闻标题"
              width="160">
            </el-table-column>
            <el-table-column
              v-if="columnShow"
              show-overflow-tooltip
              prop="yearCode"
              label="年度"
              width="160">
            </el-table-column>
            <el-table-column
              v-if="columnShow"
              prop="newsDate"
              label="适用时间"
              width="200">
              <template slot-scope="scope">
                <span>{{ scope.row.newsDate }}</span>
              </template>
            </el-table-column>
            <el-table-column
              v-if="columnShow"
              show-overflow-tooltip
              prop="newsAuthor"
              label="作者/来源"
              width="130">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="newsTheme"
              label="主题"
              width="210">
              <template slot-scope="scope">
                <span>{{ scope.row.newsTheme }}</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="status"
              label="发布状态"
              width="180">
              <template slot-scope="scope">
                <span v-if="scope.row.status == '0'">已发布</span>
                <span v-else-if="scope.row.status == '1'">未发布</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="openType"
              label="公开"
              width="140">
              <template slot-scope="scope">
                <span v-if="scope.row.openType == '0'">隐藏</span>
                <span v-else-if="scope.row.openType == '1'">公开</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="isTop"
              label="置顶"
              width="140">
              <template slot-scope="scope">
                <span v-if="scope.row.isTop == '0'">否</span>
                <span v-else-if="scope.row.isTop == '1'">是</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="isBold"
              label="标题加粗"
              width="140">
              <template slot-scope="scope">
                <span v-if="scope.row.isBold == '0'">否</span>
                <span v-else-if="scope.row.isBold == '1'">是</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="isRedTitle"
              label="标题红色"
              width="140">
              <template slot-scope="scope">
                <span v-if="scope.row.isRedTitle == '0'">否</span>
                <span v-else-if="scope.row.isRedTitle == '1'">是</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="modifyMan"
              label="修改人"
              width="180">
            </el-table-column>
            <el-table-column
              prop="modifyTime"
              label="修改时间"
              width="200">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChange"
            :current-page="paramsTwo.page"
            :page-size="paramsTwo.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo.total">
          </el-pagination>
        </div>
      </div>
    </el-main>
    <!-- 新增弹框--广发之最 -->
    <el-dialog
      :visible.sync="dialogAdd"
      width="1100px"
      class="hurdleAll"
      :before-close="handleClose">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicShow.png" alt="">
        新增
      </div>
      <el-form :model="paramsAdd" :rules="rulesAudit" ref="ruleFormAdd" label-width="120px" class="demo-ruleForm">
        <el-form-item label="新闻标题：" prop="newsTitle">
          <el-input v-model="paramsAdd.newsTitle" style="width: 50%"></el-input>
        </el-form-item>
        <el-form-item label="面向企业：" prop="orgFlag1">
          <el-select v-model="paramsAdd.orgFlag1" filterable style="width: 50%">
            <el-option
              v-for="(item, index) in branchListContent"
              :key="index"
              :label="item.flag1+' '+item.organizeName"
              :value="item.flag1"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="作者或来源：">
          <el-input v-model="paramsAdd.newsAuthor" style="width: 50%"></el-input>
        </el-form-item>
        <el-form-item label="表现形式：">
          <span>
            <span>置顶</span>
            <el-switch
              v-model="paramsAdd.isTop"
              @change="paramsAddIsTop"
              :active-value="1"
              :inactive-value="0">
            </el-switch>
          </span>&nbsp;&nbsp;&nbsp;
          <span>
            <span>标题加粗</span>
            <el-switch
              v-model="paramsAdd.isBold"
              @change="paramsAddIsBold"
              :active-value="1"
              :inactive-value="0">
            </el-switch>
          </span>&nbsp;&nbsp;&nbsp;
          <span>
            <span>标题红色</span>
            <el-switch
              v-model="paramsAdd.isRedTitle"
              @change="paramsAddIsRedTitle"
              :active-value="1"
              :inactive-value="0">
            </el-switch>
          </span>&nbsp;&nbsp;&nbsp;
        </el-form-item>
        <el-form-item class="editorXin" label="适用日期：" prop="newsDate">
          <el-date-picker
            v-model="paramsAdd.newsDate"
            type="date"
            format="yyyy 年 MM 月 dd 日"
            value-format="yyyy-MM-dd"
            placeholder="请选择时间">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="主题：">
          <el-input v-model="paramsAdd.newsTheme" style="width: 50%"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="新闻内容：" v-model="paramsAdd.newsContent">
          <editor></editor>
        </el-form-item>
      </el-form>
      <br>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitFormAdd('1')">保存</el-button>
        <el-button type="primary" @click="submitFormAdd('0')">确定发布</el-button>
        <el-button @click="resetForm('1')">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 编辑弹框--广发之最 -->
    <el-dialog
      :visible.sync="dialogEdit"
      width="1100px"
      class="hurdleAll"
      :before-close="handleClose">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicShow.png" alt="">
        编辑
      </div>
      <el-form :model="paramsEdit" :rules="rulesAudit" ref="ruleFormEdit" label-width="120px" class="demo-ruleForm">
        <el-form-item label="新闻标题：" prop="newsTitle">
          <el-input v-model="paramsEdit.newsTitle" style="width: 50%"></el-input>
        </el-form-item>
        <el-form-item label="面向企业：" prop="orgFlag1">
          <el-select v-model="paramsEdit.orgFlag1" filterable style="width: 50%">
            <el-option
              v-for="(item, index) in branchListContent"
              :key="index"
              :label="item.flag1+' '+item.organizeName"
              :value="item.flag1"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="作者或来源：">
          <el-input v-model="paramsEdit.newsAuthor" style="width: 50%"></el-input>
        </el-form-item>
        <el-form-item label="表现形式：">
          <span>
            <span>置顶</span>
            <el-switch
              v-model="paramsEdit.isTop"
              @change="paramsEditIsTop"
              :active-value="1"
              :inactive-value="0">
            </el-switch>
          </span>&nbsp;&nbsp;&nbsp;
          <span>
            <span>标题加粗</span>
            <el-switch
              v-model="paramsEdit.isBold"
              @change="paramsEditIsBold"
              :active-value="1"
              :inactive-value="0">
            </el-switch>
          </span>&nbsp;&nbsp;&nbsp;
          <span>
            <span>标题红色</span>
            <el-switch
              v-model="paramsEdit.isRedTitle"
              @change="paramsEditIsRedTitle"
              :active-value="1"
              :inactive-value="0">
            </el-switch>
          </span>&nbsp;&nbsp;&nbsp;
        </el-form-item>
        <el-form-item class="editorXin" label="适用日期：" prop="newsDate">
          <el-date-picker
            v-model="paramsEdit.newsDate"
            type="date"
            format="yyyy 年 MM 月 dd 日"
            value-format="yyyy-MM-dd"
            placeholder="请选择">
          </el-date-picker>
        </el-form-item>
        <el-form-item label="主题：">
          <el-input v-model="paramsEdit.newsTheme" style="width: 50%"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="新闻内容：" v-model="paramsEdit.newsContent">
          <editor></editor>
        </el-form-item>
      </el-form>
      <br>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitFormEdit('1')">保存</el-button>
        <el-button type="primary" @click="submitFormEdit('0')">确定发布</el-button>
        <el-button @click="resetForm('2')">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 确定与否弹框 -->
    <el-dialog
      :visible.sync="dialogDelete"

      width="444px"
      class="hurdleAll"
      :before-close="handleClose">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicShow.png" alt="">
        {{ paramsThree.title }}
      </div>
      <div>确定要{{ paramsThree.title }}此数据吗？</div>
      <div v-if="paramsThree.title == '删除'">注意：如果某项包含有子数据，则不能被删除。</div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitFormDelete">确定</el-button>
        <el-button @click="dialogDelete = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 大事记弹框 -->
    <el-dialog
      :visible.sync="sendBranchDialog"
      width="444px"
      class="hurdleAll"
      :before-close="handleClose">
      <div slot="title" class="dialog-title">
        <!--<img src="../../assets/hurdle/topicShow.png" alt="">-->
        发送部门大事记代办
      </div>
      <el-form :model="sendBranchParams" :rules="rulesAudit" ref="ruleFormSendBranchDialog" label-width="120px" class="demo-ruleForm">
        <el-form-item label="所属部门：" prop="writerDept">
          <el-select v-model="sendBranchParams.writerDept" filterable placeholder="请选择" style="width: 60%" @change="sendBranchChang">
            <el-option
              v-for="(item, index) in branchListContent"
              :key="index"
              :label="item.flag1+' '+item.organizeName"
              :value="item.flag1"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="部门角色：" prop="writerName">
          <el-input type="text" v-model="sendBranchParams.writerName" :readonly="sendBranchParams.inputShow"></el-input>
        </el-form-item>
        <el-form-item label="事件标题：" prop="titleProper">
          <el-input v-model="sendBranchParams.titleProper"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="日期：" prop="bmdate">
          <el-date-picker
            v-model="sendBranchParams.bmdate"
            type="date"
            format="yyyy 年 MM 月 dd 日"
            value-format="yyyy-MM-dd"
            placeholder="请选择">
          </el-date-picker>
        </el-form-item>
      </el-form>
      <br>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitFormAddBranch">保存</el-button>
        <el-button @click="resetForm('3')">关闭</el-button>
      </div>
    </el-dialog>

    <!-- 新增弹框--广发名人堂 -->
    <el-dialog
      :visible.sync="dialogAddUser"
      width="1100px"
      class="hurdleAll"
      :before-close="handleClose">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicShow.png" alt="">
        新增
      </div>
      <el-form :model="paramsAdd" :rules="rulesAudit" ref="ruleFormAdd" label-width="120px" class="demo-ruleForm">
        <el-form-item label="姓名：" prop="userName">
          <el-input v-model="paramsAdd.userName" style="width: 50%"></el-input>
        </el-form-item>
        <el-form-item label="面向企业：" prop="orgFlag1">
          <el-select v-model="paramsAdd.orgFlag1" filterable  style="width: 50%">
            <el-option
              v-for="(item, index) in branchListContent"
              :key="index"
              :label="item.flag1+' '+item.organizeName"
              :value="item.flag1"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="年度：" prop="yearCode">
          <el-input v-model="paramsAdd.yearCode" style="width: 50%"></el-input>
        </el-form-item>
        <el-form-item label="主题：">
          <el-input v-model="paramsAdd.newsTheme" style="width: 50%"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="内容：" v-model="paramsAdd.fameContent">
          <editor></editor>
        </el-form-item>
      </el-form>
      <br>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitFormAddUser('1')">保存</el-button>
        <el-button type="primary" @click="submitFormAddUser('0')">确定发布</el-button>
        <el-button @click="resetForm('1')">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 编辑弹框--广发名人堂 -->
    <el-dialog
      :visible.sync="dialogEditUser"
      width="1100px"
      class="hurdleAll"
      :before-close="handleClose">
      <div slot="title" class="dialog-title">
        <!--<img src="../../assets/hurdle/topicShow.png" alt="">-->
        编辑
      </div>
      <el-form :model="paramsEdit" :rules="rulesAudit" ref="ruleFormEdit" label-width="120px" class="demo-ruleForm">
        <el-form-item label="姓名：" prop="userName">
          <el-input v-model="paramsEdit.userName" style="width: 50%"></el-input>
        </el-form-item>
        <el-form-item label="面向企业：" prop="orgFlag1">
          <el-select v-model="paramsEdit.orgFlag1" filterable  style="width: 50%">
            <el-option
              v-for="(item, index) in branchListContent"
              :key="index"
              :label="item.flag1+' '+item.organizeName"
              :value="item.flag1"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="年度：" prop="yearCode">
          <el-input v-model="paramsEdit.yearCode" style="width: 50%"></el-input>
        </el-form-item>
        <el-form-item label="主题：">
          <el-input v-model="paramsEdit.newsTheme" style="width: 50%"></el-input>
        </el-form-item>
        <el-form-item class="editorXin" label="内容：" v-model="paramsEdit.fameContent">
          <editor></editor>
        </el-form-item>
      </el-form>
      <br>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitFormEditUser('1')">保存</el-button>
        <el-button type="primary" @click="submitFormEditUser('0')">确定发布</el-button>
        <el-button @click="resetForm('2')">关闭</el-button>
      </div>
    </el-dialog>

    <!-- 新增弹框--广发大事记or部门大事记 -->
    <el-dialog
      :visible.sync="dialogAddBranch"
      width="1100px"
      class="hurdleAll"
      :before-close="handleClose">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicShow.png" alt="">
        新增
      </div>
      <el-form :model="paramsAdd" :rules="rulesAudit" ref="ruleFormAdd" label-width="120px" class="demo-ruleForm">
        <el-form-item label="所属部门：" prop="orgFlag1">
          <el-select v-model="paramsAdd.orgFlag1" filterable   style="width: 50%">
            <el-option
              v-for="(item, index) in branchListContent"
              :key="index"
              :label="item.flag1+' '+item.organizeName"
              :value="item.flag1"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item class="editorXin" label="适用日期：" prop="dsjdate">
          <el-date-picker
            v-model="paramsAdd.dsjdate"
            type="date"
            format="yyyy 年 MM 月 dd 日"
            value-format="yyyy-MM-dd"
            placeholder="请选择时间">
          </el-date-picker>
        </el-form-item>
        <el-form-item class="editorXin" label="大事记内容：">
          <div class="btnAddBranch">
            <span @click="myAddList"><img src="../../assets/system/p1.png" alt="">添加</span>
            <span @click="myDeleteList"><img src="../../assets/system/p3.png" alt="">删除</span>
          </div>
          <ul>
            <li class="wDCheckNone wDCheckNoneOne wDCheckNoneTheOne">选择</li>
            <li class="wDCheckNone wDCheckNoneTwo wDCheckNoneTheOne">日期</li>
            <li class="wDCheckNone wDCheckNoneThree wDCheckNoneTheOne">内容</li>
          </ul>
          <ul>
            <li v-for="(item, index) in mydata" :key="index">
              <div class="wDCheckNone wDCheckNoneOne">
                <el-checkbox-group v-model="checkList" @change="mydataChange(item, index)" :max="1">
                  <el-checkbox :label="item"></el-checkbox>
                </el-checkbox-group>
              </div>
              <div class="wDCheckNone wDCheckNoneTwo">
                <el-select v-model="item.dsjDate" filterable placeholder="请选择">
                  <el-option
                    v-for="item in selectTypeListDate"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id">
                  </el-option>
                </el-select>
              </div>
              <div class="wDCheckNone wDCheckNoneThree">
                <el-input v-model="item.dsjContent" placeholder="请输入内容"></el-input>
              </div>
            </li>
          </ul>
        </el-form-item>
      </el-form>
      <br>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitFormAddBranchBtn('1')">保存</el-button>
        <el-button type="primary" @click="submitFormAddBranchBtn('0')">确定发布</el-button>
        <el-button @click="resetForm('1')">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 编辑弹框--广发大事记or部门大事记 -->
    <el-dialog
      :visible.sync="dialogEditBranch"
      width="1100px"
      class="hurdleAll"
      :before-close="handleClose">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicShow.png" alt="">
        编辑
      </div>
      <el-form :model="paramsEdit" :rules="rulesAudit" ref="ruleFormAdd" label-width="120px" class="demo-ruleForm">
        <el-form-item label="所属部门：" prop="orgFlag1">
          <el-select v-model="paramsEdit.orgFlag1" filterable style="width: 50%">
            <el-option
              v-for="(item, index) in branchListContent"
              :key="index"
              :label="item.flag1+' '+item.organizeName"
              :value="item.flag1"
            >
            </el-option>
          </el-select>
        </el-form-item>
        <el-form-item class="editorXin" label="适用日期：" prop="dsjdate">
          <el-date-picker
            v-model="paramsEdit.dsjdate"
            type="date"
            format="yyyy 年 MM 月 dd 日"
            value-format="yyyy-MM-dd"
            placeholder="请选择时间">
          </el-date-picker>
        </el-form-item>
        <el-form-item class="editorXin" label="大事记内容：" style="max-height: 374px;overflow: auto;">
          <div class="btnAddBranch">
            <span @click="myAddList"><img src="../../assets/system/p1.png" alt="">添加</span>
            <span @click="deleteContentListOnce"><img src="../../assets/system/p3.png" alt="">删除</span>
          </div>
          <ul>
            <li class="wDCheckNone wDCheckNoneOne wDCheckNoneTheOne">选择</li>
            <li class="wDCheckNone wDCheckNoneTwo wDCheckNoneTheOne">日期</li>
            <li class="wDCheckNone wDCheckNoneThree wDCheckNoneTheOne">内容</li>
          </ul>
          <ul>
            <li v-for="(item, index) in mydata" :key="index">
              <div class="wDCheckNone wDCheckNoneOne">
                <el-checkbox-group v-model="checkList" @change="mydataChange(item, index)" :max="1">
                  <el-checkbox :label="item"></el-checkbox>
                </el-checkbox-group>
              </div>
              <div class="wDCheckNone wDCheckNoneTwo">
                <el-select v-model="item.dsjDate" filterable placeholder="请选择">
                  <el-option
                    v-for="item in selectTypeListDate"
                    :key="item.id"
                    :label="item.name"
                    :value="item.id">
                  </el-option>
                </el-select>
              </div>
              <div class="wDCheckNone wDCheckNoneThree">
                <el-input v-model="item.dsjContent" placeholder="请输入内容"></el-input>
              </div>
            </li>
          </ul>
        </el-form-item>
      </el-form>
      <br>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="submitFormEditBranchBtn('1')">保存</el-button>
        <el-button type="primary" @click="submitFormEditBranchBtn('0')">确定发布</el-button>
        <el-button @click="resetForm('2')">关闭</el-button>
      </div>
    </el-dialog>
  </el-container>
</template>

<script>
import { listColumnTreeData, listNewsData, branchListOrg, deleteNews, updateNewsOfOpenOrNOt, updateNewsOfTopOrNot, updateNewsOfBoldOrNot,
  listDsjAuthorByDept, updateNewsOfRedOrNot, userGetNews, addSaveNews, editUpdateNews, releaseNews, addSaveHallOfFame, editUpdateHallOfFame,
  editUserGetNews, branchListTUser, addSaveMemorabilia, addSaveDsj1, addSaveDsjContent, roleListDsjContentData, editUpdateDsj, deleteDsjContent} from '@/js/getData'
import { wordPull } from '../../js/wordDerive'
import editor from '../../components/quillEditor/editor'
import PinDao from '../../components/menuChildren/pinDao'
import Bus from '../../utils/busEmit'
export default {
  name: 'newManage',
  components: {
    editor, PinDao
  },
  data () {
    return {
      checkList: [],
      ruleForm: {
        dsjContent: null,
        dsjDate: null,
      },
      treTable: [],
      branchUserListT: [], // 归档部门人
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      params: {
        total: 0,
        rows: 10,
        page: 1
      },
      paramsTwo: {
        total: 0,
        rows: 10,
        page: 1
      },
      paramsEditor: {},
      onceTable: [],
      tableData: [],
      mydata: [], // 广发大事记or部门大事记
      mydataSelect: {}, // 广发大事记or部门大事记
      mydataSelectIndex: null, // 广发大事记or部门大事记
      selectTypeList: [
        {id: 1, name: '内容页'},
        {id: 2, name: '信息列表页'},
        {id: 3, name: '图片列表页'},
        {id: 4, name: '视频列表'},
        {id: 99, name: '外部模块'},
        {id: 100, name: '栏目组别'}
      ],
      selectTypeListDate: [
        {id: 1, name: '1日'},
        {id: 2, name: '2日'},
        {id: 3, name: '3日'},
        {id: 4, name: '4日'},
        {id: 5, name: '5日'},
        {id: 6, name: '6日'},
        {id: 7, name: '7日'},
        {id: 8, name: '8日'},
        {id: 9, name: '9日'},
        {id: 10, name: '10日'},
        {id: 11, name: '11日'},
        {id: 12, name: '12日'},
        {id: 13, name: '13日'},
        {id: 14, name: '14日'},
        {id: 15, name: '15日'},
        {id: 16, name: '16日'},
        {id: 17, name: '17日'},
        {id: 18, name: '18日'},
        {id: 19, name: '19日'},
        {id: 20, name: '20日'},
        {id: 21, name: '21日'},
        {id: 22, name: '22日'},
        {id: 23, name: '23日'},
        {id: 24, name: '24日'},
        {id: 25, name: '25日'},
        {id: 26, name: '26日'},
        {id: 27, name: '27日'},
        {id: 28, name: '28日'},
        {id: 29, name: '29日'},
        {id: 30, name: '30日'},
        {id: 31, name: '31日'},
      ],

      paramsAdd: {},
      dialogAdd: false,
      paramsEdit: {},
      dialogEdit: false,
      dialogDelete: false,

      rulesAudit: {
        columnName: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        columnType: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        newsDate: [{ required: true, message: '请选择时间', trigger: 'blur'}],
        newsContent: [{ required: true, message: '请注意选择', trigger: 'blur'}],
        writerDept: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        titleProper: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        newsTitle: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        newsAuthor: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        orgFlag1: [{ required: true, message: '请注意选择', trigger: 'blur'}],
        yearCode: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        writerName: [{ required: true, message: '请选择有效编写人', trigger: 'blur'}],
        bmdate: [{ required: true, message: '请选择时间', trigger: 'blur'}],
        dsjdate: [{ required: true, message: '请选择时间', trigger: 'blur'}],
        userName: [{ required: true, message: '请注意填写', trigger: 'blur'}]
      },
      columnShow: false, // 字段隐藏
      columnShowId: false, // 公开，隐藏，等等一切操作 是否隐藏
      branchShow: false, // 部门名称
      branchListContent: [{flag1: '0000', organizeName: '全部'}], // 部门名称List
      paramsThree: {}, // 公开，隐藏 等等一切操作
      sendBranchDialog: false, // 部门大事记
      sendBranchParams: {
        inputShow: true
      },
      dialogAddBranch: false, // 部门大事记新增弹框
      dialogEditBranch: false, // 部门大事记编辑弹框
      dialogAddUser: false, // 广发大事记新增弹框
      dialogEditUser: false // 广发大事记编辑弹框
    }
  },
  methods: {
    // 树形菜单点击
    handleNodeClick (val) {
      // console.log(val);
      // this.paramsTwo.columnId = val.id
      if (val.id !== '4028b88160904f760160905ad73001b8') {
        this.columnShow = true
      } else {
        this.columnShow = false
      }
      if (val.id === '8a8262025a7e1227015a7e247e400001' || val.id === '8a8262025a7e1227015a7e24b0a00002') {
        this.columnShowId = false
      } else {
        this.columnShowId = true
      }
      if (val.id === '8a8262025a7e1227015a7e24b0a00002') {
        this.branchShow = true
      } else {
        this.branchShow = false
      }
      this.paramsTwo = {
        page: 1,
        rows: 10,
        total: 0,
        orgFlag1: null,
        columnId: val.id
      }
      listColumnTreeData({columnPid: val.id, id: val.id}).then(res => {
        if (res.data) {
          val.children = [...res.data]
        }
      })
      this.showListTwo()
    },
    showList () {
      listColumnTreeData(this.params).then(res => {
        this.treTable.push(res.data[0])
      })
    },
    showListTwo () {
      listNewsData(this.paramsTwo).then(res => {
        this.tableData = res.data.rows
        this.paramsTwo.total = res.data.total == 0? 0 : res.data.total
        // console.log(this.paramsTwo.total);
      })
    },
    handleSelectionChange (val) {
      this.onceTable = val
    },
    // 单页面点击
    handleCurrentChange (val) {
      this.paramsTwo.page = val
      this.showListTwo()
    },
    showDigBtn (val) {
      if (val == 1) {
        this.checkList = []
        this.paramsAdd = {}
        if (this.paramsTwo.columnId === '2c9180846e3c327d016e41d87d620008' || this.paramsTwo.columnId === '8a8262025a498e6b015a4999595d0001') {
          this.dialogAdd = true
          this.$nextTick(() => {
            let qlEditor = document.getElementsByClassName('ql-editor')
            let qlEditorP = qlEditor[0].getElementsByTagName('p')
            qlEditorP[0].innerText = null
          })
        } else if (this.paramsTwo.columnId === '8a8262025a7e1227015a7e24b0a00002' || this.paramsTwo.columnId === '8a8262025a7e1227015a7e247e400001') {
          this.mydata = []
          this.dialogAddBranch = true
        } else if (this.paramsTwo.columnId === '4028b88160904f760160905ad73001b8') {
          this.dialogAddUser = true
          this.$nextTick(() => {
            let qlEditor = document.getElementsByClassName('ql-editor')
            let qlEditorP = qlEditor[0].getElementsByTagName('p')
            qlEditorP[0].innerText = null
          })
        } else {
          this.dialogAdd = true
          this.$nextTick(() => {
            let qlEditor = document.getElementsByClassName('ql-editor')
            let qlEditorP = qlEditor[0].getElementsByTagName('p')
            qlEditorP[0].innerText = null
          })
        }
        this.paramsAdd.columnId = this.paramsTwo.columnId
      } else if (val == 2) {
        this.checkList = []
        let item = this.selectLength()
        if (item == 1) {
          if (this.paramsTwo.columnId === '2c9180846e3c327d016e41d87d620008' || this.paramsTwo.columnId === '8a8262025a498e6b015a4999595d0001') {
            userGetNews({newsId: this.onceTable[0].id}).then(res => {
              this.paramsEdit = res
              this.dialogEdit = true
              this.$nextTick(() => {
                let qlEditor = document.getElementsByClassName('ql-editor')
                let qlEditorP = qlEditor[0].getElementsByTagName('p')
                qlEditorP[0].innerText = res.newsContent || ''
              })
            })
          } else if (this.paramsTwo.columnId === '8a8262025a7e1227015a7e24b0a00002' || this.paramsTwo.columnId === '8a8262025a7e1227015a7e247e400001') {
            this.mydata = []
            this.dialogEditBranch = true
            roleListDsjContentData({id: this.onceTable[0].id}).then(res => {
              this.mydata = res.data.rows
              this.paramsEdit = JSON.parse(JSON.stringify(this.onceTable[0]))
              this.paramsEdit.dsjdate = JSON.parse(JSON.stringify(this.onceTable[0].newsDate))
              if (this.onceTable[0].orgFlag1.split(',').length > 1) {
                this.paramsEdit.orgFlag1 = JSON.parse(JSON.stringify(this.onceTable[0].orgFlag1.split(',')[1]))
              }
            })
          } else if (this.paramsTwo.columnId === '4028b88160904f760160905ad73001b8') {
            editUserGetNews({newsId: this.onceTable[0].id}).then(res => {
              this.paramsEdit = res.data
              this.dialogEditUser = true
              this.$nextTick(() => {
                let qlEditor = document.getElementsByClassName('ql-editor')
                let qlEditorP = qlEditor[0].getElementsByTagName('p')
                qlEditorP[0].innerText = res.data.newsContent || ''
              })
            })
          } else {
            // this.dialogEdit = true
            // this.paramsEdit = JSON.parse(JSON.stringify(this.onceTable[0]))
            userGetNews({newsId: this.onceTable[0].id}).then(res => {
              this.paramsEdit = res
              this.dialogEdit = true
              this.$nextTick(() => {
                let qlEditor = document.getElementsByClassName('ql-editor')
                let qlEditorP = qlEditor[0].getElementsByTagName('p')
                qlEditorP[0].innerText = res.newsContent || ''
              })
            })
          }
          // let that = this
        }
      } else if (val == 3) {
        let item = this.selectLengthList()
        if (item == 1) {
          let item = this.$onceWay().onceTableList(this.onceTable)
          if (item == 1) {
            this.paramsThree.title = '删除'
            this.dialogDelete = true
          }
        }
      } else if (val == 4) {
        let item = this.selectLengthList()
        if (item == 1) {
          this.paramsThree.title = '公开'
          this.dialogDelete = true
        }
      } else if (val == 5) {
        let item = this.selectLengthList()
        if (item == 1) {
          this.paramsThree.title = '隐藏'
          this.dialogDelete = true
        }
      } else if (val == 6) {
        let item = this.selectLengthList()
        if (item == 1) {
          this.paramsThree.title = '置顶'
          this.dialogDelete = true
        }
      } else if (val == 7) {
        let item = this.selectLengthList()
        if (item == 1) {
          this.paramsThree.title = '置顶取消'
          this.dialogDelete = true
        }
      } else if (val == 8) {
        let item = this.selectLengthList()
        if (item == 1) {
          this.paramsThree.title = '加粗'
          this.dialogDelete = true
        }
      } else if (val == 9) {
        let item = this.selectLengthList()
        if (item == 1) {
          this.paramsThree.title = '加粗取消'
          this.dialogDelete = true
        }
      } else if (val == 10) {
        let item = this.selectLengthList()
        if (item == 1) {
          this.paramsThree.title = '红标'
          this.dialogDelete = true
        }
      } else if (val == 11) {
        let item = this.selectLengthList()
        if (item == 1) {
          this.paramsThree.title = '红标取消'
          this.dialogDelete = true
        }
      } else if (val == 12) {
        let item = this.selectLengthList()
        if (item == 1) {
          this.paramsThree.title = '发布'
          this.dialogDelete = true
        }
      }
    },
    // 广发之最新增
    submitFormAdd (val) {
      let qlEditor = document.getElementsByClassName('ql-editor')
      let qlEditorP = qlEditor[0].getElementsByTagName('p')
      this.paramsAdd.newsContent = qlEditorP[0].innerText
      this.paramsAdd.bj = val
      // this.paramsAdd.columnId =
      if (this.paramsAdd.newsContent == ' ' || this.paramsAdd.newsContent == null || this.paramsAdd.newsContent == undefined) {
        this.$message.error('请输入新闻内容')
      } else {
        this.$refs['ruleFormAdd'].validate((valid) => {
          if (valid) {
            addSaveNews(this.paramsAdd).then(res => {
              if (res.code == 0) {
                this.$message.success(res.message)
                this.paramsAdd = {}
                this.dialogAdd = false
                this.showListTwo()
              } else {
                this.$message.error(res.message)
              }
            })
          }
        })
      }
    },
    // 广发名人堂新增
    submitFormAddUser (val) {
      let qlEditor = document.getElementsByClassName('ql-editor')
      let qlEditorP = qlEditor[0].getElementsByTagName('p')
      this.paramsAdd.fameContent = qlEditorP[0].innerText
      this.paramsAdd.bj = val
      if (this.paramsAdd.fameContent == '' || this.paramsAdd.fameContent == null || this.paramsAdd.fameContent == undefined) {
        this.$message.error('请输入新闻内容')
      } else {
        this.$refs['ruleFormAdd'].validate((valid) => {
          if (valid) {
            addSaveHallOfFame(this.paramsAdd).then(res => {
              if (res.code == 0) {
                this.$message.success(res.message)
                this.paramsAdd = {}
                this.dialogAddUser = false
                this.showListTwo()
              } else {
                this.$message.error(res.message)
              }
            })
          }
        })
      }
    },
    // 发布大事记
    submitFormAddBranch () {
      this.$refs['ruleFormSendBranchDialog'].validate((valida) => {
        if (valida) {
          this.sendBranchParams.columnId = this.paramsTwo.columnId
          addSaveMemorabilia(this.sendBranchParams).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message)
              this.sendBranchDialog = false
              this.showListTwo()
            } else {
              this.$message.error(res.message)
            }
          })
        }
      })
    },
    // 发布广发大事记or部门大事记 -- 新增
    submitFormAddBranchBtn (val) {
      this.$refs['ruleFormAdd'].validate((valida) => {
        if (valida) {
          if (this.mydata.length <= 0) {
            this.$message.error('请添加大事记内容')
          } else {
            let pop = ''
            try {
              this.mydata.forEach(item => {
                if (item.dsjContent == undefined || item.dsjContent == null || item.dsjContent == '') {
                  throw new Error('请输入内容')
                } else if (item.dsjDate == undefined || item.dsjDate == null || item.dsjDate == '') {
                  throw new Error('请选择时间')
                } else {
                  pop = 1
                }
              })
            } catch (e) {
              pop = 0
              this.$message.error('请选择日期和输入内容')
            }
            if (pop == 1) {
              let params = {
                orgFlag1: this.paramsAdd.orgFlag1,
                columnId: this.paramsTwo.columnId,
                dsjdate: this.paramsAdd.dsjdate,
                bj: val
              }
              addSaveDsj1(params).then(res => {
                let formData = new FormData()
                for (let i in this.mydata) {
                  this.mydata[i].id = 'undefined'
                }
                formData.append('mydata', JSON.stringify(this.mydata))
                formData.append('id', res.data.optFlag)
                addSaveDsjContent(formData).then(item => {
                  if (item.code == 0) {
                    this.$message.success('添加成功')
                    this.dialogAddBranch = false
                    this.paramsAdd = {}
                    this.paramsTwo.page = 1
                    this.paramsTwo.rows = 10
                    this.showListTwo()
                  } else this.$message.error(res.message)
                })
              })
            }
          }
        }
      })
    },
    // 发布广发大事记or部门大事记 -- 编辑
    submitFormEditBranchBtn (val) {
      this.$refs['ruleFormAdd'].validate((valida) => {
        if (valida) {
          let pop = ''
          try {
            this.mydata.forEach(item => {
              if (item.dsjContent == undefined || item.dsjContent == null || item.dsjContent == '') {
                throw new Error('请输入内容')
              } else if (item.dsjDate == undefined || item.dsjDate == null || item.dsjDate == '') {
                throw new Error('请选择时间')
              } else {
                pop = 1
              }
            })
          } catch (e) {
            pop = 0
            this.$message.error('请选择日期和输入内容')
          }
          if (pop == 1) {
            let params = {
              orgFlag1: this.paramsEdit.orgFlag1,
              id: this.onceTable[0].id,
              columnId: this.onceTable[0].columnId,
              dsjdate: this.paramsEdit.dsjdate,
              bj: val
            }
            editUpdateDsj(params).then(res => {
              for (let i in this.mydata) {
                if (this.mydata[i].id == null) {
                  this.mydata[i].id = 'undefined'
                }
              }
              let formData = new FormData()
              formData.append('mydata', JSON.stringify(this.mydata))
              formData.append('id', res.data.optFlag)
              addSaveDsjContent(formData).then(item => {
                if (item.code == 0) {
                  this.$message.success(res.message)
                  this.dialogEditBranch = false
                  this.paramsEdit = {}
                  this.paramsTwo.page = 1
                  this.paramsTwo.rows = 10
                  this.showListTwo()
                } else this.$message.error(res.message)
              })
            })
          }
        }
      })
    },
    // 广发之最编辑
    submitFormEdit (val) {
      this.$refs['ruleFormEdit'].validate((valid) => {
        if (valid) {
          this.paramsEdit.newsContent = ''
          let qlEditor = document.getElementsByClassName('ql-editor')
          let qlEditorP = qlEditor[0].getElementsByTagName('p')
          this.paramsEdit.newsContent = qlEditorP[0].innerText
          this.paramsEdit.bj = val
          if (this.paramsEdit.newsContent.length < 2) {
            this.$message.error('内容长度不得小于2')
          } else {
            editUpdateNews(this.paramsEdit).then(res => {
              if (res.code == 0) {
                this.$message.success(res.message)
                this.paramsEdit = {}
                this.dialogEdit = false
                this.showListTwo()
              } else this.$message.error(res.message)
            })
          }
        }
      })
    },
    // 广发名人堂编辑
    submitFormEditUser (val) {
      this.$refs['ruleFormEdit'].validate((valid) => {
        if (valid) {
          let qlEditor = document.getElementsByClassName('ql-editor')
          let qlEditorP = qlEditor[0].getElementsByTagName('p')
          this.paramsEdit.fameContent = qlEditorP[0].innerText
          this.paramsEdit.bj = val
          if (this.paramsEdit.newsContent.length < 2) {
            this.$message.error('内容长度不得小于2')
          } else {
            editUpdateHallOfFame(this.paramsEdit).then(res => {
              if (res.code == 0) {
                this.$message.success(res.message)
                this.paramsEdit = {}
                this.dialogEditUser = false
                this.showListTwo()
              } else this.$message.error(res.message)
            })
          }
        }
      })
    },
    submitFormDelete () {
      let params = this.onceTable[0].id
      // for (let i in this.onceTable) {
      //   params += this.onceTable[i].id + ','
      // }
      if (this.paramsThree.title == '删除') {
        deleteNews({newsIds: params }).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogDelete = false
            this.showListTwo()
          } else this.$message.error(res.message)
        })
      } else if (this.paramsThree.title == '公开') {
        let item = {fileIds: params, flag: '1'}
        updateNewsOfOpenOrNOt(item).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogDelete = false
            this.showListTwo()
          } else this.$message.error(res.message)
        })
      } else if (this.paramsThree.title == '隐藏') {
        let item = {fileIds: params, flag: '0'}
        updateNewsOfOpenOrNOt(item).then(res => {
          // console.log(res)
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogDelete = false
            this.showListTwo()
          } else this.$message.error(res.message)
        })
      } else if (this.paramsThree.title == '置顶') {
        let item = {newsId: params, flag: '1'}
        updateNewsOfTopOrNot(item).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogDelete = false
            this.showListTwo()
          } else this.$message.error(res.message)
        })
      } else if (this.paramsThree.title == '置顶取消') {
        let item = {newsId: params, flag: '0'}
        updateNewsOfTopOrNot(item).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogDelete = false
            this.showListTwo()
          } else this.$message.error(res.message)
        })
      } else if (this.paramsThree.title == '加粗') {
        let item = {newsId: params, flag: '1'}
        updateNewsOfBoldOrNot(item).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogDelete = false
            this.showListTwo()
          } else this.$message.error(res.message)
        })
      } else if (this.paramsThree.title == '加粗取消') {
        let item = {newsId: params, flag: '0'}
        updateNewsOfBoldOrNot(item).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogDelete = false
            this.showListTwo()
          } else this.$message.error(res.message)
        })
      } else if (this.paramsThree.title == '红标') {
        let item = {newsId: params, flag: '1'}
        updateNewsOfRedOrNot(item).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogDelete = false
            this.showListTwo()
          } else this.$message.error(res.message)
        })
      } else if (this.paramsThree.title == '红标取消') {
        let item = {newsId: params, flag: '0'}
        updateNewsOfRedOrNot(item).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogDelete = false
            this.showListTwo()
          } else this.$message.error(res.message)
        })
      } else if (this.paramsThree.title == '发布') {
        let item = {ids: params}
        releaseNews(item).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogDelete = false
            this.showListTwo()
          } else this.$message.error(res.message)
        })
      }
    },
    /* 重置 */
    resetForm (val) {
      if (val == 1) {
        if (this.$refs['ruleFormAdd']) {
          this.$nextTick(() => {
            this.$refs['ruleFormAdd'].clearValidate()
          })
        }
        this.paramsAdd = {}
        this.dialogAdd = false
        this.dialogAddUser = false
        this.dialogAddBranch = false
      } else if (val == 2) {
        if (this.$refs['ruleFormEdit']) {
          this.$nextTick(() => {
            this.$refs['ruleFormEdit'].clearValidate()
          })
        }
        this.paramsEdit = {}
        this.dialogEdit = false
        this.dialogEditUser = false
        this.dialogEditBranch = false
      } else if (val == 3) {
        if (this.$refs['ruleFormSendBranchDialog']) {
          this.$nextTick(() => {
            this.$refs['ruleFormSendBranchDialog'].clearValidate()
          })
        }
        this.sendBranchDialog = {}
        this.sendBranchDialog = false
      }
    },
    /* 关闭弹框 */
    handleClose () {
      this.dialogAdd = false
      this.dialogEdit = false
      this.dialogDelete = false
      this.sendBranchDialog = false
      this.dialogAddUser = false // 广发名人堂新增弹框
      this.dialogEditUser = false // 广发名人堂编辑弹框

      this.dialogEditBranch = false // 部门大事记新增弹框
      this.dialogAddBranch = false // 广发大事记新增弹框
    },
    /* 选择条目--单 */
    selectLength (val) {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.onceTable.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        return 1
      }
    },
    /* 选择条目--多 */
    selectLengthList () {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else {
        return 1
      }
    },

    /* 归档部门 */
    branchList () {
      branchListOrg().then(res => {
        this.branchListContent = [...this.branchListContent, ...res.data]
      })
      branchListTUser().then(res => {
        this.branchUserListT = res.data
      })
    },
    // 标题搜索
    titleBtnList () {
      this.showListTwo()
    },
    // 部门搜索
    branchChang (val) {
      this.showListTwo()
    },
    /* 发送部门大事记 */
    sendBranch () {
      if (this.$refs['ruleFormSendBranchDialog']) {
        this.$nextTick(() => {
          this.$refs['ruleFormSendBranchDialog'].clearValidate()
        })
      }
      this.sendBranchParams = {inputShow: true}
      this.sendBranchDialog = true
    },
    /* 发送部门大事记--所选部门 */
    sendBranchChang (val) {
      this.sendBranchParams.writerName = ''
      this.sendBranchParams.inputShow = false
      listDsjAuthorByDept({flag1: val}).then(res => {
        let item = res.data.split(',')
        let itemName = ''
        for (let i in this.branchUserListT) {
          for (let s in item) {
            if (this.branchUserListT[i].userId == item[s]) {
              itemName += this.branchUserListT[i].userName + ','
            }
          }
        }
        this.sendBranchParams.writerName = itemName
        this.sendBranchParams.inputShow = true
      })
    },
    myAddList () {
      let pop = null
      try {
        if (this.mydata.length >= 1) {
          this.mydata.forEach(item => {
            if (item.dsjContent == null || item.dsjContent == undefined || item.dsjContent == '') {
              throw new Error('请输入内容')
            } else if (item.dsjDate == null || item.dsjDate == undefined || item.dsjDate == '') {
              throw new Error('请选择日期')
            } else {
              pop = 1
            }
          })
        } else {
          pop = 1
        }
      } catch (e) {
        pop = 0
        this.$message.error('请选择日期与输入内容')
      }
      if (pop == 1) {
        this.mydata.push(this.ruleForm)
        this.ruleForm = {
          dsjContent: '',
          dsjDate: ''
        }
      }
    },
    // 新增--删除
    myDeleteList () {
      if (this.mydataSelectIndex == null) {
        this.$message.error('请选择一条数据')
      } else {
        this.mydata.splice(this.mydataSelectIndex, 1)
        this.checkList = []
      }
    },
    // 编辑--删除
    deleteContentListOnce () {
      if (this.mydataSelectIndex == null) {
        this.$message.error('请选择一条数据')
      } else {
        if (this.mydataSelect.id == null || this.mydataSelect.id == '') {
        } else {
          deleteDsjContent({id: this.mydataSelect.id}).then(res => {
            if (res.code == 0) {
              this.mydata.splice(this.mydataSelectIndex, 1)
              this.checkList = []
              this.$message.success(res.message)
            } else {
              this.$message.error(res.message)
            }
          })
        }
      }
    },
    mydataChange (val, index, item) {
      this.mydataSelect = val
      this.mydataSelectIndex = index
    },

    paramsAddIsTop (val) {
      this.paramsAdd.isTop = val
    },
    paramsAddIsBold (val) {
      this.paramsAdd.isBold = val
    },
    paramsAddIsRedTitle (val) {
      this.paramsAdd.isRedTitle = val
    },
    paramsEditIsTop (val) {
      this.paramsEdit.isTop = val
    },
    paramsEditIsBold (val) {
      this.paramsEdit.isBold = val
    },
    paramsEditIsRedTitle (val) {
      this.paramsEdit.isRedTitle = val
    },
    wordBtn () {
      let item = ''
      for (let i in this.onceTable) {
        item += this.onceTable[i].id
      }
      wordPull(`gdda-new/cms/dsj/exportWord?ids=${item}`, '部门大事记')
    }
  },
  created () {
    this.showList()
    this.branchList()
  },
  beforeUpdate () {
    // this.sendBranchChang()
  }
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  .headerBtn{
    >p{
      display: inline-block;
      /*width: 80px;*/
      margin-right: 10px;
      font-size: 12px;
      color: #282828;
      margin-bottom: 10px;
      img{
        vertical-align: middle;
        margin-right: 4px;
      }
    }
    .shuSpan{
      width: 30px;
      text-align: center;
    }
    .double{
      width: 100px;
    }
    .searchInput{
      width: 230px;
      .el-input{
        width: 49.8%;
        input{
          border-radius: 0;
        }
      }
      /*.el-select{*/
        /*width: 66%;*/
      /*}*/
      .searchBtn{
        float: right;
        width: 52px;
        text-indent: 2px;
        height: 40px;
        line-height: 40px;
        /*border-radius: 4px;*/
        color: #fff;
        background-color: #0067AD;
      }
    }
    .issueBtn{
      width: 150px;
    }
    span>span:hover{
       cursor: pointer;
       color: #00A7EB;
     }
    span:hover{
       cursor: pointer;
       /*color: #00A7EB;*/
     }
    .searchBtn:hover{
      color: #fff;
    }
  }
  .el-dialog{
    .el-select{
      width: 100%;
    }
  }
</style>
<style lang="less">

  .searchInput{
    .el-input{
      input{
        border-radius: 0;
      }
    }
  }
  .wDCheckNone{
    float: left;
    /*margin-bottom: 4px;*/
    /*padding: 0 8px;*/
    /*text-indent: 4px;*/
    box-sizing: border-box;
    height: 42px;
    .el-checkbox__label{
      display: none!important;
    }
  }
  .wDCheckNoneOne{
    width: 60px;
    border: 1px solid #929292;
    text-indent: 5px;
  }
  .wDCheckNoneTwo{
    width: 160px;
    border: 1px solid #929292;
  }
  .wDCheckNoneThree{
    width: 76%;
    border: 1px solid #929292;
  }
  .wDCheckNoneTheOne{
    background-color: #E8EDF4;
    color: #282828;
    height: 40px;
    margin-bottom: 0;
    text-indent: 10px;
  }
  .btnAddBranch{
    width: 99.2%;
    background-color: #E8EDF4;
    color: #282828;
    border: 1px solid #929292;
    span{
      margin-right: 6px;
    }
    span:hover{
      cursor: pointer;
      color: #08A9E6;
    }
    img{
      vertical-align: sub;
      margin-right: 4px;
    }
  }
</style>
