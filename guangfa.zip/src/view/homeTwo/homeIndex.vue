<template>
    <el-container style="background-color: #fff;">
      <MenuChildren style="max-width:200px;max-height:800px;"></MenuChildren>
      <el-main style="padding:0;">
        <router-view></router-view>
      </el-main>
    </el-container>
</template>

<script>
import MenuChildren from '../../components/menuChildren/menuChildren'
export default {
  name: 'homeIndex',
  components: {
    MenuChildren
  }
}
</script>

<style scoped lang="less">
@import "../../css/public";
</style>
