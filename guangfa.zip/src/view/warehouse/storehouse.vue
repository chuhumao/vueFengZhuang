<!-- 库房管理 -->
<template>
  <el-container style="background-color: #fff;">
    <div class="bigDog menuShrink black-tree">
      <PinDao once-title="库房资源结构"></PinDao>
      <el-tree :data="treeTable" :props="defaultProps" :check-strictly="true" :default-expand-all="true" :expand-on-click-node="false" :highlight-current="true" @node-click="handleNodeClick" accordion>
        <span class="custom-tree-node" slot-scope="{ node, data }">
          <span class="treeSpan" :dataType="data.type">
            <img src="../../assets/hurdle/hurdleNew.png" alt="">
            {{ node.label }}
          </span>
        </span>
      </el-tree>
    </div>
    <el-main style="padding:0;">
      <div class="contentPadding tableShrink" v-show="oneType=='store_type'">
        <!--新增，编辑，删除，备注，库房 层级为store_type -->
        <div class="headerBtn">
          <span @click="openAdd"><img src="../../assets/hurdle/hurdleAdd.png" alt="">新增</span>
          <span @click="openDetail"><img src="../../assets/hurdle/hurdleAudit.png" alt="">编辑</span>
          <span @click="openDel"><img src="../../assets/hurdle/hurdleDelete.png" alt="">删除</span>
          <span @click="openRemark"><img src="../../assets/hurdle/hurdleDelete.png" alt="">备注</span>
        </div>
        <!-- 表格 -->
        <div class="all-Table">
          <el-table :data="tableData" stripe border @selection-change="seltChange" style="width: 100%">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="storeValue" label="库房号">
            </el-table-column>
            <el-table-column prop="storeName" label="库房名称">
            </el-table-column>
            <el-table-column prop="startUpDate" label="启动时间">
            </el-table-column>
            <el-table-column prop="remark" label="备注">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="funCurChange" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
          </el-pagination>
        </div>
      </div>
      <div class="contentPadding tableShrink" v-show="oneType=='matrix_type'">
        <!--新增，编辑，删除，备注，库房 层级为matrix_type  -->
        <div class="headerBtn">
          <span @click="openAdd1"><img src="../../assets/hurdle/hurdleAdd.png" alt="">新增</span>
          <span @click="openDetail1"><img src="../../assets/hurdle/hurdleAudit.png" alt="">编辑</span>
          <span @click="openDel1"><img src="../../assets/hurdle/hurdleDelete.png" alt="">删除</span>
          <span @click="openRemark1"><img src="../../assets/hurdle/hurdleDelete.png" alt="">备注</span>
        </div>
        <!-- 表格 -->
        <div class="all-Table">
          <el-table :data="tableData" stripe border @selection-change="seltChange" style="width: 100%">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="storeValue" label="矩阵编号">
            </el-table-column>
            <el-table-column prop="remark" label="备注">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="funCurChange" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
          </el-pagination>
        </div>
      </div>
      <div class="contentPadding tableShrink" v-show="oneType=='bent_type'">
        <!--新增，编辑，删除，备注，库房 层级为bent_type -->
        <div class="headerBtn">
          <span @click="openAdd2"><img src="../../assets/hurdle/hurdleAdd.png" alt="">新增</span>
          <span @click="openDetail2"><img src="../../assets/hurdle/hurdleAudit.png" alt="">编辑</span>
          <span @click="openDel2"><img src="../../assets/hurdle/hurdleDelete.png" alt="">删除</span>
          <span @click="openRemark2"><img src="../../assets/hurdle/hurdleDelete.png" alt="">备注</span>
        </div>
        <!-- 表格 -->
        <div class="all-Table">
          <el-table :data="tableData" stripe border @selection-change="seltChange" style="width: 100%">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="storeValue" label="排架号">
            </el-table-column>
            <el-table-column prop="weight" label="承重">
            </el-table-column>
            <el-table-column prop="storeSize" label="尺寸">
            </el-table-column>
            <el-table-column prop="remark" label="备注">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="funCurChange" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
          </el-pagination>
        </div>
      </div>
      <div class="contentPadding tableShrink" v-show="oneType=='face_type'">
        <!--新增，编辑，删除，备注，库房 层级为face_type  -->
        <div class="headerBtn">
          <span @click="openAdd3"><img src="../../assets/hurdle/hurdleAdd.png" alt="">新增</span>
          <span @click="openDetail3"><img src="../../assets/hurdle/hurdleAudit.png" alt="">编辑</span>
          <span @click="openDel3"><img src="../../assets/hurdle/hurdleDelete.png" alt="">删除</span>
          <span @click="openRemark3"><img src="../../assets/hurdle/hurdleDelete.png" alt="">备注</span>
        </div>
        <!-- 表格 -->
        <div class="all-Table">
          <el-table :data="tableData" stripe border @selection-change="seltChange" style="width: 100%">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="storeValue" label="面编号">
            </el-table-column>
            <el-table-column prop="remark" label="备注">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="funCurChange" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
          </el-pagination>
        </div>
      </div>
      <div class="contentPadding tableShrink" v-show="oneType=='train_type'">
        <!--新增，编辑，删除，备注，库房 层级为face_type  -->
        <div class="headerBtn">
          <span @click="openAdd4"><img src="../../assets/hurdle/hurdleAdd.png" alt="">新增</span>
          <span @click="openDetail4"><img src="../../assets/hurdle/hurdleAudit.png" alt="">编辑</span>
          <span @click="openDel4"><img src="../../assets/hurdle/hurdleDelete.png" alt="">删除</span>
          <span @click="openRemark4"><img src="../../assets/hurdle/hurdleDelete.png" alt="">备注</span>
          <span @click="openAll4"><img src="../../assets/hurdle/hurdleDelete.png" alt="">批量添加</span>
        </div>
        <!-- 表格 -->
        <div class="all-Table">
          <el-table :data="tableData" stripe border @selection-change="seltChange" style="width: 100%">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="storeValue" label="列行号">
            </el-table-column>
            <el-table-column prop="caseNumber" label="箱号">
            </el-table-column>
            <el-table-column prop="archiveType" label="档案类型">
            </el-table-column>
            <el-table-column prop="weight" label="承重">
            </el-table-column>
            <el-table-column prop="storeSize" label="尺寸">
            </el-table-column>
            <el-table-column prop="remark" label="备注">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="funCurChange" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
          </el-pagination>
        </div>
      </div>
      <!-- 第一个层级 store_type -->
      <!-- 新增 -->
      <el-dialog :visible.sync="addFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          添加库房
        </div>
        <el-form :model="paramsAdd" :rules="rulesAudit" ref="paramsAdd" label-width="100px">
          <el-form-item label="库房号：" prop="storeValue">
            <el-input v-model="paramsAdd.storeValue"></el-input>
          </el-form-item>
          <el-form-item label="库房名称：" prop="storeName">
            <el-input v-model="paramsAdd.storeName"></el-input>
          </el-form-item>
          <el-form-item label="启动时间：" prop="startUpDate">
            <el-date-picker type="date" value-format="yyyy-MM-dd" placeholder="选择日期" v-model="paramsAdd.startUpDate" style="width: 100%"></el-date-picker>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="submitAdd">保存</el-button>
          <el-button @click="addFlag = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 编辑 -->
      <el-dialog :visible.sync="detailFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          编辑库房
        </div>
        <el-form :model="paramsDetail" :rules="rulesAudit" ref="paramsDetail" label-width="100px">
          <el-form-item label="库房号：" prop="storeValue">
            <el-input v-model="paramsDetail.storeValue"></el-input>
          </el-form-item>
          <el-form-item label="库房名称：" prop="storeName">
            <el-input v-model="paramsDetail.storeName"></el-input>
          </el-form-item>
          <el-form-item label="启动时间：" prop="startUpDate">
            <el-date-picker type="date" value-format="yyyy-MM-dd" placeholder="选择日期" v-model="paramsDetail.startUpDate" style="width: 100%"></el-date-picker>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="submitDetail">保存</el-button>
          <el-button @click="detailFlag = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 删除 -->
      <el-dialog :visible.sync="delFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicDel.png" alt="">
          系统提示
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要删除此数据吗?</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
          <el-button type="primary" @click="submitDel">确定</el-button>
          <el-button @click="delFlag = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 备注 -->
      <el-dialog :visible.sync="remFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/save/s7.png" alt="">
          增加库房备注
        </div>
        <div>
          <el-form label-width="80px" :model="remarkParams" :rules="rulesAudit" ref="remarkParams">
            <el-form-item label="备注：" prop="remark">
              <el-input type="textarea" :rows="5" v-model="remarkParams.remark" style="width: 90%"></el-input>
            </el-form-item>
          </el-form>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="submitRem">保存</el-button>
          <el-button @click="remFlag = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 第二个层级   -->
      <!-- 添加 -->
      <el-dialog :visible.sync="addFlag1" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          添加矩阵
        </div>
        <el-form label-width="100px" :model="paramsAdd1" :rules="rulesAudit1" ref="paramsAdd1">
          <el-form-item label="矩阵号：" prop="storeValue">
            <el-input v-model="paramsAdd1.storeValue"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="submitAdd1">保存</el-button>
          <el-button @click="addFlag1 = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 编辑 -->
      <el-dialog :visible.sync="detailFlag1" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          编辑矩阵
        </div>
        <el-form label-width="100px" :model="paramsDetail1" :rules="rulesAudit1" ref="paramsDetail1">
          <el-form-item label="矩阵号：" prop="storeValue">
            <el-input v-model="paramsDetail1.storeValue"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="submitDetail1">保存</el-button>
          <el-button @click="detailFlag1 = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 删除 -->
      <el-dialog :visible.sync="delFlag1" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicDel.png" alt="">
          系统提示
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要删除此数据吗?</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
          <el-button type="primary" @click="submitDel1">确定</el-button>
          <el-button @click="delFlag1 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 备注 -->
      <el-dialog :visible.sync="remFlag1" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/save/s7.png" alt="">
          增加矩阵备注
        </div>
        <div>
          <el-form label-width="80px" :model="remarkParams1" :rules="rulesAudit" ref="remarkParams1">
            <el-form-item label="备注：" prop="remark">
              <el-input type="textarea" :rows="5" v-model="remarkParams1.remark" style="width: 90%"></el-input>
            </el-form-item>
          </el-form>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="submitRem1">保存</el-button>
          <el-button @click="remFlag1 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 第三个层级 -->
      <!-- 添加 -->
      <el-dialog :visible.sync="addFlag2" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          添加排架
        </div>
        <el-form label-width="100px" :model="paramsAdd2" :rules="rulesAudit2" ref="paramsAdd2">
          <el-form-item label="排架号：" prop="storeValue">
            <el-input v-model="paramsAdd2.storeValue"></el-input>
          </el-form-item>
          <el-form-item label="承重：" prop="weight">
            <el-input v-model="paramsAdd2.weight"></el-input>
          </el-form-item>
          <el-form-item label="尺寸：">
            <el-input v-model="paramsAdd2.storeSize"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="submitAdd2">保存</el-button>
          <el-button @click="addFlag2 = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 编辑 -->
      <el-dialog :visible.sync="detailFlag2" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          编辑排架
        </div>
        <el-form label-width="100px" :model="paramsDetail2" :rules="rulesAudit2" ref="paramsDetail2">
          <el-form-item label="排架号：" prop="storeValue">
            <el-input v-model="paramsDetail2.storeValue"></el-input>
          </el-form-item>
          <el-form-item label="承重：" prop="weight">
            <el-input v-model="paramsDetail2.weight"></el-input>
          </el-form-item>
          <el-form-item label="尺寸：">
            <el-input v-model="paramsDetail2.storeSize"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="submitDetail2">保存</el-button>
          <el-button @click="detailFlag2 = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 删除 -->
      <el-dialog :visible.sync="delFlag2" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicDel.png" alt="">
          系统提示
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要删除此数据吗?</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
          <el-button type="primary" @click="submitDel2">确定</el-button>
          <el-button @click="delFlag2 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 备注 -->
      <el-dialog :visible.sync="remFlag2" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/save/s7.png" alt="">
          增加排架备注
        </div>
        <div>
          <el-form label-width="80px" :model="remarkParams2" :rules="rulesAudit" ref="remarkParams2">
            <el-form-item label="备注：" prop="remark">
              <el-input type="textarea" :rows="5" v-model="remarkParams2.remark" style="width: 90%"></el-input>
            </el-form-item>
          </el-form>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="submitRem2">保存</el-button>
          <el-button @click="remFlag2 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 第四个层级 -->
      <!-- 添加 -->
      <el-dialog :visible.sync="addFlag3" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          增加面
        </div>
        <el-form label-width="100px" :model="paramsAdd3" :rules="rulesAudit3" ref="paramsAdd3">
          <el-form-item label="面号：" prop="storeValue">
            <el-input v-model="paramsAdd3.storeValue"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="submitAdd3">保存</el-button>
          <el-button @click="addFlag3 = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 编辑 -->
      <el-dialog :visible.sync="detailFlag3" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          编辑面
        </div>
        <el-form label-width="100px" :model="paramsDetail3" :rules="rulesAudit3" ref="paramsDetail3">
          <el-form-item label="面号：" prop="storeValue">
            <el-input v-model="paramsDetail3.storeValue"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="submitDetail3">保存</el-button>
          <el-button @click="detailFlag3 = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 删除 -->
      <el-dialog :visible.sync="delFlag3" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicDel.png" alt="">
          系统提示
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要删除此数据吗?</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
          <el-button type="primary" @click="submitDel3">确定</el-button>
          <el-button @click="delFlag3 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 备注 -->
      <el-dialog :visible.sync="remFlag3" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/save/s7.png" alt="">
          增加面备注
        </div>
        <div>
          <el-form label-width="80px" :model="remarkParams3" :rules="rulesAudit" ref="remarkParams3">
            <el-form-item label="备注：" prop="remark">
              <el-input type="textarea" :rows="5" v-model="remarkParams3.remark" style="width: 90%"></el-input>
            </el-form-item>
          </el-form>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="submitRem3">保存</el-button>
          <el-button @click="remFlag3= false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 第五个层级 -->
      <!-- 添加 -->
      <el-dialog :visible.sync="addFlag4" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          增加列行
        </div>
        <el-form label-width="100px" :model="paramsAdd4" :rules="rulesAudit4" ref="paramsAdd4">
          <el-form-item label="列行号：" prop="storeValue">
            <el-input v-model="paramsAdd4.storeValue"></el-input>
          </el-form-item>
          <el-form-item label="箱号：">
            <el-input v-model="paramsAdd4.caseNumber"></el-input>
          </el-form-item>
          <el-form-item label="承重：" prop="weight">
            <el-input v-model="paramsAdd4.weight"></el-input>
          </el-form-item>
          <el-form-item label="尺寸：">
            <el-input v-model="paramsAdd4.storeSize"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="submitAdd4">保存</el-button>
          <el-button @click="addFlag4 = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 编辑 -->
      <el-dialog :visible.sync="detailFlag4" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          编辑列行
        </div>
        <el-form label-width="100px" :model="paramsDetail4" :rules="rulesAudit4" ref="paramsDetail4">
          <el-form-item label="列行号：" prop="storeValue">
            <el-input v-model="paramsDetail4.storeValue"></el-input>
          </el-form-item>
          <el-form-item label="箱号：">
            <el-input v-model="paramsDetail4.caseNumber"></el-input>
          </el-form-item>
          <el-form-item label="承重：" prop="weight">
            <el-input v-model="paramsDetail4.weight"></el-input>
          </el-form-item>
          <el-form-item label="尺寸：">
            <el-input v-model="paramsDetail4.storeSize"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="submitDetail4">保存</el-button>
          <el-button @click="detailFlag4 = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 删除 -->
      <el-dialog :visible.sync="delFlag4" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicDel.png" alt="">
          系统提示
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要删除此数据吗?</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
          <el-button type="primary" @click="submitDel4">确定</el-button>
          <el-button @click="delFlag4 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 备注 -->
      <el-dialog :visible.sync="remFlag4" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/save/s7.png" alt="">
          增加列行备注
        </div>
        <div>
          <el-form label-width="80px" :model="remarkParams4" :rules="rulesAudit" ref="remarkParams4">
            <el-form-item label="备注：" prop="remark">
              <el-input type="textarea" :rows="5" v-model="remarkParams4.remark" style="width: 90%"></el-input>
            </el-form-item>
          </el-form>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="submitRem4">保存</el-button>
          <el-button @click="remFlag4= false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 批量添加 -->
      <el-dialog :visible.sync="allFlag4" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          编辑列行
        </div>
        <el-form label-width="100px" :model="paramsAll4" :rules="rulesAudit5" ref="paramsAll4">
          <el-form-item label="开始：" prop="startNumber">
            <el-input v-model="paramsAll4.startNumber"></el-input>
          </el-form-item>
          <el-form-item label="结束：">
            <el-input v-model="paramsAll4.endNumber"></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="submitAll4">保存</el-button>
          <el-button @click="allFlag4 = false">关闭</el-button>
        </div>
      </el-dialog>
    </el-main>
  </el-container>
</template>
<script>
import { leftTree, leftJudge, leftTreeChi, storeList, storeAdd, storeDetail, storeDel, storeAddAll } from '@/js/getData';
import PinDao from '../../components/menuChildren/pinDao';
import { valueIndex } from '@/js/transitionText'
export default {
  name: 'storehouse',
  components: {
    PinDao
  },
  data() {
    const validataNum = (rule, value, callback) => {
      let reg = /^[0-9]+.?[0-9]*$/
      if (!reg.test(value)) {
        callback(new Error('输入只能是数字'))
      } else {
        callback()
      }
    };
    const validataNum1 = (rule, value, callback) => {
      let reg = /^(0+(\.[0-9]{1,3}))$|^([0-9]{1,16})$|^([0-9]{1,16}\.[0-9]{1,3})$/
      if (!reg.test(value)) {
        callback(new Error('输入只能是数字(最多3位小数，最大16位整数)'))
      } else {
        callback()
      }
    }
    return {
      treeTable: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      oneType: null,
      oneId: null,
      tableData: [],
      params: {
        page: 1,
        rows: 6,
        total: null
      },
      oneArr: [],
      addFlag: false,
      paramsAdd: {},
      rulesAudit: {
        storeValue: [{ required: true, message: '库房号不能为空！', trigger: 'blur' },
          { validator: validataNum, trigger: 'blur' }
        ],
        storeName: [{ required: true, message: '库房名称不能为空！', trigger: 'blur' }],
        startUpDate: [{ required: true, message: '请选择启动时间！', trigger: 'change' }],
        remark: [{ required: true, message: '备注不能为空！', trigger: 'blur' }],
      },
      rulesAudit1: {
        storeValue: [{ required: true, message: '矩阵号不能为空！', trigger: 'blur' },
          { validator: validataNum, trigger: 'blur' }
        ],
      },
      rulesAudit2: {
        storeValue: [{ required: true, message: '排架号不能为空！', trigger: 'blur' },
          { validator: validataNum1, trigger: 'blur' }
        ],
        weight: [{ required: true, message: '承重不能为空！', trigger: 'blur' },
          { validator: validataNum1, trigger: 'blur' }
        ],
      },
      rulesAudit3: {
        storeValue: [{ required: true, message: '面号不能为空！', trigger: 'blur' }],
      },
      rulesAudit4: {
        storeValue: [{ required: true, message: '列行号不能为空！', trigger: 'blur' },
          { validator: validataNum1, trigger: 'blur' }
        ],
        weight: [{ required: true, message: '承重不能为空！', trigger: 'blur' },
          { validator: validataNum1, trigger: 'blur' }
        ],
      },
      rulesAudit5: {
        startNumber: [{ required: true, message: '开始不能为空！', trigger: 'blur' },
          { validator: validataNum, trigger: 'blur' }
        ],
      },
      leftClick: {},
      // 1
      detailFlag: false,
      paramsDetail: {},
      delFlag: false,
      remFlag: false,
      remarkParams: {},
      addFlag1: false,
      // 2
      paramsAdd1: {},
      detailFlag1: false,
      paramsDetail1: {},
      delFlag1: false,
      remFlag1: false,
      remarkParams1: {},
      // 3
      addFlag2: false,
      paramsAdd2: {},
      detailFlag2: false,
      paramsDetail2: {},
      delFlag2: false,
      remFlag2: false,
      remarkParams2: {},
      // 4
      addFlag3: false,
      paramsAdd3: {},
      detailFlag3: false,
      paramsDetail3: {},
      delFlag3: false,
      remFlag3: false,
      remarkParams3: {},
      // 5
      addFlag4: false,
      paramsAdd4: {},
      detailFlag4: false,
      paramsDetail4: {},
      delFlag4: false,
      remFlag4: false,
      remarkParams4: {},
      allFlag4: false,
      paramsAll4: {},
    }
  },
  methods: {
    //获取左侧数据
    //左侧增加子树
    append(data) {
      let appParams = {};
      if (data.attributes != null) {
        appParams = {
          parentId: data.id,
          storeValue: data.attributes.place,
        }
      } else {
        appParams = {
          parentId: data.id,
        }
      }
      leftTreeChi(appParams).then(res => {
        if (res.code == 0) {
          if (!data.children) {
            this.$set(data, 'children', []);
          }
          data.children = res.data;
        } else this.$message.error(res.message);
      })
    },
    //左侧数
    showTree() {
      leftTree().then(res => {
        if (res.code == 0) {
          this.treeTable = res.data
        } else this.$message.error(res.message);
      })
    },
    //左侧数点击
    handleNodeClick(val) {
      this.leftClick = {};
      this.leftClick = val;
      this.append(val);
      if (val.attributes != null && (val.attributes.parentId == 'a' || val.is == 1)) { //库房查询页面

      } else { //普通的层级显示
        this.initTable(val.id);
        this.oneArr = [];
      }
    },
    //普通的层级显示,根据节点类型选择页面
    initTable(val) {
      this.oneId = val;
      leftJudge({ id: val }).then(res => {
        if (res.code == 0) {
          this.searchOne(val, res.data.codeType)
        } else this.$message.error(res.message);
      })
    },
    //层级查询
    searchList(val, val1) {
      this.params.parentId = val;
      this.params.codeType = val1;
      storeList(this.params).then(res => {
        if (res.code == 0) {
          this.tableData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
      this.oneType = val1;
    },
    searchOne(val, val1) {
      this.params.page = 1;
      this.searchList(val, val1);
    },
    seltChange(val) {
      this.oneArr = val;
    },
    funCurChange(val) {
      this.params.page = val;
      this.searchList(this.oneId, this.oneType);
    },
    //第一个层级的按钮操作store_type
    openAdd() {
      if (!this.oneId) {
        this.$message.error("请你先在资源树中选中一项作为上级资源");
      } else {
        this.paramsAdd = {};
        this.addFlag = true;
        if (this.$refs['paramsAdd']) {
          this.$nextTick(() => {
            this.$refs['paramsAdd'].clearValidate();
          })
        }
      }
    },
    submitAdd() {
      this.$refs['paramsAdd'].validate((valid) => {
        if (valid) {
          this.paramsAdd.parentId = this.oneId;
          this.paramsAdd.codeType = this.oneType;
          storeAdd(this.paramsAdd).then(res => {
            if (res.code == 0) {
              this.addFlag = false;
              this.searchOne(this.oneId, this.oneType);
              this.append(this.leftClick)
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    openDetail() {
      let open = this.$onceWay().onceTableList(this.oneArr);
      if (open == 1) {
        storeDetail({ id: this.oneArr[0].id }).then(res => {
          if (res.code == 0) {
            this.paramsDetail = res.data;
          } else this.$message.error(res.message)
        })
        this.detailFlag = true;
      }
    },
    submitDetail() {
      this.$refs['paramsDetail'].validate((valid) => {
        if (valid) {
          this.paramsDetail.parentId = this.oneId;
          this.paramsDetail.codeType = this.oneType;
          this.paramsDetail.id = this.oneArr[0].id;
          storeAdd(this.paramsDetail).then(res => {
            if (res.code == 0) {
              this.detailFlag = false;
              this.searchOne(this.oneId, this.oneType);
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    openDel() {
      let open = this.$onceWay().onceTableListTwo(this.oneArr);
      if (open == 1) {
        this.delFlag = true;
      }
    },
    submitDel() {
      let ids = this.$onceWay().deleteId(this.oneArr);
      storeDel({ ids: ids }).then(res => {
        if (res.code == 0) {
          this.delFlag = false;
          this.searchOne(this.oneId, this.oneType);
          this.append(this.leftClick)
          this.$message.success(res.message);
        } else this.$message.error(res.data[0])
      })
    },
    openRemark() {
      let open = this.$onceWay().onceTableList(this.oneArr);
      if (open == 1) {
        this.remFlag = true;
        this.remarkParams = {};
        if (this.$refs['remarkParams']) {
          this.$nextTick(() => {
            this.$refs['remarkParams'].clearValidate();
          })
        }
      }
    },
    submitRem() {
      this.$refs['remarkParams'].validate((valid) => {
        if (valid) {
          this.remarkParams.id = this.oneArr[0].id
          storeAdd(this.remarkParams).then(res => {
            if (res.code == 0) {
              this.remFlag = false;
              this.searchOne(this.oneId, this.oneType);
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    /*第二个层级*/
    // 新增
    openAdd1() {
      if (!this.oneId) {
        this.$message.error("请你先在资源树中选中一项作为上级资源");
      } else {
        this.paramsAdd1 = {};
        this.addFlag1 = true;
        if (this.$refs['paramsAdd1']) {
          this.$nextTick(() => {
            this.$refs['paramsAdd1'].clearValidate();
          })
        }
      }
    },
    submitAdd1() {
      this.$refs['paramsAdd1'].validate((valid) => {
        if (valid) {
          this.paramsAdd1.parentId = this.oneId;
          this.paramsAdd1.codeType = this.oneType;
          this.paramsAdd1.parentCode = this.leftClick.attributes.place;
          storeAdd(this.paramsAdd1).then(res => {
            if (res.code == 0) {
              this.addFlag1 = false;
              this.searchOne(this.oneId, this.oneType);
              this.append(this.leftClick)
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    //编辑
    openDetail1() {
      let open = this.$onceWay().onceTableList(this.oneArr);
      if (open == 1) {
        storeDetail({ id: this.oneArr[0].id }).then(res => {
          if (res.code == 0) {
            this.paramsDetail1 = res.data;
          } else this.$message.error(res.message)
        })
        this.detailFlag1 = true;
      }
    },
    submitDetail1() {
      this.$refs['paramsDetail1'].validate((valid) => {
        if (valid) {
          this.paramsDetail1.parentId = this.oneId;
          this.paramsDetail1.codeType = this.oneType;
          this.paramsDetail1.id = this.oneArr[0].id;
          /*     this.paramsDetail1.parentCode = this.leftClick.attributes.place;*/
          storeAdd(this.paramsDetail1).then(res => {
            if (res.code == 0) {
              this.detailFlag1 = false;
              this.searchOne(this.oneId, this.oneType);
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    //删除
    openDel1() {
      let open = this.$onceWay().onceTableListTwo(this.oneArr);
      if (open == 1) {
        this.delFlag1 = true;
      }
    },
    submitDel1() {
      let ids = this.$onceWay().deleteId(this.oneArr);
      storeDel({ ids: ids }).then(res => {
        if (res.code == 0) {
          this.delFlag1 = false;
          this.searchOne(this.oneId, this.oneType);
          this.append(this.leftClick)
          this.$message.success(res.message);
        } else this.$message.error(res.data[0])
      })
    },
    openRemark1() {
      let open = this.$onceWay().onceTableList(this.oneArr);
      if (open == 1) {
        this.remFlag1 = true;
        this.remarkParams1 = {};
        if (this.$refs['remarkParams1']) {
          this.$nextTick(() => {
            this.$refs['remarkParams1'].clearValidate();
          })
        }
      }
    },
    submitRem1() {
      this.$refs['remarkParams1'].validate((valid) => {
        if (valid) {
          this.remarkParams1.id = this.oneArr[0].id
          storeAdd(this.remarkParams1).then(res => {
            if (res.code == 0) {
              this.remFlag1 = false;
              this.searchOne(this.oneId, this.oneType);
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    /*第三个层级*/
    // 新增
    openAdd2() {
      if (!this.oneId) {
        this.$message.error("请你先在资源树中选中一项作为上级资源");
      } else {
        this.paramsAdd2 = {};
        this.addFlag2 = true;
        if (this.$refs['paramsAdd2']) {
          this.$nextTick(() => {
            this.$refs['paramsAdd2'].clearValidate();
          })
        }
      }
    },
    submitAdd2() {
      this.$refs['paramsAdd2'].validate((valid) => {
        if (valid) {
          this.paramsAdd2.parentId = this.oneId;
          this.paramsAdd2.codeType = this.oneType;
          this.paramsAdd2.parentCode = this.leftClick.attributes.place;
          storeAdd(this.paramsAdd2).then(res => {
            if (res.code == 0) {
              this.addFlag2 = false;
              this.searchOne(this.oneId, this.oneType);
              this.append(this.leftClick)
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    //编辑
    openDetail2() {
      let open = this.$onceWay().onceTableList(this.oneArr);
      if (open == 1) {
        storeDetail({ id: this.oneArr[0].id }).then(res => {
          if (res.code == 0) {
            this.paramsDetail2 = res.data;
          } else this.$message.error(res.message)
        })
        this.detailFlag2 = true;
      }
    },
    submitDetail2() {
      this.$refs['paramsDetail2'].validate((valid) => {
        if (valid) {
          this.paramsDetail2.parentId = this.oneId;
          this.paramsDetail2.codeType = this.oneType;
          this.paramsDetail2.id = this.oneArr[0].id;
          /*     this.paramsDetail2.parentCode = this.leftClick.attributes.place;*/
          storeAdd(this.paramsDetail2).then(res => {
            if (res.code == 0) {
              this.detailFlag2 = false;
              this.searchOne(this.oneId, this.oneType);
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    //删除
    openDel2() {
      let open = this.$onceWay().onceTableListTwo(this.oneArr);
      if (open == 1) {
        this.delFlag2 = true;
      }
    },
    submitDel2() {
      let ids = this.$onceWay().deleteId(this.oneArr);
      storeDel({ ids: ids }).then(res => {
        if (res.code == 0) {
          this.delFlag2 = false;
          this.searchOne(this.oneId, this.oneType);
          this.append(this.leftClick)
          this.$message.success(res.message);
        } else this.$message.error(res.data[0])
      })
    },
    openRemark2() {
      let open = this.$onceWay().onceTableList(this.oneArr);
      if (open == 1) {
        this.remFlag2 = true;
        this.remarkParams2 = {};
        if (this.$refs['remarkParams2']) {
          this.$nextTick(() => {
            this.$refs['remarkParams2'].clearValidate();
          })
        }
      }
    },
    submitRem2() {
      this.$refs['remarkParams2'].validate((valid) => {
        if (valid) {
          this.remarkParams2.id = this.oneArr[0].id
          storeAdd(this.remarkParams2).then(res => {
            if (res.code == 0) {
              this.remFlag2 = false;
              this.searchOne(this.oneId, this.oneType);
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    /*第四个层级*/
    // 新增
    openAdd3() {
      if (!this.oneId) {
        this.$message.error("请你先在资源树中选中一项作为上级资源");
      } else {
        this.paramsAdd3 = {};
        this.addFlag3 = true;
        if (this.$refs['paramsAdd3']) {
          this.$nextTick(() => {
            this.$refs['paramsAdd3'].clearValidate();
          })
        }
      }
    },
    submitAdd3() {
      this.$refs['paramsAdd3'].validate((valid) => {
        if (valid) {
          this.paramsAdd3.parentId = this.oneId;
          this.paramsAdd3.codeType = this.oneType;
          this.paramsAdd3.parentCode = this.leftClick.attributes.place;
          storeAdd(this.paramsAdd3).then(res => {
            if (res.code == 0) {
              this.addFlag3 = false;
              this.searchOne(this.oneId, this.oneType);
              this.append(this.leftClick)
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    //编辑
    openDetail3() {
      let open = this.$onceWay().onceTableList(this.oneArr);
      if (open == 1) {
        storeDetail({ id: this.oneArr[0].id }).then(res => {
          if (res.code == 0) {
            this.paramsDetail3 = res.data;
          } else this.$message.error(res.message)
        })
        this.detailFlag3 = true;
      }
    },
    submitDetail3() {
      this.$refs['paramsDetail3'].validate((valid) => {
        if (valid) {
          this.paramsDetail3.parentId = this.oneId;
          this.paramsDetail3.codeType = this.oneType;
          this.paramsDetail3.id = this.oneArr[0].id;
          /*     this.paramsDetail2.parentCode = this.leftClick.attributes.place;*/
          storeAdd(this.paramsDetail3).then(res => {
            if (res.code == 0) {
              this.detailFlag3 = false;
              this.searchOne(this.oneId, this.oneType);
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    //删除
    openDel3() {
      let open = this.$onceWay().onceTableListTwo(this.oneArr);
      if (open == 1) {
        this.delFlag3 = true;
      }
    },
    submitDel3() {
      let ids = this.$onceWay().deleteId(this.oneArr);
      storeDel({ ids: ids }).then(res => {
        if (res.code == 0) {
          this.delFlag3 = false;
          this.searchOne(this.oneId, this.oneType);
          this.append(this.leftClick)
          this.$message.success(res.message);
        } else this.$message.error(res.data[0])
      })
    },
    openRemark3() {
      let open = this.$onceWay().onceTableList(this.oneArr);
      if (open == 1) {
        this.remFlag3 = true;
        this.remarkParams3 = {};
        if (this.$refs['remarkParams3']) {
          this.$nextTick(() => {
            this.$refs['remarkParams3'].clearValidate();
          })
        }
      }
    },
    submitRem3() {
      this.$refs['remarkParams3'].validate((valid) => {
        if (valid) {
          this.remarkParams3.id = this.oneArr[0].id
          storeAdd(this.remarkParams3).then(res => {
            if (res.code == 0) {
              this.remFlag3 = false;
              this.searchOne(this.oneId, this.oneType);
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    /*第五个层级*/
    // 新增
    openAdd4() {
      if (!this.oneId) {
        this.$message.error("请你先在资源树中选中一项作为上级资源");
      } else {
        this.paramsAdd4 = {};
        this.addFlag4 = true;
        if (this.$refs['paramsAdd4']) {
          this.$nextTick(() => {
            this.$refs['paramsAdd4'].clearValidate();
          })
        }
      }
    },
    submitAdd4() {
      this.$refs['paramsAdd4'].validate((valid) => {
        if (valid) {
          this.paramsAdd4.parentId = this.oneId;
          this.paramsAdd4.codeType = this.oneType;
          this.paramsAdd4.parentCode = this.leftClick.attributes.place;
          storeAdd(this.paramsAdd4).then(res => {
            if (res.code == 0) {
              this.addFlag4 = false;
              this.searchOne(this.oneId, this.oneType);
              this.append(this.leftClick)
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    //编辑
    openDetail4() {
      let open = this.$onceWay().onceTableList(this.oneArr);
      if (open == 1) {
        storeDetail({ id: this.oneArr[0].id }).then(res => {
          if (res.code == 0) {
            this.paramsDetail4 = res.data;
          } else this.$message.error(res.message)
        })
        this.detailFlag4 = true;
      }
    },
    submitDetail4() {
      this.$refs['paramsDetail4'].validate((valid) => {
        if (valid) {
          this.paramsDetail4.parentId = this.oneId;
          this.paramsDetail4.codeType = this.oneType;
          this.paramsDetail4.id = this.oneArr[0].id;
          /*     this.paramsDetail2.parentCode = this.leftClick.attributes.place;*/
          storeAdd(this.paramsDetail4).then(res => {
            if (res.code == 0) {
              this.detailFlag4 = false;
              this.searchOne(this.oneId, this.oneType);
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    //删除
    openDel4() {
      let open = this.$onceWay().onceTableListTwo(this.oneArr);
      if (open == 1) {
        this.delFlag4 = true;
      }
    },
    submitDel4() {
      let ids = this.$onceWay().deleteId(this.oneArr);
      storeDel({ ids: ids }).then(res => {
        if (res.code == 0) {
          this.delFlag4 = false;
          this.searchOne(this.oneId, this.oneType);
          this.append(this.leftClick)
          this.$message.success(res.message);
        } else this.$message.error(res.data[0])
      })
    },
    openRemark4() {
      let open = this.$onceWay().onceTableList(this.oneArr);
      if (open == 1) {
        this.remFlag4 = true;
        this.remarkParams4 = {};
        if (this.$refs['remarkParams4']) {
          this.$nextTick(() => {
            this.$refs['remarkParams4'].clearValidate();
          })
        }
      }
    },
    submitRem4() {
      this.$refs['remarkParams4'].validate((valid) => {
        if (valid) {
          this.remarkParams4.id = this.oneArr[0].id
          storeAdd(this.remarkParams4).then(res => {
            if (res.code == 0) {
              this.remFlag4 = false;
              this.searchOne(this.oneId, this.oneType);
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
    openAll4() {
      this.paramsAll4 = {
        endNumber: null
      };
      this.allFlag4 = true;
      if (this.$refs['paramsAll4']) {
        this.$nextTick(() => {
          this.$refs['paramsAll4'].clearValidate();
        })
      }
    },
    submitAll4() {
      this.$refs['paramsAll4'].validate((valid) => {
        if (valid) {
          this.paramsAll4.parentId = this.oneId;
          this.paramsAll4.codeType = "train_type";
          storeAddAll(this.paramsAll4).then(res => {
            if (res.code == 0) {
              this.allFlag4 = false;
              this.searchOne(this.oneId, this.oneType);
              this.$message.success(res.message);
            } else this.$message.error(res.message)
          })
        }
      })
    },
  },
  created() {
    this.showTree();
  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

</style>
