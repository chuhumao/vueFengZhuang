<!-- 库房管理--查看--管理类 -->
<template>
  <div>
    <div>
      <div class="headerBtn mb-20">
        <span class="search-doc">
          <label>库房状态:</label>
          <el-select v-model="params.containerStatus" @change="changeState">
            <el-option v-for="item in stateArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span @click="openSea"><img src="../../assets/save/s1.png" alt="">检索</span>
      </div>
      <!-- 表格 -->
      <div>
        <div class='all-Table' style="max-height: 530px;overflow-y: auto;">
          <el-table :data="fileData" stripe border @selection-change="fileSelect">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="storagePlace" label="存址号" width="160">
            </el-table-column>
            <el-table-column prop="containerStatus" label="库房状态" width="100">
              <template slot-scope="scope">
                {{conArr[scope.row.containerStatus]}}
              </template>
            </el-table-column>
            <el-table-column prop="officeArchivalCode" label="档号" width="140">
            </el-table-column>
            <el-table-column prop="itemNo" label="件号" width="80">
            </el-table-column>
            <el-table-column prop="fileCode" label="文号" width="140">
            </el-table-column>
            <el-table-column prop="titleProper" label="题名" width="240">
            </el-table-column>
            <el-table-column prop="retentionPeriod" label="保管期限" width="100">
              <template slot-scope="scope">
                {{saveArr[scope.row.retentionPeriod]}}
              </template>
            </el-table-column>
            <el-table-column prop="openingType" label="公开属性" width="100">
              <template slot-scope="scope">
                {{pubArr[scope.row.openingType]}}
              </template>
            </el-table-column>
            <el-table-column prop="caseNo" label="文件盒号" width="100">
            </el-table-column>
            <el-table-column prop="dateOfCreation" label="文件日期" width="140">
            </el-table-column>
            <el-table-column prop="c92" label="来源" width="100">
            </el-table-column>
            <el-table-column prop="yearCode" label="年度" width="100">
            </el-table-column>
            <el-table-column prop="amountOfPages" label="页数" width="100">
            </el-table-column>
            <el-table-column prop="seriesCode" label="分类号" width="100">
            </el-table-column>
            <el-table-column prop="c58" label="是否为原件" width="120">
              <template slot-scope="scope">
                {{cArr[scope.row.c58]}}
              </template>
            </el-table-column>
            <el-table-column prop="c8" label="备注" width="120">
            </el-table-column>
            <el-table-column prop="c100" label="文件类型" width="100">
            </el-table-column>
            <el-table-column prop="c117" label="合同号" width="120">
            </el-table-column>
            <el-table-column prop="c113" label="责任者" width="160">
            </el-table-column>
            <el-table-column prop="filingDeptName" label="归档部门" width="160">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="fileCurr" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
          </el-pagination>
        </div>
      </div>
    </div>
    <el-dialog :visible.sync="seaFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/u2.png" alt="">
        检索
      </div>
      <div style="height: 416px;overflow-y: auto;">
        <el-form :model="paramsSea" label-width="120px">
          <el-form-item label="题名：">
            <el-input v-model="paramsSea.titleProper"></el-input>
          </el-form-item>
          <el-form-item label="年度：">
            <el-input v-model="paramsSea.yearCode"></el-input>
          </el-form-item>
          <el-form-item label="文号：">
            <el-input v-model="paramsSea.fileCode"></el-input>
          </el-form-item>
          <el-form-item label="合同号：">
            <el-input v-model="paramsSea.c117"></el-input>
          </el-form-item>
          <el-form-item label="责任者：">
            <el-input v-model="paramsSea.author"></el-input>
          </el-form-item>
          <el-form-item label="移交状态：">
            <el-select v-model="paramsSea.status" class="w-100" filterable>
              <el-option v-for="item in yjArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="拟稿部门：">
            <el-select v-model="paramsSea.c90" class="w-100" filterable>
              <el-option v-for="item in deptArr1" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="拟稿人：">
            <el-select v-model="paramsSea.c89" class="w-100" filterable :filter-method="getUser">
              <el-option v-for="item in userArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="文件类型：">
            <el-select v-model="paramsSea.fileType" class="w-100" filterable>
              <el-option v-for="item in typeArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="公章类型：">
            <el-select v-model="paramsSea.c112" class="w-100" filterable>
              <el-option v-for="item in gzArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="文件日期：">
            <el-date-picker type="date" value-format="yyyy-MM-dd" placeholder="选择日期" v-model="paramsSea.fileDataOfCreate" style="width: 100%"></el-date-picker>
          </el-form-item>
          </el-form-item>
          <el-form-item label="存址号：">
            <el-input v-model="paramsSea.storagePlace"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="searchSea">检索</el-button>
        <el-button type="primary" @click="paramsSea ={}">重置条件</el-button>
        <el-button @click="seaFlag = false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { storeQuery1, storeYj, storeDept, storeFile, storeGz, storeUser } from '@/js/getData';
export default {
  name: 'oneShow',
  data() {
    return {
      params: {}
      fileData: [],
      fileOne: [],
      seaFlag: false,
      paramsSea: {},
      yjArr: [],
      deptArr1: [],
      userArr: [],
      typeArr: [],
      gzArr: [],
      pubArr: ['', '公开', '内部', '受控', '广发商密三级', '广发商密二级', '广发商密一级'],
      saveArr: ['', '短期', '长期', '永久', '', '10年', '15年', '', '30年', '', '35年'],
      cArr: ['是', '否'],
      conArr: ['', '在库', '出库']
    }
  },
  methods: {
    //管理类代码
    //管理类--列表
    searchOne() {
      this.params.page = 1;
      this.searchList();
    },
    searchList() {
      storeQuery1(this.params).then(res => {
        if (res.code == 0) {
          this.fileData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    fileCurr(val) {
      this.params.page = val;
      this.searchList();
    },
    fileSelect(val) {
      this.fileOne = val;
      this.seeOneList();
    },
    //管理类--检索
    //获取移交
    getYj() {
      storeYj().then(res => {
        if (res.code == 0) {
          this.yjArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //拟稿部门
    getDept1() {
      storeDept().then(res => {
        if (res.code == 0) {
          this.deptArr1 = res.data;
        } else this.$message.error(res.message)
      })
    },
    //拟稿人下拉
    getUser(val) {
      let users = {
        orgFlag1: this.paramsSea.c90 || -10000,
        q: val
      }
      storeUser(users).then(res => {
        if (res.code == 0) {
          this.userArr = res.data;
        }
      })
    },
    //文件类型下拉
    getFiles() {
      storeFile().then(res => {
        if (res.code == 0) {
          this.typeArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //公章类型下拉
    getGz() {
      storeGz().then(res => {
        if (res.code == 0) {
          this.gzArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //打开检索
    openSea() {
      this.getYj();
      this.getUser();
      this.getDept1();
      this.getFiles();
      this.getGz();
      this.paramsSea = {};
      this.seaFlag = true;
    },
    searchSea() {
      this.resetInit();
      Object.assign(this.params, this.paramsSea);
      this.searchOne();
      this.seaFlag = false;
    },
    resetInit() {
      this.params.titleProper = null;
      this.params.yearCode = null;
      this.params.fileCode = null;
      this.params.c117 = null;
      this.params.author = null;
      this.params.status = null;
      this.params.c90 = null;
      this.params.c89 = null;
      this.params.fileType = null;
      this.params.c112 = null;
      this.params.fileDataOfCreate = null;
      this.params.storagePlace = null;
    },

  },
  created() {

  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.search-doc {
  margin-top: 10px;

  label {
    font-size: 14px;
    color: #282828;
    padding-right: 5px
  }

  .el-input,
  .el-select {
    width: 200px;
  }
}

</style>
