<!-- 声像档案 -->
<template>
  <div>
    <div>
      <div class="headerBtn mb-20">
        <span class="search-doc">
          <label>库房状态:</label>
          <el-select v-model="params.containerStatus" @change="changeState">
            <el-option v-for="item in stateArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span @click="openSea"><img src="../../assets/save/s1.png" alt="">检索</span>
      </div>
      <!-- 表格 -->
      <div>
        <div class='all-Table'>
          <el-table :data="fileData" stripe border @selection-change="fileSelect">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="storagePlace" label="存址号" width="140">
            </el-table-column>
            <el-table-column prop="containerStatus" label="库房状态" width="100">
              <template slot-scope="scope">
                {{conArr[scope.row.containerStatus]}}
              </template>
            </el-table-column>
            <el-table-column prop="officeArchivalCode" label="档号" width="140">
            </el-table-column>
            <el-table-column prop="seriesCode" label="分类号" width="100">
            </el-table-column>
            <el-table-column prop="itemNo" label="件号" width="100">
            </el-table-column>
            <el-table-column prop="titleProper" label="题名" width="200">
            </el-table-column>
            <el-table-column prop="c63" label="主题" width="100">
            </el-table-column>
            <el-table-column prop="takePhotoDate" label="拍摄时间" width="120">
            </el-table-column>
            <el-table-column prop="takePhotoPlace" label="地点" width="160">
            </el-table-column>
            <el-table-column prop="c64" label="背景" width="100">
            </el-table-column>
            <el-table-column prop="c65" label="人物(职务)" width="160">
            </el-table-column>
            <el-table-column prop="takePhotoPerson" label="摄(录)者" width="120">
            </el-table-column>
            <el-table-column prop="c68" label="所属部门" width="140">
            </el-table-column>
            <el-table-column prop="contentDescription" label="内容简介" width="200">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="fileCurr" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
          </el-pagination>
        </div>
      </div>
    </div>
    <el-dialog :visible.sync="seaFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/u2.png" alt="">
        检索
      </div>
      <div>
        <el-form :model="paramsSea" label-width="120px">
          <el-form-item label="档案号：">
            <el-input v-model="paramsSea.officeArchivalCode"></el-input>
          </el-form-item>
          <el-form-item label="题名：">
            <el-input v-model="paramsSea.titleProper"></el-input>
          </el-form-item>
          <el-form-item label="主题：">
            <el-input v-model="paramsSea.c63"></el-input>
          </el-form-item>
          <el-form-item label="所属部门：">
            <el-input v-model="paramsSea.c68"></el-input>
          </el-form-item>
          <el-form-item label="存址号：">
            <el-input v-model="paramsSea.storagePlace"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="searchSea">检索</el-button>
        <el-button type="primary" @click="paramsSea ={}">重置条件</el-button>
        <el-button @click="seaFlag = false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { fileList1 } from '@/js/getData';
export default {
  name: 'sevenShow',
  data() {
    return {
      params: {}
      fileData: [],
      fileOne: [],
      seaFlag: false,
      paramsSea: {},
      conArr: ['', '在库', '出库'],
    }
  },
  methods: {
    //管理类代码
    //管理类--列表
    searchOne() {
      this.params.page = 1;
      this.searchList();
    },
    searchList() {
      fileList1(this.params).then(res => {
        if (res.code == 0) {
          this.fileData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    fileCurr(val) {
      this.params.page = val;
      this.searchList();
    },
    fileSelect(val) {
      this.fileOne = val;
      this.seeOneList();
    },
    //--检索
    //打开检索
    openSea() {
      this.paramsSea = {};
      this.seaFlag = true;
    },
    searchSea() {
      this.resetInit();
      Object.assign(this.params, this.paramsSea);
      this.searchOne();
      this.seaFlag = false;
    },
    resetInit() {
      this.params.officeArchivalCode = null;
      this.params.titleProper = null;
      this.params.c63 = null;
      this.params.c68 = null;
      this.params.storagePlace = null;
    },

  },
  created() {

  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.search-doc {
  margin-top: 10px;

  label {
    font-size: 14px;
    color: #282828;
    padding-right: 5px
  }

  .el-input,
  .el-select {
    width: 200px;
  }
}

</style>
