<!-- 库房管理下查询 -->
<template>
  <div>
    <div class="contentPadding doc-main">
      <div class="headerBtn mb-20">
        <span class="search-doc">
          <label>全宗：</label>
          <el-select v-model="params.fonds" @change="changeFonds">
            <el-option v-for="item in fonds" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc">
          <label>类型：</label>
          <el-select v-model="params.series1" @change="changeOne">
            <el-option v-for="item in oneArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc">
          <el-select v-model="params.series2" @change="changeTwo">
            <el-option v-for="item in twoArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc" v-show="showType =='f'">
          <el-select v-model="folderSelect" @change="changeF">
            <el-option v-for="item in foldArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc" v-show="showType=='p'">
          <el-select v-model="projectSelect" @change="changeP">
            <el-option v-for="item in proArr" :key="item.value" :value="item.value" :label="item.key"></el-option>
          </el-select>
        </span>
      </div>
      <!-- 管理类代码 -->
      <div v-if="oneType=='1'"></div>
      <!-- 业务档案 && 投资银行 &&项目 -->
      <div v-show="oneType=='21'"></div>
      <!-- 业务档案 && 投资银行 &&案卷 -->
      <div v-show="oneType=='22'"></div>
    </div>
  </div>
</template>
<script>
import { getFonds, getAndRole, getIdList } from '@/js/getData';
export default {
  name: 'oneQuery'
  data() {
    return {
      showType: false,
      oneType: null,
      typeFlag: false,
      showFlag: null,
      stateArr: [
        { "name": "全部", "id": "0" },
        { "name": "在库", "id": "1" },
        { "name": "出库", "id": "2" }
      ],
      fonds: [],
      oneArr: [],
      twoArr: [],
      threeArr: [],
      params: {
        page: 1,
        rows: 7,
        total: null,
      },
      folderSelect: null,
      foldArr: [
        { "name": "案卷", "id": "0" },
        { "name": "按件", "id": "1" },
      ],
      projectSelect: null,
      proArr: [
        { "name": "项目", "id": "0" },
        { "name": "案卷", "id": "1" },
        { "name": "案件", "id": "2" },
      ],
    }
  },
  methods: {
    //获取全宗
    searchFond() {
      getFonds().then(res => {
        if (res.code == 0) {
          this.fonds = res.data;
          this.initFond();
        } else this.$message.error(res.message)
      })
    },
    //初始化选中全宗--原系统逻辑
    initFond(val) {
      if ("8106" == val) {
        this.params.fonds = 1463117877850; //广发乾和
      } else {
        this.params.fonds = 1374133141812 //新广发证券
      }
      this.fondsM();
    },
    //全宗方法
    fondsM() {
      this.searchType(this.params.fonds);
      this.initType();
    },
    //改变选中全宗
    changeFonds() {
      this.$forceUpdate();
      this.fondsM();
    },
    //根据全宗获取档案分类
    searchType(val) {
      getAndRole({ id: val }).then(res => {
        if (res.code == 0) {
          this.oneArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //初始化选中档案分类--原系统逻辑
    initType() {
      if (this.params.fonds == 1374133141812) {
        this.params.series1 = 1379482316593 //管理类案件(按件)
      } else if (this.params.fonds == 1463117877850) {
        this.params.series1 = 1463318429461 //管理类档案
      } else {
        this.params.series1 = null;
      }
      this.params.series2 = null;
      this.searchType1(this.params.series1, 1);
      this.initType1();
    },
    //改变第一个类型
    changeOne() {
      this.$forceUpdate();
      this.searchType1(this.params.series1, 1);
      this.initType1();
      this.params.series2 = null;
      this.typeFlag = false
    },
    //根据档案分类id获取下级分类
    searchType1(val, val1) {
      getIdList({ id: val }).then(res => {
        if (res.code == 0) {
          if (val1 == 1) {
            this.twoArr = res.data;
          } /*else this.threeArr = res.data;*/
        } else this.$message.error(res.message)
      })
    },
    //初始化获取下级分类--原系统逻辑
    initType1() {
      this.params.series2 = null;
      this.initList();
    },
    //改变第二个类型
    changeTwo() {
      this.$forceUpdate();
      this.initList();
    },
    //初始化获取档案列表--原系统逻辑
    initList() {
      this.oneType = null;
      this.showType = "";
      if (this.params.series1) {
        //第一种情况 管理类档案（按件）|| 管理类档案 || 管理类档案（按件历史）
        if (this.params.series1 == 1379482316593 || this.params.series1 == 1463318429461 || this.params.series1 == 1383033168454) {
          this.oneType = "1";
        } else if (this.params.series1 == 1388742017296 && this.params.series2 == 1388742017297) { //第二种情况 业务档案/投资银行
          this.showType = "p";
          this.projectSelect = "0";
          this.oneType = "21";
        } else if (this.params.series1 == 1379398885203) { //员工档案 默认选中案卷
          this.showType = "f";
          this.folderSelect = "0";
          this.oneType = "51"
        } else if (this.params.series1 == 1374133285828) { //声像档案 
          this.oneType = "7"
        } else if (this.params.series1 == 1374133285843) { //实物档案
          this.oneType = "6"
        } else if (this.params.series1 == 1384966177247) { //基建档案
          this.showType = "p";
          this.projectSelect = "0";
          this.oneType = "4"
        } else if (this.params.series1 == 1388742017269) { //会计档案
          this.oneType = "3"
        }
      }
    },
    changeState() {

    },
    changeF(val) {
      if (this.params.series1 == 1379398885203) { //员工档案
        if (val == "1") {
          this.oneType = "52"
        } else if (val == "0") {
          this.oneType = "51"
        }
      }
    },
    changeP(val) {
      if (this.params.series1 == 1388742017296 && this.params.series2 == 1388742017297) { //业务档案&&投资银行
        if (val == "0") {
          this.oneType = "21";
        } else if (val == "1") {
          this.oneType = "22";
        } else if (val == "2") {
          this.oneType = "23";
        }
      } else if (this.params.series1 == 1384966177247) { //基建档案
        if (val == "0") {
          this.oneType = "41";
        } else if (val == "1") {
          this.oneType = "42";
        } else if (val == "2") {
          this.oneType = "43";
        }
      }
    },
  },
  created() {
    this.searchFond();
  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.search-doc {
  margin-top: 10px;

  label {
    font-size: 14px;
    color: #282828;
    padding-right: 5px
  }

  .el-input,
  .el-select {
    width: 200px;
  }
}

.doc-main {
  background-color: #fff;
  min-height: 700px;

  .mb-20 {

    margin-bottom: 20px;
  }

  .doc-down {
    font-size: 13px;
    color: #515BED;
    float: right;
  }

  .doc-doss {
    width: 100%;
    height: 500px;
    overflow: auto;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .mt-f18 {
    margin-top: -18px;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .lend-table {
    max-height: 200px;
    overflow-y: auto;
    width: 100%
  }
}

.w-100 {
  width: 100%
}

</style>
