<!-- 实物档案 -->
<!-- 员工档案--案卷 -->
<template>
  <div>
    <div>
      <div class="headerBtn mb-20">
        <span class="search-doc">
          <label>库房状态:</label>
          <el-select v-model="params.containerStatus" @change="changeState">
            <el-option v-for="item in stateArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span @click="openSea"><img src="../../assets/save/s1.png" alt="">检索</span>
      </div>
      <!-- 表格 -->
      <div>
        <div class='all-Table'>
          <el-table :data="fileData" stripe border @selection-change="fileSelect">
            <el-table-column type="selection" width="55">
            </el-table-column>
            </el-table-column>
            <el-table-column prop="storagePlace" label="存址号" width="120">
            </el-table-column>
            <el-table-column prop="containerStatus" label="库房状态" width="100">
              <template slot-scope="scope">
                {{conArr[scope.row.containerStatus]}}
              </template>
            </el-table-column>
            <el-table-column prop="officeArchivalCode" label="档号" width="120">
            </el-table-column>
            <el-table-column prop="c15" label="类别" width="120">
            </el-table-column>
            <el-table-column prop="titleProper" label="题名" width="250">
            </el-table-column>
            <el-table-column prop="c20" label="颁发单位" width="140">
            </el-table-column>
            <el-table-column prop="c24" label="颁发日期" width="140">
            </el-table-column>
            <el-table-column prop="c72" label="印章种类" width="140">
            </el-table-column>
            <el-table-column prop="c73" label="印章形状" width="100">
            </el-table-column>
            <el-table-column prop="seriesCode" label="分类号" width="140">
            </el-table-column>
            <el-table-column prop="retentionPeriod" label="保管期限" width="140">
              <template slot-scope="scope">
                {{saveArr[scope.row.retentionPeriod]}}
              </template>
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="fileCurr" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
          </el-pagination>
        </div>
      </div>
    </div>
    <el-dialog :visible.sync="seaFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/u2.png" alt="">
        检索
      </div>
      <div>
        <el-form :model="paramsSea" label-width="120px">
          <el-form-item label="题名：">
            <el-input v-model="paramsSea.titleProper"></el-input>
          </el-form-item>
          <el-form-item label="颁发日期：">
            <el-input v-model="paramsSea.c24"></el-input>
          </el-form-item>
          <el-form-item label="印章类型：">
            <el-input v-model="paramsSea.c72"></el-input>
          </el-form-item>
          <el-form-item label="印章形状：">
            <el-input v-model="paramsSea.c73"></el-input>
          </el-form-item>
          <el-form-item label="保管期限：">
            <el-select v-model="paramsSea.retentionPeriod" class="w-100" filterable>
              <el-option v-for="item in renArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="存址号：">
            <el-input v-model="paramsSea.storagePlace"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="searchSea">检索</el-button>
        <el-button type="primary" @click="paramsSea ={}">重置条件</el-button>
        <el-button @click="seaFlag = false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { fileList1, listRet } from '@/js/getData';
export default {
  name: 'sixShow',
  data() {
    return {
      params: {}
      fileData: [],
      fileOne: [],
      seaFlag: false,
      paramsSea: {},
      renArr: [],
      conArr: ['', '在库', '出库'],
      pubArr: ['', '公开', '内部', '受控', '广发商密三级', '广发商密二级', '广发商密一级'],
      saveArr: ['', '短期', '长期', '永久', '', '10年', '15年', '', '30年', '', '35年'],
    }
  },
  methods: {
    //管理类代码
    //管理类--列表
    searchOne() {
      this.params.page = 1;
      this.searchList();
    },
    searchList() {
      fileList1(this.params).then(res => {
        if (res.code == 0) {
          this.fileData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    fileCurr(val) {
      this.params.page = val;
      this.searchList();
    },
    fileSelect(val) {
      this.fileOne = val;
      this.seeOneList();
    },
    //保管期限
    getRet() {
      listRet().then(res => {
        if (res.code == 0) {
          this.renArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //--检索
    //打开检索
    openSea() {
      this.getRet();
      this.paramsSea = {};
      this.seaFlag = true;
    },
    searchSea() {
      this.resetInit();
      Object.assign(this.params, this.paramsSea);
      this.searchOne();
      this.seaFlag = false;
    },
    resetInit() {
      this.params.titleProper = null;
      this.params.c24 = null;
      this.params.c72= null;
      this.params.c73 = null;
      this.params.retentionPeriod = null;
      this.params.storagePlace= null;
    },

  },
  created() {

  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.search-doc {
  margin-top: 10px;

  label {
    font-size: 14px;
    color: #282828;
    padding-right: 5px
  }

  .el-input,
  .el-select {
    width: 200px;
  }
}

</style>
