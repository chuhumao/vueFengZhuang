<!-- 基建档案--案卷 -->
<template>
  <div>
    <div>
      <div class="headerBtn mb-20">
        <span class="search-doc">
          <label>库房状态:</label>
          <el-select v-model="params.containerStatus" @change="changeState">
            <el-option v-for="item in stateArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span @click="openSea"><img src="../../assets/save/s1.png" alt="">检索</span>
      </div>
      <!-- 表格 -->
      <div>
        <div class='all-Table'>
          <el-table :data="fileData" stripe border @selection-change="fileSelect">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="officeArchivalCode" label="档号" width="120">
            </el-table-column>
            <el-table-column prop="folderNo" label="案卷号" width="120">
            </el-table-column>
            <el-table-column prop="yearCode" label="年度" width="120">
            </el-table-column>
            <el-table-column prop="titleProper" label="案卷题名" width="250">
            </el-table-column>
            <el-table-column prop="c11" label="项目名称" width="250">
            </el-table-column>
            <el-table-column prop="openingType" label="公开属性" width="100">
              <template slot-scope="scope">
                {{pubArr[scope.row.openingType]}}
              </template>
            </el-table-column>
            <el-table-column prop="retentionPeriod" label="保管期限" width="100">
              <template slot-scope="scope">
                {{saveArr[scope.row.retentionPeriod]}}
              </template>
            </el-table-column>
            <el-table-column prop="seriesCode" label="分类号" width="100">
            </el-table-column>
            <el-table-column prop="filingDeptName" label="归档部门" width="180">
            </el-table-column>
            <el-table-column prop="filingUser" label="归档人" width="120">
            </el-table-column>
            <el-table-column prop="filingDate" label="归档日期" width="120">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="fileCurr" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
          </el-pagination>
        </div>
      </div>
    </div>
    <el-dialog :visible.sync="seaFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/u2.png" alt="">
        检索
      </div>
      <div>
        <el-form :model="paramsSea" label-width="120px">
          <el-form-item label="项目名称：">
            <el-input v-model="paramsSea.c11"></el-input>
          </el-form-item>
          <el-form-item label="案卷号：">
            <el-input v-model="paramsSea.folderNo"></el-input>
          </el-form-item>
          <el-form-item label="案卷题名：">
            <el-input v-model="paramsSea.fTitleProper"></el-input>
          </el-form-item>
          <el-form-item label="分类号：">
            <el-input v-model="paramsSea.seriesCode"></el-input>
          </el-form-item>
          <el-form-item label="归档部门：">
            <el-select v-model="paramsSea.filingDept" class="w-100" filterable>
              <el-option v-for="item in deptArr1" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="searchSea">检索</el-button>
        <el-button type="primary" @click="paramsSea ={}">重置条件</el-button>
        <el-button @click="seaFlag = false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { conPList, thDept } from '@/js/getData';
export default {
  name: 'oneShow',
  data() {
    return {
      params: {}
      fileData: [],
      fileOne: [],
      seaFlag: false,
      paramsSea: {},
      deptArr1: [],
      pubArr: ['', '公开', '内部', '受控', '广发商密三级', '广发商密二级', '广发商密一级'],
      saveArr: ['', '短期', '长期', '永久', '', '10年', '15年', '', '30年', '', '35年'],
    }
  },
  methods: {
    //管理类代码
    //管理类--列表
    searchOne() {
      this.params.page = 1;
      this.searchList();
    },
    searchList() {
      conPList(this.params).then(res => {
        if (res.code == 0) {
          this.fileData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    fileCurr(val) {
      this.params.page = val;
      this.searchList();
    },
    fileSelect(val) {
      this.fileOne = val;
      this.seeOneList();
    },
    //拟稿部门
    getDept1() {
      thDept().then(res => {
        if (res.code == 0) {
          this.deptArr1 = res.data;
        } else this.$message.error(res.message)
      })
    },
    //--检索
    //打开检索
    openSea() {
      this.getDept1();
      this.paramsSea = {};
      this.seaFlag = true;
    },
    searchSea() {
      this.resetInit();
      Object.assign(this.params, this.paramsSea);
      this.searchOne();
      this.seaFlag = false;
    },
    resetInit() {
      this.params.c11 = null;
      this.params.folderNo = null;
      this.params.fTitleProper = null;
      this.params.seriesCode = null;
      this.params.filingDept = null;
    },

  },
  created() {

  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.search-doc {
  margin-top: 10px;

  label {
    font-size: 14px;
    color: #282828;
    padding-right: 5px
  }

  .el-input,
  .el-select {
    width: 200px;
  }
}

</style>
