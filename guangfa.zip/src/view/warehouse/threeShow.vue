<!--会计档案 -->
<template>
  <div>
    <div>
      <div class="headerBtn mb-20">
        <span class="search-doc">
          <label>库房状态:</label>
          <el-select v-model="params.containerStatus" @change="changeState">
            <el-option v-for="item in stateArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span @click="openSea"><img src="../../assets/save/s1.png" alt="">检索</span>
      </div>
      <!-- 表格 -->
      <div>
        <div class='all-Table' style="max-height: 530px;overflow-y: auto;">
          <el-table :data="fileData" stripe border @selection-change="fileSelect">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="storagePlace" label="存址号" width="160">
            </el-table-column>
            <el-table-column prop="containerStatus" label="库房状态" width="100">
              <template slot-scope="scope">
                {{conArr[scope.row.containerStatus]}}
              </template>
            </el-table-column>
            <el-table-column prop="officeArchivalCode" label="档号" width="160">
            </el-table-column>
            <el-table-column prop="yearCode" label="年度" width="120">
            </el-table-column>
            <el-table-column prop="c163" label="分类号" width="100">
            </el-table-column>
            <el-table-column prop="c113" label="所属部门" width="120">
            </el-table-column>
            <el-table-column prop="c220" label="案卷号" width="100">
            </el-table-column>
            <el-table-column prop="c15" label="类别" width="140">
            </el-table-column>
            <el-table-column prop="titleProper" label="卷(册，袋)标题" width="160">
            </el-table-column>
            <el-table-column prop="dateOfCreation" label="开始时间" width="140">
            </el-table-column>
            <el-table-column prop="dateOfEnd" label="结束时间" width="140">
            </el-table-column>
            <el-table-column prop="c160" label="起" width="100">
            </el-table-column>
            <el-table-column prop="c162" label="止" width="100">
            </el-table-column>
            <el-table-column prop="retentionPeriod" label="保管期限" width="100">
              <template slot-scope="scope">
                {{saveArr[scope.row.retentionPeriod]}}
              </template>
            </el-table-column>
            <el-table-column prop="amountOfPages" label="卷内张数" width="100">
            </el-table-column>
            <el-table-column prop="c8" label="备考" width="100">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="fileCurr" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
          </el-pagination>
        </div>
      </div>
    </div>
    <el-dialog :visible.sync="seaFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/u2.png" alt="">
        检索
      </div>
      <div>
        <el-form :model="paramsSea" label-width="120px">
          <el-form-item label="案卷号：">
            <el-input v-model="paramsSea.c220"></el-input>
          </el-form-item>
          <el-form-item label="类别：">
            <el-input v-model="paramsSea.c15"></el-input>
          </el-form-item>
          <el-form-item label="卷(册，袋)标题：">
            <el-input v-model="paramsSea.titleProper"></el-input>
          </el-form-item>
          <el-form-item label="起始时间：">
            <el-date-picker type="date" value-format="yyyy-MM-dd" placeholder="选择日期" v-model="paramsSea.dateOfCreation" style="width: 100%"></el-date-picker>
          </el-form-item>
          <el-form-item label="终止时间：">
            <el-date-picker type="date" value-format="yyyy-MM-dd" placeholder="选择日期" v-model="paramsSea.dateOfEnd" style="width: 100%"></el-date-picker>
          </el-form-item>
          <el-form-item label="凭证起始号：">
            <el-input v-model="paramsSea.c160"></el-input>
          </el-form-item>
          <el-form-item label="凭证终止号：">
            <el-input v-model="paramsSea.c162"></el-input>
          </el-form-item>
          <el-form-item label="存址号：">
            <el-input v-model="paramsSea.storagePlace"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="searchSea">检索</el-button>
        <el-button type="primary" @click="paramsSea ={}">重置条件</el-button>
        <el-button @click="seaFlag = false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { storeKj } from '@/js/getData';
export default {
  name: 'oneShow',
  data() {
    return {
      params: {}
      fileData: [],
      fileOne: [],
      seaFlag: false,
      paramsSea: {},
      conArr: ['', '在库', '出库'],
      saveArr: ['', '短期', '长期', '永久', '', '10年', '15年', '', '30年', '', '35年'],
    }
  },
  methods: {
    //管理类代码
    //管理类--列表
    searchOne() {
      this.params.page = 1;
      this.searchList();
    },
    searchList() {
      storeKj(this.params).then(res => {
        if (res.code == 0) {
          this.fileData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    fileCurr(val) {
      this.params.page = val;
      this.searchList();
    },
    fileSelect(val) {
      this.fileOne = val;
      this.seeOneList();
    },
    //--检索
    //打开检索
    openSea() {
      this.getDept1();
      this.paramsSea = {};
      this.seaFlag = true;
    },
    searchSea() {
      this.resetInit();
      Object.assign(this.params, this.paramsSea);
      this.searchOne();
      this.seaFlag = false;
    },
    resetInit() {
      this.params.c220 = null;
      this.params.c15 = null;
      this.params.titleProper = null;
      this.params.dateOfCreation = null;
      this.params.dateOfEnd = null;
      this.params.c160 = null;
      this.params.c162 = null;
      this.params.storagePlace = null;
    },

  },
  created() {

  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.search-doc {
  margin-top: 10px;

  label {
    font-size: 14px;
    color: #282828;
    padding-right: 5px
  }

  .el-input,
  .el-select {
    width: 200px;
  }
}

</style>
