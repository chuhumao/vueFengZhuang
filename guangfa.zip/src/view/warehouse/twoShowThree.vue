<!-- 业务档案投资银行 --第三种--案件 -->
<template>
  <div>
    <div>
      <div class="headerBtn mb-20">
        <span class="search-doc">
          <label>库房状态:</label>
          <el-select v-model="params.containerStatus" @change="changeState">
            <el-option v-for="item in stateArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span @click="openSea"><img src="../../assets/save/s1.png" alt="">检索</span>
      </div>
      <!-- 表格 -->
      <div>
        <div class='all-Table' style="max-height: 530px;overflow-y: auto;">
          <el-table :data="fileData1" stripe border @selection-change="fileSelect1">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="containerStatus" label="库房状态" width="100">
              <template slot-scope="scope">
                {{conArr[scope.row.containerStatus]}}
              </template>
            </el-table-column>
            <el-table-column prop="officeArchivalCode" label="档案号" width="140">
            </el-table-column>
            <el-table-column prop="c220" label="案卷号" width="100">
            </el-table-column>
            <el-table-column prop="caseNo" label="盒号" width="100">
            </el-table-column>
            <el-table-column prop="itemNo" label="件号" width="100">
            </el-table-column>
            <el-table-column prop="storagePlace" label="存址号" width="140">
            </el-table-column>
            <el-table-column prop="titleProper" label="文件题名" width="250">
            </el-table-column>
            <el-table-column prop="c72" label="章节号" width="100">
            </el-table-column>
            <el-table-column prop="dateOfCreation" label="文件日期" width="140">
            </el-table-column>
            <el-table-column prop="yearCode" label="年度" width="100">
            </el-table-column>
            <el-table-column prop="c229" label="页号" width="140">
            </el-table-column>
            <el-table-column prop="seriesCode" label="分类号" width="100">
            </el-table-column>
            <el-table-column prop="filingDeptName" label="归档部门" width="120">
            </el-table-column>
            <el-table-column prop="filingDate" label="归档日期" width="140">
            </el-table-column>
            <el-table-column prop="c76" label="索引备注" width="140">
            </el-table-column>
            <el-table-column prop="c77" label="情况说明" width="140">
            </el-table-column>
          </el-table>
        </div>
<!--         分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="fileCurr" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
          </el-pagination>
        </div>
      </div>
    </div>
    <el-dialog :visible.sync="seaFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/u2.png" alt="">
        检索
      </div>
      <div>
        <el-form :model="paramsSea" label-width="120px">
          <el-form-item label="项目名称：">
            <el-input v-model="paramsSea.titleProper"></el-input>
          </el-form-item>
          <el-form-item label="案卷号：">
            <el-input v-model="paramsSea.c220"></el-input>
          </el-form-item>
          <el-form-item label="盒号：">
            <el-input v-model="paramsSea.caseNo"></el-input>
          </el-form-item>
          <el-form-item label="文件题名：">
            <el-input v-model="paramsSea.fTitleProper"></el-input>
          </el-form-item>
          <el-form-item label="年度：">
            <el-input v-model="paramsSea.yearCode"></el-input>
          </el-form-item>
          <el-form-item label="分类号：">
            <el-input v-model="paramsSea.seriesCode"></el-input>
          </el-form-item>
          <el-form-item label="归档部门：">
            <el-select v-model="paramsSea.filingDept" class="w-100" filterable>
              <el-option v-for="item in deptArr1" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="存址号：">
            <el-input v-model="paramsSea.storagePlace"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="searchSea">检索</el-button>
        <el-button type="primary" @click="paramsSea ={}">重置条件</el-button>
        <el-button @click="seaFlag = false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { proListP, thDept } from '@/js/getData';
export default {
  name: 'oneShow',
  data() {
    return {
      params: {}
      fileData: [],
      fileOne: [],
      seaFlag: false,
      paramsSea: {},
      deptArr1: [],
      conArr: ['', '在库', '出库']
    }
  },
  methods: {
    //管理类代码
    //管理类--列表
    searchOne() {
      this.params.page = 1;
      this.searchList();
    },
    searchList() {
      proListP(this.params).then(res => {
        if (res.code == 0) {
          this.fileData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    fileCurr(val) {
      this.params.page = val;
      this.searchList();
    },
    fileSelect(val) {
      this.fileOne = val;
      this.seeOneList();
    },
    //--检索
    //打开检索
    openSea() {
      this.getDept1();
      this.paramsSea = {};
      this.seaFlag = true;
    },
    searchSea() {
      this.resetInit();
      Object.assign(this.params, this.paramsSea);
      this.searchOne();
      this.seaFlag = false;
    },
    resetInit() {
      this.params.titleProper = null;
      this.params.c220 = null;
      this.params.caseNo = null;
      this.params.fTitleProper = null;
      this.params.yearCode = null;
      this.params.seriesCode = null;
      this.params.filingDept = null;
      this.params.storagePlace = null;
    },

  },
  created() {

  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.search-doc {
  margin-top: 10px;

  label {
    font-size: 14px;
    color: #282828;
    padding-right: 5px
  }

  .el-input,
  .el-select {
    width: 200px;
  }
}

</style>
