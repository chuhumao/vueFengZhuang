<!-- 角色数据权限 -->
<template>
  <el-container style="background-color: #fff;">
    <el-main style="padding:0;">
      <!--<el-header class="menuHeaderTop" style="padding:0;height:30px;">
        <img src="../../assets/home/childrenHurdle.png" alt="">
        子栏目列表
      </el-header>-->
      <div class="contentPadding tableShrink">
        <!--新增，编辑，删除-->
        <div class="headerBtn">
          <span @click="showDigBtn(1)"><img src="../../assets/hurdle/p7.png" alt=""><span>数据赋权</span></span>
          <span @click="showDigBtn(2)"><img src="../../assets/hurdle/p8.png" alt=""><span>查看数据权限</span></span>
        </div>
        <!-- 表格 -->
        <div class="all-Table">
          <el-table
            :data="tableData"
            stripe
            border=""
            @selection-change="handleSelectionChange"
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              prop="roleName"
              label="角色名称">
            </el-table-column>
            <el-table-column
              prop="roleIntro"
              label="角色简介">
            </el-table-column>
            <el-table-column
              prop="roleExpried"
              label="有效日期">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChange"
            :current-page="paramsTwo.page"
            :page-size="paramsTwo.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo.total">
          </el-pagination>
        </div>
      </div>
      <!-- 新增弹框 -->
      <el-dialog
        :visible.sync="dialogAdd"
        width="444px"
        class="hurdleAll"
        :before-close="handleClose">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/p4.png" alt="">
          数据赋权
        </div>
        <el-form :model="paramsAdd" :rules="rulesAudit" ref="ruleFormAdd" label-width="120px" class="demo-ruleForm">
          <el-form-item label="属性："  prop="propertyName">
            <el-select v-model="paramsAdd.propertyName" filterable @change="showChildrenList">
              <el-option v-for="(item, index) in attributeTypeList" :label="item.text" :value="item.id" :key="index"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="运算符：" prop="operator">
            <el-select v-model="paramsAdd.operator">
              <el-option v-for="(item, index) in selectTypeList" :label="item.name" :value="item.id" :key="index"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="属性值："  prop="propertyValue">
            <el-select v-model="paramsAdd.propertyValue" filterable @change="showChildrenListTwo">
              <el-option v-for="(item, index) in attributeTypeListTwo" :label="item.text" :value="item.id" :key="index"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="并/或：" prop="relation">
            <el-select v-model="paramsAdd.relation">
              <el-option v-for="(item, index) in selectTypeListTwo" :label="item.name" :value="item.id" :key="index"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="submitFormAdd">保存</el-button>
        </div>
      </el-dialog>
      <!--查看数据赋权-->
      <el-dialog
        :visible.sync="dialogEdit"
        width="1111px"
        class="hurdleAll"
        :before-close="handleClose">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/p5.png" alt="">
          查看数据赋权
        </div>
        <div class="headerBtn">
          <span @click="subBtn(1)">
            <img src="../../assets/hurdle/hurdleAudit.png" alt="">
            <span>编辑</span>
          </span>
          <span @click="subBtn(2)">
            <img src="../../assets/hurdle/hurdleDelete.png" alt="">
            <span>删除</span>
          </span>
        </div>
        <div class="all-Table">
          <el-table
            :data="tableDataTax"
            stripe
            border=""
            @selection-change="handleSelectionChangeTwo"
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              prop="relation"
              label="并/或">
              <template slot-scope="scope">
                <span v-if="scope.row.relation == 'or'">或</span>
                <span v-else-if="scope.row.relation == 'and'">并</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="propertyNameTwo"
              label="属性">
            </el-table-column>
            <el-table-column
              prop="operator"
              label="运算符">
            </el-table-column>
            <el-table-column
              prop="propertyValue"
              label="属性值">
              <template slot-scope="scope">
                <span v-if="scope.row.propertyValueTwo">{{ scope.row.propertyValueTwo }}</span>
                <span v-else-if="scope.row.propertyValue">{{ scope.row.propertyValue }}</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeTax"
            :current-page="paramsTax.page"
            :page-size="paramsTax.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTax.total">
          </el-pagination>
        </div>
      </el-dialog>
      <!-- 编辑弹框 -->
      <el-dialog
        :visible.sync="dialogTaxEdit"
        width="444px"
        class="hurdleAll"
        :before-close="handleCloseTwo">
        <div slot="title" class="dialog-title">
          <!--<img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">-->
          编辑
        </div>
        <el-form :model="paramsEdit" :rules="rulesAudit" ref="ruleFormAdd" label-width="120px" class="demo-ruleForm">
          <el-form-item label="属性："  prop="propertyName">
            <el-select v-model="paramsEdit.propertyName" disabled>
              <el-option v-for="(item, index) in attributeTypeList" :label="item.text" :value="item.id" :key="index"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="运算符：" prop="operator">
            <el-select v-model="paramsEdit.operator">
              <el-option v-for="(item, index) in selectTypeList" :label="item.name" :value="item.id" :key="index"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="属性值："  prop="propertyValue">
            <el-select v-model="paramsEdit.propertyValue" filterable>
              <el-option v-for="(item, index) in attributeTypeListTwo" :label="item.text" :value="item.id" :key="index"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="并/或：" prop="relation">
            <el-select v-model="paramsEdit.relation">
              <el-option v-for="(item, index) in selectTypeListTwo" :label="item.name" :value="item.id" :key="index"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="submitFormEdit">保存</el-button>
        </div>
      </el-dialog>
      <!-- 删除弹框 -->
      <el-dialog :visible.sync="dialogDelete" width="444px" class="hurdleAll" :before-close="handleClose">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicDel.png" alt="">
          删除
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要删除此数据吗？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
          <el-button type="primary" @click="submitFormDelete">确定</el-button>
          <el-button @click="dialogDelete = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 确定赋权 -->
      <el-dialog :visible.sync="getDataViewDialog" width="444px" class="hurdleAll" :before-close="handleClose">
        <div slot="title" class="dialog-title">
          <!--<img src="../../assets/hurdle/topicDel.png" alt="">-->
          赋权
        </div>
        <div class="dia-delete">
          <!--<img src="../../assets/hurdle/delete.png" alt="">-->
          <div>此角色没有数据权限，是否给其赋予数据权限？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
          <el-button type="primary" @click="submitFormTax">确定</el-button>
          <el-button @click="getDataViewDialog = false">取消</el-button>
        </div>
      </el-dialog>
    </el-main>
  </el-container>
</template>

<script>
import { roleListForJson, addFieldAccess, showDeleteFieldAccess, getPropertyName, listPropertyValues, getDataView,
  showListFieldAccess, showEditFieldAccess} from '@/js/getData'
import PinDao from '../../components/menuChildren/pinDao'
export default {
  name: 'roleData',
  components: {
    PinDao
  },
  data () {
    return {
      paramsTwo: {
        total: 0,
        rows: 10,
        page: 1,
        // orgId: '-1'
      },
      paramsTax: {
        rows: 10,
        page: 1,
        type: 'role'
      },
      onceTable: [],
      onceTableTwo: [],
      tableData: [],
      tableDataTax: [],
      attributeTypeList: [],
      attributeTypeListTwo: [],
      selectTypeList: [
        { id: 'eq', name: '等于'},
        { id: 'gt', name: '大于'},
        { id: 'lt', name: '小于'},
        { id: 'like', name: '包含'},
        { id: 'noteq', name: '不等于'},
        { id: 'gteq', name: '大于等于'},
        { id: 'lteq', name: '小于等于'}
      ],
      selectTypeListOnce: [
        { id: '=', name: '等于'},
        { id: '>', name: '大于'},
        { id: '<', name: '小于'},
        { id: 'like', name: '包含'},
        { id: '!=', name: '不等于'},
        { id: '>=', name: '大于等于'},
        { id: '<=', name: '小于等于'}
      ],
      selectTypeListTwo: [
        { id: 'or', name: '或'},
        { id: 'and', name: '并'}
      ],

      paramsAdd: {},
      dialogAdd: false,
      paramsEdit: {},
      dialogEdit: false,
      dialogTaxEdit: false,
      dialogDelete: false,
      getDataViewDialog: false,

      rulesAudit: {
        propertyName: [{ required: true, message: '请选择属性名', trigger: 'chang'}],
        operator: [{ required: true, message: '请选择运算符', trigger: 'chang'}],
        propertyValue: [{ required: true, message: '请选择属性值', trigger: 'chang'}],
        relation: [{ required: true, message: '请选择并/或', trigger: 'chang'}]
      },
      treTable: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      }
    }
  },
  methods: {
    showListTwo () {
      roleListForJson(this.paramsTwo).then(res => {
        if (res.data) {
          this.tableData = res.data.rows
          this.paramsTwo.total = res.data.total == 0 ? null : res.data.total
        }
      })
    },
    handleSelectionChange (val) {
      this.onceTable = val
    },
    handleSelectionChangeTwo (val) {
      this.onceTableTwo = val
    },
    // 单页面点击
    handleCurrentChange (val) {
      this.paramsTwo.page = val
      this.showListTwo()
      // console.log(`当前页: ${val}`)
    },
    // Tax单页面点击
    handleCurrentChangeTax (val) {
      this.paramsTax.page = val
      this.showListTax()
      // console.log(`当前页: ${val}`)
    },
    showDigBtn (val) {
      if (val == 1) {
        // let item = this.selectLength(this.onceTable)
        let item = this.$onceWay().onceTableList(this.onceTable)
        if (item == 1) {
          let params = {
            type: 'role',
            id: this.onceTable[0].id
          }
          getDataView(params).then(res => {
            if (res.data.result == 1) {
              this.dialogAdd = true
              this.paramsAdd = {}
              this.paramsAdd.flag = res.data.result
            } else {
              this.paramsAdd = {}
              this.paramsAdd.flag = res.data.result
              this.getDataViewDialog = true
            }
          })
        }
      } else if (val == 2) {
        // let item = this.selectLength(this.onceTable)
        let item = this.$onceWay().onceTableList(this.onceTable)
        if (item == 1) {
          this.showListTax()
        }
      }
      if (this.$refs['ruleFormAdd']) {
        this.$nextTick(() => {
          this.$refs['ruleFormAdd'].clearValidate()
        })
      }
    },
    showListTax () {
      this.paramsTax.id = this.onceTable[0].id
      showListFieldAccess(this.paramsTax).then(res => {
        if (res.data) {
          this.tableDataTax = res.data.rows
          this.paramsTax.total = res.data.total
          this.dialogEdit = true
          this.$nextTick(() => {
            for (let i in this.tableDataTax) {
              this.tableDataTax[i].operatorOne = this.tableDataTax[i].operator
              for (let s in this.selectTypeList) {
                if (this.tableDataTax[i].operator == this.selectTypeList[s].id) {
                  this.tableDataTax[i].operator = this.selectTypeList[s].name
                }
              }
              this.tableDataTax[i].propertyNameThree = this.tableDataTax[i].propertyName
              this.tableDataTax[i].propertyValueThree = this.tableDataTax[i].propertyValue

              let row = this.tableDataTax[i].propertyName.split('-')
              this.tableDataTax[i].propertyName = row[0]
              this.tableDataTax[i].propertyNameTwo = row[1]

              if (this.tableDataTax[i].propertyName !== 'yearCode') {
                let rowTwo = this.tableDataTax[i].propertyValue.split('-')
                this.tableDataTax[i].propertyValue = rowTwo[0]
                this.tableDataTax[i].propertyValueTwo = rowTwo[1]
              }
            }
          })
        } else {
          this.$message.error(res.message)
        }
      })
    },
    subBtn (val) {
      if (val == 1) {
        // let item = this.selectLength(this.onceTableTwo)
        let item = this.$onceWay().onceTableList(this.onceTableTwo)
        if (item == 1) {
          this.paramsEdit = JSON.parse(JSON.stringify(this.onceTableTwo[0]))
          this.paramsEdit.id = JSON.parse(JSON.stringify(this.onceTable[0].id))
          this.showChildrenList(this.paramsEdit.propertyName)
          this.dialogTaxEdit = true
        }
      } else if (val == 2) {
        // let item = this.selectLength(this.onceTableTwo)
        let item = this.$onceWay().onceTableList(this.onceTableTwo)
        if (item == 1) {
          this.dialogDelete = true
        }
      }
      if (this.$refs['ruleFormAdd']) {
        this.$nextTick(() => {
          this.$refs['ruleFormAdd'].clearValidate()
        })
      }
    },
    submitFormAdd () {
      this.$refs['ruleFormAdd'].validate((valid) => {
        if (valid) {
          this.paramsAdd.id = this.onceTable[0].id
          this.paramsAdd.name = this.onceTable[0].createMan
          this.paramsAdd.type = 'role'
          addFieldAccess(this.paramsAdd).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message)
              this.paramsAdd = {}
              this.dialogAdd = false
              this.showListTwo()
            } else {
              this.$message.error(res.message)
            }
          })
        }
      })
    },
    submitFormEdit () {
      this.$refs['ruleFormAdd'].validate((valid) => {
        if (valid) {
          let params = {
            type: 'role',
            id: this.onceTable[0].id,
            rowId: this.onceTableTwo[0].id,
            page: this.paramsTax.page,
            rows: this.paramsTax.rows,
            propertyName: this.paramsEdit.propertyName,
            operator: this.paramsEdit.operator,
            propertyValue: this.paramsEdit.propertyValue,
            relation: this.paramsEdit.relation
          }
          showEditFieldAccess(params).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message)
              this.dialogTaxEdit = false
              this.showListTax()
            } else {
              this.$message.error(res.message)
            }
          })
        }
      })
    },
    submitFormDelete () {
      let item = ''
      for (let i in this.selectTypeListOnce) {
        if (this.selectTypeListOnce[i].name == this.onceTableTwo[0].operator) {
          item = this.selectTypeListOnce[i].id
        }
      }
      let params = {
        // contents: `,${this.onceTableTwo[0].propertyNameThree},${this.onceTableTwo[0].operatorOne},${this.onceTableTwo[0].propertyValueThree},,${this.onceTableTwo[0].relation};`,
        contents: `,${this.onceTableTwo[0].propertyNameThree},${item},${this.onceTableTwo[0].propertyValueThree},,${this.onceTableTwo[0].relation};`,
        remark: this.onceTableTwo[0].remark
      }
      showDeleteFieldAccess(params).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.dialogDelete = false
          this.showListTax()
        } else {
          this.$message.error(res.message)
        }
      })
    },
    submitFormTax () {
      // console.log(this.onceTable[0].userId);
      // this.paramsAdd.flag = 1
      this.getDataViewDialog = false
      this.dialogAdd = true
    },
    /* 重置 */
    resetForm (val) {
      if (val == 1) {
        this.$refs['ruleFormAdd'].clearValidate()
        this.paramsAdd = {}
      } else if (val == 2) {
        this.$refs['ruleFormEdit'].clearValidate()
        this.paramsEdit = {}
      }
    },
    /* 关闭弹框 */
    handleClose () {
      this.dialogAdd = false
      this.dialogEdit = false
      this.dialogDelete = false
      this.getDataViewDialog = false
    },
    handleCloseTwo () {
      this.dialogTaxEdit = false
    },
    /* 选择条目 */
    selectLength (val) {
      // if (this.onceTable.length <= 0) {
      if (val.length <= 0) {
        this.$message.error('请选择一条数据')
        // } else if (this.onceTable.length > 1) {
      } else if (val.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        return 1
      }
    },
    // 获取下拉框内容
    showListContent () {
      getPropertyName().then(res => {
        this.attributeTypeList = res.data
      })
    },
    // 获取下一级属性
    showChildrenList (val) {
      this.paramsAdd.propertyValue = null
      listPropertyValues({type: val}).then(res => {
        this.attributeTypeListTwo = res.data
      })
    },
    showChildrenListTwo (val) {
      this.paramsAdd.propertyValue = val
      this.$forceUpdate()
    }
  },
  created () {
    this.showListContent()
    this.showListTwo()
  },
  watch: {
    paramsTwo (val, item) {
      this.paramsTwo = val
    }
  }
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  /*.headerBtn{*/
    /*margin-bottom: 10px;*/
    /*>span{*/
      /*display: inline-block;*/
      /*width: 100px;*/
      /*color: #282828;*/
      /*font-size: 12px;*/
      /*!*cursor: pointer;*!*/
      /*span{*/
        /*cursor: pointer;*/
      /*}*/
      /*img{*/
        /*vertical-align: middle;*/
        /*margin-right: 4px;*/
      /*}*/
    /*}*/
  /*}*/
  .el-dialog{
    .el-select{
      width: 100%;
    }
  }
  .dialog-title {
    background-color: #0067AD;
    img{
      vertical-align: middle;
    }
  }
</style>
