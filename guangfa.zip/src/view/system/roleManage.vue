<!-- 角色管理 -->
<template>
  <div>
    <div class="contentPadding" style="background-color: #fff">
      <!--新增，编辑，删除-->
      <div class="headerBtn">
        <span @click="openAdd"><img src="../../assets/system/p1.png" alt="">新增</span>
        <span @click="openDetail"><img src="../../assets/system/p2.png" alt="">编辑</span>
        <span @click="openDelete"><img src="../../assets/system/p3.png" alt="">删除</span>
        <span @click="openGain"><img src="../../assets/system/p4.png" alt="">赋权</span>
        <span @click="openData"><img src="../../assets/system/p5.png" alt="">数据赋权</span>
        <span @click="openUser"><img src="../../assets/system/p6.png" alt="">所辖用户</span>
        <span @click="openArch"><img src="../../assets/system/p7.png" alt="">全宗赋权</span>
        <span @click="openGen"><img src="../../assets/system/p8.png" alt="">新增全宗</span>
        <span @click="openItem"><img src="../../assets/system/p1.png" alt="">新增专项</span>
        <span class="search-select">
          <label>角色名称:</label>
          <el-input v-model="params.roleName"></el-input>
        </span>
        <span class="search-select">
          <label>子角色：</label>
          <el-select v-model="params.roleChild">
            <el-option v-for="item in childArr" :key="item.key" :value="item.key" :label="item.value"></el-option>
          </el-select>
        </span>
        <span class="search-select">
          <label>用于注册：</label>
          <el-select v-model="params.roleReg">
            <el-option v-for="item in childArr" :key="item.key" :value="item.key" :label="item.value"></el-option>
          </el-select>
        </span>
        <span @click="oneSearch"><img src="../../assets/system/p8.png" alt="">检索</span>
      </div>
      <!-- 表格 -->
      <div class='all-Table'>
        <el-table :data="tableData" stripe border @selection-change="handleSelectionChange" style="width: 100%">
          <el-table-column type="selection" width="55">
          </el-table-column>
          <el-table-column prop="roleName" label="角色名称">
          </el-table-column>
          <el-table-column prop="roleIntro" label="角色简介">
          </el-table-column>
          <el-table-column prop="roleChild" label="是否子角色" width="120">
            <template slot-scope="scope">
              <span v-if="scope.row.roleChild=== 0">否</span>
              <span v-if="scope.row.roleChild=== 1">是</span>
            </template>
          </el-table-column>
          <el-table-column prop="roleReg" label="是否注册角色" width="120">
            <template slot-scope="scope">
              <span v-if="scope.row.roleReg=== 0">否</span>
              <span v-if="scope.row.roleReg=== 1">是</span>
            </template>
          </el-table-column>
          <el-table-column prop="roleExpried" label="有效期限" width="120">
          </el-table-column>
        </el-table>
      </div>
      <!-- 分页 -->
      <div class="pageLayout">
        <el-pagination @current-change="currChange" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.totals">
        </el-pagination>
      </div>
    </div>
    <!-- 新增弹框 -->
    <el-dialog :visible.sync="dialogAdd" width="444px" class="hurdleAll spicial-add">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/roleAdd.png" alt="">
        新增角色
      </div>
      <el-form :model="paramsAdd" :rules="rulesAudit" ref="paramsAdd" label-width="120px" class="demo-ruleForm">
        <el-form-item label="角色名称：" prop="roleName">
          <el-input v-model="paramsAdd.roleName" maxlength="20"></el-input>
        </el-form-item>
        <el-form-item label="父类角色：" prop="roleParentName">
          <el-input v-model="paramsAdd.roleParentName" disabled></el-input>
        </el-form-item>
        <el-form-item label="角色简介：" prop="roleIntro">
          <el-input v-model="paramsAdd.roleIntro" type="textarea"></el-input>
        </el-form-item>
        <el-form-item label="有效期限：" prop="roleExpried">
          <el-date-picker type="date" value-format="yyyy-MM-dd" placeholder="选择日期" v-model="paramsAdd.roleExpried" style="width: 100%"></el-date-picker>
        </el-form-item>
        <el-form-item label="是否用于注册:" prop="roleReg">
          <el-radio-group v-model="paramsAdd.roleReg">
            <el-radio :label="0">否</el-radio>
            <el-radio :label="1">是</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="submitAdd">保存</el-button>
        <el-button @click="dialogAdd = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 修改弹框 -->
    <el-dialog :visible.sync="dialogDetail" width="444px" class="hurdleAll spicial-add">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/roleAdd.png" alt="">
        编辑角色
      </div>
      <el-form :model="paramsDetail" :rules="rulesAudit" ref="paramsDetail" label-width="120px" class="demo-ruleForm">
        <el-form-item label="角色名称：" prop="roleName">
          <el-input v-model="paramsDetail.roleName" maxlength="20"></el-input>
        </el-form-item>
        <el-form-item label="父类角色：" prop="roleParentName">
          <el-input v-model="paramsDetail.roleParentName" disabled></el-input>
        </el-form-item>
        <el-form-item label="角色简介：" prop="roleIntro">
          <el-input v-model="paramsDetail.roleIntro" type="textarea"></el-input>
        </el-form-item>
        <el-form-item label="有效期限：" prop="roleExpried">
          <el-date-picker type="date" value-format="yyyy-MM-dd" placeholder="选择日期" v-model="paramsDetail.roleExpried" style="width: 100%"></el-date-picker>
        </el-form-item>
        <el-form-item label="是否用于注册:" prop="roleReg">
          <el-radio-group v-model="paramsDetail.roleReg">
            <el-radio :label="0">否</el-radio>
            <el-radio :label="1">是</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="submitDetail">保存</el-button>
        <el-button @click="dialogDetail = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 删除弹框 -->
    <el-dialog :visible.sync="dialogDelete" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicDel.png" alt="">
        删除确认
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要删除此角色吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="clickDelete">确定</el-button>
        <el-button @click="dialogDelete = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 角色赋权 -->
    <el-dialog :visible.sync="roleaGainFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/g3.png" alt="">
        角色赋权
      </div>
      <div style="height: 400px;overflow: auto;width: 100%">
        <el-tree :data="roleData" class="filter-tree" empty-text='加载中......' :default-expand-all="expendFlag" :show-checkbox="true" node-key="id" ref="tree1" highlight-current :props="defaultProps">
        </el-tree>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="clickRoles">确定赋权</el-button>
        <el-button type="primary" @click="changeExpend(true)">展开</el-button>
        <el-button @click="changeExpend(false)">闭合</el-button>
      </div>
    </el-dialog>
    <!-- 全宗赋权 -->
    <el-dialog :visible.sync="archFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/g3.png" alt="">
        全宗赋权
      </div>
      <div style="height: 400px;overflow: auto;width: 100%">
        <el-tree class="filter-tree" :data="archData" empty-text='加载中......' :default-expand-all='true' :show-checkbox="true" node-key="id" ref="tree2" highlight-current :props="defaultProps">
        </el-tree>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="clickArch">确定赋权</el-button>
      </div>
    </el-dialog>
    <!-- 数据赋权 -->
    <el-dialog :visible.sync="dataGainFlag" width="578px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicDel.png" alt="">
        数据赋权
      </div>
      <div>
        <el-form :model="dataGain" :rules="rulesData" ref="dataGain" label-width="168px" class="demo-ruleForm">
          <el-form-item label="本部门档案查看权限:" prop="owerDeptPower">
            <el-radio-group v-model="dataGain.owerDeptPower" class="dia-radio">
              <el-radio :label="1">查看记录</el-radio>
              <el-radio :label="2">查看记录材料</el-radio>
              <el-radio :label="0">禁止</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="其它部门档案查看权限:" prop="otherDeptPower">
            <el-radio-group v-model="dataGain.otherDeptPower" class="dia-radio">
              <el-radio :label="1">查看记录</el-radio>
              <el-radio :label="2">查看记录材料</el-radio>
              <el-radio :label="0">禁止</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="档案编辑权限:" prop="fileEditPower">
            <el-radio-group v-model="dataGain.fileEditPower" class="dia-radio">
              <el-radio :label="1">允许编辑自己</el-radio>
              <el-radio :label="2">允许编辑全部</el-radio>
              <el-radio :label="0">禁止</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="查看下次移交权限:" prop="nextHandoverPower">
            <el-radio-group v-model="dataGain.nextHandoverPower" class="dia-radio">
              <el-radio :label="1">查看记录</el-radio>
              <el-radio :label="0">禁止</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="secondConfig">保存</el-button>
        <el-button @click="dataGainFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 数据赋权--确认提交 -->
    <el-dialog :visible.sync="confirmFlag" width="288px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        确认提交
      </div>
      <div class="dia-delete">
        <div>确定要提交数据吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="clickData">确定</el-button>
        <el-button @click="confirmFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 新增全宗 -->
    <el-dialog :visible.sync="generalFlag" width="1100px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/g1.png" alt="">
        新增全宗
      </div>
      <div class="general">
        <div class="general-left">
          <el-tree :expand-on-click-node="false" empty-text='加载中......' class="filter-tree" :data="dataGel" default-expand-all :props="defaultProps" :highlight-current="true" @node-click="handleGen">
          </el-tree>
        </div>
        <div class="general-right">
          <div class="headerBtn">
            <span @click="openGenAdd"><img src="../../assets/system/p1.png" alt="">新增</span>
            <span @click="openGenDetail"><img src="../../assets/system/p2.png" alt="">编辑</span>
            <span @click="openGenDel"><img src="../../assets/system/p3.png" alt="">删除</span>
          </div>
          <div>
            <!--分类列表 -->
            <div class='all-Table' style="max-height: 406px;overflow-y: auto;">
              <el-table :data="tableGen" stripe border @selection-change="selectGen" style="width: 100%">
                <el-table-column type="selection" width="55">
                </el-table-column>
                <!-- 分类表格 -->
                <el-table-column prop="propertyValue" label="分类号" v-if="genOneFlag">
                </el-table-column>
                <el-table-column prop="name" label="分类名称" v-if="genOneFlag">
                </el-table-column>
                <el-table-column prop="archiveName" label="对应档案类型" v-if="genOneFlag">
                </el-table-column>
                <!-- 全宗表格 -->
                <el-table-column prop="fondsCode" label="全宗号" v-if="!genOneFlag">
                </el-table-column>
                <el-table-column prop="fondsCodeName" label="全宗名称" v-if="!genOneFlag">
                </el-table-column>
                <el-table-column label="单位名称" v-if="!genOneFlag">
                  <span>广发证券</span>
                </el-table-column>
                <el-table-column prop="fondsCodeSynopsis" label="全宗简介" v-if="!genOneFlag">
                </el-table-column>
              </el-table>
            </div>
            <!-- 分页 -->
            <div class="pageLayout">
              <el-pagination @current-change="ganChange" :current-page="paramsGan.page" :page-size="paramsGan.rows" layout="prev, pager, next, jumper" :total="paramsGan.totals">
              </el-pagination>
            </div>
          </div>
        </div>
      </div>
    </el-dialog>
    <!-- 新增全宗--新增全宗 -->
    <el-dialog :visible.sync="fondAddFlag" width="444px" class="hurdleAll spicial-add">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/g2.png" alt="">
        新增全宗
      </div>
      <el-form :model="fondAdd" :rules="fondAudit" ref="fondAdd" label-width="120px" class="demo-ruleForm">
        <el-form-item label="全宗号：" prop="fondCode">
          <el-input v-model="fondAdd.fondCode"></el-input>
        </el-form-item>
        <el-form-item label="全宗名称：" prop="fondName">
          <el-input v-model="fondAdd.fondName"></el-input>
        </el-form-item>
        <el-form-item label="单位名称：" prop="names">
          <el-input v-model="fondAdd.names" disabled></el-input>
        </el-form-item>
        <el-form-item label="全宗简介：" prop="fondsCodeSynopsis">
          <el-input v-model="fondAdd.fondsCodeSynopsis"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="submitFondAdd">保存</el-button>
        <el-button @click="fondAddFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 新增全宗--编辑全宗 -->
    <el-dialog :visible.sync="fondDetailFlag" width="444px" class="hurdleAll spicial-add">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/g2.png" alt="">
        新增全宗
      </div>
      <el-form :model="fondDetail" :rules="fondAudit" ref="fondDetail" label-width="120px" class="demo-ruleForm">
        <el-form-item label="全宗号：" prop="fondCode">
          <el-input v-model="fondDetail.fondCode"></el-input>
        </el-form-item>
        <el-form-item label="全宗名称：" prop="fondName">
          <el-input v-model="fondDetail.fondName"></el-input>
        </el-form-item>
        <el-form-item label="单位名称：" prop="names">
          <el-input v-model="fondDetail.names" disabled></el-input>
        </el-form-item>
        <el-form-item label="全宗简介：" prop="fondsCodeSynopsis">
          <el-input v-model="fondDetail.fondsCodeSynopsis"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="submitFondDetail">保存</el-button>
        <el-button @click="fondDetailFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 新增全宗--新增分类节点 -->
    <el-dialog :visible.sync="genAddFlag" width="444px" class="hurdleAll spicial-add">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/g2.png" alt="">
        新增分类节点
      </div>
      <el-form :model="genAdd" :rules="genAudit" ref="genAdd" label-width="120px" class="demo-ruleForm">
        <el-form-item label="分类号：" prop="propertyValue">
          <el-input v-model="genAdd.propertyValue"></el-input>
        </el-form-item>
        <el-form-item label="分类名称：" prop="propertyName">
          <el-input v-model="genAdd.propertyName"></el-input>
        </el-form-item>
        <el-form-item label="对应档案类型：" prop="archiveType">
          <el-select v-model="genAdd.archiveType" @change="$forceUpdate()">
            <el-option v-for="item in  typeArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="submitGenAdd">保存</el-button>
        <el-button @click="genAddFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 新增全宗--编辑分类节点 -->
    <el-dialog :visible.sync="genDetailFlag" width="444px" class="hurdleAll spicial-add">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/g2.png" alt="">
        编辑
      </div>
      <el-form :model="genDetail" :rules="genAudit" ref="genDetail" label-width="120px" class="demo-ruleForm">
        <el-form-item label="分类号：" prop="propertyValue">
          <el-input v-model="genDetail.propertyValue"></el-input>
        </el-form-item>
        <el-form-item label="分类名称：" prop="propertyName">
          <el-input v-model="genDetail.propertyName"></el-input>
        </el-form-item>
        <el-form-item label="对应档案类型：" prop="archiveType">
          <el-select v-model="genDetail.archiveType" disabled>
            <el-option v-for="item in  typeArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="submitGenDetail">保存</el-button>
        <el-button @click="genDetailFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 新增全宗--删除分类节点 -->
    <el-dialog :visible.sync="genDelFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicDel.png" alt="">
        删除确认
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要删除此数据吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="submitGenDel">确定</el-button>
        <el-button @click="genDelFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 所辖用户 -->
    <el-dialog :visible.sync="userFlag" width="1100px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/u1.png" alt />
        角色所辖用户管理
      </div>
      <div class="user-content">
        <div class="user-left" v-show="showLeft">
          <p class="user-title dialog-title">所辖用户列表
            <!--        @click="changeLeft"  -->
            <img src="../../assets/home/g2.png" alt="" />
          </p>
          <div>
            <p class="headerBtn user-head" style="margin-top: 20px"><span @click="openDelUser"><img src="../../assets/system/p3.png" alt="">删除用户</span></p>
            <div class="all-Table" style="height: 318px;overflow: auto;">
              <el-table :data="userTable" stripe border style="width: 100%;" @selection-change="userLeftHander">
                <el-table-column type="selection" width="40">
                </el-table-column>
                <el-table-column label="用户姓名" prop="userName"></el-table-column>
                <el-table-column label="手机号码" prop="mobile"></el-table-column>
                <el-table-column label="部门名称" prop="organizeName"></el-table-column>
              </el-table>
            </div>
          </div>
        </div>
        <!--         :style="{width: showLeft?'36.9':'96.9%'}" -->
        <div class="user-right">
          <p class="user-title dialog-title">为角色新增用户
            <img src="../../assets/home/g2.png" alt="" />
          </p>
          <div class="headerBtn user-head">
            <span class="search-select">
              <label>姓名:</label>
              <el-input v-model="userParams1.userName"></el-input>
              <span class="user-search" @click="searchUser1"><img src="../../assets/system/u2.png" alt="">查询</span>
            </span>
            <span @click="openAddUser"><img src="../../assets/system/p1.png" alt="">添加用户</span>
          </div>
          <div class="all-Table" style="margin-top:-8px; height: 318px;overflow: auto;">
            <el-table :data="userTable1" stripe border :highlight-current-row="true" style="width: 100%;" @current-change="userHandle">
              <el-table-column label="用户姓名" prop="userName"></el-table-column>
              <el-table-column label="手机号码" prop="mobile"></el-table-column>
              <el-table-column label="部门名称" prop="organizeName"></el-table-column>
            </el-table>
          </div>
        </div>
      </div>
    </el-dialog>
    <!-- 所辖用户--新增 -->
    <el-dialog :visible.sync="userAddFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/u3.png" alt="">
        请你确认
      </div>
      <div class="dia-delete">
        <img src="../../assets/system/u4.png" alt="">
        <div>确定为此角色增加该用户吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="clickUserAdd">确定</el-button>
        <el-button @click="userAddFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 所辖用户--新增成功提示 -->
    <el-dialog :visible.sync="successAdd" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/u5.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/system/u6.png" alt="">
        <div>增加用户成功</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="successAdd = false">确定</el-button>
      </div>
    </el-dialog>
    <!-- 所辖用户--删除 -->
    <el-dialog :visible.sync="userDelFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicDel.png" alt="">
        删除确认
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要删除此数据吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="clickUserDel">确定</el-button>
        <el-button @click="userDelFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 新增专项 -->
    <el-dialog :visible.sync="itemFlag" width="444px" class="hurdleAll spicial-add">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/roleAdd.png" alt="">
        添加专项角色
      </div>
      <el-form :model="paramsItem" :rules="rulesItem" ref="paramsItem" label-width="120px" class="demo-ruleForm">
        <el-form-item label="角色名称：" prop="roleName">
          <el-input v-model="paramsItem.roleName" maxlength="20"></el-input>
        </el-form-item>
        <el-form-item label="父类角色：" prop="roleParentName">
          <el-input v-model="paramsItem.roleParentName" disabled></el-input>
        </el-form-item>
        <el-form-item label="角色简介：" prop="roleIntro">
          <el-input v-model="paramsItem.roleIntro" maxlength="80"></el-input>
        </el-form-item>
        <el-form-item label="检查组名称：" prop="checkTeamName">
          <el-input v-model="paramsItem.checkTeamName" maxlength="80"></el-input>
        </el-form-item>
        <el-form-item label="单位全称：" prop="organizationName">
          <el-input v-model="paramsItem.organizationName" maxlength="80"></el-input>
        </el-form-item>
        <el-form-item label="检查事项：" prop="checkMatter">
          <el-input v-model="paramsItem.checkMatter" maxlength="80"></el-input>
        </el-form-item>
        <el-form-item label="对接部门：" prop="dockingDepartment">
          <el-input v-model="paramsItem.dockingDepartment" maxlength="80"></el-input>
        </el-form-item>
        <el-form-item label="有效期限：" prop="roleExpried">
          <el-date-picker type="date" value-format="yyyy-MM-dd" placeholder="选择日期" v-model="paramsItem.roleExpried" style="width: 100%"></el-date-picker>
        </el-form-item>
        <el-form-item label="是否用于注册:" prop="roleReg">
          <el-radio-group v-model="paramsItem.roleReg">
            <el-radio :label="0">否</el-radio>
            <el-radio :label="1">是</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="是否启用:" prop="inuse">
          <el-radio-group v-model="paramsItem.inuse">
            <el-radio :label="0">否</el-radio>
            <el-radio :label="1">是</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="submitItem">保存</el-button>
        <el-button @click="itemFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 编辑专项 -->
    <el-dialog :visible.sync="itemFlag1" width="444px" class="hurdleAll spicial-add">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/roleAdd.png" alt="">
        修改专项角色
      </div>
      <el-form :model="paramsItem1" :rules="rulesItem" ref="paramsItem1" label-width="120px" class="demo-ruleForm">
        <el-form-item label="角色名称：" prop="roleName">
          <el-input v-model="paramsItem1.roleName" maxlength="20"></el-input>
        </el-form-item>
        <el-form-item label="父类角色：" prop="roleParentName">
          <el-input v-model="paramsItem1.roleParentName" disabled></el-input>
        </el-form-item>
        <el-form-item label="角色简介：" prop="roleIntro">
          <el-input v-model="paramsItem1.roleIntro" maxlength="80"></el-input>
        </el-form-item>
        <el-form-item label="检查组名称：" prop="checkTeamName">
          <el-input v-model="paramsItem1.checkTeamName" maxlength="80"></el-input>
        </el-form-item>
        <el-form-item label="单位全称：" prop="organizationName">
          <el-input v-model="paramsItem1.organizationName" maxlength="80"></el-input>
        </el-form-item>
        <el-form-item label="检查事项：" prop="checkMatter">
          <el-input v-model="paramsItem1.checkMatter" maxlength="80"></el-input>
        </el-form-item>
        <el-form-item label="对接部门：" prop="dockingDepartment">
          <el-input v-model="paramsItem1.dockingDepartment" maxlength="80"></el-input>
        </el-form-item>
        <el-form-item label="有效期限：" prop="roleExpried">
          <el-date-picker type="date" value-format="yyyy-MM-dd" placeholder="选择日期" v-model="paramsItem1.roleExpried" style="width: 100%"></el-date-picker>
        </el-form-item>
        <el-form-item label="是否用于注册:" prop="roleReg">
          <el-radio-group v-model="paramsItem1.roleReg">
            <el-radio :label="0">否</el-radio>
            <el-radio :label="1">是</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="是否启用:" prop="inuse">
          <el-radio-group v-model="paramsItem1.inuse">
            <el-radio :label="0">否</el-radio>
            <el-radio :label="1">是</el-radio>
          </el-radio-group>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="submitItem1">保存</el-button>
        <el-button @click="itemFlag1 = false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { BASICURL, listRole, roleId, saveRole, detailRole, deleteRole, roleTree, selectTree, dataState, saveData1, saveData2, userList, userSearch, userAdd, userDelete, addItem, listGeneral, leftGeneral, addGeneral, detailGeneral, delGeneral, filesArr, arcType, allFiles, saveRoleFor, archSelect, archAdd, addFonds, detailFonds, deleFonds, roleSaveBefore, detailRoleDlg, saveRoleDlg } from '@/js/getData';
export default {
  name: 'roleManage',
  data() {
    return {
      fondAddFlag: false,
      fondAdd: {
        fondCode: null,
        fondName: null,
        names: '广发证券',
        fondsCodeSynopsis: null
      },
      fondDetailFlag: false,
      fondDetail: {},
      fondAudit: {
        fondCode: [
          { required: true, message: '全宗号不能为空！', trigger: 'blur' },
        ],
        fondName: [
          { required: true, message: '全宗名称不能为空！', trigger: 'blur' },
        ],
        names: [
          { required: true, message: '单位名称不能为空！', trigger: 'blur' },
        ],
        fondsCodeSynopsis: [
          { required: true, message: '全宗简介不能为空！', trigger: 'blur' },
        ]
      },
      genOneFlag: true,
      expendFlag: true,
      childArr: [{ key: '-100', value: '请选择' }, { key: '0', value: '否' }, { key: '1', value: '是' }],
      params: {
        totals: null,
        rows: 13,
        page: 1,
        roleChild: '-100',
        roleReg: '-100'
      },
      parentId: {},
      dialogAdd: false,
      paramsAdd: {
        id: ''
      },
      dialogDetail: false,
      paramsDetail: {
        id: ''
      },
      dialogDelete: false,
      roleaGainFlag: false,
      roleIds: [],
      roleData: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      onceTable: [],
      tableData: [],
      paramsEdit: {},
      dialogEdit: false,
      rulesAudit: {
        roleName: [
          { required: true, message: '角色名称不能为空！', trigger: 'blur' },
        ],
        roleParentName: [
          { required: true, message: '父类角色不能为空！', trigger: 'blur' },
        ],
        roleIntro: [
          { required: true, message: '角色简介不能为空！', trigger: 'blur' },
        ],
        roleExpried: [
          { required: true, message: '请选择有效期限！', trigger: 'change' },
        ],
        roleReg: [
          { required: true, message: '请选择是否用于注册！', trigger: 'change' },
        ]
      },
      limit: 1,
      dataGainFlag: false,
      dataGain: {
        nextHandoverPower: null,
        fileEditPower: null,
        otherDeptPower: null,
        owerDeptPower: null
      },
      rulesData: {
        owerDeptPower: [
          { required: true, message: '请选择本部门档案查看权限！', trigger: 'change' },
        ],
        otherDeptPower: [
          { required: true, message: '请选择其它部门档案查看权限！', trigger: 'change' },
        ],
        fileEditPower: [
          { required: true, message: '请选择档案编辑权限！', trigger: 'change' },
        ],
        nextHandoverPower: [
          { required: true, message: '请选择查看下次移交权限！', trigger: 'change' },
        ]
      },
      tRoleDataPowerNewId: null,
      userFlag: false,
      userParams: {},
      userParams1: {},
      userTable: [],
      userTable1: [],
      userOne: {},
      userArr: [],
      userAddFlag: false,
      userDelFlag: false,
      successAdd: false,
      confirmFlag: false,
      itemFlag: false,
      paramsItem: {},
      itemFlag1: false,
      paramsItem1: {},
      rulesItem: {
        roleName: [
          { required: true, message: '角色名称不能为空！', trigger: 'blur' },
        ],
        roleParentName: [
          { required: true, message: '父类角色不能为空！', trigger: 'blur' },
        ],
        roleIntro: [
          { required: true, message: '角色简介不能为空！', trigger: 'blur' },
        ],
        checkTeamName: [
          { required: true, message: '检查组名称不能为空！', trigger: 'blur' },
        ],
        organizationName: [
          { required: true, message: '单位全称不能为空！', trigger: 'blur' },
        ],
        checkMatter: [
          { required: true, message: '检查事项不能为空！', trigger: 'blur' },
        ],
        dockingDepartment: [
          { required: true, message: '对接部门不能为空！', trigger: 'blur' },
        ],
        roleExpried: [
          { required: true, message: '请选择有效期限！', trigger: 'change' },
        ],
        roleReg: [
          { required: true, message: '请选择是否用于注册！', trigger: 'change' },
        ],
        inuse: [
          { required: true, message: '请选择是否启用！', trigger: 'change' },
        ]
      },
      showLeft: true,
      //新增全宗
      generalFlag: false,
      dataGel: [],
      tableGen: [],
      paramsGan: {
        totals: null,
        rows: 8,
        page: 1,
      },
      genAddFlag: false,
      genAdd: {
        propertyValue: null,
        propertyName: null,
        archiveType: null
      },
      genDetailFlag: false,
      genDetail: {},
      genDelFlag: false,
      filesArray: [],
      typeArr: [],
      genSelectArr: [],
      genAudit: {
        propertyValue: [
          { required: true, message: '分类号不能为空！', trigger: 'blur' },
        ],
        propertyName: [
          { required: true, message: '分类名称不能为空！', trigger: 'blur' },
        ],
        archiveType: [
          { required: true, message: '对应档案类型不能为空！', trigger: 'change' },
        ],
      },
      archFlag: false,
      archData: [],
      currFlage: false,
    }
  },
  methods: {
    changeExpend(val) {
      this.expendFlag = val;
      for (var i = 0; i < this.$refs.tree1.store._getAllNodes().length; i++) {
        this.$refs.tree1.store._getAllNodes()[i].expanded = this.expendFlag;
      }
    },
    /*   changeLeft() {
         this.showLeft = !this.showLeft;
       },*/
    //查询角色列表
    oneSearch() {
      this.params.page = 1;
      this.searchList()
    },
    searchList() {
      listRole(this.params).then(res => {
        if (res.code == 0) {
          this.tableData = res.data.rows;
          this.params.totals = res.data.total;
        } else this.$message.error(res.message);
      })
    },
    // 列表单页面点击
    currChange(val) {
      this.params.page = val;
      this.searchList();
    },
    handleSelectionChange(val) {
      this.onceTable = [];
      this.onceTable = val
    },
    //获取父角色ID
    getParent() {
      roleId().then(res => {
        if (res.code == 0) {
          this.parentId = res.data;
        } else this.$message.error(res.message);
      })
    },
    //打开角色新增
    openAdd() {
      this.paramsAdd = {
        id: null,
        roleParentId: this.parentId.parentRoleId,
        roleParentName: this.parentId.parentRoleName
      }
      this.dialogAdd = true
      if (this.$refs['paramsAdd']) {
        this.$nextTick(() => {
          this.$refs['paramsAdd'].clearValidate();
        })
      }
    },
    //角色新增
    submitAdd() {
      this.$refs['paramsAdd'].validate((valid) => {
        if (valid) {
          saveRole(this.paramsAdd).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message);
              this.dialogAdd = false;
              this.oneSearch();
            } else this.$message.error(res.message);
          })
        }
      })
    },
    //角色详情
    getDetail() {
      let id = this.onceTable[0].id
      detailRole({ id: id }).then(res => {
        if (res.code == 0) {
          this.paramsDetail = res.data;
          this.paramsDetail.roleParentName = this.parentId.parentRoleName
        } else this.$message.error(res.message);
      })
    },
    openDetail() {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.onceTable.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        this.beforeDetail();
      }
    },
    //判断编辑是角色还是专项
    beforeDetail() {
      let id = this.onceTable[0].id
      roleSaveBefore({ id: id }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 1) { //编辑专项
            this.openDetailItem();
            this.itemFlag1 = true;
            if (this.$refs['paramsItem1']) {
              this.$nextTick(() => {
                this.$refs['paramsItem1'].clearValidate();
              })
            }
          } else { //编辑角色
            this.getDetail();
            this.dialogDetail = true;
            if (this.$refs['paramsDetail']) {
              this.$nextTick(() => {
                this.$refs['paramsDetail'].clearValidate();
              })
            }
          }
        } else this.$message.error(res.message);
      })
    },
    submitDetail() {
      this.$refs['paramsDetail'].validate((valid) => {
        if (valid) {
          saveRole(this.paramsDetail).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message);
              this.dialogDetail = false;
              this.oneSearch();
            } else this.$message.error(res.message);
          })
        }
      })
    },
    //角色删除
    openDelete() {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else {
        this.dialogDelete = true;
      }
    },
    clickDelete() {
      let ids = [];
      this.onceTable.forEach(item => {
        ids.push(item.id)
      });

      deleteRole({ ids: ids.join(',') }).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.dialogDelete = false;
          this.oneSearch();
        } else this.$message.error(res.message);
      })
    },
    //打开赋权页面
    openGain() {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.onceTable.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        if (this.limit == 1) {
          this.getGain(); //权限数是一样的，所以只调用一次就行
          this.limit++;
        }
        this.selectGain();
        this.roleaGainFlag = true;
      }
    },
    getGain() {
      let id = this.onceTable[0].id
      roleTree({ roleId: id }).then(res => {
        if (res.code == 0) {
          this.roleData = res.data;
        } else this.$message.error(res.message);
      })
    },
    //回显权限数选中状态
    selectGain() {
      let gain = {};
      gain.targetId = this.onceTable[0].id;
      gain.checkState = 1;
      this.roleIds = [];
      selectTree(gain).then(res => {
        if (res.code == 0) {
          res.data.forEach(item => {
            this.roleIds.push(item.resourceId)
          })
          this.$refs.tree1.setCheckedKeys(this.roleIds)
        } else this.$message.error(res.message);
      })
    },
    //确定赋权
    clickRoles() {
      let datas = this.$refs.tree1.getCheckedKeys() || [];
      let datas1 = [];
      if (datas.length >= 1) {
        datas.forEach(item => {
          let items = item + '_true'
          datas1.push(items)
        })
        datas1.push("0_false")
      }
      let roleFor = {
        resourceIds: datas1.join(','),
        targetId: this.onceTable[0].id,
        powerFlag: 0
      };
      saveRoleFor(roleFor).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.roleaGainFlag = false;
          this.oneSearch();
        } else this.$message.error(res.message);
      })
    },
    //全宗赋权--打开页面
    openArch() {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.onceTable.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        this.getAllArch();
        this.getSelectArch();
        this.archFlag = true;
      }
    },
    //全宗赋权--获取所有下拉树
    getAllArch() {
      leftGeneral({ type: 0 }).then(res => {
        if (res.code == 0) {
          this.archData = res.data;
        } else this.$message.error(res.message);
      })
    },
    //全宗赋权--获取选中的id
    getSelectArch() {
      let archIds = [];
      archSelect({ targetId: this.onceTable[0].id }).then(res => {
        if (res.code == 0) {
          res.data.forEach(item => {
            archIds.push(item.resourceId)
          })
          this.$refs.tree2.setCheckedKeys(archIds)
        } else this.$message.error(res.message);
      })
    },
    //全宗赋值--确定赋值
    clickArch() {
      let datas = this.$refs.tree2.getCheckedKeys() || [];
      let roleFor = {
        resourceIds: datas.join(','),
        targetId: this.onceTable[0].id,
      };
      archAdd(roleFor).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.archFlag = false;
          this.oneSearch();
        } else this.$message.error(res.message);
      })
    },
    //数据赋权
    //打开数据赋权
    openData() {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.onceTable.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        this.dataGain = {
          id: null,
          roleId: this.onceTable[0].id,
          nextHandoverPower: null,
          fileEditPower: null,
          otherDeptPower: null,
          owerDeptPower: null
        };
        this.getDataGain(); //获取数据赋权选中状态
        this.dataGainFlag = true;
        if (this.$refs['dataGain']) {
          this.$nextTick(() => {
            this.$refs['dataGain'].clearValidate();
          })
        }
      }
    },
    //获取数据赋权详情
    getDataGain() {
      let id = this.onceTable[0].id
      dataState({ roleId: id }).then(res => {
        if (res.code == 0) {
          this.dataGain.id = res.data.id
          this.dataGain.owerDeptPower = res.data.owerDeptPower
          this.dataGain.otherDeptPower = res.data.otherDeptPower
          this.dataGain.fileEditPower = res.data.fileEditPower
          this.dataGain.nextHandoverPower = res.data.nextHandoverPower
          this.tRoleDataPowerNewId = res.data.tRoleDataPowerNewId
        } else this.$message.error(res.message);
      })
    },
    //数据赋权前三行保存
    dataSave1() {
      saveData1(this.dataGain).then(res => {
        if (res.code == 0) {

        } else this.$message.error(res.message);
      })
    },
    //数据赋权最后一行保存
    dataSave2() {
      this.dataGain.id = this.tRoleDataPowerNewId;
      saveData2(this.dataGain).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.dataGainFlag = false;
          this.confirmFlag = false;
          this.oneSearch();
        } else this.$message.error(res.message);
      })
    },
    //数据赋权提示确定
    secondConfig() {
      this.$refs['dataGain'].validate((valid) => {
        if (valid) {
          this.confirmFlag = true;
        }
      });
    },
    //数据赋权确定完成
    clickData() {
      this.dataSave1();
      this.dataSave2();
    },
    //所辖用户--打开
    openUser() {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.onceTable.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        this.currFlage = false;
        this.userParams.roleId = this.onceTable[0].id;
        this.searchUser();
        this.userParams1 = {};
        this.userTable1 = [];
        this.userFlag = true;
      }
    },
    //所辖用户左侧查询
    searchUser() {
      userList(this.userParams).then(res => {
        if (res.code == 0) {
          this.userTable = res.data;
        } else this.$message.error(res.message);
      })
    },
    //所辖用户左侧多选
    userLeftHander(val) {
      this.userArr = [];
      this.userArr = val;
    },
    //所辖用户右侧查询
    searchUser1() {
      userSearch(this.userParams1).then(res => {
        if (res.code == 0) {
          this.userTable1 = res.data;
        } else this.$message.error(res.message);
      })
    },
    userHandle(val) {
      this.userOne = {};
      if (val) {
        this.currFlage = true;
        this.userOne = val;
      } else {
        this.currFlage = false
      }
    },
    openAddUser() {
      if (!this.currFlage) {
        this.$message.error('请选择一条数据')
      } else {
        this.userAddFlag = true;
      }
    },
    clickUserAdd() {
      let userAddParams = {
        userId: this.userOne.userId,
        roleId: this.onceTable[0].id,
        organizeId: this.userOne.organizeId
      };
      userAdd(userAddParams).then(res => {
        if (res.code == 0) {
          this.userAddFlag = false;
          this.searchUser();
          this.successAdd = true;
        } else this.$message.error(res.message);
      })
    },
    //所辖用户删除
    openDelUser() {
      if (this.userArr.length <= 0) {
        this.$message.error('请选择一条数据')
      } else {
        this.userDelFlag = true;
      }
    },
    clickUserDel() {
      let ids = [];
      this.userArr.forEach(item => {
        ids.push(item.id)
      });
      userDelete({ ids: ids.join(',') }).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.userDelFlag = false;
          this.searchUser();
        } else this.$message.error(res.message);
      })
    },
    //新增全宗
    //新增全宗--打开页面
    openGen() {
      this.tableGen = [];
      this.paramsGan.nodeId = null;
      this.searchGanTree(); //每次点开都调用一次
      this.generalFlag = true;
      this.genOneFlag = true;
    },
    //新增全宗--列表
    oneGenSearch() {
      this.paramsGan.page = 1;
      this.searchGenList();
    },
    searchGenList() {
      listGeneral(this.paramsGan).then(res => {
        if (res.code == 0) {
          this.tableGen = res.data.rows;
          this.paramsGan.totals = res.data.total;
        } else this.$message.error(res.message);
      })
    },
    ganChange(val) {
      this.paramsGan.page = val;
      this.searchGenList();
    },
    //新增全宗--获取列表中档案类型的显示---初始化调用一次
    searchFiles() {
      allFiles().then(res => {
        if (res.code == 0) {
          this.filesArray = res.data;
        } else this.$message.error(res.message);
      })
    },
    //新增全宗--左侧下拉树
    searchGanTree() {
      leftGeneral({ type: 1 }).then(res => {
        if (res.code == 0) {
          this.dataGel = res.data;
        } else this.$message.error(res.message);
      })
    },
    handleGen(val) {
      this.paramsGan.nodeId = val.id;
      this.oneGenSearch();
      if (val.id == 0) {
        this.genOneFlag = false;
      } else {
        this.genOneFlag = true;
      }
    },
    //新增全宗--新增
    openGenAdd() {
      if (this.paramsGan.nodeId == null) {
        this.$message.error('请选择一条数据')
      } else if (this.paramsGan.nodeId == 0) { //全宗
        this.fondAdd = {
          fondCode: null,
          fondName: null,
          names: '广发证券',
          fondsCodeSynopsis: null
        };
        this.fondAddFlag = true;
        if (this.$refs['fondAdd']) {
          this.$nextTick(() => {
            this.$refs['fondAdd'].clearValidate();
          })
        }
      } else { //分类
        this.genAdd = {
          nodeId: this.paramsGan.nodeId,
          propertyValue: null,
          propertyName: null,
          archiveType: null
        };
        this.getFileType(this.paramsGan.nodeId);
        this.genAddFlag = true;
        if (this.$refs['genAdd']) {
          this.$nextTick(() => {
            this.$refs['genAdd'].clearValidate();
          })
        }
      }
    },
    //新增全宗--对应档案类型
    getFileType(val) {
      arcType({ id: val }).then(res => {
        if (res.code == 0) {
          this.typeArr = res.data; //新增档案类型下拉树，默认选中第一个
          if (res.data.length == 1) {
            this.genAdd.archiveType = this.typeArr[0].id; //只有一个默认选中
          } else {
            this.genAdd.archiveType = null;
          }
        } else this.$message.error(res.message);
      })
    },
    //分类新增
    submitGenAdd() {
      this.$refs['genAdd'].validate((valid) => {
        if (valid) {
          addGeneral(this.genAdd).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message)
              this.genAddFlag = false;
              this.searchGanTree();
              this.oneGenSearch();
            } else this.$message.error(res.message)
          })
        }
      })
    },
    //全宗新增
    submitFondAdd() {
      this.$refs['fondAdd'].validate((valid) => {
        if (valid) {
          addFonds(this.fondAdd).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message)
              this.fondAddFlag = false;
              this.searchGanTree();
              this.oneGenSearch();
            } else this.$message.error(res.message)
          })
        }
      })
    },
    selectGen(val) {
      this.genSelectArr = [];
      this.genSelectArr = val;
    },
    openGenDetail() {
      if (this.genSelectArr.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.genSelectArr.length > 1) {
        this.$message.error('只能选择一条数据')
      } else if (this.paramsGan.nodeId == 0) { //全宗编辑
        let showG = {};
        showG = this.genSelectArr[0]
        this.fondDetail = {
          seriesId: showG.id,
          fondCode: showG.fondsCode,
          fondName: showG.fondsCodeName,
          names: '广发证券',
          fondsCodeSynopsis: showG.fondsCodeSynopsis
        };
        this.fondDetailFlag = true;
        if (this.$refs['fondDetail']) {
          this.$nextTick(() => {
            this.$refs['fondDetail'].clearValidate();
          })
        }
      } else {
        //分类编辑
        this.getFileType(this.genSelectArr[0].id);
        let showG = {};
        showG = this.genSelectArr[0]
        this.genDetail = {
          seriesId: showG.id,
          propertyValue: showG.propertyValue,
          propertyName: showG.name,
          archiveType: showG.archiveTypeId,
          archiveTypeId: showG.archiveTypeId
        };
        this.genDetailFlag = true;
        if (this.$refs['genDetail']) {
          this.$nextTick(() => {
            this.$refs['genDetail'].clearValidate();
          })
        }
      }
    },
    //分类编辑
    submitGenDetail() {
      this.$refs['genDetail'].validate((valid) => {
        if (valid) {
          this.genDetail.name = this.genDetail.propertyName
          detailGeneral(this.genDetail).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message)
              this.genDetailFlag = false;
              this.searchGanTree();
              this.oneGenSearch()
            } else this.$message.error(res.message)
          })
        }
      })
    },
    //全宗编辑
    submitFondDetail() {
      this.$refs['fondDetail'].validate((valid) => {
        if (valid) {
          let fondParams = {
            fondsCode: this.fondDetail.fondCode,
            fondsCodeName: this.fondDetail.fondName,
            fondsCodeSynopsis: this.fondDetail.fondsCodeSynopsis,
            seriesId: this.fondDetail.seriesId,
            orgId: 105
          }
          detailFonds(fondParams).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message)
              this.fondDetailFlag = false;
              this.searchGanTree();
              this.oneGenSearch();
            } else this.$message.error(res.message)
          })
        }
      })
    },
    openGenDel() {
      if (this.genSelectArr.length <= 0) {
        this.$message.error('请选择一条数据')
      } else {
        this.genDelFlag = true;
      }
    },
    submitGenDel() { //删除分类or全宗
      let ids = [];
      this.genSelectArr.forEach(item => {
        ids.push(item.id)
      });
      if (this.paramsGan.nodeId == 0) { //删除全宗
        deleFonds({ seriesIds: ids.join(',') }).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message);
            this.genDelFlag = false;
            this.searchGanTree();
            this.oneGenSearch();
          } else this.$message.error(res.message);
        })
      } else { //删除分类
        delGeneral({ seriesIds: ids.join(',') }).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message);
            this.genDelFlag = false;
            this.searchGanTree();
            this.oneGenSearch();
          } else this.$message.error(res.message);
        })
      }
    },
    //专项新增
    openItem() {
      this.paramsItem = {
        roleParentId: this.parentId.parentRoleId,
        roleParentName: this.parentId.parentRoleName,
        roleReg: 0,
        inuse: 1
      };
      this.itemFlag = true;
      if (this.$refs['paramsItem']) {
        this.$nextTick(() => {
          this.$refs['paramsItem'].clearValidate();
        })
      }
    },
    submitItem() {
      this.$refs['paramsItem'].validate((valid) => {
        if (valid) {
          addItem(this.paramsItem).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message);
              this.itemFlag = false;
              this.oneSearch();
            } else this.$message.error(res.message);
          })
        }
      })
    },
    //专项编辑
    openDetailItem() {
      detailRoleDlg({ roleId: this.onceTable[0].id }).then(res => {
        if (res.code == 0) {
          this.paramsItem1 = res.data.tHtckRole;
          this.paramsItem1.roleParentName = res.data.parentRoleName;
          this.paramsItem1.roleIntro = res.data.role.roleIntro;
          this.paramsItem1.roleExpried = res.data.role.roleExpried;
        } else this.$message.error(res.message)
      })
    },
    submitItem1() {
      this.$refs['paramsItem1'].validate((valid) => {
        if (valid) {
          saveRoleDlg(this.paramsItem1).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message);
              this.itemFlag1 = false;
              this.oneSearch();
            } else this.$message.error(res.message);
          })
        }
      })
    },
  },
  created() {
    this.searchList();
    this.getParent();
    this.searchFiles();
  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.filter-tree {
  display: inline-block;

  .el-tree__empty-block {
    width: 200px;
  }
}

.general {
  clear: both;
  height: 500px;
  margin-top: -30px;

  .general-left {
    width: 30%;
    float: left;
    padding-top: 20px;
    height: 484px;
    overflow: auto;
  }

  .general-right {
    padding-top: 20px;
    width: 68%;
    float: left;
    border-left: 3px solid #1982BF;
    height: 500px;
    padding-left: 6px;
  }
}

.user-head {
  margin-top: 10px;
  margin-left: 9px;
}

.user-search {
  width: 57px;
  background: #0067AD;
  height: 28px;
  line-height: 42px;
  margin-left: -2px;
  border-radius: 4px;
  color: #fff !important;

  img {
    margin-top: -2px;
    margin-left: 5px;
    margin-right: 2px !important;
  }
}

.user-title {
  color: #fff;
  padding-left: 10px;

  img {
    float: right;
    margin-top: 6px;
  }
}

.user-content {
  height: 400px;
  margin-top: -24px;
  margin-left: -14px;
  margin-right: -14px;

  .user-left {
    width: 60%;
    float: left;
  }

  .user-right {
    width: 39.6%;
    display: inline-block;
    margin-left: 4px;
  }
}

.dia-radio {
  label {
    width: 100px;
  }
}

.see {
  width: 100%;
  clear: both;
  height: 500px;

  .see-left {
    width: 40%;
    float: left;
  }

  .see-right {
    width: 59%;
    float: left;
    border-left: 3px solid #1982BF;
    height: 500px;
  }
}

.input-uploads {
  .el-input {
    width: 70%;
  }

  .upload-show {
    display: inline-block;

    .el-button--primary {
      height: 36px;
      background: #0067AD;
      border-color: #0067AD;
    }
  }
}

.mt-31 {
  margin-top: -31px;
}

.table-botton {
  width: 80%;
  background: #08A9E6;
  color: #fff;
}

.headerBtn {
  margin-bottom: 10px;

  span {
    display: inline-block;
    font-size: 12px;
    color: #282828;
    margin-right: 12px;
    cursor: pointer;
    padding-bottom: 10px;

    img {
      vertical-align: middle;
      margin-right: 4px;
    }
  }

  .search-select {
    label {
      font-size: 14px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 143px;
    }

  }
}

.el-dialog {
  .el-select {
    width: 100%;
  }
}

.dialog-title {
  background-color: #0067AD;

  img {
    vertical-align: middle;
  }
}

/deep/.hurdleAll>div>div:first-child {
  padding: 0 !important;

  >div {
    height: 30px;
    line-height: 30px;
    text-indent: 10px;
    font-size: 14px;
    color: #fff;
  }

  button {
    top: 8px;

    i {
      color: #fff;
    }
  }
}

</style>
<style lang="less">
.filter-tree {
  .el-tree__empty-block {
    width: 200px;
  }
}

</style>
