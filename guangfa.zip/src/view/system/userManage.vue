<!-- 用户管理 -->
<template>
  <el-container style="background-color: #fff;">
    <div class="bigDog menuShrink black-tree">
      <PinDao></PinDao>
      <el-tree
        :data="treTable"
        :props="defaultProps"
        :check-strictly="true"
        :default-expand-all="false"
        :expand-on-click-node="false"
        :highlight-current="true"
        accordion
        @node-click="handleNodeClick">
        <span class="custom-tree-node"  slot-scope="{ node, data }">
            <span class="treeSpan" :dataType="data.type">
              <img :src="imgUrlHost +'/gdda-new'+ data.iconCls" alt="">
                  <!--<i :class="data.checkIcon"></i>-->
                  <!--<i :class="data.iconSkin"></i>-->
                {{ node.label }}
            </span>
        </span>
      </el-tree>
    </div>
    <el-main style="padding:0;">
      <el-header class="menuHeaderTop" style="padding:0;height:30px;">
        <img src="../../assets/home/childrenHurdle.png" alt="">
        用户列表
      </el-header>
      <div class="contentPadding tableShrink">
        <!--新增，编辑，删除-->
        <div class="headerBtn">
          <span @click="showDigBtn(1)"><img src="../../assets/hurdle/hurdleAdd.png" alt="">新增</span>
          <span @click="showDigBtn(11)"><img src="../../assets/hurdle/p3.png" alt="">新增到列表</span>
          <span @click="showDigBtn(2)"><img src="../../assets/hurdle/hurdleAudit.png" alt="">编辑</span>
          <span @click="showDigBtn(3)"><img src="../../assets/hurdle/hurdleDelete.png" alt="">删除</span>
          <span @click="showDigBtn(4)"><img src="../../assets/hurdle/p1.png" alt="">启用</span>
          <span @click="showDigBtn(5)"><img src="../../assets/hurdle/fengTing.png" alt="">封停</span>
          <span @click="showDigBtn(6)"><img src="../../assets/hurdle/p2.png" alt="">角色</span>
        </div>
        <!-- 表格 -->
        <div class="all-Table">
          <el-table
            :data="tableData"
            stripe
            border
            @selection-change="handleSelectionChange"
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              prop="userName"
              label="姓名"
              width="180">
            </el-table-column>
            <el-table-column
              prop="loginName"
              label="登录账号">
            </el-table-column>
            <el-table-column
              prop="mobile"
              label="手机号码">
            </el-table-column>
            <el-table-column
              prop="email"
              label="电子邮箱">
            </el-table-column>
            <el-table-column
              prop="station"
              label="职位情况">
            </el-table-column>
            <el-table-column
              prop="flag3"
              label="有效期限">
            </el-table-column>
            <el-table-column
              prop="flag2"
              label="账号状态"
              width="180">
              <template slot-scope="scope">
                <span v-if="scope.row.flag2 == '0'">正常</span>
                <span v-else-if="scope.row.flag2 == '1'">封停</span>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChange"
            :current-page="paramsTwo.page"
            :page-size="paramsTwo.rows"
            layout="prev, pager, next, jumper"
            :total="paramsTwo.total">
          </el-pagination>
        </div>
      </div>
      <!-- 新增弹框（用户） -->
      <el-dialog
        :visible.sync="dialogAdd"
        width="444px"
        class="hurdleAll"
        :before-close="handleClose">
        <div slot="title" class="dialog-title">
          <!--<img src="../../assets/hurdle/hurdleAdd.png" alt="">-->
          <img src="../../assets/dialog/tj.png" alt="">
          新增
        </div>
        <el-form :model="paramsAdd" :rules="rulesAudit" ref="ruleFormAdd" label-width="106px" class="demo-ruleForm">
          <el-form-item label="真实姓名：" prop="userName">
            <el-input v-model="paramsAdd.userName"></el-input>
          </el-form-item>
          <el-form-item label="登录账号：" prop="loginName">
            <el-input v-model="paramsAdd.loginName"></el-input>
          </el-form-item>
          <el-form-item label="手机号码：" prop="mobile">
            <el-input v-model="paramsAdd.mobile"></el-input>
          </el-form-item>
          <el-form-item label="电子邮箱：" prop="email">
            <el-input v-model="paramsAdd.email"></el-input>
          </el-form-item>
          <el-form-item class="editorXin" label="账户有效期：" prop="flag3">
            <el-date-picker
              style="width: 100%;"
              v-model="paramsAdd.flag3"
              type="date"
              format="yyyy 年 MM 月 dd 日"
              value-format="yyyy-MM-dd"
              placeholder="请选择时间">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="账号状态：" prop="flag2">
            <el-radio-group v-model="paramsAdd.flag2">
              <el-radio label="0">正常</el-radio>
              <el-radio label="1">封停</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item style="text-align: right">
            <el-button type="primary" @click="submitFormAdd">保存</el-button>
            <el-button @click="resetForm('1')">重置</el-button>
          </el-form-item>
        </el-form>
      </el-dialog>
      <!-- 编辑弹框（用户） -->
      <el-dialog
        :visible.sync="dialogEdit"
        width="444px"
        class="hurdleAll"
        :before-close="handleClose">
        <div slot="title" class="dialog-title">
          <!--<img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">-->
          编辑
        </div>
        <el-form :model="paramsEdit" :rules="rulesAudit" ref="ruleFormEdit" label-width="106px" class="demo-ruleForm">
          <el-form-item label="真实姓名：" prop="userName">
            <el-input v-model="paramsEdit.userName"></el-input>
          </el-form-item>
          <el-form-item label="登录账号：" prop="loginName">
            <el-input v-model="paramsEdit.loginName"></el-input>
          </el-form-item>
          <el-form-item label="手机号码：" prop="mobile">
            <el-input v-model="paramsEdit.mobile"></el-input>
          </el-form-item>
          <el-form-item label="电子邮箱：" prop="email">
            <el-input v-model="paramsEdit.email"></el-input>
          </el-form-item>
          <el-form-item class="editorXin" label="账户有效期：" prop="flag3">
            <el-date-picker
              style="width: 100%;"
              v-model="paramsEdit.flag3"
              type="date"
              format="yyyy 年 MM 月 dd 日"
              value-format="yyyy-MM-dd"
              placeholder="请选择时间">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="账号状态：" prop="flag2">
            <el-radio-group v-model="paramsEdit.flag2">
              <el-radio label="0">正常</el-radio>
              <el-radio label="1">封停</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item style="text-align: right">
            <el-button type="primary" @click="submitFormEdit">保存</el-button>
            <el-button @click="resetForm('2')">重置</el-button>
          </el-form-item>
        </el-form>
      </el-dialog>
      <!-- 操作弹框 -->
      <el-dialog :visible.sync="dialogDelete" width="444px" class="hurdleAll" :before-close="handleClose">
        <div slot="title" class="dialog-title">
          <!--<img src="../../assets/hurdle/topicDel.png" alt="">-->
          {{ paramsThree.title }}
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要{{ paramsThree.title }}此数据吗？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
          <el-button type="primary" @click="submitFormDelete">确定</el-button>
          <el-button @click="dialogDelete = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 新增弹框（用户权限） -->
      <el-dialog
        :visible.sync="dialogAddList"
        width="1325px"
        class="hurdleAll"
        :before-close="handleClose">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          新增
        </div>
        <div class="dialogAddList">
          <div>
            <p class="searchInput">
              用户名称：
              <el-input v-model="paramsUserName" placeholder="请输入内容"></el-input>
              <span class="searchBtn" @click="userNameBtnList" style="cursor: pointer;"><img src="../../assets/hurdle/searchBtn.png" alt="">搜索</span>
            </p>
            <p style="margin-left: 20px; cursor: pointer;" @click="addUserRole">
              <img src="../../assets/system/p1.png" alt="">
              新增用户
            </p>
          </div>
          <div class="all-Table">
            <el-table
              :data="userListTable"
              stripe
              border
              @selection-change="handleSelectionChangeUser"
              style="width: 100%">
              <el-table-column
                type="selection"
                width="55">
              </el-table-column>
              <el-table-column
                prop="userName"
                label="用户名称">
              </el-table-column>
              <el-table-column
                prop="station"
                label="岗位">
              </el-table-column>
              <el-table-column
                prop="email"
                label="电子邮箱">
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="dialogAddList">
          <div>
            <p class="searchInput">
              角色名称：
              <el-input v-model="paramsUserNameTwo" placeholder="请输入内容"></el-input>
              <span class="searchBtn" @click="userNameBtnListTwo" style="cursor: pointer;"><img src="../../assets/hurdle/searchBtn.png" alt="">搜索</span>
            </p>
          </div>
          <div class="all-Table">
            <el-table
              :data="roleListTable"
              stripe
              border
              @selection-change="handleSelectionChangeRole"
              style="width: 100%">
              <el-table-column
                type="selection"
                width="55">
              </el-table-column>
              <el-table-column
                prop="roleName"
                label="姓名">
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="clear"></div>
      </el-dialog>
      <!-- 新增弹框（角色权限） -->
      <el-dialog
        :visible.sync="dialogAddListUser"
        width="1325px"
        class="hurdleAll"
        :before-close="handleClose">
        <div slot="title" class="dialog-title">
          <!--<img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">-->
          角色
        </div>
        <div class="dialogAddList">
          <div>
            <p style="margin: 10px 10px; cursor: pointer;" @click="deleteUserRole">
              <img src="../../assets/system/p1.png" alt="">
              删除用户
            </p>
          </div>
          <div class="all-Table">
            <el-table
              :data="userListTable"
              stripe
              border
              @selection-change="handleSelectionChangeUserTwo"
              style="width: 100%">
              <el-table-column
                type="selection"
                width="55">
              </el-table-column>
              <el-table-column
                prop="roleName"
                label="角色名称">
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="dialogAddList">
          <div>
            <p class="searchInput">
              角色名称：
              <el-input v-model="paramsUserNameTwo" placeholder="请输入内容"></el-input>
              <span class="searchBtn" @click="userNameBtnListTwoUser" style="cursor: pointer;"><img src="../../assets/hurdle/searchBtn.png" alt="">搜索</span>
            </p>
            <p style="margin: 10px 10px; cursor: pointer;" @click="addUserAuthorityRole">
              <img src="../../assets/system/p1.png" alt="">
              增加角色
            </p>
          </div>
          <div class="all-Table">
            <el-table
              :data="roleListTable"
              stripe
              border
              @selection-change="handleSelectionChangeRoleTwo"
              style="width: 100%">
              <el-table-column
                type="selection"
                width="55">
              </el-table-column>
              <el-table-column
                prop="roleName"
                label="姓名">
              </el-table-column>
            </el-table>
          </div>
        </div>
        <div class="clear"></div>
      </el-dialog>
    </el-main>
  </el-container>
</template>

<script>
import { userlistTopForTreeJson, userlistForJson, userAddSave, userDeleteByOrgUser, userUpdateStateStart, userListByName,
  roleListForJson2, addUrrOnce, roleListRoleForJson, roleDeleteByOrgUser, userAddSaveOnce, roleDeleteTuserRole } from '@/js/getData'
import PinDao from '../../components/menuChildren/pinDao'
import { DEV_HOST } from '@/js/http.js'
export default {
  name: 'userManage',
  components: {
    PinDao
  },
  data () {
    const validataZm = (rule, value, callback) => {
      let reg = /^[A-Za-z]+$/
      if (!reg.test(value)) {
        callback(new Error('请输入英文'))
      } else {
        callback()
      }
    }
    return {
      imgUrlHost: DEV_HOST,
      params: {
        total: 0,
        rows: 10,
        page: 1
      },
      paramsTwo: {
        total: 0,
        rows: 10,
        userName: null,
        page: 1
      },
      paramsThree: {},
      paramsUserName: '',
      paramsUserNameTwo: '',
      onceTable: [],
      tableData: [],
      userListTable: [], // 用户
      roleListTable: [], // 角色
      twoTable: [], // 用户的多选
      threeTable: [], // 角色的多选
      fourTable: [], // 角色按钮的用户的多选
      fiveTable: [], // 角色按钮的角色的多选
      selectTypeList: [
        { id: 1, name: '内容页'},
        { id: 2, name: '信息列表页'},
        { id: 3, name: '图片列表页'},
        { id: 4, name: '视频列表'},
        { id: 99, name: '外部模块'},
        { id: 100, name: '栏目组别'}
      ],

      paramsAdd: {
        flag2: '0'
      },
      dialogAdd: false,
      paramsEdit: {},
      dialogEdit: false,
      dialogDelete: false,
      dialogAddList: false,
      dialogAddListUser: false,
      // paramsUserAuthority: '',

      rulesAudit: {
        userName: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        loginName: [
          { required: true, message: '请注意填写', trigger: 'blur'},
          { validator: validataZm, trigger: 'blur'}
        ],
        mobile: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        email: [{ required: true, message: '请注意填写', trigger: 'blur'}],
        flag3: [{ required: true, message: '请注意选择', trigger: 'blur'}],
        flag2: [{ required: true, message: '请注意选择', trigger: 'blur'}]
      },
      treTable: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      }
    }
  },
  methods: {
    handleNodeClick (val) {
      // console.log(val);
      this.paramsTwo = {
        page: 1,
        rows: 10,
        total: 0,
        userName: null,
        orgId: val.id
      }
      this.showListTwo()
    },
    showList () {
      userlistTopForTreeJson().then(res => {
        this.treTable.push(res.data)
      })
    },
    showListTwo () {
      userlistForJson(this.paramsTwo).then(res => {
        this.tableData = res.data.rows
        this.paramsTwo.total = res.data.total
      })
    },
    handleSelectionChange (val) {
      this.onceTable = val
    },
    // 单页面点击
    handleCurrentChange (val) {
      this.paramsTwo.page = val
      this.showListTwo()
      // console.log(`当前页: ${val}`)
    },
    showDigBtn (val) {
      this.userListTable = []
      this.roleListTable = []
      this.paramsUserNameTwo = ''
      if (val == 1) {
        this.dialogAdd = true
        this.paramsAdd = {flag2: '0'}
        this.showClear()
      } else if (val == 2) {
        let item = this.$onceWay().onceTableList(this.onceTable)
        if (item == 1) {
          this.paramsEdit = JSON.parse(JSON.stringify(this.onceTable[0]))
          this.dialogEdit = true
          this.showClear()
        }
      } else if (val == 3) {
        let item = this.$onceWay().onceTableList(this.onceTable)
        if (item == 1) {
          this.paramsThree.title = '删除'
          this.dialogDelete = true
        }
      } else if (val == 4) {
        let item = this.$onceWay().onceTableList(this.onceTable)
        if (item == 1) {
          this.paramsThree.title = '启用'
          this.dialogDelete = true
        }
      } else if (val == 5) {
        let item = this.$onceWay().onceTableList(this.onceTable)
        if (item == 1) {
          this.paramsThree.title = '封停'
          this.dialogDelete = true
        }
      } else if (val == 11) {
        // let item = this.$onceWay().onceTableList(this.onceTable)
        // if (item == 1) {
        // }
        if (this.paramsTwo.orgId) {
          this.paramsUserName = ''
          this.paramsUserNameTwo = ''
          this.dialogAddList = true
          this.showClear()
          this.userNameBtnListTwo()
        } else {
          this.$message.error('请你先在部门机构树中选中一项作为职员所在部门')
        }
      } else if (val == 6) {
        let item = this.$onceWay().onceTableList(this.onceTable)
        if (item == 1) {
          let params = {
            organizeId: this.paramsTwo.orgId,
            userId: this.onceTable[0].userId
          }
          this.selectUserList(params)
          // roleListRoleForJson(params).then(res => {
          //   this.userListTable = res.data
          // })
          this.dialogAddListUser = true
        }
      }
    },
    submitFormAdd () {
      this.$refs['ruleFormAdd'].validate((valid) => {
        if (valid) {
          this.paramsAdd.orgId = this.paramsTwo.orgId
          userAddSave(this.paramsAdd).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message)
              this.dialogAdd = false
              this.showListTwo()
            } else {
              this.$message.error(res.message)
            }
          })
        }
      })
    },
    submitFormEdit () {
      this.$refs['ruleFormEdit'].validate((valid) => {
        if (valid) {
          let params = {
            // orgId: this.paramsTwo.orgId,
            userId: this.paramsEdit.userId,
            userName: this.paramsEdit.userName,
            loginName: this.paramsEdit.loginName,
            mobile: this.paramsEdit.mobile,
            email: this.paramsEdit.email,
            flag3: this.paramsEdit.flag3,
            flag2: this.paramsEdit.flag2
          }
          userAddSave(params).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message)
              this.dialogEdit = false
              this.showListTwo()
            } else {
              this.$message.error(res.message)
            }
          })
        }
      })
    },
    submitFormDelete () {
      let params = {
        ids: this.onceTable[0].userId
      }
      if (this.paramsThree.title === '删除') {
        params.orgId = this.paramsTwo.orgId
        userDeleteByOrgUser(params).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogDelete = false
            this.showListTwo()
          } else {
            this.$message.error(res.message)
          }
        })
      } else if (this.paramsThree.title === '启用') {
        params.stateFlag = '0'
        userUpdateStateStart(params).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogDelete = false
            this.showListTwo()
          } else {
            this.$message.error(res.message)
          }
        })
      } else if (this.paramsThree.title === '封停') {
        params.stateFlag = '1'
        userUpdateStateStart(params).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogDelete = false
            this.showListTwo()
          } else {
            this.$message.error(res.message)
          }
        })
      }
    },
    /* 重置 */
    resetForm (val) {
      if (val == 1) {
        this.$refs['ruleFormAdd'].clearValidate()
        this.paramsAdd = {}
      } else if (val == 2) {
        this.$refs['ruleFormEdit'].clearValidate()
        this.paramsEdit = {}
      }
    },
    /* 关闭弹框 */
    handleClose () {
      this.dialogAdd = false
      this.dialogEdit = false
      this.dialogDelete = false
      this.dialogAddList = false
      this.dialogAddListUser = false
    },
    showClear () {
      if (this.$refs['ruleFormEdit']) {
        this.$nextTick(() => {
          this.$refs['ruleFormEdit'].clearValidate()
        })
      } else if (this.$refs['ruleFormAdd']) {
        this.$nextTick(() => {
          this.$refs['ruleFormAdd'].clearValidate()
        })
      }
    },
    userNameBtnList () {
      userListByName({userName: this.paramsUserName}).then(res => {
        this.userListTable = res.data
      })
    },
    // 角色查询
    userNameBtnListTwo () {
      roleListForJson2({roleName: this.paramsUserNameTwo}).then(res => {
        this.roleListTable = res.data
      })
    },
    // 角色按钮查询
    userNameBtnListTwoUser () {
      if (this.paramsUserNameTwo) {
        roleListForJson2({roleName: this.paramsUserNameTwo}).then(res => {
          this.roleListTable = res.data
        })
      } else this.$message.error('请输入角色名称')
    },
    handleSelectionChangeUser (val) {
      this.twoTable = val
    },
    handleSelectionChangeRole (val) {
      this.threeTable = val
    },
    handleSelectionChangeUserTwo (val) {
      this.fourTable = val
    },
    handleSelectionChangeRoleTwo (val) {
      this.fiveTable = val
    },
    // 增加权限
    addUserRole () {
      // this.paramsTwo.orgId
      if (this.twoTable.length <= 0) {
        this.$message.error('请选择一条用户')
      } else if (this.twoTable.length > 1) {
        this.$message.error('只能选择一条用户')
      } else if (this.threeTable.length <= 0) {
        this.$message.error('请选择角色')
      } else {
        let params = ''
        this.threeTable.forEach((val, index) => {
          params += val.id + ';'
        })
        let item = {
          organizeId: this.paramsTwo.orgId,
          userId: this.twoTable[0].userId,
          roleId: params
        }
        addUrrOnce(item).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            this.dialogAddList = false
            this.showListTwo()
          } else {
            this.$message.error(res.message)
          }
        })
      }
    },
    // 删除用户
    deleteUserRole () {
      if (this.fourTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else {
        let item = ''
        for (let i in this.fourTable) {
          item += this.fourTable[i].id + ','
        }
        roleDeleteTuserRole({ids: item}).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            let params = {
              organizeId: this.paramsTwo.orgId,
              userId: this.onceTable[0].userId
            }
            this.selectUserList(params)
          } else this.$message.error(res.message)
        })
      }
    },
    addUserAuthorityRole () {
      if (this.fiveTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.fiveTable.length > 1) {
        this.$message.error('只可以选择一条数据')
      } else {
        let params = {
          organizeId: this.paramsTwo.orgId,
          userId: this.onceTable[0].userId,
          roleId: this.fiveTable[0].id
        }
        userAddSaveOnce(params).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message)
            let params = {
              organizeId: this.paramsTwo.orgId,
              userId: this.onceTable[0].userId
            }
            this.selectUserList(params)
          } else {
            this.$message.error(res.message)
          }
        })
      }
    },
    /* 搜索角色名称 */
    selectUserList (val) {
      // let params = {
      //   organizeId: this.paramsTwo.orgId,
      //   userId: this.onceTable[0].userId
      // }
      roleListRoleForJson(val).then(res => {
        this.userListTable = res.data
      })
    }
  },
  created () {
    this.showList()
  }
}
</script>

<style scoped lang="less">
  @import "../../css/public";
  .headerBtn{
    margin-bottom: 10px;
    span{
      display: inline-block;
      /*width: 100px;*/
      font-size: 12px;
      color: #282828;
      cursor: pointer;
      margin-right: 20px;
      img{
        vertical-align: middle;
        margin-right: 4px;
      }
    }
  }
  .el-dialog{
    .el-select{
      width: 100%;
    }
  }
  .dialog-title {
    background-color: #0067AD;
    img{
      vertical-align: middle;
    }
  }
  .dialogAddList{
    float: left;
    width: 49%;
    border: 1px solid;
    margin: 0 4px;
    padding: 0 4px;
    box-sizing: border-box;
    min-height: 600px;
    max-height: 600px;
    overflow: auto;
    p{
      display: inline-block;
      width: 90px;
    }
    img{
      vertical-align: middle;
    }
    .searchInput{
      width: 308px;
      margin: 8px 0;
      .el-input{
        width: 50%;
        input{
          border-radius: 0!important;
        }
      }
      /*.el-select{*/
      /*width: 66%;*/
      /*}*/
      .searchBtn{
        float: right;
        width: 80px;
        text-align: center;
        height: 40px;
        line-height: 40px;
        color: #fff;
        background-color: #0067AD;
        img{
          margin-right: 5px;
          vertical-align: middle;
        }
      }
    }
  }
</style>
