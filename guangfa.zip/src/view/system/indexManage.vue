<!-- 索引管理 -->
<template>
  <div>
    <div class="contentPadding index-main">
      <div class="index-div">
        <div class="index-one" @click="createArch">
          <span class="index-span"><img src="../../assets/system/index1.png" alt="" /></span>
          <span>创建Archive索引库</span>
        </div>
        <div class="index-one" @click="createDoc">
          <span class="index-span"><img src="../../assets/system/index1.png" alt="" /></span>
          <span>创建Document索引库</span>
        </div>
        <div class="index-one" @click="totalArch">
          <span class="index-span"><img src="../../assets/system/index1.png" alt="" /></span>
          <span>全量索引Archive</span>
        </div>
        <div class="index-one" @click="addArch">
          <span class="index-span"><img src="../../assets/system/index1.png" alt="" /></span>
          <span>增量索引Archive</span>
        </div>
        <div class="index-one" @click="totalDoc">
          <span class="index-span"><img src="../../assets/system/index1.png" alt="" /></span>
          <span>全量索引Document</span>
        </div>
        <div class="index-one" @click="addDoc">
          <span class="index-span"><img src="../../assets/system/index1.png" alt="" /></span>
          <span>增量索引Document</span>
        </div>
      </div>
      <div class="index-div">
        <div class="index-one" @click="openDel(1)">
          <span class="index-span"><img src="../../assets/system/index3.png" alt="" /></span>
          <span>删除Archive索引库</span>
        </div>
        <div class="index-one" @click="openDel(2)">
          <span class="index-span"><img src="../../assets/system/index3.png" alt="" /></span>
          <span>删除Document索引库</span>
        </div>
        <div class="index-one" @click="searchTypeList">
          <span class="index-span"><img src="../../assets/system/index1.png" alt="" /></span>
          <span>创建索引</span>
        </div>
        <div class="index-one" @click="listImport">
          <span class="index-span"><img src="../../assets/system/index2.png" alt="" /></span>
          <span>导入数据</span>
        </div>
      </div>
      <!-- 执行结果（前6个按钮） -->
      <el-dialog :visible.sync="showFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/system/u5.png" alt="">
          系统提示
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>{{showTitle}}</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-18">
          <el-button type="primary" @click="showFlag = false">确定</el-button>
        </div>
      </el-dialog>
      <!-- 删除弹框 -->
      <el-dialog :visible.sync="delFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicDel.png" alt="">
          系统提示
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>此操作不可逆，确定要删除整个索引库吗？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-18">
          <el-button type="primary" @click="clickDelete">确定</el-button>
          <el-button @click="delFlag = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 创建索引弹框 -->
      <el-dialog :visible.sync="createFlag" width="1100px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/system/g2.png" alt="">
          创建索引类型
        </div>
        <div>
          <div class="headerBtn index-span index-btn">
            <span @click="createType"><img src="../../assets/system/p1.png" alt="">创建索引</span>
            <span @click="changeExpend(true)"><img src="../../assets/system/e1.png" alt="">展开</span>
            <span @click="changeExpend(false)"><img src="../../assets/system/e2.png" alt="">关闭</span>
          </div>
          <div class="index-tree">
            <el-tree :data="listData" ref="index1" :props="defaultProps1" show-checkbox node-key="id" :expand-on-click-node="false">
              <span class="custom-tree-node" slot-scope="{ node, data }">
                <span>{{ node.label}}</span>
                <span v-show="node.level>1">
                  <el-radio-group v-model="data.estype">
                    <el-radio label="keyword">keyword</el-radio>
                    <el-radio label="text" style="margin-right: 0px">text:{{data.analyze}}</el-radio>
                    <el-select v-model="data.analyze" class="index-select" size="mini">
                      <el-option v-for="item in analyArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
                    </el-select>
                    <el-radio label="date">date</el-radio>
                    <el-radio label="double">double</el-radio>
                  </el-radio-group>
                </span>
              </span>
            </el-tree>
          </div>
        </div>
      </el-dialog>
      <!-- 创建索引前-确认 -->
      <el-dialog :visible.sync="beforeFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle1.png" alt="">
          确认
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定创建勾选的索引？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-18">
          <el-button type="primary" @click="clickBefore">确定</el-button>
          <el-button @click="beforeFlag = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 导入数据列表 -->
      <el-dialog :visible.sync="downFlag" width="440px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/system/g2.png" alt="">
          索引导入数据
        </div>
        <div>
          <div class="headerBtn index-span index-btn">
            <span class="import-radio">
              <el-radio v-model="radioDown" label="0">增量</el-radio>
            </span>
            <span class="import-radio">
              <el-radio v-model="radioDown" label="1">全景</el-radio>
            </span>
            <span><img class="index-img" src="../../assets/system/index4.png" alt="" @click="listSave">执行</span>
          </div>
          <div class="index-tree">
            <el-tree :data="downData" ref="index2" :props="defaultProps" show-checkbox node-key="id" :expand-on-click-node="false">
            </el-tree>
          </div>
        </div>
      </el-dialog>
      <!-- 导入执行--进度条 -->
      <el-dialog :visible.sync="perFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/system/circle.png" alt="">
          请稍后
        </div>
        <div class="dia-delete">
          <el-progress :percentage="perData"></el-progress>
          <div>任务执行中</div>
        </div>
      </el-dialog>
      <!-- 导入索引前-确认 -->
      <el-dialog :visible.sync="conFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle1.png" alt="">
          确认
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定执行该任务？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-18">
          <el-button type="primary" @click="clickCon">确定</el-button>
          <el-button @click="conFlag = false">取消</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import { indexArch, indexDoc, indexData, indexDocData, deleteArch, deleteDoc, indexTypeList, indexTypeMap, indexSave, indexImport, indexImportList } from '@/js/getData';
export default {
  name: 'indexManage',
  data() {
    return {
      defaultRadio: 'keyword',
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      perData: 20,
      defaultProps1: {
        children: 'newChild',
        label: 'text'
      },
      analyArr: [{ id: 'Y', text: 'Y' }, { id: 'N', text: 'N' }],
      showTitle: null,
      showFlag: false,
      loadMsg: null,
      delFlag: false,
      delType: null,
      createFlag: false,
      radioArr: [{ show: null }],
      listData: [],
      show: null,
      expendFlag: null,
      downFlag: false,
      downData: [],
      radioDown: null,
      perFlag: false,
      conFlag: false,
      saveParams: [],
      beforeFlag: false
    }
  },
  methods: {
    //执行加载中
    openFullScreen(val, flag) {
      const loading = this.$loading({
        lock: true,
        text: val,
        background: 'rgba(0, 0, 0, 0.3)'
      });
      if (flag) {
        loading.close();
      }
    },
    //创建archives档案索引库
    createArch() {
      let msg = '正在执行创建索引操作，请稍候...';
      this.openFullScreen(msg, false);
      indexArch().then(res => {
        this.openFullScreen(msg, true);
        if (res.code == 0) {
          this.showTitle = res.data.info;
          this.showFlag = true;
        } else this.$message.error('系统错误!')
      })
    },
    //创建Document文档索引库 
    createDoc() {
      let msg = '正在执行创建索引操作，请稍候...'
      this.openFullScreen(msg, false);
      indexDoc().then(res => {
        this.openFullScreen(msg, true);
        if (res.code == 0) {
          this.showTitle = res.data.info;
          this.showFlag = true;
        } else this.$message.error('系统错误!')
      })
    },
    //全量索引Archive
    totalArch() {
      let msg = '正从数据库表将archive导入es索引库中...';
      this.openFullScreen(msg, false);
      indexData({ increatment: false }).then(res => {
        this.openFullScreen(msg, true);
        if (res.code == 0) {
          this.showTitle = res.data.archive;
          this.showFlag = true;
        } else this.$message.error('系统错误!')
      })
    },
    //增量索引Archive
    addArch() {
      let msg = '正从数据库表将archive导入es索引库中...';
      this.openFullScreen(msg, false);
      indexData({ increatment: true }).then(res => {
        this.openFullScreen(msg, true);
        if (res.code == 0) {
          this.showTitle = res.data.archive;
          this.showFlag = true;
        } else this.$message.error('系统错误!')
      })
    },
    //全量索引Document 
    totalDoc() {
      let msg = '正从数据库表将document导入es索引库中...';
      this.openFullScreen(msg, false);
      indexDocData({ increatment: false }).then(res => {
        this.openFullScreen(msg, true);
        if (res.code == 0) {
          this.showTitle = res.data.document;
          this.showFlag = true;
        } else this.$message.error('系统错误!')
      })
    },
    //增量索引Document 
    addDoc() {
      let msg = '正从数据库表将document导入es索引库中...';
      this.openFullScreen(msg, false);
      indexDocData({ increatment: true }).then(res => {
        this.openFullScreen(msg, true);
        if (res.code == 0) {
          this.showTitle = res.data.document;
          this.showFlag = true;
        } else this.$message.error('系统错误!')
      })
    },
    //打开删除弹框
    openDel(val) { //1删除arch;2删除doc
      this.delFlag = true;
      this.delType = val;
    },
    clickDelete() {
      if (this.delType == 1) {
        this.delArc();
      }
      if (this.delType == 2) {
        this.delDoc();
      }
    },
    //删除Archive索引库 
    delArc() {
      let msg = '正在执行删除索引操作，请稍候...';
      this.openFullScreen(msg, false);
      deleteArch().then(res => {
        this.openFullScreen(msg, true);
        if (res.code == 0) {
          this.showTitle = res.data.info;
          this.showFlag = true;
          this.delFlag = false;
        } else this.$message.error('系统错误!')
      })
    },
    //删除Document索引库 
    delDoc() {
      let msg = '正在执行删除索引操作，请稍候...';
      this.openFullScreen(msg, false);
      deleteDoc().then(res => {
        this.openFullScreen(msg, true);
        if (res.code == 0) {
          this.showTitle = res.data.info;
          this.showFlag = true;
          this.delFlag = false;
        } else this.$message.error('系统错误!')
      })
    },
    //获取索引类型列表
    searchTypeList() {
      indexTypeList().then(res => {
        if (res.code == 0) {
          this.listData = res.data;
          this.createFlag = true;
        } else this.$message.error(res.message)
      })
    },
    //打开、关闭索引下拉树
    changeExpend(val) {
      this.expendFlag = val;
      for (var i = 0; i < this.$refs.index1.store._getAllNodes().length; i++) {
        this.$refs.index1.store._getAllNodes()[i].expanded = this.expendFlag
      }
    },
    //创建索引
    createType() {
      this.saveParams = [];
      let tableArr = this.$refs.index1.getCheckedNodes() || [];
      let parentText = this.$refs.index1.getHalfCheckedNodes().text || null;
      if (tableArr.length <= 0) {
        this.$message.error("请选择节点!")
      } else {
        let newArr = [...new Set(tableArr)];
        newArr.forEach(item => {
          let name = item.id.replace("/=/", ",").split(',');
          let oneItem = {
            tableName: name[0],
            columnName: name[1],
            ESType: item.estype,
            analyze: 'Y'
          }
          this.saveParams.push(oneItem)
        });
        this.beforeFlag = true;
      }
    },
    //创建索引保存
    clickBefore() {
      this.beforeFlag = false;
      indexSave(this.saveParams).then(res => {
        this.showTitle = res.message;
        this.showFlag = true;
      })
    },
    //索引列表导出--列表
    listImport() {
      this.radioDown = null;
      indexImportList().then(res => {
        if (res.code == 0) {
          this.downData = res.data;
          this.downFlag = true;
        } else this.$message.error(res.message)
      })
    },
    //索引列表导出--保存前校验
    listSave() {
      let datas = this.$refs.index2.getCheckedNodes() || [];
      if (datas.length <= 0) { //没有选中tree
        this.$message.error("请选择一个索引！");
      } else if (this.radioDown == null) {
        this.$message.error("请选择全量或增量！");
      } else {
        this.conFlag = true;
      }
    },
    //索引列表导出-保存
    clickCon() {
      this.conFlag = false;
      let datas = this.$refs.index2.getCheckedNodes() || [];
      let datas1 = [];
      datas.forEach(item => {
        datas1.push(item.text)
      })
      let importData = {
        table: datas1,
        type: this.radioDown
      };
      indexImport(importData).then(res => {
        this.showTitle = res.message;
        this.showFlag = true;
      })
    },
  },
  created() {

  }
}

</script>
<style lang="less">
.el-loading-spinner .circular {
  width: 42px;
  height: 42px;
  animation: loading-rotate 2s linear infinite;
  display: none;
}

.el-loading-spinner {
  background: url(../../assets/system/load.gif) no-repeat 139px 10px !important;
  background-size: 100px 100px !important;
  width: 389px !important;
  height: 147px !important;
  background-color: #fff !important;
  position: relative;
  top: 15vh;
  left: 40%;
}

.el-loading-spinner .el-loading-text {
  font-size: 14px !important;
  padding-top: 109px !important;
  color: #282828 !important;
}

.import-radio {
  .el-radio__input.is-checked .el-radio__inner {
    border-color: #0067AD;
    background: #fff;
  }

  .el-radio__inner {
    width: 22px;
    height: 22px;
    border: 2px solid #0067AD;
  }

  .el-radio__label,
  .el-radio__input.is-checked+.el-radio__label {
    color: #282828;
  }

  .el-radio__inner::after {
    width: 10px;
    height: 10px;
    background: #0067AD;
  }
}

.index-select {
  .el-input--mini .el-input__inner {
    display: none
  }

  .el-input--mini .el-input__icon {
    margin-top: 7px;
  }
}

</style>
<style scoped lang="less">
@import "../../css/public";

.index-select {
  width: 30px;
  margin-right: 30px;

  .el-input--mini .el-input__inner {
    display: none
  }
}

.index-main {
  background-color: #fff;
  height: 700px
}

.mt-18 {
  margin-top: -18px;
}

.index-btn {
  margin-bottom: 22px;
  margin-top: -12px;
}

.index-tree {
  height: 600px;
  overflow-y: auto;
}

.index-img {
  margin-top: -1px;
  margin-right: 10px;
}

.index-tree1 {
  height: 400px;
  overflow-y: auto
}

.el-dropdown-link {
  cursor: pointer;
  color: #409EFF;
}

.el-icon-arrow-down {
  font-size: 12px;
}

.el-dropdown-link {
  cursor: pointer;
  color: #409EFF;
}

.el-icon-arrow-down {
  font-size: 12px;
}

.custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 274px;
}

.loadsClass {
  font-size: 14px;
  color: #282828;
}

.index-div {
  padding-left: 18px;
  width: 100%;
  font-size: 12px;
  clear: both;
  color: rgb(255, 255, 255);

  .index-one {
    cursor: pointer;
    float: left;
    width: 190px;
    height: 54px;
    border-radius: 6px;
    background-color: rgb(0, 103, 173);
    line-height: 54px;
    margin-right: 10px;
    margin-top: 15px;

    .index-span {
      height: 46px;
      width: 46px;
      line-height: 46px;
      background-color: rgb(255, 255, 255);
      border-radius: 6px 0px 0px 6px;
      display: inline-block;
      margin-left: 3px;
      margin-top: 4px;
      text-align: center;
      margin-right: 16px;
    }

    img {
      vertical-align: middle
    }
  }
}

.index-span {
  >span {
    cursor: pointer;
  }
}

</style>
