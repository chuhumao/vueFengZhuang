<!-- 功能模块 -->
<template>
  <el-container style="background-color: #fff;">
    <div class="bigDog menuShrink black-tree">
      <PinDao once-title="资源结构"></PinDao>
      <el-tree :data="treeTable" :props="defaultProps" :check-strictly="true" :default-expand-all="true" :expand-on-click-node="false" :highlight-current="true" @node-click="handleNodeClick" accordion>
        <span class="custom-tree-node" slot-scope="{ node, data }">
          <span class="treeSpan" :dataType="data.type">
            <img src="../../assets/hurdle/hurdleNew.png" alt="">
            {{ node.label }}
          </span>
        </span>
      </el-tree>
    </div>
    <el-main style="padding:0;">
      <el-header class="menuHeaderTop" style="padding:0;height:30px;">
        <img src="../../assets/home/childrenHurdle.png" alt="">
        子资源列表
      </el-header>
      <div class="contentPadding tableShrink">
        <!--新增，编辑，删除-->
        <div class="headerBtn">
          <span @click="openAdd"><img src="../../assets/hurdle/hurdleAdd.png" alt="">新增</span>
          <span @click="openDetail"><img src="../../assets/hurdle/hurdleAudit.png" alt="">编辑</span>
          <span @click="openDel"><img src="../../assets/hurdle/hurdleDelete.png" alt="">删除</span>
        </div>
        <!-- 表格 -->
        <div class="all-Table">
          <el-table :data="tableData" stripe border @selection-change="handleSelectionChange" style="width: 100%">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="resourceCode" label="资源编号">
            </el-table-column>
            <el-table-column prop="resourceName" label="资源名称">
            </el-table-column>
            <el-table-column prop="resourceType" label="资源类型">
              <template slot-scope="scope">
                <span v-if="scope.row.resourceType == 1">模块组别</span>
                <span v-if="scope.row.resourceType == 2">功能模块</span>
                <span v-if="scope.row.resourceType == 3">功能按钮</span>
              </template>
            </el-table-column>
            <el-table-column prop="resourceActType" label="操作类型">
              <template slot-scope="scope">
                <span v-if="scope.row.resourceActType == 1">打开子模块</span>
                <span v-if="scope.row.resourceActType == 2">浏览数据</span>
                <span v-if="scope.row.resourceActType == 3">增加数据</span>
                <span v-if="scope.row.resourceActType == 4">编辑数据</span>
                <span v-if="scope.row.resourceActType == 5">删除数据</span>
              </template>
            </el-table-column>
            <el-table-column prop="resourceSort" label="排序" width="100">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="funCurChange" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
          </el-pagination>
        </div>
      </div>
      <!-- 新增 -->
      <el-dialog :visible.sync="dialogAdd" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          资源信息新增
        </div>
        <el-form :model="paramsAdd" :rules="rulesAudit" ref="paramsAdd" label-width="140px" class="demo-ruleForm">
          <el-form-item label="资源编号：" prop="resourceCode">
            <el-input v-model="paramsAdd.resourceCode" maxlength="20"></el-input>
          </el-form-item>
          <el-form-item label="资源名称：" prop="resourceName">
            <el-input v-model="paramsAdd.resourceName" maxlength="20"></el-input>
          </el-form-item>
          <el-form-item label="资源类型：" prop="resourceType">
            <el-select v-model="paramsAdd.resourceType">
              <el-option v-for="item in typeArr" :label="item.name" :key="item.id" :value="item.id" placeholder="请选择"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="功能类型：" prop="resourceActType">
            <el-select v-model="paramsAdd.resourceActType">
              <el-option v-for="item in actTypeArr" :label="item.name" :key="item.id" :value="item.id" placeholder="请选择"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="排序：" prop="resourceSort">
            <el-input-number style="width: 100%" v-model="paramsAdd.resourceSort" controls-position="right" :min="1"></el-input-number>
          </el-form-item>
          <el-form-item label="资源访问URL：" prop="resourceUrl">
            <el-input v-model="paramsAdd.resourceUrl"></el-input>
          </el-form-item>
          <el-form-item label="图标：">
            <span :class="['icons-span', inputClass]"></span>
            <span class="icons-select" @click="addIcon"><img src="../../assets/system/selects.png" alt="" />选择</span>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="submitFormAdd">保存</el-button>
          <el-button @click="dialogAdd = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 编辑 -->
      <el-dialog :visible.sync="dialogDetail" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/hurdleDialogAdd.png" alt="">
          资源信息编辑
        </div>
        <el-form :model="paramsDetail" :rules="rulesAudit" ref="paramsDetail" label-width="140px" class="demo-ruleForm">
          <el-form-item label="资源编号：" prop="resourceCode">
            <el-input v-model="paramsDetail.resourceCode" disabled></el-input>
          </el-form-item>
          <el-form-item label="资源名称：" prop="resourceName">
            <el-input v-model="paramsDetail.resourceName" maxlength="20"></el-input>
          </el-form-item>
          <el-form-item label="资源类型：" prop="resourceType">
            <el-select v-model="paramsDetail.resourceType" @change="$forceUpdate()">
              <el-option v-for="item in typeArr" :label="item.name" :key="item.id" :value="item.id" placeholder="请选择"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="功能类型：" prop="resourceActType">
            <el-select v-model="paramsDetail.resourceActType" @change="$forceUpdate()">
              <el-option v-for="item in actTypeArr" :label="item.name" :key="item.id" :value="item.id" placeholder="请选择"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="排序：" prop="resourceSort">
            <el-input-number style="width: 100%" v-model="paramsDetail.resourceSort" controls-position="right" :min="1"></el-input-number>
          </el-form-item>
          <el-form-item label="资源访问URL：" prop="resourceUrl">
            <el-input v-model="paramsDetail.resourceUrl"></el-input>
          </el-form-item>
          <el-form-item label="图标：">
            <span :class="['icons-span', detailClass]"></span>
            <span class="icons-select" @click="detailIcon"><img src="../../assets/system/selects.png" alt="" />选择</span>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="submitDetail">保存</el-button>
          <el-button @click="dialogDetail = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 删除 -->
      <el-dialog :visible.sync="dialogDelete" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicDel.png" alt="">
          系统提示
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要删除此数据吗?</div>
          <div>注意：如果某项包含有子数据，则不能被删除</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
          <el-button type="primary" @click="submitDel">确定</el-button>
          <el-button @click="dialogDelete = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 选择图标弹框 -->
      <el-dialog :visible.sync="iconFlage" width="680px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/system/selects.png" alt="">
          图标(双击选择)
        </div>
        <div style="height: 400px">
          <div v-for="(item,index) in classArr" :key='index' @dblclick="doubleSubmit(item)" class="one-icon" :class="[{'hoverBg':index==bsColor},item]" @mouseover="bsColor=index" @mouseout="bsColor=-1">
          </div>
        </div>
      </el-dialog>
    </el-main>
  </el-container>
</template>
<script>
import qs from 'qs'
import axios from 'axios';
import { BASICURL, funTree, funList, funSave, funDetail, funDel } from '@/js/getData'
import PinDao from '../../components/menuChildren/pinDao'
export default {
  name: 'functionManage',
  components: {
    PinDao
  },
  data() {
    const validataZm = (rule, value, callback) => {
      let reg = /^[A-Za-z]{6,20}$/
      if (!reg.test(value)) {
        callback(new Error('请输入6到20位英文'))
      } else {
        callback()
      }
    }
    return {
      //图标名称
      cssName: "icon_add_01,icon_add_02,icon_arrow_01,icon_arrow_02,icon_arrow_03,icon_arrow_04,icon_arrow_05,icon_arrow_06,icon_attach,icon_attach_2,icon_book_01,icon_book_02,icon_book_03,icon_book_04,icon_cd_01,icon_cd_02,icon_close_01,icon_close_02,icon_clr_01,icon_clr_02,icon_computer_01,icon_computer_02,icon_computer_03,icon_copy_01,icon_cut_01,icon_data_01,icon_data_02,icon_data_04,icon_data_05,icon_data_06,icon_del_01,icon_del_02,icon_del_03,icon_del_06,icon_del_07,icon_del_08,icon_del_09,icon_del_10,icon_dlg_01,icon_dlg_02,icon_dlg_03,icon_dlg_04,icon_dlg_05,icon_dlg_06,icon_dos,icon_feed,icon_feed_ballon,icon_folder_01,icon_folder_02,icon_folder_03,icon_font_01,icon_font_02,icon_font_03,icon_font_04,icon_home_01,icon_home_02,icon_home_03,icon_horn_01,icon_horn_02,icon_horn_03,icon_horn_04,icon_key_01,icon_key_02,icon_key_03,icon_lock_01,icon_lock_02,icon_lock_03,icon_lock_04,icon_mail_01,icon_mail_02,icon_mail_03,icon_map,icon_mobile_01,icon_msg_01,icon_music_01,icon_music_02,icon_music_03,icon_music_04,icon_ok_01,icon_ok_02,icon_online,icon_online_gprs,icon_online_net,icon_other_001,icon_other_02,icon_other_03,icon_other_04,icon_other_05,icon_other_06,icon_other_07,icon_other_08,icon_other_09,icon_other_10,icon_other_11,icon_other_12,icon_other_13,icon_other_ad,icon_other_bell,icon_other_blank,icon_other_blue_rect_1,icon_other_blue_rect_2,icon_other_board,icon_other_connect,icon_other_disconnect,icon_other_filter,icon_other_heart,icon_other_help,icon_other_more,icon_other_org,icon_other_region,icon_other_stop,icon_other_tip,icon_other_usb,icon_other_zip,icon_outline,icon_paper_bag,icon_paste_plain,icon_paste_word,icon_person_01,icon_person_02,icon_person_03,icon_person_04,icon_person_05,icon_person_06,icon_person_07,icon_person_09,icon_play_01,icon_play_02,icon_play_03,icon_play_04,icon_play_05,icon_play_06,icon_play_07,icon_print_01,icon_print_02,icon_relaod_01,icon_reload_02,icon_reload_03,icon_reload_04,icon_rili_01,icon_rili_02,icon_rili_03,icon_rili_04,icon_rss_01,icon_rss_02,icon_save_00,icon_save_01,icon_save_02,icon_save_03,icon_screen_01,icon_screen_02,icon_screen_03,icon_screen_04,icon_screen_05,icon_screen_07,icon_search,icon_search_01,icon_set,icon_set_01,icon_set_02,icon_set_03,icon_set_04,icon_set_05,icon_set_06,icon_start_01,icon_start_02,icon_start_03,icon_sum_01,icon_sum_02,icon_sum_03,icon_sum_04,icon_sum_05,icon_table,icon_tag_01,icon_tag_02,icon_tag_03,icon_tel_01,icon_tel_02,icon_text_01,icon_text_02,icon_text_03,icon_text_04,icon_text_05,icon_text_16,icon_timer_01,icon_timer_02,icon_timer_03,icon_timer_04,icon_videos_04,icon_video_02,icon_video_03,icon_warn_01,icon_warn_02,icon_warn_03,icon_world,icon_world_01,icon_world_02,icon_world_03",
      classArr: [],
      inputClass: '',
      detailClass: '',
      bsColor: -1,
      params: {
        total: null,
        rows: 10,
        page: 1
      },
      iconFlage: false,
      onceTable: [],
      tableData: [],
      typeArr: [
        { id: 1, name: '模块组别' },
        { id: 2, name: '功能模块' },
        { id: 3, name: '功能按钮' },
      ],
      actTypeArr: [
        { id: 1, name: '打开子模块' },
        { id: 2, name: '浏览数据' },
        { id: 3, name: '增加数据' },
        { id: 4, name: '编辑数据' },
        { id: 5, name: '删除数据' },
      ],
      paramsAdd: {},
      dialogDetail: false,
      paramsDetail: {},
      dialogAdd: false,
      openOne: '',
      rulesAudit: {
        resourceCode: [{ required: true, message: '资源编号不能为空！', trigger: 'blur' },
          { validator: validataZm, trigger: 'blur' }
        ],
        resourceName: [
          { required: true, message: '资源名称不能为空！', trigger: 'blur' }
        ],
        resourceType: [{ required: true, message: '请选择资源类型！', trigger: 'change' }],
        resourceActType: [{ required: true, message: '请选择功能类型！', trigger: 'change' }],
        resourceUrl: [{ required: true, message: '资源访问URL不能为空！', trigger: 'blur' }],
        resourceSort: [{ required: true, message: '排序不能为空！', trigger: 'blur' }]
      },
      treeTable: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      leftClick: {},
      dialogDelete: false,
      addFlag:false,
    }
  },
  methods: {
    //左侧增加子树
    append(data) {
      let treeOption = BASICURL + '/gdda-new/sysmng/resource/listTreeJson?resourceSysFlag=03&resourceParentId=' + data.id + '&tm=' + Date.now();
      let formData = new FormData()
      formData.append('id', data.id)
      axios({
        url: treeOption,
        method: 'post',
        data: formData
      }).then((res) => {
        if (res.data.code == 0) {
          if (!data.children) {
            this.$set(data, 'children', []);
          }
          data.children = res.data.data;
        } else this.$message.error(res.data.message);
      })
    },
    //左侧数
    showTree() {
      funTree().then(res => {
        this.treeTable = res.data
      })
    },
    //左侧数点击
    handleNodeClick(val) {
      this.addFlag = true;
      this.leftClick = {};
      this.params = {
        page: 1,
        rows: 10,
        total: null,
        tm: Date.now(),
        resourceParentId: val.id
      };
      this.leftClick = val;
      this.append(val);
      this.oneSearch()

    },
   //右侧列表
    oneSearch(){
      this.params.page = 1;
      this.searchList();
    },
    searchList() {
      funList(this.params).then(res => {
        if (res.code == 0) {
          this.tableData = res.data.rows
          this.params.total = res.data.total
        } else this.$message.error(res.message)
      })
    },
    funCurChange(val) {
      this.params.page = val;
      this.searchList();
    },
    //新增或者修改 选择图标
    doubleSubmit(val) {
      if (this.openOne === 'add') {
        this.inputClass = val;
        this.paramsAdd.resourceIcon = val;
      }
      if (this.openOne === 'detail') {
        this.detailClass = val;
        this.paramsDetail.resourceIcon = val;
      }
      this.iconFlage = false;
    },
    //新增
    openAdd() {
      if (this.addFlag) {
        this.paramsAdd = {
          resourceParentId: this.leftClick.id,
          resourceSort: 1
        };
        this.dialogAdd = true;
        this.inputClass = '';
        if (this.$refs['paramsAdd']) {
          this.$nextTick(() => {
            this.$refs['paramsAdd'].clearValidate();
          })
        }
      } else {
        this.$message.error("请你先在资源树中选中一项作为上级资源！")
      }
    },
    handleSelectionChange(val) {
      this.onceTable = val
    },
    addIcon() {
      this.iconFlage = true;
      this.openOne = 'add';
      this.bsColor = -1;
    },
    submitFormAdd() {
      this.$refs['paramsAdd'].validate((valid) => {
        if (valid) {
          funSave(this.paramsAdd).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message)
              this.dialogAdd = false
              this.oneSearch();
              this.append(this.leftClick)
            } else {
              this.$message.error(res.message)
            }
          })
        }
      })
    },
    //编辑
    openDetail() {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.onceTable.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        this.detailClass = '';
        this.paramsDetail = {};
        this.getDetail();
        this.dialogDetail = true;
        if (this.$refs['paramsDetail']) {
          this.$nextTick(() => {
            this.$refs['paramsDetail'].clearValidate();
          })
        }
      }
    },
    //编辑获取详情
    getDetail() {
      let id = this.onceTable[0].id;
      funDetail({ id: id }).then(res => {
        if (res.code == 0) {
          this.paramsDetail = res.data;
          this.detailClass = res.data.resourceIcon;
        } else this.$message.error(res.message)
      })
    },
    detailIcon() {
      this.iconFlage = true;
      this.openOne = 'detail';
      this.bsColor = -1;
    },
    //点击编辑
    submitDetail() {
      this.$refs['paramsDetail'].validate((valid) => {
        if (valid) {
          funSave(this.paramsDetail).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message)
              this.dialogDetail = false;
              this.oneSearch();
            } else {
              this.$message.error(res.message)
            }
          })
        }
      })
    },
    //删除
    openDel() {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else {
        this.dialogDelete = true;
      }
    },
    //提交删除
    submitDel() {
      let ids = [];
      this.onceTable.forEach(item => {
        ids.push(item.id)
      });
      funDel({ ids: ids.join(',') }).then(res => {
        if (res.code == 0) {
          this.dialogDelete = false;
          this.oneSearch();
          this.append(this.leftClick)
        } else {
          this.$message.error(res.message)
        }
      })
    },
  },
  created() {
    this.showTree();
    this.classArr = this.cssName.split(",")
  }
}

</script>
<style scoped lang="less">
@import "../../css/public";
@import "../../css/icon_001";

.one-icon {
  width: 20px;
  height: 20px;
  border: 1px solid #CCC;
  float: left;
  margin: 5px;
  display: inline-block;
  cursor: pointer;
}

.hoverBg {
  border: 1px solid red;
}

.icons-span {
  width: 45px;
  height: 38px;
  line-height: 38px;
  display: inline-block;
  border: 1px solid rgb(204, 204, 204);
  float: left;
  border-radius: 4px;
  border: 1px solid #DCDFE6;
}

.icons-select {
  display: inline-block;
  width: 60px;
  height: 40px;
  line-height: 40px;
  background-color: rgb(0, 103, 173);
  text-align: center;
  color: #fff;

  img {
    margin-right: 3px;
    vertical-align: middle;
    margin-top: -4px;
  }
}

.headerBtn {
  margin-bottom: 10px;

  span {
    display: inline-block;
    /*width: 100px;*/
    font-size: 12px;
    color: #282828;
    cursor: pointer;
    margin-right: 20px;

    img {
      vertical-align: middle;
      margin-right: 4px;
    }
  }
}

.el-dialog {
  .el-select {
    width: 100%;
  }
}

.dialog-title {
  background-color: #0067AD;

  img {
    vertical-align: middle;
  }
}

.dialogAddList {
  float: left;
  width: 49%;
  border: 1px solid;
  margin: 0 4px;
  padding: 0 4px;
  box-sizing: border-box;
  min-height: 600px;
  max-height: 600px;
  overflow: auto;

  p {
    display: inline-block;
    width: 90px;
  }

  img {
    vertical-align: middle;
  }

  .searchInput {
    width: 308px;
    margin: 8px 0;

    .el-input {
      width: 50%;

      input {
        border-radius: 0 !important;
      }
    }

    /*.el-select{*/
    /*width: 66%;*/
    /*}*/
    .searchBtn {
      float: right;
      width: 80px;
      text-align: center;
      height: 40px;
      line-height: 40px;
      color: #fff;
      background-color: #0067AD;

      img {
        margin-right: 5px;
        vertical-align: middle;
      }
    }
  }
}

</style>
