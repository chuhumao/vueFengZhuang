<!-- 缓存管理 -->
<template>
  <div>
    <div class="contentPadding" style="background-color: #fff">
      <!--新增，编辑，删除-->
      <div class="headerBtn">
        <span @click="openAdd"><img src="../../assets/system/p1.png" alt="">新增</span>
        <span @click="openDetail"><img src="../../assets/system/p2.png" alt="">编辑</span>
        <span @click="openDelete"><img src="../../assets/system/p3.png" alt="">删除</span>
        <span @click="updates"><img src="../../assets/system/reset.png" alt="">更新缓存</span>
      </div>
      <!-- 表格 -->
      <div class='all-Table'>
        <el-table :data="tableData" ref="cacheTable" stripe border @selection-change="handleSelectionChange" style="width: 100%">
          <el-table-column type="selection" width="55">
          </el-table-column>
          <el-table-column prop="COperName" label="主机名">
          </el-table-column>
          <el-table-column prop="COperNote" label="简介">
          </el-table-column>
          <el-table-column prop="COperDate" label="创建日期">
          </el-table-column>
          <el-table-column prop="CUrl" label="地址">
          </el-table-column>
        </el-table>
      </div>
      <!-- 分页 -->
      <div class="pageLayout">
        <el-pagination @current-change="currChange" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.totals">
        </el-pagination>
      </div>
    </div>
    <!-- 新增弹框 -->
    <el-dialog :visible.sync="dialogAdd" width="444px" class="hurdleAll spicial-add">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/roleAdd.png" alt="">
        新增
      </div>
      <el-form :model="paramsAdd" :rules="rulesAudit" ref="paramsAdd" label-width="120px" class="demo-ruleForm">
        <el-form-item label="名称：" prop="COperName">
          <el-input v-model="paramsAdd.COperName"></el-input>
        </el-form-item>
        <el-form-item label="地址：" prop="CUrl">
          <el-input v-model="paramsAdd.CUrl"></el-input>
        </el-form-item>
        <el-form-item label="备注：" prop="COperNote">
          <el-input v-model="paramsAdd.COperNote" type="textarea"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="submitAdd">保存</el-button>
        <el-button @click="dialogAdd = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 修改弹框 -->
    <el-dialog :visible.sync="dialogDetail" width="444px" class="hurdleAll spicial-add">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/roleAdd.png" alt="">
        编辑
      </div>
      <el-form :model="paramsDetail" :rules="rulesAudit" ref="paramsDetail" label-width="120px" class="demo-ruleForm">
        <el-form-item label="名称：" prop="COperName">
          <el-input v-model="paramsDetail.COperName"></el-input>
        </el-form-item>
        <el-form-item label="地址：" prop="CUrl">
          <el-input v-model="paramsDetail.CUrl"></el-input>
        </el-form-item>
        <el-form-item label="备注：" prop="COperNote">
          <el-input v-model="paramsDetail.COperNote" type="textarea"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="submitDetail">保存</el-button>
        <el-button @click="dialogDetail = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 删除弹框 -->
    <el-dialog :visible.sync="dialogDelete" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicDel.png" alt="">
        删除确认
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要删除吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="clickDelete">确定</el-button>
        <el-button @click="dialogDelete = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 更新缓存--确定缓存 -->
    <el-dialog :visible.sync="updateFlage1" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/u5.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <div>确定要更新缓存吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="getUpdate">确定</el-button>
        <el-button @click="updateFlage1 = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 更新缓存--成功 -->
    <el-dialog :visible.sync="updateFlage" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/u5.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/system/u6.png" alt="">
        <div>更新成功</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
        <el-button type="primary" @click="updateFlage = false">确定</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { cacheList, cacheSave, cacheDetail, cacheUpdate, cacheDel } from '@/js/getData';
export default {
  name: 'cacheManage',
  data() {
    return {
      params: {
        totals: null,
        rows: 13,
        page: 1,
      },
      dialogAdd: false,
      paramsAdd: {},
      dialogDetail: false,
      paramsDetail: {},
      dialogDelete: false,
      onceTable: [],
      tableData: [],
      paramsEdit: {},
      dialogEdit: false,
      rulesAudit: {
        COperName: [
          { required: true, message: '名称不能为空！', trigger: 'blur' },
        ],
        CUrl: [
          { required: true, message: '地址不能为空！', trigger: 'blur' },
        ],
        COperNote: [
          { required: true, message: '备注不能为空！', trigger: 'blur' },
        ]
      },
      updateFlage: false,
      updateFlage1: false,
      cacheIds: [],
    }
  },
  methods: {
    //查询缓存列表
    searchList() {
      cacheList(this.params).then(res => {
        if (res.code == 0) {
          this.tableData = res.data.rows;
          this.params.totals = res.data.total;
        } else this.$message.error(res.message);
      })
    },
    // 列表单页面点击
    currChange(val) {
      this.params.page = val;
      this.searchList();
    },
    //查询--每次从第一页查询
    oneSearch() {
      this.params.page = 1;
      this.searchList();
    },
    handleSelectionChange(val) {
      this.onceTable = [];
      this.onceTable = val
    },
    //打开角色新增
    openAdd() {
      this.paramsAdd = {};
      this.dialogAdd = true;
      if (this.$refs['paramsAdd']) {
        this.$nextTick(() => {
          this.$refs['paramsAdd'].clearValidate();
        })
      }
    },
    //角色新增
    submitAdd() {
      this.$refs['paramsAdd'].validate((valid) => {
        if (valid) {
          cacheSave(this.paramsAdd).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message);
              this.dialogAdd = false;
              this.oneSearch();
            } else this.$message.error(res.message);
          })
        }
      })
    },
    //缓存详情
    getDetail() {
      let id = this.onceTable[0].CId
      cacheDetail({ CId: id }).then(res => {
        if (res.code == 0) {
          this.paramsDetail = res.data;
          console.log(res.data);
        } else this.$message.error(res.message);
      })
    },
    openDetail() {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else if (this.onceTable.length > 1) {
        this.$message.error('只能选择一条数据')
      } else {
        this.getDetail();
        this.dialogDetail = true;
        if (this.$refs['paramsDetail']) {
          this.$nextTick(() => {
            this.$refs['paramsDetail'].clearValidate();
          })
        }
      }
    },
    submitDetail() {
      this.$refs['paramsDetail'].validate((valid) => {
        if (valid) {
          cacheSave(this.paramsDetail).then(res => {
            if (res.code == 0) {
              this.$message.success(res.message);
              this.dialogDetail = false;
              this.oneSearch();
            } else this.$message.error(res.message);
          })
        }
      })
    },
    //更新缓存--全选
    updates() {
      this.cacheIds = [];
      let dataArr = this.tableData || [];
      //默认全选
      this.$nextTick(() => {
        for (let i = 0; i < dataArr.length; i++) {
          this.$refs.cacheTable.toggleRowSelection(
            dataArr[i],
            true
          );
          this.cacheIds.push(dataArr[i].CId)
        }
      });
      this.updateFlage1 = true;
    },
    getUpdate() {
      cacheUpdate({ CIds: this.cacheIds.join(',') }).then(res => {
        if (res.code == 0) {
          this.updateFlage1 = false;
          this.updateFlage = true;
          this.oneSearch();
        } else this.$message.error(res.message)
      })
    },
    //缓存删除
    openDelete() {
      if (this.onceTable.length <= 0) {
        this.$message.error('请选择一条数据')
      } else {
        this.dialogDelete = true;
      }
    },
    clickDelete() {
      let ids = [];
      this.onceTable.forEach(item => {
        ids.push(item.CId)
      });
      cacheDel({ CIds: ids.join(',') }).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.dialogDelete = false;
          this.oneSearch();
        } else this.$message.error(res.message);
      })
    },

  },
  created() {
    this.searchList();
  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.general {
  clear: both;
  height: 500px;
  margin-top: -30px;

  .general-left {
    width: 30%;
    float: left;
    padding-top: 20px
  }

  .general-right {
    padding-top: 20px;
    width: 68%;
    float: left;
    border-left: 3px solid #1982BF;
    height: 500px;
    padding-left: 6px;
  }
}

.user-head {
  margin-top: 10px;
  margin-left: 9px;
}

.user-search {
  width: 57px;
  background: #0067AD;
  height: 28px;
  line-height: 42px;
  margin-left: -2px;
  border-radius: 4px;
  color: #fff !important;

  img {
    margin-top: -2px;
    margin-left: 5px;
    margin-right: 2px !important;
  }
}

.user-title {
  color: #fff;
  padding-left: 10px;

  img {
    float: right;
    margin-top: 6px;
  }
}

.user-content {
  height: 400px;
  margin-top: -24px;
  margin-left: -14px;
  margin-right: -14px;

  .user-left {
    width: 60%;
    float: left;
  }

  .user-right {
    width: 39.6%;
    display: inline-block;
    margin-left: 4px;
  }
}

.dia-radio {
  label {
    width: 100px;
  }
}

.see {
  width: 100%;
  clear: both;
  height: 500px;

  .see-left {
    width: 40%;
    float: left;
  }

  .see-right {
    width: 59%;
    float: left;
    border-left: 3px solid #1982BF;
    height: 500px;
  }
}

.input-uploads {
  .el-input {
    width: 70%;
  }

  .upload-show {
    display: inline-block;

    .el-button--primary {
      height: 36px;
      background: #0067AD;
      border-color: #0067AD;
    }
  }
}

.mt-31 {
  margin-top: -31px;
}

.table-botton {
  width: 80%;
  background: #08A9E6;
  color: #fff;
}

.headerBtn {
  margin-bottom: 10px;

  span {
    display: inline-block;
    font-size: 12px;
    color: #282828;
    margin-right: 12px;
    cursor: pointer;
    padding-bottom: 10px;

    img {
      vertical-align: middle;
      margin-right: 4px;
    }
  }

  .search-select {
    label {
      font-size: 14px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 143px;
    }

  }
}

.el-dialog {
  .el-select {
    width: 100%;
  }
}

.dialog-title {
  background-color: #0067AD;

  img {
    vertical-align: middle;
  }
}

/deep/.hurdleAll>div>div:first-child {
  padding: 0 !important;

  >div {
    height: 30px;
    line-height: 30px;
    text-indent: 10px;
    font-size: 14px;
    color: #fff;
  }

  button {
    top: 8px;

    i {
      color: #fff;
    }
  }
}

</style>
