<!-- 待确认 -->
<template>
  <div>
    <div class="contentPadding doc-main">
      <div class="headerBtn mb-20">
        <span class="search-doc">
          <label>全宗：</label>
          <el-select v-model="params.fonds" @change="changeFonds">
            <el-option v-for="item in fonds" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc">
          <label>类型：</label>
          <el-select v-model="params.series1" @change="changeOne">
            <el-option v-for="item in oneType" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc">
          <el-select v-model="params.series2" @change="changeTwo">
            <el-option v-for="item in twoType" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc">
          <el-select v-model="params.series3" @change="changeThree">
            <el-option v-for="item in threeType" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
      </div>
      <div v-show="showFlag">
        <div class="headerBtn mb-20">
          <span @click="openCom"><img src="../../assets/confirmed/a2.png" alt="">确认</span>
          <span @click="openAgain"><img src="../../assets/confirmed/a7.png" alt="">重发归档确认代办</span>
          <span @click="openSea"><img src="../../assets/system/p8.png" alt="">检索</span>
          <span @click="openEnd"><img src="../../assets/confirmed/a8.png" alt="">归档</span>
          <span @click="openUndo"><img src="../../assets/confirmed/a9.png" alt="">撤销归档确认代办</span>
        </div>
        <!-- 表格 -->
        <div class='all-Table'>
          <el-table :data="ageData" stripe border @selection-change="ageSelect">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="itemNo" label="件号" width="80px">
            </el-table-column>
            <el-table-column prop="fileCode" label="文号" width="180px">
            </el-table-column>
            <el-table-column prop="titleProper" label="题名" width="300px">
            </el-table-column>
            <el-table-column prop="retentionPeriod" label="保管期限" width="80px">
              <template slot-scope="scope">
                {{retArr[scope.row.retentionPeriod]}}
              </template>
            </el-table-column>
            <el-table-column prop="openingType" label="公开属性" width="80px">
              <template slot-scope="scope">
                {{openArr[scope.row.openingType]}}
              </template>
            </el-table-column>
            <el-table-column prop="dateOfCreation" label="文件日期" width="100px">
            </el-table-column>
            <el-table-column prop="yearCode" label="年度" width="80px">
            </el-table-column>
            <el-table-column prop="seriesCode" label="分类号" width="80px">
            </el-table-column>
            <el-table-column prop="c58" label="是否为原件" width="100px">
              <template slot-scope="scope">
                {{isArr[scope.row.c58]}}
              </template>
            </el-table-column>
            <el-table-column prop="filingDept" label="归档部门" width="120px">
            </el-table-column>
            <el-table-column prop="c8" label="备注" width="80px">
            </el-table-column>
            <el-table-column prop="c100" label="文件类型" width="80px">
            </el-table-column>
            <el-table-column prop="c92" label="来文系统" width="80px">
            </el-table-column>
            <el-table-column prop="c117" label="合同号" width="100px">
            </el-table-column>
            <el-table-column prop="c89" label="拟稿人" width="80px">
            </el-table-column>
            <el-table-column label="操作" align="center" width="146px">
              <template slot-scope="scope">
                <el-button size="mini" class="table-botton" @click="openDetail(scope.row)">查看
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="ageChange" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
          </el-pagination>
        </div>
      </div>
      <!-- 重发档案确认弹窗 -->
      <el-dialog :visible.sync="againFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle2.png" alt="">
          重发代办确认
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要重发代办吗?</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-18">
          <el-button type="primary" @click="clickAgain">确定</el-button>
          <el-button @click="againFlag = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 检索弹框 -->
      <el-dialog :visible.sync="seaFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/searchBtn.png" alt="">
          检索
        </div>
        <el-form :model="paramsSea" label-width="120px" style="height: 419px;overflow-y: auto;">
          <el-form-item label="题名：">
            <el-input v-model="paramsSea.titleProper"></el-input>
          </el-form-item>
          <el-form-item label="年度：">
            <el-input v-model="paramsSea.yearCode"></el-input>
          </el-form-item>
          <el-form-item label="文号：">
            <el-input v-model="paramsSea.fileCode"></el-input>
          </el-form-item>
          <el-form-item label="合同号：">
            <el-input v-model="paramsSea.c117"></el-input>
          </el-form-item>
          <el-form-item label="责任者：">
            <el-input v-model="paramsSea.c113"></el-input>
          </el-form-item>
          <el-form-item label="来文系统：">
            <el-input v-model="paramsSea.c92"></el-input>
          </el-form-item>
          <el-form-item label="归档部门：">
            <el-select v-model="paramsSea.filingDept" class="w-100" filterable @change="changefili">
              <el-option v-for="item in deptArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="归档人：">
            <el-select v-model="paramsSea.filingUser" class="w-100" filterable :filter-method="getUser" @change="$forceUpdate()">
              <el-option v-for="item in userArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="拟稿部门：">
            <el-select v-model="paramsSea.c90" class="w-100" filterable @change="changeUser">
              <el-option v-for="item in deptArr1" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="拟稿人：">
            <el-select v-model="paramsSea.c89" class="w-100" filterable :filter-method="getUser1" @change="$forceUpdate()">
              <el-option v-for="item in userArr1" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="文件类型：">
            <el-select v-model="paramsSea.c100" class="w-100" filterable>
              <el-option v-for="item in fileArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="盖章类型：">
            <el-select v-model="paramsSea.c112" class="w-100" filterable>
              <el-option v-for="item in sealArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="文件日期：">
            <el-date-picker v-model="paramsSea.dateOfCreation" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" class="w-100">
            </el-date-picker>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="searchSea">检索</el-button>
          <el-button type="primary" @click="paramsSea ={}">重置条件</el-button>
          <el-button @click="seaFlag = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 归档弹窗 -->
      <el-dialog :visible.sync="endFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle2.png" alt="">
          归档确认
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要直接归档吗？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-18">
          <el-button type="primary" @click="clickEnd">确定</el-button>
          <el-button @click="endFlag = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 撤销归档弹窗 -->
      <el-dialog :visible.sync="undoFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle2.png" alt="">
          撤销待办确认
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要撤销该待办吗?</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-18">
          <el-button type="primary" @click="clickUndo">确定</el-button>
          <el-button @click="undoFlag = false">取消</el-button>
        </div>
      </el-dialog>
      <!--待确认的查看 -->
      <el-dialog :visible.sync="detailFlag" width="1100px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicShow.png" alt="">
          查看
        </div>
        <div>
          <!-- 表格 -->
          <div class="all-Table">
            <el-table :data="tableDetail" stripe border @selection-change="detailChange" class="w-100">
              <el-table-column type="selection" width="55">
              </el-table-column>
              <el-table-column prop="titleProper" label="材料名称">
              </el-table-column>
              <el-table-column prop="fileSize" label="大小">
              </el-table-column>
              <el-table-column prop="fileFormat" label="格式">
              </el-table-column>
              <el-table-column label="操作" align="center">
                <template slot-scope="scope">
                  <el-button size="mini" class="table-botton" @click="openSee(scope.row)">查看
                  </el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <!-- 分页 -->
          <div class="pageLayout">
            <el-pagination @current-change="detailCurrChange" :current-page="detailParams.page" :page-size="detailParams.rows" layout="prev, pager, next, jumper" :total="detailParams.totals">
            </el-pagination>
          </div>
        </div>
      </el-dialog>
      <!-- 查看中的详情 -->
      <el-dialog :visible.sync="seeFlag" width="1100px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicShow.png" alt="">
          查看材料
        </div>
        <div class="see">
          <div class="see-left">
            <el-tree class="filter-tree" :highlight-current="true" :expand-on-click-node="false" :data="dataShow" default-expand-all :props="defaultProps" @node-click="handleNodeClick">
            </el-tree>
          </div>
          <div class="see-right">
            <embed :src='showUrl' type="application/pdf" width="100%" height="100%">
          </div>
        </div>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="downSee" :disabled="clickFlag">下载</el-button>
          <el-button @click="seeFlag = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 该文件非PDF,是否需要进行下载(查看失败) -->
      <el-dialog :visible.sync="notShow1" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle1.png" alt="">
          下载确认
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/nShow1.png" alt="">
          <div>该文档非PDF文件，是否要进行下载？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="clickDown">确定</el-button>
          <el-button @click="notShow1 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 对不起，您访问的材料还未扫描。(查看失败) -->
      <el-dialog :visible.sync="notShow2" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle2.png" alt="">
          系统提示
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/nShow2.png" alt="">
          <div>对不起，您访问的材料还未扫描。</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="notShow2 = false">确定</el-button>
          <el-button @click="notShow2 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 确认按钮弹框 -->
      <el-dialog :visible.sync="comFlag" width="1100px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/confirmed/a10.png" alt="" />
          归档确认
        </div>
        <div>
          <!-- form表单详情 -->
          <div>
            <el-form :model="comParams" label-width="120px" ref="comParams">
              <el-form-item label="题名：">
                <el-input v-model="comParams.titleProper"></el-input>
              </el-form-item>
              <el-row :gutter="20">
                <el-col :span="12">
                  <el-form-item label="类型：">
                    <el-input v-model="comParams.c1001"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="12">
                  <el-form-item label="文件日期：">
                    <el-date-picker v-model="comParams.dateOfCreation" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" class="w-100">
                    </el-date-picker>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row :gutter="20">
                <el-col :span="12">
                  <el-form-item label="拟稿人：">
                    <el-input v-model="comParams.c89"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="12">
                  <el-form-item label="拟稿部门：">
                    <el-input v-model="comParams.c90"></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
            </el-form>
          </div>
          <!-- table操作 -->
          <div>
            <!-- 表格 -->
            <div class="headerBtn mb-20">
              <span @click="openListSee"><img src="../../assets/confirmed/a4.png" alt="">查看</span>
              <span @click="openFindDel"><img src="../../assets/home/g5.png" alt="">删除</span>
            </div>
            <div class="all-Table">
              <el-table :data="tableCom" stripe border @selection-change="comChange" class="w-100">
                <el-table-column type="selection" width="55">
                </el-table-column>
                <el-table-column prop="titleProper" label="附件列表">
                </el-table-column>
                <el-table-column prop="fileSize" label="文件大小">
                </el-table-column>
                <el-table-column prop="fileFormat" label="文件格式">
                </el-table-column>
              </el-table>
            </div>
            <!-- 分页 -->
            <div class="pageLayout">
              <el-pagination @current-change="comCurrChange" :current-page="comParams1.page" :page-size="comParams1.rows" layout="prev, pager, next, jumper" :total="comParams1.total">
              </el-pagination>
            </div>
          </div>
          <div>
            <p>确认事项:</p>
            <p class="ml-61">本流程相关电子文件已全部上传、内容完整且为终版
              <el-radio-group v-model="radio1" @change="initRadio2" class="ml-75">
                <el-radio :label="1">是</el-radio>
                <el-radio :label="0">否</el-radio>
              </el-radio-group>
            </p>
            <p class="ml-61">本流程存在应归档纸质文件（盖章、签名等），待移交
              <el-radio-group v-model="radio2" class="ml-62" :disabled="radioFlag">
                <el-radio :label="1">是</el-radio>
                <el-radio :label="0">否</el-radio>
              </el-radio-group>
            </p>
          </div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <span class="con-show">疑问咨询：张晓瑛 020-66336359</span>
          <el-button v-show="!showSave" type="primary" @click="openUpload">上传</el-button>
          <el-button v-show="showSave" type="primary" @click="saveClick">确定</el-button>
          <el-button @click="comFlag = false">暂不确认</el-button>
        </div>
      </el-dialog>
      <!-- 确认按钮--列表查看非PDF弹框 -->
      <el-dialog :visible.sync="newDownFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle1.png" alt="">
          下载确认
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/nShow1.png" alt="">
          <div>该文档非PDF文件，是否要进行下载？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="comSee">确定</el-button>
          <el-button @click="newDownFlag = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 确认按钮--列表查看PDF文件 -->
      <el-dialog :visible.sync="seePdfFlag" width="900px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicShow.png" alt="">
          查看材料
        </div>
        <div class="con-em">
          <embed :src='seePdf' type="application/pdf" width="100%" height="100%">
        </div>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="seeDown">下载</el-button>
          <el-button @click="seePdfFlag = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 确认按钮--列表删除按钮-->
      <el-dialog :visible.sync="delFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle2.png" alt="">
          删除附件确认
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要删除此附件吗?</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-18">
          <el-button type="primary" @click="clickDel">确定</el-button>
          <el-button @click="delFlag = false">取消</el-button>
        </div>
      </el-dialog>
      <!--确认弹框上传 -->
      <el-dialog :visible.sync="uploadMapFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/home/map2.png" alt="">
          文件上传
        </div>
        <div class="map-upload">
          上传 <el-upload class="map-demo" ref="upload" action="#" :on-remove="handleRemove" :before-remove="beforeRemove" :auto-upload="false" :on-change="handleChange">
            <el-button size="small" type="primary">上传</el-button>
          </el-upload>
        </div>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="saveUploadMap">保存</el-button>
          <el-button @click="resetUploadMap">取消</el-button>
        </div>
      </el-dialog>
      <!--确定前弹框-->
      <el-dialog :visible.sync="saveFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle2.png" alt="">
          提交确认
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>{{titleSave}}</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-18">
          <el-button type="primary" @click="clickSave">确定</el-button>
          <el-button @click="saveFlag = false">取消</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import qs from 'qs'
import axios from 'axios';
import { confirmList, getFonds, getAndRole, getIdList, conDept, conUser, confile, conSeal, confirmDoc, conLeft, seeConLeft, conLeft1, conCheckUser, BASICURL, sendGdOA, gdEnd, undoGd, checkFile, getArchDetail, listGdQrData, saveGdQr, findCom, findComDel, cleanAccept, findComUpload } from '@/js/getData';
import { valueIndex } from '@/js/transitionText'
export default {
  name: 'confirm',
  data() {
    return {
      clickFlag: true,
      params: {
        page: 1,
        rows: 10,
        total: null,
        c0: 2,
        type: 1
      },
      fonds: [],
      oneType: [],
      twoType: [],
      threeType: [],
      ageData: [],
      retArr: ['', '短期', '长期', '永久', '', '10年', '15年', '', '30年'], //保管期限
      openArr: ['', '公开', '内部', '受控', '广发商密三级', '广发商密二级', '广发商密一级'], //公开属性
      isArr: ['是', '否'], //是否为原件
      showFlag: true,
      seaFlag: false,
      paramsSea: {},
      deptArr: [],
      deptArr1: [],
      userArr: [],
      userArr1: [],
      fileArr: [],
      sealArr: [],
      oneTable: [],
      tableDetail: [],
      detailFlag: false,
      dataShow: [],
      seeFlag: false,
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      detailParams: {
        totals: 0,
        rows: 8,
        page: 1
      },
      notShow1: false,
      notShow2: false,
      pdfId: null,
      showUrl: '',
      downName: '',
      detailArr: [],
      topicId: null,
      downId: null,
      againFlag: false,
      endFlag: false,
      undoFlag: false,
      comParams: {},
      comRules: [],
      tableCom: [],
      comParams1: {
        page: 1,
        rows: 5,
        total: null
      },
      comFlag: false,
      subCon: {},
      newSubId: null,
      comOne: [],
      newDownFlag: false,
      seePdfFlag: false,
      seePdf: null,
      delFlag: false,
      uploadMapFlag: false,
      fileList: [],
      radioFlag: true,
      radio1: null,
      radio2: null,
      showSave: false,
      saveFlag: false,
      titleSave: null,
      orgFlag1: null,
      orgFlag2: null,
    }
  },
  methods: {
    //获取全宗
    searchFond() {
      getFonds().then(res => {
        if (res.code == 0) {
          this.fonds = res.data;
          this.initFond();
        } else this.$message.error(res.message)
      })
    },
    //初始化选中全宗--原系统逻辑
    initFond(val) {
      if ("8106" == val) {
        this.params.fonds = 1463117877850; //广发乾和
      } else {
        this.params.fonds = 1374133141812 //新广发证券
      }
      this.fondsM();
    },
    //全宗方法
    fondsM() {
      this.searchType(this.params.fonds); //根据全宗获取类型
      this.initType();
    },
    //改变选中全宗
    changeFonds() {
      this.$forceUpdate();
      this.fondsM();
    },
    //根据全宗获取类型
    searchType(val) {
      getAndRole({ id: val }).then(res => {
        if (res.code == 0) {
          this.oneType = res.data;
        } else this.$message.error(res.message)
      })
    },
    //初始化选中分类1--原系统逻辑
    initType() {
      if (this.params.fonds == 1463117877850) {
        this.params.series1 = 1463318429461 //管理类档案
      } else if (this.params.fonds == 1374133141812) {
        this.params.series1 = 1379482316593 //管理类案件(按件)
      } else {
        this.params.series1 = null;
      }
      this.params.series2 = null;
      this.params.series3 = null;
      this.searchType1(this.params.series1, 1);
      this.initList();
    },
    //改变第一个类型
    changeOne() {
      this.$forceUpdate();
      this.searchType1(this.params.series1, 1);
      this.initList();
      this.params.series2 = null;
      this.params.series3 = null;
    },
    //根据档案分类id获取分类2
    searchType1(val, val1) {
      getIdList({ id: val }).then(res => {
        if (res.code == 0) {
          if (val1 == 1) {
            this.twoType = res.data;
          } else this.threeType = res.data;
        } else this.$message.error(res.message)
      })
    },
    //改变第二个类型
    changeTwo() {
      this.$forceUpdate();
      this.searchType1(this.params.series2, 2);
      this.params.series3 = null;
      this.initList();
    },
    //改变第三个类型
    changeThree() {
      this.$forceUpdate();
      this.initList();
    },
    //初始化获取档案列表--原系统逻辑
    initList() {
      if (this.params.series1) {
        if (this.params.series1 == 1379482316593 || this.params.series1 == 1463318429461) { //管理类档案（按件）|| 管理类档案
          this.resetInit();
          this.searchOne();
          this.showFlag = true;
        } else this.showFlag = false;
      } else this.showFlag = false;
    },
    resetInit() {
      this.params.searchType = null;
      this.params.titleProper = null;
      this.params.yearCode = null;
      this.params.fileCode = null;
      this.params.c117 = null;
      this.params.c113 = null;
      this.params.c92 = null;
      this.params.filingDept = null;
      this.params.filingUser = null;
      this.params.c90 = null;
      this.params.c89 = null;
      this.params.c100 = null;
      this.params.c112 = null;
      this.params.dateOfCreation = null;
    },
    //获取档案列表
    searchOne() {
      this.params.page = 1;
      this.searchList();
    },
    searchList() {
      confirmList(this.params).then(res => {
        if (res.code == 0) {
          this.ageData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    ageChange(val) {
      this.params.page = val;
      this.searchList();
    },
    ageSelect(val) {
      this.oneTable = val;
    },
    //检索
    //检索--归档部门/拟稿部门下拉
    getDept() {
      conDept().then(res => {
        if (res.code == 0) {
          this.deptArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    changefili(val) {
      this.orgFlag1 = val;
      this.paramsSea.filingUser = null;
      this.userArr = [];
    },
    getDept1() {
      conDept().then(res => {
        if (res.code == 0) {
          this.deptArr1 = res.data;
        } else this.$message.error(res.message)
      })
    },
    changeUser(val) {
      this.orgFlag2 = val;
      this.paramsSea.c89 = null;
      this.userArr1 = [];
    },
    //检索--归档人/拟稿人下拉
    getUser(val) {
      let users = {
        q: val,
        orgFlag1: this.orgFlag1 || -10000
      }
      conUser(users).then(res => {
        if (res.code == 0) {
          this.userArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    getUser1(val) {
      let users = {
        q: val,
        orgFlag1: this.orgFlag2 || -10000
      }
      conUser(users).then(res => {
        if (res.code == 0) {
          this.userArr1 = res.data;
        }
      })
    },
    //检索--文件下拉
    getFile() {
      confile().then(res => {
        if (res.code == 0) {
          this.fileArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //检索--盖章类型
    getSeal() {
      conSeal().then(res => {
        if (res.code == 0) {
          this.sealArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    openSea() {
      this.getDept();
      this.getDept1();
      this.getFile();
      this.getSeal();
      this.orgFlag1 = null;
      this.orgFlag2 = null;
      this.seaFlag = true;
      this.paramsSea = {};
    },
    searchSea() {
      if (JSON.stringify(this.paramsSea) === '{}') {
        this.$message.error('请至少输入一项条件！')
      } else {
        this.resetInit();
        Object.assign(this.params, this.paramsSea);
        this.params.searchType = 1; //原系统逻辑
        this.searchOne();
        this.seaFlag = false;
      }
    },
    //查看
    openDetail(val) {
      this.topicId = this.detailParams.id = val.id;
      this.oneDetailSelect();
      this.detailFlag = true;
    },
    oneDetailSelect() {
      this.detailParams.page = 1;
      this.detailSelect();
    },
    detailSelect() {
      confirmDoc(this.detailParams).then(res => {
        if (res.code == 0) {
          this.tableDetail = res.data.rows;
          this.detailParams.totals = res.data.total;
        } else this.$message.error(res.message);
      })
    },
    detailCurrChange(val) {
      this.detailParams.page = val;
      this.detailSelect();
    },
    detailChange(val) {
      this.detailArr = val;
    },
    //查看详情
    openSee(val) {
      this.pdfId = val.id;
      this.dataShow = [];
      conCheckUser().then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 0) { //如果是档案管理员或者综合员
            this.seeTree1()
          } else {
            this.seeTree2()
          }
        } else this.$message.error(res.message);
      })
      this.seeFlag = true;
    },
    //详情树1
    seeTree1() {
      let seeParams = {
        id: this.topicId,
        bs: 'dbsb'
      }
      conLeft(seeParams).then(res => {
        if (res.code == 0) {
          this.dataShow = res.data;
        } else this.$message.error(res.message);
      })
    },
    //详情树2
    seeTree2() {
      let seeParams = {
        id: this.topicId,
        bs: 'dbsb'
      }
      conLeft1(seeParams).then(res => {
        if (res.code == 0) {
          this.dataShow = res.data;
        } else this.$message.error(res.message);
      })
    },
    handleNodeClick(val) {
      this.downName = val.text;
      this.showUrl = '';
      this.downId = val.id;
      seeConLeft({ id: val.id }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 2) { //页面会显示 该文件非PDF,是否需要进行下载
            this.clickFlag = true;
            this.notShow1 = true;
          } else if (res.data.optFlag == -1) { //会显示 对不起，你访问的文件还未扫描
            this.clickFlag = true;
            this.notShow2 = true;
          } else {
            this.clickFlag = false;
            this.showUrl = BASICURL + '/gdda-new/rewirte/gdda/archiveCleanUp/viewPdf?docId=' + val.id;
          }
        } else this.$message.error(res.message);
      })
    },
    //下载文件
    clickDown() {
      let ids = {
        id: this.downId,
        mode: 'dbsb'
      }
      valueIndex().exportFiles('/gdda-new/gdda/util/downLoadFile', ids, this.downName, 'get');
      this.notShow1 = false;
    },
    downSee() {
      let ids = { id: this.downId }
      valueIndex().exportFiles('/gdda-new/gdda/util/downLoadDetail', ids, this.downName, 'get');
    },
    //重发代办确认
    openAgain() {
      let open = this.$onceWay().onceTableList(this.oneTable);
      if (open == 1) {
        this.againFlag = true;
      }
    },
    clickAgain() {
      sendGdOA({ id: this.oneTable[0].id }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 0) {
            this.$message.success('发送成功');
            this.searchOne();
            this.againFlag = false;
          } else {
            this.$message.error('发送失败，因为：' + res.data.msg);
          }
        } else this.$message.error(res.message)
      })
    },
    //归档
    openEnd() {
      let open = this.$onceWay().onceTableList(this.oneTable);
      if (open == 1) {
        if (this.oneTable[0].c103 == 1) {
          this.$message.error('当前档案为外来文,无法进行当前操作!');
        } else {
          this.endFlag = true;
        }
      }
    },
    clickEnd() {
      gdEnd({ id: this.oneTable[0].id }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 1) {
            this.$message.success('归档成功');
            this.searchOne();
            this.endFlag = false;
          } else {
            this.$message.error('归档失败，因为' + res.data.msg);
          }
        } else this.$message.error(res.message)
      })
    },
    //撤销归档代办归档
    openUndo() {
      let open = this.$onceWay().onceTableList(this.oneTable);
      if (open == 1) {
        if (this.oneTable[0].c103 == 1) {
          this.$message.error('当前档案为外来文,无法进行当前操作!');
        } else {
          this.undoFlag = true;
        }
      }
    },
    clickUndo() {
      undoGd({ id: this.oneTable[0].id }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 1) {
            this.$message.success('撤销成功');
            this.searchOne();
            this.undoFlag = false;
          } else {
            this.$message.error('撤销失败，因为：' + res.data.msg);
          }
        } else this.$message.error(res.message)
      })
    },
    //确认按钮
    openCom() {
      let open = this.$onceWay().onceTableList(this.oneTable);
      if (open == 1) {
        this.beforeCom();
        this.radio1 = null;
        this.radio2 = null;
        this.radioFlag = true;
        this.showSave = false;
      }
    },
    //确认前判断是否有确认单
    beforeCom() {
      this.newSubId = null;
      checkFile({ fileId: this.oneTable[0].id }).then(res => {
        if (res.code == 0) {
          let flag1 = [];
          flag1 = res.data.flag.split(',')
          this.newSubId = flag1[1];
          if (flag1[0] == 0) { //存在确认单
            this.getComDetail();
            this.getComListOne();
            this.comFlag = true;
          } else if (flag1[0] == 1) { //已经确认
            this.$message.error('该档案本人已确认完毕，待他人确认完毕!')
          } else if (flag1[0] == 2) {
            this.$message.error('不是该文件确认人不能操作此文件!')
          }
        } else this.$message.error(res.message)

      })
    },
    //获取确认详情
    getComDetail() {
      getArchDetail({ subId: this.newSubId }).then(res => {
        if (res.code == 0) {
          this.comParams = res.data;
          this.comParams.c1001 = (this.comParams.c103 == 1 ? '外部' : '内部') + res.data.c100
        } else this.$message.error(res.message)
      })
    },
    //获取附件列表
    getComListOne() {
      this.comParams1.page = 1;
      this.getComList();
    },
    getComList() {
      this.comParams1.subId = this.newSubId;
      listGdQrData(this.comParams1).then(res => {
        if (res.code == 0) {
          this.tableCom = res.data.rows;
          this.comParams1.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    comChange(val) {
      this.comOne = val;
    },
    comCurrChange(val) {
      this.comParams1.page = val;
      this.getComList();
    },
    //附件列表打开查看按钮
    openListSee() {
      let open = this.$onceWay().onceTableList(this.comOne);
      if (open == 1) {
        let fileType = this.comOne[0].fileFormat;
        if (fileType == 'pdf' || fileType == 'PDF') { //PDF--查看预览样式
          this.acceptPDF();
        } else {
          this.newDownFlag = true;
        }
      }
    },
    //PDF是否存在
    acceptPDF() {
      this.seePdf = null;
      cleanAccept({ id: this.comOne[0].id }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 0) {
            this.seePdfFlag = true;
            this.seePdf = BASICURL + '/gdda-new/gdda/util/viewPdfForGd?docId=' + this.comOne[0].id;
          } else if (res.data.optFlag == -1) {
            this.$message.error('对不起，你访问的文件还未扫描!')
          }
        } else this.$message.error(res.message)
      })
    },
    //PDF下载
    seeDown() {
      let ids = { id: this.comOne[0].id }
      valueIndex().exportFiles('/gdda-new/gdda/util/downLoadDetail', ids, this.comOne[0].titleProper, 'get');
    },
    //附件列表--查看按钮
    comSee() {
      findCom({ id: this.comOne[0].id }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == -1) {
            this.$message.error('文件未找到，无法进行下载!')
          } else {
            let ids = { id: this.comOne[0].id }
            valueIndex().exportFiles('/gdda-new/gdda/util/downLoadDetail', ids, this.comOne[0].titleProper, 'get');
          }
        } else this.$message.error(res.message)
      })
    },
    //附件列表--删除按钮
    openFindDel() {
      let open = this.$onceWay().onceTableList(this.comOne);
      if (open == 1) {
        this.delFlag = true;
      }
    },
    clickDel() {
      findComDel({ id: this.comOne[0].id }).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message);
          this.delFlag = false;
          this.getComList();
        } else this.$message.error(res.message)
      })
    },
    //确定按钮--文件上传--多个上传
    handleRemove(file, fileList) {
      let index = -1;
      for (let i = 0; i < this.fileList.length; i++) {
        let item = this.fileList[i].path
        if (item.indexOf(file.name) >= 0) {
          index = i;
          break;
        }
      }
      this.fileList.splice(index, 1)
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${ file.name }？`);
    },
    //文件上传
    handleChange(file, fileList) {
      let formData = new FormData()
      formData.append('picture', file.raw)
      formData.append('type', 'gd')
      formData.append('name', 'file')
      axios({
        url: BASICURL + '/gdda-new/gdda/archiveYj/uploadPicture ',
        method: 'post',
        data: formData,
        header: {
          'Content-Type': 'multipart/form-data; boundary=----WebKitFormBoundaryymL45aau1VgXaJUp'
        }
      }).then((res) => {
        if (res.data.data.result == 1) {
          this.$message.success(res.data.message);
          this.fileList.push(res.data.data.pathAndMD5)
          /*     this.fileList.push(JSON.stringify(res.data.data.pathAndMD5))*/
        } else this.$message.error(res.data.data.msg);

      })
    },
    //归档地图文件--上传保存
    openUpload() {
      this.uploadMapFlag = true;
      this.fileList = [];
      if (this.$refs.upload) {
        this.$nextTick(() => {
          this.$refs.upload.clearFiles();
        })
      };
    },
    saveUploadMap() {
      if (this.fileList.length > 0) {
        let fileArr2 = [];
        this.fileList.forEach(item => {
          fileArr2.push(JSON.stringify(item))
        })
        let paramsLoad = {
          subId: this.comParams.id,
          imgVal: "[" + fileArr2.join(',') + "]"
        };
        findComUpload(paramsLoad).then(res => {
          if (res.code == 0) {
            this.$message.success(res.message);
            this.uploadMapFlag = false;
            this.getComList();
          } else this.$message.error(res.message)
        })
      } else this.$message.error("请上传图片!")

    },
    resetUploadMap() {
      this.fileList = [];
      this.uploadMapFlag = false;
    },
    initRadio2(val) {
      if (val == 1) {
        this.radioFlag = false;
        this.showSave = true;
      } else {
        this.radioFlag = true;
        this.showSave = false;
      }
      this.radio2 = null;
    },
    //确定按钮
    saveClick() {
      if (this.radio2 == null) {
        this.$message.error('请选择有无纸质移交');
      } else if (this.radio1 == 1) {
        if (this.radio2 == 1) {
          this.titleSave = '确定无误，请尽快移交纸质文件。';
        } else {
          this.titleSave = '确定无误（且无纸质文件移交）吗？';
        }
        this.saveFlag = true;
      }
    },
    clickSave() {
      let qrParams = {
        subId: this.newSubId,
        radio1: this.radio1,
        radio2: this.radio2
      }
      saveGdQr(qrParams).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == -1) {
            this.$message.error('提交失败，系统出错')
          } else {
            this.$message.success('提交成功')
            this.comFlag = false;
            this.saveFlag = false;
            this.searchOne();
          }
        } else this.$message.error(res.message)
      })
    }
  },
  created() {
    this.searchFond();
  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.ml-61 {
  margin-left: 61px
}

.ml-75 {
  margin-left: 75px;
}

.ml-62 {
  margin-left: 62px;
}

.con-show {
  position: absolute;
  left: 15px;
  font-size: 14px;
  bottom: 25px;
}

.con-em {
  width: 100%;
  height: 500px;
}

.see {
  width: 100%;
  clear: both;
  margin-top: -30px;
  height: 500px;

  .see-left {
    width: 40%;
    float: left;
    padding-top: 20px;
    overflow: auto;
    height: 100%;

    .filter-tree {
      display: inline-block;
    }
  }

  .see-right {
    width: 59%;
    height: 100%;
    padding-top: 20px;
    float: left;
    border-left: 3px solid #1982BF;
  }
}

.search-doc {
  margin-top: 10px;

  label {
    font-size: 14px;
    color: #282828;
    padding-right: 5px
  }

  .el-input,
  .el-select {
    width: 200px;
  }
}

.table-botton {
  width: 80%;
  background: #08A9E6;
  color: #fff;
}

.seeDoc {
  width: 100%;
  clear: both;
  height: 500px;

  .seeDoc-left {
    width: 20%;
    float: left;
  }

  .seeDoc-right {
    width: 79%;
    float: left;
    border-left: 3px solid #1982BF;
    height: 500px;
  }
}

.doc-car {
  background: url(../../assets/home/d2.png) no-repeat;
  position: fixed;
  width: 70px;
  height: 70px;
  right: 16px;
  bottom: 70px;
  z-index: 99999;
}

.doc-main {
  background-color: #fff;
  min-height: 700px;

  .mb-20 {

    margin-bottom: 20px;
  }

  .doc-down {
    font-size: 13px;
    color: #515BED;
    float: right;
  }

  .w-100 {
    width: 100%
  }

  .doc-doss {
    width: 100%;
    height: 500px;
    overflow: auto;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .mt-f18 {
    margin-top: -18px;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .lend-table {
    max-height: 200px;
    overflow-y: auto;
    width: 100%
  }
}

.map-upload {
  text-align: center;

  .map-demo {
    display: inline-block;
    margin-left: 6px;

    .el-button--primary {
      background-color: #0067AC;
      border-color: #0067AC;
      border-radius: 16px;
      width: 135px;
    }
  }

  .map-demo.el-upload-list {
    width: 200px !important;
  }
}

</style>
