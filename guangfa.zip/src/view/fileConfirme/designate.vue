<!-- 指定承办人 -->
<template>
  <div>
    <div class="contentPadding doc-main">
      <div class="headerBtn mb-20">
        <span class="search-doc">
          <label>全宗：</label>
          <el-select v-model="params.fonds" @change="changeFonds">
            <el-option v-for="item in fonds" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc">
          <label>类型：</label>
          <el-select v-model="params.series1" @change="changeOne">
            <el-option v-for="item in oneType" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc">
          <el-select v-model="params.series2" @change="changeTwo">
            <el-option v-for="item in twoType" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc">
          <el-select v-model="params.series3" @change="changeThree">
            <el-option v-for="item in threeType" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
      </div>
      <div v-show="showFlag">
        <div class="headerBtn mb-20">
          <span @click="openSea"><img src="../../assets/system/p8.png" alt="">检索</span>
          <span @click="openCon"><img src="../../assets/confirmed/a2.png" alt="">确认承办人</span>
        </div>
        <!-- 表格 -->
        <div class='all-Table'>
          <el-table :data="ageData" stripe border @selection-change="ageSelect">
            <el-table-column type="selection" width="55">
            </el-table-column>
            <el-table-column prop="itemNo" label="件号" width="80px">
            </el-table-column>
            <el-table-column prop="fileCode" label="文号" width="180px">
            </el-table-column>
            <el-table-column prop="titleProper" label="题名" width="300px">
            </el-table-column>
            <el-table-column prop="retentionPeriod" label="保管期限" width="80px">
              <template slot-scope="scope">
                {{retArr[scope.row.retentionPeriod]}}
              </template>
            </el-table-column>
            <el-table-column prop="openingType" label="公开属性" width="80px">
              <template slot-scope="scope">
                {{openArr[scope.row.openingType]}}
              </template>
            </el-table-column>
            <el-table-column prop="dateOfCreation" label="文件日期" width="100px">
            </el-table-column>
            <el-table-column prop="yearCode" label="年度" width="80px">
            </el-table-column>
            <el-table-column prop="seriesCode" label="分类号" width="80px">
            </el-table-column>
            <el-table-column prop="c58" label="是否为原件" width="100px">
              <template slot-scope="scope">
                {{isArr[scope.row.c58]}}
              </template>
            </el-table-column>
            <el-table-column prop="filingDept" label="归档部门" width="120px">
            </el-table-column>
            <el-table-column prop="c8" label="备注" width="80px">
            </el-table-column>
            <el-table-column prop="c100" label="文件类型" width="80px">
            </el-table-column>
            <el-table-column prop="c92" label="来文系统" width="80px">
            </el-table-column>
            <el-table-column prop="c117" label="合同号" width="100px">
            </el-table-column>
            <el-table-column prop="c89" label="拟稿人" width="80px">
            </el-table-column>
            <el-table-column label="操作" align="center" width="146px">
              <template slot-scope="scope">
                <el-button size="mini" class="table-botton" @click="openDetail(scope.row)">查看
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="ageChange" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
          </el-pagination>
        </div>
      </div>
      <!-- 检索弹框 -->
      <el-dialog :visible.sync="seaFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/searchBtn.png" alt="">
          检索
        </div>
        <el-form :model="paramsSea" label-width="120px" style="height: 419px;overflow-y: auto;">
          <el-form-item label="题名：">
            <el-input v-model="paramsSea.titleProper"></el-input>
          </el-form-item>
          <el-form-item label="年度：">
            <el-input v-model="paramsSea.yearCode"></el-input>
          </el-form-item>
          <el-form-item label="文号：">
            <el-input v-model="paramsSea.fileCode"></el-input>
          </el-form-item>
          <el-form-item label="合同号：">
            <el-input v-model="paramsSea.c117"></el-input>
          </el-form-item>
          <el-form-item label="责任者：">
            <el-input v-model="paramsSea.c113"></el-input>
          </el-form-item>
          <el-form-item label="来文系统：">
            <el-input v-model="paramsSea.c92"></el-input>
          </el-form-item>
          <el-form-item label="归档部门：">
            <el-select v-model="paramsSea.filingDept" class="w-100" filterable @change="changefili">
              <el-option v-for="item in deptArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="归档人：">
            <el-select v-model="paramsSea.filingUser" class="w-100" filterable :filter-method="getUser" @change="$forceUpdate()">
              <el-option v-for="item in userArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="拟稿部门：">
            <el-select v-model="paramsSea.c90" class="w-100" filterable @change="changeUser">
              <el-option v-for="item in deptArr1" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="拟稿人：">
            <el-select v-model="paramsSea.c89" class="w-100" filterable :filter-method="getUser1" @change="$forceUpdate()">
              <el-option v-for="item in userArr1" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="文件类型：">
            <el-select v-model="paramsSea.c100" class="w-100" filterable>
              <el-option v-for="item in fileArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="盖章类型：">
            <el-select v-model="paramsSea.c112" class="w-100" filterable>
              <el-option v-for="item in sealArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="文件日期：">
            <el-date-picker v-model="paramsSea.dateOfCreation" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" class="w-100">
            </el-date-picker>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="searchSea">检索</el-button>
          <el-button type="primary" @click="paramsSea ={}">重置条件</el-button>
          <el-button @click="seaFlag = false">关闭</el-button>
        </div>
      </el-dialog>
      <!--指定承办人的查看 -->
      <el-dialog :visible.sync="detailFlag" width="1100px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicShow.png" alt="">
          查看
        </div>
        <div>
          <!-- 表格 -->
          <div class="all-Table">
            <el-table :data="tableDetail" stripe border @selection-change="detailChange" class="w-100">
              <el-table-column type="selection" width="55">
              </el-table-column>
              <el-table-column prop="titleProper" label="材料名称">
              </el-table-column>
              <el-table-column prop="fileSize" label="大小">
              </el-table-column>
              <el-table-column prop="fileFormat" label="格式">
              </el-table-column>
              <el-table-column label="操作" align="center">
                <template slot-scope="scope">
                  <el-button size="mini" class="table-botton" @click="openSee(scope.row)">查看
                  </el-button>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <!-- 分页 -->
          <div class="pageLayout">
            <el-pagination @current-change="detailCurrChange" :current-page="detailParams.page" :page-size="detailParams.rows" layout="prev, pager, next, jumper" :total="detailParams.totals">
            </el-pagination>
          </div>
        </div>
      </el-dialog>
      <!-- 查看中的详情 -->
      <el-dialog :visible.sync="seeFlag" width="1100px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicShow.png" alt="">
          查看材料
        </div>
        <div class="see">
          <div class="see-left">
            <el-tree class="filter-tree" :highlight-current="true" :expand-on-click-node="false" :data="dataShow" default-expand-all :props="defaultProps" @node-click="handleNodeClick">
            </el-tree>
          </div>
          <div class="see-right">
            <embed :src='showUrl' type="application/pdf" width="100%" height="100%">
          </div>
        </div>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="downSee" :disabled="clickFlag">下载</el-button>
          <el-button @click="seeFlag = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 该文件非PDF,是否需要进行下载(查看失败) -->
      <el-dialog :visible.sync="notShow1" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle1.png" alt="">
          下载确认
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/nShow1.png" alt="">
          <div>该文档非PDF文件，是否要进行下载？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="clickDown">确定</el-button>
          <el-button @click="notShow1 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 对不起，您访问的材料还未扫描。(查看失败) -->
      <el-dialog :visible.sync="notShow2" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle2.png" alt="">
          系统提示
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/nShow2.png" alt="">
          <div>对不起，您访问的材料还未扫描。</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="notShow2 = false">确定</el-button>
          <el-button @click="notShow2 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 确认承办人 -->
      <el-dialog :visible.sync="conFlag" width="900px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/confirmed/a3.png" alt="">
          确认承办人
        </div>
        <div>
          <el-form :model="conParams" label-width="120px">
            <el-form-item label="题名：">
              <el-input v-model="conParams.titleProper"></el-input>
            </el-form-item>
            <el-row :gutter="20">
              <el-col :span="12">
                <el-form-item label="类型：">
                  <el-input v-model="conParams.c100"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="文件日期：">
                  <el-date-picker v-model="conParams.dateOfCreation" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" class="w-100">
                  </el-date-picker>
                </el-form-item>
              </el-col>
            </el-row>
            <el-row :gutter="20">
              <el-col :span="12">
                <el-form-item label="拟稿人：">
                  <el-input v-model="conParams.c89"></el-input>
                </el-form-item>
              </el-col>
              <el-col :span="12">
                <el-form-item label="拟稿部门：">
                  <el-input v-model="conParams.c90"></el-input>
                </el-form-item>
              </el-col>
            </el-row>
            <el-form-item label="添加承办人：">
              <span class="c-p" @click="openUser"><img src="../../assets/home/g3.png" alt=""></span>
              <el-input v-model="conParams.users" type="textarea" class="w-95" disabled></el-input>
            </el-form-item>
          </el-form>
          <div>
            <div class="headerBtn">
              <span @click="addUserSee"><img src="../../assets/confirmed/a4.png" alt="">查看</span>
            </div>
            <!-- 表格 -->
            <div class="all-Table desi-table">
              <el-table :data="tableCon" stripe border @selection-change="conChange">
                <el-table-column type="selection" width="55">
                </el-table-column>
                <el-table-column prop="titleProper" label="附件列表">
                </el-table-column>
                <el-table-column prop="fileSize" label="文件大小">
                </el-table-column>
                <el-table-column prop="fileFormat" label="文件格式">
                </el-table-column>
              </el-table>
            </div>
            <!-- 分页 -->
            <div class="pageLayout">
              <el-pagination @current-change="conCurrChange" :current-page="conParams1.page" :page-size="conParams1.rows" layout="prev, pager, next, jumper" :total="conParams1.total">
              </el-pagination>
            </div>
          </div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="conSubmit">提交</el-button>
          <el-button type="primary" @click="isExitFlag = true">结束</el-button>
          <el-button @click="conFlag = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 提交前--前提示 -->
      <el-dialog :visible.sync="conSubFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle2.png" alt="">
          提交确认
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确认要提交给承办人吗?</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="conSubmit1">确定</el-button>
          <el-button @click="conSubFlag= false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 结束--前提示 -->
      <el-dialog :visible.sync="isExitFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle2.png" alt="">
          系统消息
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要结束流程直接归档吗?</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="conExit">确定</el-button>
          <el-button @click="isExitFlag= false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 添加承办人 -->
      <el-dialog :visible.sync="userFlag" width="900px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/confirmed/a5.png" alt />
          添加承办人
        </div>
        <div class="user-content">
          <div class="user-left">
            <p class="user-title dialog-title">承办人列表
              <img src="../../assets/home/g2.png" alt="" />
            </p>
            <div>
              <div class="headerBtn user-head">
                <span class="search-select">
                  <label>承办人姓名:</label>
                  <el-input v-model="userParams.cbrName"></el-input>
                </span>
                <span @click="searchUser"><img src="../../assets/system/p8.png" alt="">查询</span>
              </div>
              <div class="all-Table desi-table1">
                <el-table :data="userTable" stripe border class="w-100" :highlight-current-row="true" @current-change="userLeftHander">
                  <!--      <el-table-column type="selection" width="40">
             </el-table-column> -->
                  <el-table-column label="承办人" prop="userName"></el-table-column>
                  <el-table-column label="承办人部门" prop="organizeName"></el-table-column>
                </el-table>
              </div>
            </div>
          </div>
          <div class="user-right">
            <p class="user-title dialog-title">承办人列表
              <img src="../../assets/home/g2.png" alt="" />
            </p>
            <p class="headerBtn user-head desi-p"><span @click="openDelUser"><img src="../../assets/system/p3.png" alt="">移除</span></p>
            <div class="all-Table desi-table2">
              <el-table :data="userTable1" stripe border class="w-100" @selection-change="userRightHander">
                <el-table-column type="selection" width="40">
                </el-table-column>
                <el-table-column label="承办人" prop="userName"></el-table-column>
                <el-table-column label="承办人部门" prop="organizeName"></el-table-column>
              </el-table>
            </div>
          </div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="confirmUser">确认</el-button>
          <el-button @click="userFlag = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 添加承办人--前确定 -->
      <el-dialog :visible.sync="userFlag1" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle1.png" alt="">
          系统提示
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定吗？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="clickUser">确定</el-button>
          <el-button @click="userFlag1 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 确认承办人--查看PDF文件 -->
      <el-dialog :visible.sync="seePdfFlag" width="900px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicShow.png" alt="">
          查看材料
        </div>
        <div class="desi-emb">
          <embed :src='seePdf' type="application/pdf" width="100%" height="100%">
        </div>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="downSeePdf">下载</el-button>
          <el-button @click="seePdfFlag = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 确认承办人--查看非PDF文件 -->
      <el-dialog :visible.sync="seeShow" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle1.png" alt="">
          下载确认
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/nShow1.png" alt="">
          <div>该文档非PDF文件，是否要进行下载？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="clickNotPdf">确定</el-button>
          <el-button @click="seeShow = false">取消</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import { valueIndex } from '@/js/transitionText';
import { confirmList, getFonds, getAndRole, getIdList, conDept, conUser, confile, conSeal, conDetailList, conLeft, seeConLeft, conLeft1, conCheckUser, BASICURL, getArch, listCbr, cbrFind, findDoc, exitCbr, saveCbr } from '@/js/getData';
export default {
  name: 'designate',
  data() {
    return {
      params: {
        page: 1,
        rows: 10,
        total: null,
        c0: 1,
        type: 0
      },
      fonds: [],
      oneType: [],
      twoType: [],
      threeType: [],
      ageData: [],
      retArr: ['', '短期', '长期', '永久', '', '10年', '15年', '', '30年'], //保管期限
      openArr: ['', '公开', '内部', '受控', '广发商密三级', '广发商密二级', '广发商密一级'], //公开属性
      isArr: ['是', '否'], //是否为原件
      showFlag: true,
      seaFlag: false,
      paramsSea: {},
      deptArr: [],
      deptArr1: [],
      userArr: [],
      userArr1: [],
      fileArr: [],
      sealArr: [],
      oneTable: [],
      tableDetail: [],
      detailFlag: false,
      tableDetail: [],
      dataShow: [],
      seeFlag: false,
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      detailParams: {
        totals: 0,
        rows: 8,
        page: 1
      },
      notShow1: false,
      notShow2: false,
      pdfId: null,
      showUrl: '',
      downName: '',
      detailArr: [],
      topicId: null,
      downId: null,
      conFlag: false,
      conParams: {},
      tableCon: [],
      conParams1: {
        page: 1,
        rows: 8,
        total: null,
      },
      userFlag: false,
      userParams: {},
      userTable: [],
      userTable1: [],
      oneUser: [],
      userFlag1: false,
      conOneTable: [],
      isExitFlag: false,
      seeShow: false,
      seePdfFlag: false,
      seePdf: '',
      conSubFlag: false,
      orgFlag1: null,
      orgFlag2: null,
      clickFlag: true,
    }
  },
  methods: {
    //获取全宗
    searchFond() {
      getFonds().then(res => {
        if (res.code == 0) {
          this.fonds = res.data;
          this.initFond();
        } else this.$message.error(res.message)
      })
    },
    //初始化选中全宗--原系统逻辑
    initFond(val) {
      if ("8106" == val) {
        this.params.fonds = 1463117877850; //广发乾和
      } else {
        this.params.fonds = 1374133141812 //新广发证券
      }
      this.fondsM();
    },
    //全宗方法
    fondsM() {
      this.searchType(this.params.fonds); //根据全宗获取类型
      this.initType();
    },
    //改变选中全宗
    changeFonds() {
      this.$forceUpdate();
      this.fondsM();
    },
    //根据全宗获取类型
    searchType(val) {
      getAndRole({ id: val }).then(res => {
        if (res.code == 0) {
          this.oneType = res.data;
        } else this.$message.error(res.message)
      })
    },
    //初始化选中分类1--原系统逻辑
    initType() {
      if (this.params.fonds == 1463117877850) {
        this.params.series1 = 1463318429461 //管理类档案
      } else if (this.params.fonds == 1374133141812) {
        this.params.series1 = 1379482316593 //管理类案件(按件)
      } else {
        this.params.series1 = null;
      }
      this.params.series2 = null;
      this.params.series3 = null;
      this.searchType1(this.params.series1, 1);
      this.initList();
    },
    //改变第一个类型
    changeOne() {
      this.$forceUpdate();
      this.searchType1(this.params.series1, 1);
      this.initList();
      this.params.series2 = null;
      this.params.series3 = null;
    },
    //根据档案分类id获取分类2
    searchType1(val, val1) {
      getIdList({ id: val }).then(res => {
        if (res.code == 0) {
          if (val1 == 1) {
            this.twoType = res.data;
          } else this.threeType = res.data;
        } else this.$message.error(res.message)
      })
    },
    //改变第二个类型
    changeTwo() {
      this.$forceUpdate();
      this.searchType1(this.params.series2, 2);
      this.params.series3 = null;
      this.initList();
    },
    //改变第三个类型
    changeThree() {
      this.$forceUpdate();
      this.initList();
    },
    //初始化获取档案列表--原系统逻辑
    initList() {
      if (this.params.series1) {
        if (this.params.series1 == 1379482316593 || this.params.series1 == 1463318429461) { //管理类档案（按件）|| 管理类档案
          this.resetInit();
          this.searchOne();
          this.showFlag = true;
        } else this.showFlag = false;
      } else this.showFlag = false;
    },
    resetInit() {
      this.params.searchType = null;
      this.params.titleProper = null;
      this.params.yearCode = null;
      this.params.fileCode = null;
      this.params.c117 = null;
      this.params.c113 = null;
      this.params.c92 = null;
      this.params.filingDept = null;
      this.params.filingUser = null;
      this.params.c90 = null;
      this.params.c89 = null;
      this.params.c100 = null;
      this.params.c112 = null;
      this.params.dateOfCreation = null;
    },
    //获取档案列表
    searchOne() {
      this.params.page = 1;
      this.searchList();
    },
    searchList() {
      confirmList(this.params).then(res => {
        if (res.code == 0) {
          this.ageData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    ageChange(val) {
      this.params.page = val;
      this.searchList();
    },
    ageSelect(val) {
      this.oneTable = val;
    },
    //检索
    //检索--归档部门/拟稿部门下拉
    getDept() {
      conDept().then(res => {
        if (res.code == 0) {
          this.deptArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    changefili(val) {
      this.orgFlag1 = val;
      this.paramsSea.filingUser = null;
      this.userArr = [];
    },
    getDept1() {
      conDept().then(res => {
        if (res.code == 0) {
          this.deptArr1 = res.data;
        } else this.$message.error(res.message)
      })
    },
    changeUser(val) {
      this.orgFlag2 = val;
      this.paramsSea.c89 = null;
      this.userArr1 = [];
    },
    //检索--归档人/拟稿人下拉
    getUser(val) {
      let users = {
        q: val,
        orgFlag1: this.orgFlag1 || -10000
      }
      conUser(users).then(res => {
        if (res.code == 0) {
          this.userArr = res.data;
        }
      })
    },
    getUser1(val) {
      let users = {
        q: val,
        orgFlag1: this.orgFlag2 || -10000
      }
      conUser(users).then(res => {
        if (res.code == 0) {
          this.userArr1 = res.data;
        }
      })
    },
    //检索--文件下拉
    getFile() {
      confile().then(res => {
        if (res.code == 0) {
          this.fileArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //检索--盖章类型
    getSeal() {
      conSeal().then(res => {
        if (res.code == 0) {
          this.sealArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    openSea() {
      this.getDept();
      this.getDept1();
      this.getFile();
      this.getSeal();
      this.seaFlag = true;
      this.orgFlag1 = null;
      this.orgFlag2 = null;
      this.paramsSea = {};
    },
    searchSea() {
      if (JSON.stringify(this.paramsSea) === '{}') {
        this.$message.error('请至少输入一项条件！')
      } else {
        this.resetInit();
        Object.assign(this.params, this.paramsSea);
        this.params.searchType = 1; //原系统逻辑
        this.searchOne();
        this.seaFlag = false;
      }
    },
    //查看
    openDetail(val) {
      this.topicId = this.detailParams.id = val.id;
      this.oneDetailSelect();
      this.detailFlag = true;
    },
    oneDetailSelect() {
      this.detailParams.page = 1;
      this.detailSelect();
    },
    detailSelect() {
      conDetailList(this.detailParams).then(res => {
        if (res.code == 0) {
          this.tableDetail = res.data.rows;
          this.detailParams.totals = res.data.total;
        } else this.$message.error(res.message);
      })
    },
    detailCurrChange(val) {
      this.detailParams.page = val;
      this.detailSelect();
    },
    detailChange(val) {
      this.detailArr = val;
    },
    //查看详情
    openSee(val) {
      this.pdfId = val.id;
      this.dataShow = [];
      conCheckUser().then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 0) { //如果是档案管理员或者综合员
            this.seeTree1()
          } else {
            this.seeTree2()
          }
        } else this.$message.error(res.message);
      })
      this.seeFlag = true;
    },
    //详情树1
    seeTree1() {
      let seeParams = {
        id: this.topicId,
        bs: 'dbsb'
      }
      conLeft(seeParams).then(res => {
        if (res.code == 0) {
          this.dataShow = res.data;
        } else this.$message.error(res.message);
      })
    },
    //详情树2
    seeTree2() {
      let seeParams = {
        id: this.topicId,
        bs: 'dbsb'
      }
      conLeft1(seeParams).then(res => {
        if (res.code == 0) {
          this.dataShow = res.data;
        } else this.$message.error(res.message);
      })
    },
    handleNodeClick(val) {
      this.downName = val.text;
      this.showUrl = '';
      this.downId = val.id;
      seeConLeft({ id: val.id }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 2) { //页面会显示 该文件非PDF,是否需要进行下载
            this.clickFlag = true;
            this.notShow1 = true;
          } else if (res.data.optFlag == -1) { //会显示 对不起，你访问的文件还未扫描
            this.clickFlag = true;
            this.notShow2 = true;
          } else {
            this.clickFlag = false;
            this.showUrl = BASICURL + '/gdda-new/rewirte/gdda/archiveCleanUp/viewPdf?docId=' + val.id;
          }
        } else this.$message.error(res.message);
      })
    },
    //下载文件
    clickDown() {
      let ids = {
        id: this.downId,
        mode: 'dbsb'
      }
      valueIndex().exportFiles('/gdda-new/gdda/util/downLoadFile', ids, this.downName, 'get');
      this.notShow1 = false;
    },
    downSee() {
      let ids = { id: this.downId }
      valueIndex().exportFiles('/gdda-new/gdda/util/downLoadDetail', ids, this.downName, 'get');
    },
    //确认承办人--打开
    openCon() {
      let open = this.$onceWay().onceTableList(this.oneTable);
      if (open == 1) {
        this.detailDes(this.oneTable[0].id)
        this.detailDesList();
        this.userTable1 = [];
        this.conFlag = true;
      }
    },
    //确认承办人--详情
    detailDes(val) {
      getArch({ subId: val }).then(res => {
        if (res.code == 0) {
          this.conParams = res.data;
        } else this.$message.error(res.message);
      })
    },
    //确认承办人--列表
    detailDesList() {
      this.conParams1.subId = this.oneTable[0].id;
      listCbr(this.conParams1).then(res => {
        if (res.code == 0) {
          this.tableCon = res.data.rows;
          this.conParams1.total = res.data.total;
        } else this.$message.error(res.message);
      })
    },
    conChange(val) {
      this.conOneTable = val;
    },
    conCurrChange(val) {
      this.conParams1.page = val;
    },
    //确认承办人--添加承办人
    openUser() {
      this.userParams = {};
      this.searchUser();
      this.userFlag = true;
    },
    searchUser() {
      cbrFind(this.userParams).then(res => {
        if (res.code == 0) {
          this.userTable = res.data.rows;
        } else this.$message.error(res.message);
      })
    },
    userLeftHander(val) {
      if (val) {
        if (this.userTable1.length <= 0) {
          this.userTable1.push(val);
        } else {
          let valFlag = false
          this.userTable1.forEach(item => {
            if (item.userId == val.userId && item.organizeId == val.organizeId) {
              valFlag = true;
              this.$message.error('该承办人已经添加!');
              return;
            }
          })
          if (!valFlag) {
            this.userTable1.push(val);
          }
        }

      }

    },
    userRightHander(val) {
      this.oneUser = val;
    },
    //移除
    openDelUser() {
      let open = this.$onceWay().onceTableList(this.oneUser);
      if (open == 1) {
        let index = -1;
        let showOne = this.oneUser[0];
        for (let i = 0; i < this.userTable1.length; i++) {
          let item = this.userTable1[i];
          if (item.userId == showOne.userId && item.organizeId == showOne.organizeId) {
            index = i;
            break
          }
        }
        this.userTable1.splice(index, 1)
        this.searchUser();
      }
    },
    //确定承办人--添加承办人--确定
    confirmUser() {
      if (this.userTable1.length <= 0) {
        this.$message.error('没有要添加的承办人!');
      } else {
        this.userFlag1 = true;
      }
    },
    clickUser() {
      this.userFlag1 = false;
      this.userFlag = false;
      let ids = "";
      let names = "";
      this.userTable1.forEach(item => {
        if (!ids) {
          ids = item.userId + '/' + item.organizeId;
        } else {
          ids = ids + ',' + item.userId + '/' + item.organizeId;
        }
        if (!names) {
          names = item.userName + "/" + item.organizeName;
        } else {
          names = names + "," + item.userName + "/" + item.organizeName;
        }
      });
      this.conParams.users = names;
      this.conParams.allIds = ids
    },
    //确认承办人--查看
    addUserSee() {
      let open = this.$onceWay().onceTableList(this.conOneTable);
      if (open == 1) {
        let fileType = this.conOneTable[0].fileFormat
        if (fileType == 'pdf' || fileType == 'PDF') { //PDF--查看预览样式
          this.clickPdf();
          this.seePdfFlag = true;
        } else {
          this.seeShow = true;
        }
      }
    },
    //确定承办人--查看--PDF文件
    clickPdf() {
      seeConLeft({ id: this.conOneTable[0].id }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == -1) { //会显示 对不起，你访问的文件还未扫描
            this.notShow2 = true;
          } else {
            this.seePdf = BASICURL + '/gdda-new/rewirte/gdda/archiveCleanUp/viewPdf?docId=' + this.conOneTable[0].id;
          }
        } else this.$message.error(res.message);
      })
    },
    //确认承办人--查看PDF下载
    downSeePdf() {
      let ids = {
        id: this.conOneTable[0].id,
      }
      valueIndex().exportFiles('/gdda-new/gdda/util/downLoadFile', ids, this.conOneTable[0].titleProper, 'get');
      this.notShow1 = false;
    },
    //确认承办人--查看点击下载（非PDF文件是否存在）
    clickNotPdf() {
      findDoc({ id: this.conOneTable[0].id }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == -1) { //不存在
            this.$message.error('文件未找到，无法下载!');
          } else { //存在--下载文件
            let ids = {
              id: this.conOneTable[0].id,
              mode: 'cbroa'
            }
            valueIndex().exportFiles('/gdda-new/gdda/util/downLoadFile', ids, this.downName, 'get');
          }
        } else this.$message.error(res.message);

      })
    },
    //确认承办人--结束
    conExit() {
      exitCbr({ subId: this.oneTable[0].id }).then(res => {
        if (res.code == 0) {
          if (res.data.flag == 0) {
            this.$message.success('归档成功!');
          } else this.$message.error('归档失败，系统出错！');
          this.isExitFlag = false;
          this.conFlag = false;
          this.searchOne();
        } else this.$message.error(res.message);
      })
    },
    //确定承办人--提交前
    conSubmit() {
      if (!this.conParams.users) {
        this.$message.error('请添加承办人!');
      } else {
        this.conSubFlag = true;
      }
    },
    conSubmit1() {
      let save = {
        subId: this.oneTable[0].id,
        cbrs: this.conParams.allIds,
        title: this.conParams.titleProper
      }
      saveCbr(save).then(res => {
        if (res.code == 0) {
          if (res.data.flag == 0) {
            this.$message.success('提交成功！');
          } else this.$message.error('提交失败，系统出错！');
          this.conSubFlag = false;
          this.conFlag = false;
          this.searchOne();
        } else this.$message.error(res.message);
      })
    }
  },
  created() {
    this.searchFond();
  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.search-select {
  label {
    font-size: 14px;
    color: #282828;
    padding-right: 5px
  }

  .el-input,
  .el-select {
    width: 143px;
  }

}

.user-head {
  margin-top: 10px;
  margin-left: 9px;
}

.user-title {
  color: #fff;
  padding-left: 10px;

  img {
    float: right;
    margin-top: 6px;
  }
}

.user-content {
  height: 400px;
  margin-top: -24px;
  margin-left: -14px;
  margin-right: -14px;

  .user-left {
    width: 50%;
    float: left;
  }

  .user-right {
    width: 48.6%;
    display: inline-block;
    margin-left: 4px;
  }
}

.see {
  width: 100%;
  clear: both;
  margin-top: -30px;
  height: 500px;

  .see-left {
    width: 40%;
    float: left;
    padding-top: 20px;
    overflow: auto;
    height: 100%;

    .filter-tree {
      display: inline-block;
    }
  }

  .see-right {
    width: 59%;
    height: 100%;
    padding-top: 20px;
    float: left;
    border-left: 3px solid #1982BF;
  }
}

.search-doc {
  margin-top: 10px;

  label {
    font-size: 14px;
    color: #282828;
    padding-right: 5px
  }

  .el-input,
  .el-select {
    width: 200px;
  }
}

.table-botton {
  width: 80%;
  background: #08A9E6;
  color: #fff;
}

.seeDoc {
  width: 100%;
  clear: both;
  height: 500px;

  .seeDoc-left {
    width: 20%;
    float: left;
  }

  .seeDoc-right {
    width: 79%;
    float: left;
    border-left: 3px solid #1982BF;
    height: 500px;
  }
}

.doc-car {
  background: url(../../assets/home/d2.png) no-repeat;
  position: fixed;
  width: 70px;
  height: 70px;
  right: 16px;
  bottom: 70px;
  z-index: 99999;
}

.doc-main {
  background-color: #fff;
  min-height: 700px;

  .mb-20 {

    margin-bottom: 20px;
  }

  .doc-down {
    font-size: 13px;
    color: #515BED;
    float: right;
  }

  .w-100 {
    width: 100%
  }

  .doc-doss {
    width: 100%;
    height: 500px;
    overflow: auto;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .mt-f18 {
    margin-top: -18px;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .lend-table {
    max-height: 200px;
    overflow-y: auto;
    width: 100%
  }
}

.desi-table {
  width: 100%;
  height: 193px;
  overflow-y: auto;
}

.desi-table1 {
  height: 318px;
  overflow: auto;
}

.desi-p {
  margin-top: 20px;
  margin-bottom: 18px;

}

.desi-table2 {
  height: 318px;
  overflow: auto;
  margin-top: 8px
}

.desi-emb {
  width: 100%;
  height: 500px;
}

.c-p {
  cursor: pointer;
}

.w-95 {
  width: 95%;
}

</style>
