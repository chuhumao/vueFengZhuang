<template>
    <div>
      <!--<div class="tuoZhai" @mousedown="showBtn($event)"></div>-->
      <!--<div id="tz" :class="turnPull? 'tuoZhaiTwo' : 'tuoZhai'" @mousedown="showBtn($event)" @mousemove="lookBtn($event)" @mouseup="shitUp($event)"></div>-->
      <span v-for="item in testArr">{{ item }},</span>
      <el-button @click="newArr"></el-button>
    </div>
</template>

<script>
export default {
  name: 'test',
  data () {
    return {
      testArr: [1, 2, 3, 4, 4, 5, 6, 6, 7, 8, 9, 6, 4, 1, 30, 130],
      params: {}
    }
  },
  methods: {
    newArr () {
      /* set去除方法 */
      // let setArr = new Set()
      // for (let i of this.testArr) {
      //   setArr.add(i)
      // }
      // this.testArr = setArr
      /* splice去除方法 */
      // for (let i = 0; i < this.testArr.length; i++) {
      //   for (let j = i + 1; j < this.testArr.length; j++) {
      //     if (this.testArr[i] == this.testArr[j]) {
      //       this.testArr.splice(j, 1)
      //       j--
      //     }
      //   }
      // }
      /* filter */
      // let arr = []
      // this.testArr.filter((item, index, val) => {
      //   // console.log(item); // 值
      //   // console.log(index); // 下标
      //   if (this.testArr.indexOf(item, 0) == index) {
      //     arr.push(item)
      //   }
      // })
      // this.testArr = arr
      let arr = [{id: 1}, {id: 5}, {id: 4}, {id: 3}, {id: 2}, {id: 6}]
      for (let [key, val] of arr) {
        console.log(key);
        console.log(val);
      }
    }
  }
}
</script>

<style scoped>

</style>
