<template>
  <el-container style="background-color: #fff;">
    <div class="bigDog menuShrink black-tree">
      <PinDao onceTitle="资源结构"></PinDao>
      <el-tree
        :data="treTable"
        :props="defaultProps"
        :check-strictly="true"
        :default-expand-all="false"
        :expand-on-click-node="false"
        :highlight-current="true"
        accordion
        @node-click="handleNodeClick">
        <span class="custom-tree-node"  slot-scope="{ node, data }">
            <span class="treeSpan" :dataType="data.type">
              <img :src="imgUrlHost +'/gdda-new'+ data.iconCls" alt="">
              <!--<i :class="data.checkIcon"></i>-->
              <!--<i :class="data.iconSkin"></i>-->
                {{ node.label }}
            </span>
        </span>
      </el-tree>
    </div>
    <el-main style="padding:0;">
      <!--<el-header class="menuHeaderTop" style="padding:0;height:30px;">-->
        <!--<img src="../../assets/home/childrenHurdle.png" alt="">-->
        <!--用户列表-->
      <!--</el-header>-->
      <div class="contentPadding tableShrink">
        <!--新增，编辑，删除-->
        <div class="headerBtn" v-if="auditShow == 'a'">
          <span @click="mateAdd"><img src="../../assets/hurdle/hurdleAdd.png" alt="">新增</span>
          <span @click="mateEdit"><img src="../../assets/hurdle/hurdleAdd.png" alt="">编辑</span>
          <span @click="mateDeleteBtn"><img src="../../assets/hurdle/hurdleAdd.png" alt="">删除</span>
        </div>
        <div class="headerBtn" v-else-if="auditShow == 'c'">
          <span @click="mateAddC"><img src="../../assets/hurdle/hurdleAdd.png" alt="">新增</span>
          <span @click="mateEditC"><img src="../../assets/hurdle/hurdleAdd.png" alt="">编辑</span>
          <span @click="mateDeleteBtn"><img src="../../assets/hurdle/hurdleAdd.png" alt="">删除</span>
        </div>
        <div class="headerBtn" v-else-if="auditShow == 'd'">
          <span @click="mateAddD"><img src="../../assets/hurdle/hurdleAdd.png" alt="">新增</span>
          <span @click="mateEditD"><img src="../../assets/hurdle/hurdleAdd.png" alt="">编辑</span>
          <span @click="mateDeleteBtn"><img src="../../assets/hurdle/hurdleAdd.png" alt="">删除</span>
        </div>
        <div class="headerBtn" v-else-if="auditShow == 'm'">
          <span @click="mateAddM"><img src="../../assets/hurdle/hurdleAdd.png" alt="">新增</span>
          <span @click="mateEditM"><img src="../../assets/hurdle/hurdleAdd.png" alt="">编辑</span>
          <span @click="mateDeleteBtn"><img src="../../assets/hurdle/hurdleAdd.png" alt="">删除</span>
          <span @click="unifyShow(1)"><img src="../../assets/hurdle/hurdleAdd.png" alt="">查看</span>
        </div>
        <!-- 统一：方法 -->
        <div class="headerBtn" v-else>
          <span @click="unifyAdd"><img src="../../assets/hurdle/hurdleAdd.png" alt="">新增</span>
          <span @click="unifyEdit"><img src="../../assets/hurdle/hurdleAdd.png" alt="">编辑</span>
          <span @click="deleteBtn"><img src="../../assets/hurdle/hurdleAdd.png" alt="">删除</span>
          <span @click="unifyShow(0)"><img src="../../assets/hurdle/hurdleAdd.png" alt="">查看</span>
        </div>
        <!-- 表格 -->
        <div class="all-Table" v-if="auditShow == 'a'">
          <el-table
            :data="tableData"
            stripe
            border
            @selection-change="handleSelectionChange"
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              prop="typeCode"
              label="档案编号">
            </el-table-column>
            <el-table-column
              prop="archiveTypeName"
              label="档案类型">
            </el-table-column>
            <el-table-column
              prop="type"
              label="类型">
              <template slot-scope="scope">
                <span v-if="scope.row.type == 'a'">档案类型</span>
                <span v-else-if="scope.row.type == 'c'">载体类型</span>
                <span v-else-if="scope.row.type == 'd'">部门</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="createUserName"
              label="创建人">
            </el-table-column>
            <el-table-column
              prop="createTime"
              label="创建时间">
            </el-table-column>
          </el-table>
        </div>
        <div class="all-Table" v-else-if="auditShow == 'c'">
          <el-table
            :data="tableData"
            stripe
            border
            @selection-change="handleSelectionChange"
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              prop="typeCode"
              label="载体编号">
            </el-table-column>
            <el-table-column
              prop="archiveTypeName"
              label="载体名称">
            </el-table-column>
            <el-table-column
              prop="type"
              label="类型">
              <template slot-scope="scope">
                <span v-if="scope.row.type == 'a'">档案类型</span>
                <span v-else-if="scope.row.type == 'c'">载体类型</span>
                <span v-else-if="scope.row.type == 'd'">部门</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="createUserName"
              label="创建人">
            </el-table-column>
            <el-table-column
              prop="createTime"
              label="创建时间">
            </el-table-column>
          </el-table>
        </div>
        <div class="all-Table" v-else-if="auditShow == 'd'">
          <el-table
            :data="tableData"
            stripe
            border
            @selection-change="handleSelectionChange"
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              prop="typeCode"
              label="部门编号">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="archiveTypeName"
              label="部门名称">
            </el-table-column>
            <el-table-column
              prop="type"
              label="类型">
              <template slot-scope="scope">
                <span v-if="scope.row.type == 'a'">档案类型</span>
                <span v-else-if="scope.row.type == 'c'">载体类型</span>
                <span v-else-if="scope.row.type == 'd'">部门</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="createUserName"
              label="创建人">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="createTime"
              label="创建时间">
            </el-table-column>
          </el-table>
        </div>
        <div class="all-Table" v-else-if="auditShow == 'm'">
          <el-table
            :data="tableData"
            stripe
            border
            @selection-change="handleSelectionChange"
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              prop="typeCode"
              label="材料编号">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="archiveTypeName"
              label="材料名称">
            </el-table-column>
            <el-table-column
              prop="createUserName"
              width="1">
            </el-table-column>
            <el-table-column
              prop="createUserName"
              label="创建人">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="effectiveData"
              label="有效期限">
            </el-table-column>
            <el-table-column
              show-overflow-tooltip
              prop="createTime"
              label="创建时间">
            </el-table-column>
          </el-table>
        </div>
        <div class="all-Table" v-else>
          <el-table
            :data="tableData"
            stripe
            border
            @selection-change="handleSelectionChange"
            style="width: 100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              prop="datumFileCode"
              label="材料编号">
            </el-table-column>
            <el-table-column
              prop="datumFileName"
              label="材料名称">
            </el-table-column>
            <el-table-column
              prop="createUserName"
              label="创建人">
            </el-table-column>
            <el-table-column
              prop="effectiveData"
              label="有效期限">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChange"
            :current-page="params.page"
            :page-size="params.rows"
            layout="prev, pager, next, jumper"
            :total="params.total">
          </el-pagination>
        </div>
      </div>
      <!-- 统一--添加材料 -->
      <el-dialog :visible.sync="dialogCl1" width="444px" class="hurdleAll" :before-close="handleCloseOne">
        <div slot="title" class="dialog-title">
          <img src="../../assets/dialog/js.png" alt="">
          添加材料
        </div>
        <el-form :model="paramsBottom" ref="ruleFormCl" :rules="ruleCl" label-width="100px" class="demo-ruleForm searchForm">
          <el-form-item label="材料编号" prop="datumFileName">
            <el-input v-model="paramsBottom.datumFileName" ></el-input>
          </el-form-item>
          <el-form-item label="材料名称" prop="datumFileCode">
            <el-input v-model="paramsBottom.datumFileCode" ></el-input>
          </el-form-item>
          <el-form-item label="有效期限" prop="effectiveData">
            <el-date-picker style="width: 100%;" v-model="paramsBottom.effectiveData" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" placeholder="选择时间"></el-date-picker>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="unifyAddBtn">保存</el-button>
          <!--<el-button @click="sxSearch18">重置</el-button>-->
          <el-button @click="dialogCl1 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 统一--编辑材料 -->
      <el-dialog :visible.sync="dialogCl2" width="444px" class="hurdleAll" :before-close="handleCloseOne">
        <div slot="title" class="dialog-title">
          <img src="../../assets/dialog/js.png" alt="">
          编辑材料
        </div>
        <el-form :model="paramsBottom" ref="ruleFormClEdit" :rules="ruleClEdit" label-width="100px" class="demo-ruleForm searchForm">
          <el-form-item label="材料编号" prop="datumFileName">
            <el-input v-model="paramsBottom.datumFileName" ></el-input>
          </el-form-item>
          <el-form-item label="材料名称" prop="datumFileCode">
            <el-input v-model="paramsBottom.datumFileCode" ></el-input>
          </el-form-item>
          <el-form-item label="有效期限" prop="effectiveData">
            <el-date-picker style="width: 100%;" v-model="paramsBottom.effectiveData" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" placeholder="选择时间"></el-date-picker>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="unifyEditBtn">保存</el-button>
          <!--<el-button @click="sxSearch18">重置</el-button>-->
          <el-button @click="dialogCl2 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 统一--删除 -->
      <el-dialog :visible.sync="dialogCl3" width="444px" class="hurdleAll" :before-close="handleCloseOne">
        <div slot="title" class="dialog-title">
          <img src="../../assets/dialog/deleteTwo.png" alt="">
          系统提示
        </div>
        <div class="dia-deleteTwo">
          <img src="../../assets/dialog/wh.png" alt="">
          <br>
          <div>确定要删除此数据吗？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
          <el-button type="primary" @click="deleteBtnTwo">确定</el-button>
          <el-button @click="dialogCl3 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 统一--材料模板使用记录 -->
      <el-dialog :visible.sync="dialogCl4" width="1314px" class="hurdleAll" :before-close="handleCloseOne">
        <div slot="title" class="dialog-title">
          <!--<img src="../../assets/dialog/deleteTwo.png" alt="">-->
          材料模板使用记录
        </div>
        <div class="all-Table">
          <el-table
            :data="tableDataDialog"
            stripe
            border
            style="width: 100%">
            <!--<el-table-column-->
              <!--type="selection"-->
              <!--width="55">-->
            <!--</el-table-column>-->
            <el-table-column
              prop="status"
              label="移交状态"
              width="200"
            >
              <template slot-scope="scope">
                <span v-if="scope.row.status == 1">欠交</span>
                <span v-else-if="scope.row.status == 2">综合员审核</span>
                <span v-else-if="scope.row.status == 3">领导审核</span>
                <span v-else-if="scope.row.status == 4">管理员审核</span>
                <span v-else-if="scope.row.status == 5">已移交</span>
              </template>
            </el-table-column>
            <el-table-column
              prop="serialNumber"
              label="移交单号"
              width="300">
            </el-table-column>
            <el-table-column
              prop="handoverUserName"
              label="移交人姓名"
              width="200">
            </el-table-column>
            <el-table-column
              prop="handoverDept"
              label="移交部门"
              width="200">
            </el-table-column>
            <el-table-column
              prop="handoverTypeName"
              label="移交方式"
              width="200">
            </el-table-column>
            <el-table-column
              prop="handoverYdh"
              label="运单号"
              width="300">
            </el-table-column>
            <el-table-column
              prop="handoverDate"
              label="移交时间"
              width="200">
            </el-table-column>
            <el-table-column
              prop="tag"
              label="档案类型"
              width="300">
            </el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination
            @current-change="handleCurrentChangeDialog"
            :current-page="paramsDialog.page"
            :page-size="paramsDialog.rows"
            layout="prev, pager, next, jumper"
            :total="paramsDialog.total">
          </el-pagination>
        </div>
        <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px; text-align: right">
          <!--<el-button type="primary" @click="deleteBtnTwo">确定</el-button>-->
          <el-button @click="dialogCl4 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 材料--添加材料 -->
      <el-dialog :visible.sync="dialogCl5" width="444px" class="hurdleAll" :before-close="handleCloseOne">
        <div slot="title" class="dialog-title">
          <img src="../../assets/dialog/js.png" alt="">
          添加档案类型
        </div>
        <el-form :model="paramsBottom" ref="ruleFormClTwo" :rules="ruleClTwo" label-width="110px" class="demo-ruleForm searchForm">
          <el-form-item label="档案编号" prop="typeCode">
            <el-input v-model="paramsBottom.typeCode" ></el-input>
          </el-form-item>
          <el-form-item label="特殊档案类型" prop="archiveTypeName">
            <el-input v-model="paramsBottom.archiveTypeName" ></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="mateAddBtn">保存</el-button>
          <!--<el-button @click="sxSearch18">重置</el-button>-->
          <el-button @click="dialogCl5 = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 材料--编辑材料 -->
      <el-dialog :visible.sync="dialogCl5Two" width="444px" class="hurdleAll" :before-close="handleCloseOne">
        <div slot="title" class="dialog-title">
          <img src="../../assets/dialog/js.png" alt="">
          编辑档案类型
        </div>
        <el-form :model="paramsBottom" ref="ruleFormClTwo" :rules="ruleClTwo" label-width="110px" class="demo-ruleForm searchForm">
          <el-form-item label="档案编号" prop="typeCode">
            <el-input v-model="paramsBottom.typeCode" ></el-input>
          </el-form-item>
          <el-form-item label="特殊档案类型" prop="archiveTypeName">
            <el-input v-model="paramsBottom.archiveTypeName" ></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="mateEditBtn">保存</el-button>
          <!--<el-button @click="sxSearch18">重置</el-button>-->
          <el-button @click="dialogCl5Two = false">取消</el-button>
        </div>
      </el-dialog>

      <!-- 材料--添加材料C -->
      <el-dialog :visible.sync="dialogCl5C" width="444px" class="hurdleAll" :before-close="handleCloseOne">
        <div slot="title" class="dialog-title">
          <img src="../../assets/dialog/js.png" alt="">
          添加载体类型
        </div>
        <el-form :model="paramsBottom" ref="ruleFormClTwo" :rules="ruleClTwoC" label-width="110px" class="demo-ruleForm searchForm">
          <el-form-item label="载体编号" prop="typeCode">
            <el-input v-model="paramsBottom.typeCode" ></el-input>
          </el-form-item>
          <el-form-item label="载体名称" prop="archiveTypeName">
            <el-input v-model="paramsBottom.archiveTypeName" ></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="mateAddCBtn">保存</el-button>
          <!--<el-button @click="sxSearch18">重置</el-button>-->
          <el-button @click="dialogCl5C = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 材料--编辑材料C -->
      <el-dialog :visible.sync="dialogCl5CTwo" width="444px" class="hurdleAll" :before-close="handleCloseOne">
        <div slot="title" class="dialog-title">
          <img src="../../assets/dialog/js.png" alt="">
          编辑载体类型
        </div>
        <el-form :model="paramsBottom" ref="ruleFormClTwo" :rules="ruleClTwoC" label-width="110px" class="demo-ruleForm searchForm">
          <el-form-item label="载体编号" prop="typeCode">
            <el-input v-model="paramsBottom.typeCode" readonly></el-input>
          </el-form-item>
          <el-form-item label="载体名称" prop="archiveTypeName">
            <el-input v-model="paramsBottom.archiveTypeName" ></el-input>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="mateEditCBtn">保存</el-button>
          <!--<el-button @click="sxSearch18">重置</el-button>-->
          <el-button @click="dialogCl5CTwo = false">取消</el-button>
        </div>
      </el-dialog>


      <!-- 材料--添加材料D -->
      <el-dialog :visible.sync="dialogCl5D" width="444px" class="hurdleAll" :before-close="handleCloseOne">
        <div slot="title" class="dialog-title">
          <img src="../../assets/dialog/js.png" alt="">
          添加部门
        </div>
        <el-form :model="paramsBottom" ref="ruleFormClTwo" :rules="ruleClTwoD" label-width="110px" class="demo-ruleForm searchForm">
          <el-form-item label="部门编号">
            <el-input v-model="paramsBottom.typeCode" readonly></el-input>
          </el-form-item>
          <el-form-item label="部门名称" prop="archiveTypeName">
            <el-select v-model="paramsBottom.archiveTypeName" filterable placeholder="请选择" @change="archiveTypeNameArrChange" style="width: 100%;">
              <el-option v-for="(item, index) in archiveTypeNameArr" :key="index" :label="item.organizeName" :value="item.flag1"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="mateAddDBtn">保存</el-button>
          <!--<el-button @click="sxSearch18">重置</el-button>-->
          <el-button @click="dialogCl5D = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 材料--编辑材料D -->
      <el-dialog :visible.sync="dialogCl5DTwo" width="444px" class="hurdleAll" :before-close="handleCloseOne">
        <div slot="title" class="dialog-title">
          <img src="../../assets/dialog/js.png" alt="">
          编辑部门
        </div>
        <el-form :model="paramsBottom" ref="ruleFormClTwo" :rules="ruleClTwoD" label-width="110px" class="demo-ruleForm searchForm">
          <el-form-item label="部门编号">
            <el-input v-model="paramsBottom.typeCode" readonly></el-input>
          </el-form-item>
          <el-form-item label="部门名称" prop="archiveTypeName">
            <el-select v-model="paramsBottom.archiveTypeName" filterable placeholder="请选择" @change="archiveTypeNameArrChange" style="width: 100%;">
              <el-option v-for="(item, index) in archiveTypeNameArr" :key="index" :label="item.organizeName" :value="item.flag1"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="mateEditDBtn">保存</el-button>
          <!--<el-button @click="sxSearch18">重置</el-button>-->
          <el-button @click="dialogCl5DTwo = false">取消</el-button>
        </div>
      </el-dialog>

      <!-- 材料--添加材料M -->
      <el-dialog :visible.sync="dialogCl5M" width="444px" class="hurdleAll" :before-close="handleCloseOne">
        <div slot="title" class="dialog-title">
          <img src="../../assets/dialog/js.png" alt="">
          添加材料
        </div>
        <el-form :model="paramsBottom" ref="ruleFormClTwo" :rules="ruleClTwoM" label-width="110px" class="demo-ruleForm searchForm">
          <el-form-item label="材料编号" prop="typeCode">
            <el-input v-model="paramsBottom.typeCode" readonly></el-input>
          </el-form-item>
          <el-form-item label="材料名称" prop="archiveTypeName">
            <el-select v-model="paramsBottom.archiveTypeName" filterable placeholder="请选择" @change="materialListArrChange" style="width: 100%;">
              <el-option v-for="(item, index) in materialListArr" :key="index" :label="item.datumFileName" :value="item.id"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="有效期限" prop="effectiveData">
            <!--<el-date-picker style="width: 100%;" v-model="paramsBottom.effectiveData" type="date" format="yyyy-MM-dd HH:mm:ss"-->
                            <!--value-format="yyyy-MM-dd HH:mm:ss" placeholder="选择时间"></el-date-picker>-->
            <el-date-picker style="width: 100%;" v-model="paramsBottom.effectiveData" type="datetime" format="yyyy-MM-dd HH:mm:ss"
                            value-format="yyyy-MM-dd HH:mm:ss" placeholder="选择时间"></el-date-picker>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="mateAddMBtn">保存</el-button>
          <!--<el-button @click="sxSearch18">重置</el-button>-->
          <el-button @click="dialogCl5M = false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 材料--编辑材料M -->
      <el-dialog :visible.sync="dialogCl5MTwo" width="444px" class="hurdleAll" :before-close="handleCloseOne">
        <div slot="title" class="dialog-title">
          <img src="../../assets/dialog/js.png" alt="">
          编辑材料
        </div>
        <el-form :model="paramsBottom" ref="ruleFormClTwo" :rules="ruleClTwoM" label-width="110px" class="demo-ruleForm searchForm">
          <el-form-item label="材料编号" prop="typeCode">
            <el-input v-model="paramsBottom.typeCode" readonly></el-input>
          </el-form-item>
          <el-form-item label="材料名称" prop="archiveTypeName">
            <el-select v-model="paramsBottom.archiveTypeName" filterable placeholder="请选择" @change="materialListArrChange" style="width: 100%;" disabled>
              <el-option v-for="(item, index) in materialListArr" :key="index" :label="item.datumFileName" :value="item.id"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="有效期限" prop="effectiveData">
            <!--<el-date-picker style="width: 100%;" v-model="paramsBottom.effectiveData" type="date" format="yyyy-MM-dd HH:mm:ss"-->
                            <!--value-format="yyyy-MM-dd HH:mm:ss" placeholder="选择时间"></el-date-picker>-->
            <el-date-picker style="width: 100%;" v-model="paramsBottom.effectiveData" type="datetime" format="yyyy-MM-dd HH:mm:ss"
                            value-format="yyyy-MM-dd HH:mm:ss" placeholder="选择时间"></el-date-picker>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn">
          <el-button type="primary" @click="mateEditMBtn">保存</el-button>
          <!--<el-button @click="sxSearch18">重置</el-button>-->
          <el-button @click="dialogCl5MTwo = false">取消</el-button>
        </div>
      </el-dialog>

      <!-- 材料--删除 -->
      <el-dialog :visible.sync="dialogCl6" width="444px" class="hurdleAll" :before-close="handleCloseOne">
        <div slot="title" class="dialog-title">
          <img src="../../assets/dialog/deleteTwo.png" alt="">
          系统提示
        </div>
        <div class="dia-deleteTwo">
          <img src="../../assets/dialog/wh.png" alt="">
          <br>
          <div>确定要删除此数据吗？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn" style="margin-top: -18px;">
          <el-button type="primary" @click="mateDeleteBtnTwo">确定</el-button>
          <el-button @click="dialogCl6 = false">取消</el-button>
        </div>
      </el-dialog>
    </el-main>
  </el-container>
</template>

<script>
import { DEV_HOST } from '@/js/http.js'
import PinDao from '../../components/menuChildren/pinDao'
import {listTreeJson, childrenData, judgeType, fileListForJson, listForJson, saveFile, getMaterial, deleteMaterial,
  yjRecordList, saveArchiveType, ListOrg, materialList, mateGet, mateDelete} from '@/js/mateMange'
export default {
  name: 'mateMange',
  components: {
    PinDao
  },
  data () {
    return {
      params: {page: 1, rows: 10, total: 1},
      paramsDialog: {page: 1, rows: 10, total: 1},
      tableData: [],
      treTable: [],
      tableDataUnify: [],

      tableDataDialog: [],
      tableDataDialogOnce: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      imgUrlHost: DEV_HOST,
      auditShow: '',
      auditShowId: null,
      ruleCl: {
        datumFileName: {required: true, message: '请填写材料编号', trigger: 'blur'},
        datumFileCode: {required: true, message: '请填写材料名称', trigger: 'blur'},
        effectiveData: {required: true, message: '请填写有效期限', trigger: 'blur'},
      },
      ruleClTwo: {
        typeCode: {required: true, message: '请填写档案编号', trigger: 'blur'},
        archiveTypeName: {required: true, message: '请填写档案类型名称', trigger: 'blur'},
      },
      ruleClTwoC: {
        typeCode: {required: true, message: '请填写载体编号', trigger: 'blur'},
        archiveTypeName: {required: true, message: '请填写载体名称', trigger: 'blur'},
      },
      ruleClTwoD: {
        archiveTypeName: {required: true, message: '请选择部门列表', trigger: 'blur'},
      },
      ruleClTwoM: {
        archiveTypeName: {required: true, message: '请选择材料名称', trigger: 'blur'},
        effectiveData: {required: true, message: '请选择有效期限', trigger: 'blur'},
      },
      ruleClEdit: {
        datumFileName: {required: true, message: '请填写材料编号', trigger: 'blur'},
        datumFileCode: {required: true, message: '请填写材料名称', trigger: 'blur'},
        effectiveData: {required: true, message: '请填写有效期限', trigger: 'blur'},
      },

      paramsBottom: {},
      dialogCl1: false,
      dialogCl2: false,
      dialogCl3: false,
      dialogCl4: false,
      dialogCl5: false,
      dialogCl5Two: false,
      dialogCl5C: false,
      dialogCl5CTwo: false,
      dialogCl5D: false,
      dialogCl5DTwo: false,
      dialogCl5M: false,
      dialogCl5MTwo: false,
      dialogCl6: false,
      archiveTypeNameArr: [],
      materialListArr: [],
    }
  },
  methods: {
    showListTre () {
      listTreeJson().then(res => {
        this.treTable = res.data
      })
    },
    showList (item) {
      this.tableData = []
      if (item.parentId == 1) {
        let params = {
          parentId: item.parentId,
          page: item.page,
          rows: item.rows
        }
        fileListForJson(params).then(res => {
          this.tableData = res.rows
          this.params.total = res.total
        })
      } else {
        let params = {
          parentId: item.parentId,
          page: item.page,
          rows: item.rows
        }
        listForJson(params).then(res => {
          this.tableData = res.data.rows
          this.params.total = res.data.total
        })
      }
    },
    handleNodeClick (val) {
      console.log(val);
      val.children = []
      this.auditShowId = []
      judgeType({id: val.id}).then(res => {
        this.auditShow = res.data.type
        childrenData({parentId: val.id}).then(res => {
          val.children = res.data
        });
        [this.params.page, this.params.total, this.params.parentId, this.auditShowId] = [1, 0, val.id, val.id]
        this.showList(this.params)
      })
    },
    handleSelectionChange (val) {
      this.tableDataUnify = val
    },
    // 分页
    handleCurrentChange (val) {
      this.params.page = val
      this.showList(this.params)
    },
    handleCloseOne () {
      this.dialogCl1 = false
      this.dialogCl2 = false
      this.dialogCl3 = false
      this.dialogCl4 = false
      this.dialogCl5 = false
      this.dialogCl5Two = false
      this.dialogCl5C = false
      this.dialogCl5CTwo = false
      this.dialogCl5D = false
      this.dialogCl5DTwo = false
      this.dialogCl5M = false
      this.dialogCl5MTwo = false
      this.dialogCl6 = false
    },
    // 新增
    unifyAdd () {
      if (this.auditShowId == null || this.auditShowId == '') {
        this.$message.error('请你先在资源树中选中一项作为上级资源')
      } else {
        this.dialogCl1 = true
        this.clearFiles('ruleFormCl')
        this.paramsBottom = {}
      }
    },
    unifyAddBtn () {
      this.$refs.ruleFormCl.validate((valid) => {
        if (valid) {
          saveFile(this.paramsBottom).then(res => {
            if (res.code == 0) {
              this.$message.success('添加成功');
              [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              this.showList(this.params)
              this.dialogCl1 = false
            } else {
              // this.$message.error('添加异常');
              this.$message.error(res.message);
              // [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              // this.showList(this.params)
              // this.dialogCl1 = false
            }
          })
        }
      })
    },
    // 编辑
    unifyEdit () {
      if (this.auditShowId == null || this.auditShowId == '') {
        this.$message.error('请你先在资源树中选中一项作为上级资源')
      } else {
        let item = this.$onceWay().onceTableList(this.tableDataUnify)
        if (item == 1) {
          getMaterial({id: this.tableDataUnify[0].id}).then(res => {
            this.dialogCl2 = true
            this.clearFiles('ruleFormClEdit')
            this.paramsBottom = res.data
          })
        }
      }
    },
    unifyEditBtn () {
      this.$refs.ruleFormClEdit.validate((valid) => {
        if (valid) {
          this.paramsBottom.id = this.tableDataUnify[0].id
          saveFile(this.paramsBottom).then(res => {
            if (res.code == 0) {
              this.$message.success('修改成功');
              [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              this.showList(this.params)
              this.dialogCl2 = false
            } else {
              this.$message.error(res.message);
              // [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              // this.showList(this.params)
              // this.dialogCl2 = false
            }
          })
        }
      })
    },
    // 删除
    deleteBtn () {
      let item = this.$onceWay().onceTableListTwo(this.tableDataUnify)
      if (item == 1) {
        this.dialogCl3 = true
      }
    },
    deleteBtnTwo () {
      let arr = ''
      for (let i of this.tableDataUnify) {
        arr += i.id + ','
      }
      deleteMaterial({ids: arr}).then(res => {
        if (res.code == 0) {
          this.$message.success('删除成功');
          [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
          this.showList(this.params)
          this.dialogCl3 = false
        } else {
          this.$message.error(res.message);
          [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
          this.showList(this.params)
          this.dialogCl3 = false
        }
      })
    },

    // 查看
    unifyShow (val) {
      let item = this.$onceWay().onceTableListTwo(this.tableDataUnify)
      if (item == 1) {
        let params = {
          // type: 0,
          type: val,
          infoId: this.tableDataUnify[0].id,
          page: this.paramsDialog.page,
          rows: this.paramsDialog.rows,
        }
        yjRecordList(params).then(res => {
          this.dialogCl4 = true
          this.tableDataDialog = res.data.rows
          this.paramsDialog.total = res.data.total
        })
        // this.tableDataDialog
      }
    },
    handleCurrentChangeDialog (val) {
      this.paramsDialog.page = val
      this.unifyShow()
    },

    // 材料---
    // 添加
    mateAdd () {
      if (this.auditShowId == null || this.auditShowId == '') {
        this.$message.error('请你先在资源树中选中一项作为上级资源')
      } else {
        this.dialogCl5 = true
        this.clearFiles('ruleFormClTwo')
        this.paramsBottom = {}
      }
    },
    mateAddBtn () {
      this.$refs.ruleFormClTwo.validate((valid) => {
        if (valid) {
          this.paramsBottom.parentId = this.params.parentId
          saveArchiveType(this.paramsBottom).then(res => {
            if (res.code == 0) {
              this.$message.success('添加成功');
              [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              this.showList(this.params)
              this.dialogCl5 = false
            } else {
              this.$message.error(res.message);
              // [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              // this.showList(this.params)
              // this.dialogCl5 = false
            }
          })
        }
      })
    },
    // 编辑
    mateEdit () {
      if (this.auditShowId == null || this.auditShowId == '') {
        this.$message.error('请你先在资源树中选中一项作为上级资源')
      } else {
        let item = this.$onceWay().onceTableList(this.tableDataUnify)
        if (item == 1) {
          mateGet({id: this.tableDataUnify[0].id}).then(res => {
            this.dialogCl5Two = true
            this.clearFiles('ruleFormClTwo')
            this.paramsBottom = res.data
          })
        }
      }
    },
    mateEditBtn () {
      this.$refs.ruleFormClTwo.validate((valid) => {
        if (valid) {
          this.paramsBottom.id = this.tableDataUnify[0].id
          saveFile(this.paramsBottom).then(res => {
            if (res.code == 0) {
              this.$message.success('修改成功');
              [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              this.showList(this.params)
              this.dialogCl5Two = false
            } else {
              this.$message.error(res.message);
              // [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              // this.showList(this.params)
              // this.dialogCl5Two = false
            }
          })
        }
      })
    },
    // 删除
    mateDeleteBtn () {
      let item = this.$onceWay().onceTableListTwo(this.tableDataUnify)
      if (item == 1) {
        this.dialogCl6 = true
      }
    },
    mateDeleteBtnTwo () {
      let arr = ''
      for (let i of this.tableDataUnify) {
        arr += i.id + ','
      }
      mateDelete({ids: arr}).then(res => {
        if (res.code == 0) {
          this.$message.success('删除成功');
          [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
          this.showList(this.params)
          this.dialogCl6 = false
        } else {
          this.$message.error(res.message);
          [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
          this.showList(this.params)
          this.dialogCl6 = false
        }
      })

    },


    // 添加C
    mateAddC () {
      if (this.auditShowId == null || this.auditShowId == '') {
        this.$message.error('请你先在资源树中选中一项作为上级资源')
      } else {
        this.dialogCl5C = true
        this.clearFiles('ruleFormClTwo')
        this.paramsBottom = {}
      }
    },
    mateAddCBtn () {
      this.$refs.ruleFormClTwo.validate((valid) => {
        if (valid) {
          this.paramsBottom.parentId = this.params.parentId
          saveArchiveType(this.paramsBottom).then(res => {
            if (res.code == 0) {
              this.$message.success('添加成功');
              [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              this.showList(this.params)
              this.dialogCl5C = false
            } else {
              this.$message.error(res.message);
              // [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              // this.showList(this.params)
              // this.dialogCl5C = false
            }
          })
        }
      })
    },
    // 编辑C
    mateEditC () {
      if (this.auditShowId == null || this.auditShowId == '') {
        this.$message.error('请你先在资源树中选中一项作为上级资源')
      } else {
        let item = this.$onceWay().onceTableList(this.tableDataUnify)
        if (item == 1) {
          mateGet({id: this.tableDataUnify[0].id}).then(res => {
            this.dialogCl5CTwo = true
            this.clearFiles('ruleFormClTwo')
            this.paramsBottom = res.data
          })
        }
      }
    },
    mateEditCBtn () {
      this.$refs.ruleFormClTwo.validate((valid) => {
        if (valid) {
          this.paramsBottom.id = this.tableDataUnify[0].id
          saveArchiveType(this.paramsBottom).then(res => {
            if (res.code == 0) {
              this.$message.success('修改成功');
              [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              this.showList(this.params)
              this.dialogCl5CTwo = false
            } else {
              this.$message.error(res.message);
              // [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              // this.showList(this.params)
              // this.dialogCl5CTwo = false
            }
          })
        }
      })
    },

    // 添加D
    mateAddD () {
      if (this.auditShowId == null || this.auditShowId == '') {
        this.$message.error('请你先在资源树中选中一项作为上级资源')
      } else {
        this.dialogCl5D = true
        this.clearFiles('ruleFormClTwo')
        this.paramsBottom = {}
      }
    },
    mateAddDBtn () {
      this.$refs.ruleFormClTwo.validate((valid) => {
        if (valid) {
          let params = {
            parentId: this.params.parentId,
            archiveTypeName: this.paramsBottom.archiveTypeName,
            typeCode: this.paramsBottom.typeCode,
            archiveTypeId: this.paramsBottom.archiveTypeId
          }
          for (let i of this.archiveTypeNameArr) {
            if (i.flag1 == this.paramsBottom.archiveTypeName) {
              params.archiveTypeName = i.organizeName
            }
          }
          // this.paramsBottom.parentId = this.params.parentId
          saveArchiveType(params).then(res => {
            if (res.code == 0) {
              this.$message.success('添加成功');
              [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              this.showList(this.params)
              this.dialogCl5D = false
            } else {
              this.$message.error(res.message);
              // [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              // this.showList(this.params)
              // this.dialogCl5D = false
            }
          })
        }
      })
    },
    archiveTypeNameArrChange (val) {
      for (let i of this.archiveTypeNameArr) {
        if (i.flag1 == val) {
          this.paramsBottom.typeCode = i.flag1
          this.paramsBottom.archiveTypeId = i.organizeId
        }
      }
    },
    // 编辑D
    mateEditD () {
      if (this.auditShowId == null || this.auditShowId == '') {
        this.$message.error('请你先在资源树中选中一项作为上级资源')
      } else {
        let item = this.$onceWay().onceTableList(this.tableDataUnify)
        if (item == 1) {
          mateGet({id: this.tableDataUnify[0].id}).then(res => {
            this.dialogCl5DTwo = true
            this.clearFiles('ruleFormClTwo')
            this.paramsBottom = res.data
          })
        }
      }
    },
    mateEditDBtn () {
      this.$refs.ruleFormClTwo.validate((valid) => {
        if (valid) {
          let params = {
            parentId: this.params.parentId,
            archiveTypeName: this.paramsBottom.archiveTypeName,
            typeCode: this.paramsBottom.typeCode,
            archiveTypeId: this.paramsBottom.archiveTypeId,
            id: this.tableDataUnify[0].id
          }
          for (let i of this.archiveTypeNameArr) {
            if (i.flag1 == this.paramsBottom.archiveTypeName) {
              params.archiveTypeName = i.organizeName
            }
          }
          // this.paramsBottom.id = this.tableDataUnify[0].id
          saveArchiveType(params).then(res => {
            if (res.code == 0) {
              this.$message.success('修改成功');
              [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              this.showList(this.params)
              this.dialogCl5DTwo = false
            } else {
              this.$message.error(res.message);
              // [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              // this.showList(this.params)
              // this.dialogCl5DTwo = false
            }
          })
        }
      })
    },

    // 添加M
    mateAddM () {
      if (this.auditShowId == null || this.auditShowId == '') {
        this.$message.error('请你先在资源树中选中一项作为上级资源')
      } else {
        this.dialogCl5M = true
        this.clearFiles('ruleFormClTwo')
        this.paramsBottom = {}
      }
    },
    mateAddMBtn () {
      this.$refs.ruleFormClTwo.validate((valid) => {
        if (valid) {
          let params = {
            parentId: this.params.parentId,
            archiveTypeName: this.paramsBottom.archiveTypeName,
            typeCode: this.paramsBottom.typeCode,
            effectiveData: this.paramsBottom.effectiveData,
            archiveTypeId: this.paramsBottom.archiveTypeId
          }
          for (let i of this.materialListArr) {
            if (i.id == this.paramsBottom.archiveTypeName) {
              params.archiveTypeName = i.datumFileName
            }
          }
          // this.paramsBottom.parentId = this.params.parentId
          saveArchiveType(params).then(res => {
            if (res.code == 0) {
              this.$message.success('添加成功');
              [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              this.showList(this.params)
              this.dialogCl5M = false
            } else {
              this.$message.error(res.message);
              // [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              // this.showList(this.params)
              // this.dialogCl5M = false
            }
          })
        }
      })
    },
    materialListArrChange (val) {
      for (let i of this.materialListArr) {
        if (i.id == val) {
          this.paramsBottom.typeCode = i.datumFileCode
          this.paramsBottom.archiveTypeId = i.id
        }
      }
    },
    // 编辑
    mateEditM () {
      if (this.auditShowId == null || this.auditShowId == '') {
        this.$message.error('请你先在资源树中选中一项作为上级资源')
      } else {
        let item = this.$onceWay().onceTableList(this.tableDataUnify)
        if (item == 1) {
          mateGet({id: this.tableDataUnify[0].id}).then(res => {
            this.dialogCl5MTwo = true
            this.clearFiles('ruleFormClTwo')
            this.paramsBottom = res.data
            // this.paramsBottom.effectiveData = res.data.effectiveData
          })
        }
      }
    },
    mateEditMBtn () {
      this.$refs.ruleFormClTwo.validate((valid) => {
        if (valid) {
          let params = {
            parentId: this.params.parentId,
            archiveTypeName: this.paramsBottom.archiveTypeName,
            typeCode: this.paramsBottom.typeCode,
            archiveTypeId: this.paramsBottom.archiveTypeId,
            effectiveData: this.paramsBottom.effectiveData,
            id: this.tableDataUnify[0].id
          }
          for (let i of this.materialListArr) {
            if (i.id == this.paramsBottom.archiveTypeName) {
              params.archiveTypeName = i.datumFileName
            }
          }
          // this.paramsBottom.id = this.tableDataUnify[0].id
          saveArchiveType(params).then(res => {
            if (res.code == 0) {
              this.$message.success('修改成功');
              [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              this.showList(this.params)
              this.dialogCl5MTwo = false
            } else {
              this.$message.error(res.message);
              // [this.params.page, this.params.total, this.params.parentId] = [1, 0, this.auditShowId]
              // this.showList(this.params)
              // this.dialogCl5MTwo = false
            }
          })
        }
      })
    },


    // 清除掉回调表单验证
    clearFiles (val) {
      if (this.$refs[val]) {
        this.$nextTick(() => {
          this.$refs[val].clearValidate()
        })
      }
    },
  },
  created () {
    this.showListTre()
    ListOrg().then(res => {
      this.archiveTypeNameArr = res.data
    })
    materialList().then(res => {
      // this.materialListArr = res.data
      this.materialListArr = res
    })
  }
}
</script>

<style scoped lang="less">
@import "../../css/public";
</style>
