<!-- 首页 -->
<template>
  <div style="width: 100%;overflow: auto">
    <!--首页主区域 -->
    <div class="main">
      <div class="home-main">
        <!-- 左区域 -->
        <div class="home-main-left">
          <!-- 左上 -->
          <div class="home-left-top home-h1">
            <p class="home-left-p1"><img class="left-p1-img1" src="../../assets/home/borrow.png" alt="" /><span>我的借阅</span><img @click="searchOutOne" class="left-p1-img2" src="../../assets/home/reset.png" alt="" /></p>
            <p class="home-left-p2">
              <span @click="openBorrow">
                <img src="../../assets/home/read.png" alt="" />
                <span class="pointerSpan">借阅</span>
              </span>
              <span @click="openDelete">
                <img src="../../assets/home/delete.png" alt="" />
                <span class="pointerSpan">删除</span>
              </span>
              <span @click="openOutRel">
                <img src="../../assets/home/rela.png" alt="" />
                <span class="pointerSpan">关联借阅人</span>
              </span>
            </p>
            <div>
              <el-table size="mini" class="home-t1" ref="multipleTable" @selection-change="outSelect" :data="outTable" border stripe>
                <el-table-column type="selection" width="40">
                </el-table-column>
                <el-table-column prop="titleProper" label="题名"></el-table-column>
              </el-table>
              <div class="home-left-page">
                <el-pagination @current-change="outCurrChange" :current-page="outParams.page" :page-size="outParams.rows" layout="prev, pager, next, jumper" :total="outParams.totals">
                </el-pagination>
              </div>
            </div>
          </div>
          <!-- 左下 -->
          <div class="home-left-top">
            <p class="home-left-p1"><span @click="transFlag = true"><img class="left-p1-img1" src="../../assets/home/trans.png" alt="" /><span>我的移交</span></span><img class="left-p1-img2" src="../../assets/home/Move.png" alt="" /></p>
            <div class="home-turn">
              <div class="turn-left">
                <el-table size="mini" ref="multipleTable" :data="transData1" border stripe class="turn-t1">
                  <el-table-column prop="serialNumber" label="移交正常"></el-table-column>
                </el-table>
                <div>
                  <el-pagination @current-change="transCurrChange1" :current-page="transParams1.page" :page-size="transParams1.rows" layout="prev, pager, next, jumper" :total="transParams1.totals">
                  </el-pagination>
                </div>
              </div>
              <div class="turn-right">
                <el-table size="mini" ref="multipleTable" :data="transData2" border stripe class="turn-t1">
                  <el-table-column prop="serialNumber" label="移交异常"></el-table-column>
                </el-table>
                <div>
                  <el-pagination @current-change="transCurrChange2" :current-page="transParams2.page" :page-size="transParams2.rows" layout="prev, pager, next, jumper" :total="transParams2.totals">
                  </el-pagination>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- 中区域 -->
        <div class="home-center">
          <div class="home-center-top">
            <p class="home-center-p1">
              <img src="../../assets/home/search.png" alt="" />
              <span>档案查询</span>
            </p>
            <div class="home-center-div">
              <p>
                <el-input v-model="keyWords" class="center-input" type="text" placeholer="请输入关键字进行检索"></el-input>
                <el-button class="center-btn" @click="searchKey">检索</el-button>
              </p>
            </div>
            <zt></zt>
          </div>
          <div class="sectTitle">
            <el-tabs v-model="activeName" @tab-click="handleClick">
              <el-tab-pane label="专题栏" name="first">专题栏</el-tab-pane>
              <el-tab-pane label="名人堂" name="second">名人堂</el-tab-pane>
              <el-tab-pane label="荣誉榜" name="third">荣誉榜</el-tab-pane>
            </el-tabs>
          </div>
        </div>
        <!-- 右区域 -->
        <div class="home-main-right">
          <!-- 右上 -->
          <div class="home-right-top">
            <p class="home-right-p1">
              <img class="right-p1-img1" src="../../assets/home/inform.png" alt="" />
              <span>通知公告</span>
              <span @click="openNew" class="c-p"><img class="right-p1-img2" src="../../assets/home/Move.png" alt="" /><span class="right-p1-span">MORE</span></span>
            </p>
            <div>
              <vue-seamless-scroll :data="newArr" class="seamless-warp" @click.native="parentClick">
                <ul class="item">
                  <li v-for="item in newArr">
                    <span class="title span1" :data-id="item.id">{{item.newstitle}}</span><span class="date span2">{{item.createtime}}</span>
                  </li>
                </ul>
              </vue-seamless-scroll>
            </div>
          </div>
          <!-- 右中 -->
          <div class="home-right-top">
            <p class="home-right-p1">
              <img class="right-p1-img1" src="../../assets/home/flowTitle.png" alt="" />
              <span>流程指引</span>
              <span @click="flowFlag= true"><img class="right-p1-img2" src="../../assets/home/Move.png" alt="" />
                <span class="right-p1-span">MORE</span>
              </span>
            </p>
            <div v-for="item in 6" class="right-content">
              <span class="span1">主题</span><span class="span2">2019-11-6</span>
            </div>
          </div>
          <!-- 右下 -->
          <div class="home-right-top">
            <p class="home-right-p1">
              <img class="right-p1-img1" src="../../assets/home/special.png" alt="" />
              <span>专项档案服务</span>
            </p>
            <taskforce></taskforce>
          </div>
        </div>
      </div>
      <!-- 借阅单所有弹框 -->
      <!-- 关联借阅人 -->
      <el-dialog :visible.sync="relAddFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicAdd.png" alt="">
          选择借阅人
        </div>
        <el-form :model="paramsAdd" :rules="rulesAudit" ref="paramsAdd" label-width="120px">
          <el-form-item label="部门：" prop="deptCode">
            <el-select v-model="paramsAdd.deptCode" filterable @change="searchUser">
              <el-option v-for="item in orgArr" :key="item.organizeId" :value="item.organizeId" :label="item.flag1 +'  '+ item.organizeName"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="用户名：" prop="userId">
            <el-select v-model="paramsAdd.userId" filterable>
              <el-option v-for="item in userArr" :key="item.userId" :value="item.userId" :label="item.userName"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer all-btn mt-31">
          <el-button type="primary" @click="clickCom">保存</el-button>
          <el-button @click="relAddFlag = false">关闭</el-button>
        </div>
      </el-dialog>
      <!-- 关联前确认 -->
      <el-dialog :visible.sync="confirmFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle2.png" alt="">
          确认
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要提交数据吗?</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="clickOutAdd">确定</el-button>
          <el-button @click="confirmFlag= false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 借阅单提交 -->
      <el-dialog :visible.sync="borrowFlag" class="hurdleAll" width="1170px">
        <div slot="title" class="dialog-title">
          <img src="../../assets/home/submit.png" alt />
          借阅单提交
        </div>
        <div>
          <div class="headerBtn mt-f14">
            <span @click="lendDel"><img src="../../assets/home/delete.png" alt="" />删除</span>
          </div>
          <div class="all-Table lend-table">
            <el-table :data="tableData" border @selection-change="handleSelectionChange">
              <el-table-column type="selection" width="55"></el-table-column>
              <el-table-column prop="officeArchivalCode" label="档号" width="180"></el-table-column>
              <el-table-column prop="titleProper" label="题名" width="200"></el-table-column>
              <el-table-column prop="fondsCode" label="全宗"></el-table-column>
              <el-table-column prop="openingType" label="公开属性">
                <template slot-scope="scope">
                  {{outPubArr[scope.row.openingType]}}
                </template>
              </el-table-column>
              <el-table-column prop="filingDept" label="归档部门"></el-table-column>
            </el-table>
          </div>
          <div>
            <div class="header-lend">电子借阅单</div>
            <el-form :model="showParams" :rules="rules" ref="showParams" label-width="190px">
              <el-row :gutter="10">
                <el-col :span="8">
                  <el-form-item label="借阅人：" prop="personName">
                    <el-input v-model="showParams.personName"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="8">
                  <el-form-item label="借阅部门：" prop="deptName">
                    <el-input v-model="showParams.deptName"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="8">
                  <el-form-item label="联系方式：" prop="tel">
                    <el-input v-model="showParams.tel"></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row :gutter="10">
                <el-col :span="8">
                  <el-form-item label="申请日期：" prop="startDate">
                    <el-input v-model="showParams.startDate"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="8">
                  <el-form-item label="借阅方式：" prop="borrowType">
                    <el-select v-model="showParams.borrowType" @change="$forceUpdate()">
                      <el-option v-for="item in borrowArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span="8">
                  <el-form-item label="借阅时间(天)：" prop="endDate">
                    <el-select v-model="showParams.endDate" @change="$forceUpdate()">
                      <el-option v-for="item in borrowDayArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row :gutter="10">
                <el-col :span="8">
                  <el-form-item label="是否加水印：" prop="watermarkFlag">
                    <el-select v-model="showParams.watermarkFlag" @change="$forceUpdate()">
                      <el-option v-for="item in waterArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <el-col :span="8">
                  <el-form-item label="对内/外部使用：" prop="brFaceTo">
                    <el-select v-model="showParams.brFaceTo" @change="$forceUpdate()">
                      <el-option v-for="item in faceArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
                <!-- 对外部使用 -->
                <el-col :span="8" v-if="showParams.brFaceTo ==1">
                  <el-form-item label="对外使用单位：" prop="brExternalDep1">
                    <el-select v-model="showParams.brExternalDep1" @change="$forceUpdate()">
                      <el-option v-for="item in exterArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                    </el-select>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row :gutter="10">
                <!-- 对外部使用 -->
                <el-col :span="8" v-if="showParams.brFaceTo ==1">
                  <el-form-item label="其他对外使用单位：" prop="brExternalDep2">
                    <el-input v-model="showParams.brExternalDep2" disabled></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-form-item label="借阅原因：" prop="reason">
                <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4}" v-model="showParams.reason"></el-input>
              </el-form-item>
              <!-- 借阅方式---选择实体借阅 -->
              <el-row :gutter="10">
                <el-col :span="8" v-if="showParams.borrowType ==2">
                  <el-form-item label="实体档案接收人姓名：" prop="acceptName">
                    <el-input v-model="showParams.acceptName"></el-input>
                  </el-form-item>
                </el-col>
                <el-col :span="8" v-if="showParams.borrowType ==2">
                  <el-form-item label="实体档案接收人联系电话：" prop="acceptTel">
                    <el-input v-model="showParams.acceptTel"></el-input>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-form-item label="实体档案接收人地址：" prop="acceptAddr" v-if="showParams.borrowType ==2">
                <el-input type="textarea" :autosize="{ minRows: 1, maxRows: 1}" v-model="showParams.acceptAddr"></el-input>
              </el-form-item>
              <!-- 选择电子文档无水印 -->
              <el-form-item label="选择无水印原因：" prop="watermarkReason" v-if="showParams.watermarkFlag==2">
                <el-input type="textarea" :autosize="{ minRows: 2, maxRows: 4}" v-model="showParams.watermarkReason"></el-input>
              </el-form-item>
              <el-form-item label="是否修改：" prop="brChange" v-if="showParams.borrowType ==2">
                <el-radio v-model="showParams.brChange" label="1">是</el-radio>
                <el-radio v-model="showParams.brChange" label="0">否</el-radio>
              </el-form-item>
              <el-form-item prop="agreement2" v-if="showParams.borrowType ==2" class="requirIterm">
                <el-checkbox v-model="showParams.agreement2">擅自伪造、修改、抽换、隐匿或销毁档案的，属违法行为，将受法律追究！</el-checkbox>
              </el-form-item>
            </el-form>
            <div slot="footer" class="dialog-footer all-btn">
              <el-button type="primary" @click="clickOrder">提交订阅</el-button>
              <el-button @click="borrowFlag= false">关闭</el-button>
            </div>
          </div>
        </div>
      </el-dialog>
      <!-- 删除借阅单 -->
      <el-dialog :visible.sync="deleteFlage" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/topicDel.png" alt="">
          删除
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>确定要删除借阅单吗？</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="clickDelete">确定</el-button>
          <el-button @click=" deleteFlage= false">取消</el-button>
        </div>
      </el-dialog>
      <!-- 我的移交弹框 -->
      <el-dialog class="give hand-over" :visible.sync="transFlag">
        <div slot="title" class="titl">
          <img src="../../assets/home/send.png" alt />
          移交状态
        </div>
        <table class="content" cellspacing="0" cellpadding="0" border="0">
          <tr>
            <td>文件号</td>
            <td>111</td>
          </tr>
          <tr>
            <td>合同号</td>
            <td>111</td>
          </tr>
          <tr>
            <td>文件标题</td>
            <td>111</td>
          </tr>
          <tr>
            <td>对方单位</td>
            <td>111</td>
          </tr>
          <tr>
            <td>文件日期</td>
            <td>111</td>
          </tr>
          <tr>
            <td>文件类型</td>
            <td>111</td>
          </tr>
          <tr>
            <td>是否原件</td>
            <td>111</td>
          </tr>
          <tr>
            <td>公章等级</td>
            <td>111</td>
          </tr>
          <tr>
            <td>移交异常</td>
            <td>111</td>
          </tr>
        </table>
      </el-dialog>
      <!-- 通知公告 -->
      <el-dialog :visible.sync="newFlage" class="inform give">
        <div slot="title" class="titl">
          <img src="../../assets/home/newList.png" alt />
          通知公告
        </div>
        <div>
          <el-table border :data="newTable" highlight-current-row @current-change="selectNews">
            <el-table-column prop="newsTitle" label="题名"></el-table-column>
            <el-table-column prop="createTime" label="创建时间"></el-table-column>
          </el-table>
          <div class="page">
            <el-pagination @current-change="newCurrChange" :current-page="newListPar.page" :page-size="newListPar.rows" layout="prev, pager, next, jumper" :total="newListPar.totals">
            </el-pagination>
          </div>
        </div>
      </el-dialog>
      <!-- 通知公告-阅读 -->
      <el-dialog :visible.sync="readFlag" class="give read">
        <div slot="title" class="titl">
          <img src="../../assets/home/newList.png" alt />
          新闻详细内容
        </div>
        <div class="read-content">
          <p class="read-p1">{{newContent.newsTitle}}</p>
          <p class="read-p2"><span class="read-p2-span">新闻来源: {{newContent.newsAuthor}}</span><span>发布时间: {{newContent.newsDate}}</span></p>
          <div class="read-div" v-html="newContent.newsContent"></div>
        </div>
        <div class="gray-button">
          <el-button type="primary" class="borrow" @click="onRead">
            已读
          </el-button>
          <el-button type="primary" class="borrow" @click="readFlag = false">
            未读
          </el-button>
        </div>
      </el-dialog>
      <!-- 流程指引 -->
      <el-dialog :visible.sync="flowFlag" class="give process">
        <div slot="title" class="titl">
          <img src="../../assets/home/flowTitle.png" alt />
          流程指引
        </div>
        <div class="process-content">
          <div class="left">
            <div class="headline-top">全部</div>
            <div v-for="(item,index) in flowData" :key="index" class="headline" @click="toContent(item)">
              <img src="../../assets/home/yuan.png" alt="" />
              {{item.title}}
            </div>
          </div>
          <div class="right">
            <div class="content-top">
              替代文字
            </div>
            <div class="content">{{active}}</div>
          </div>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import zt from '../../components/zt/zt';
import taskforce from '../../components/specialScheme/taskforce'
import { outList, borrowList, showBorrowDetail, outDelete, submitOrder, successTrans, errorTrans, searchArchive, topNew, listNew, detailNew, readNew, getListDept, saveRead, getListOrg } from '@/js/getData.js'
export default {
  name: 'homePage',
  components: {
    zt,
    taskforce
  },
  data() {
    const validateRe = (rule, value, callback) => {
      let reg = /^[\s\S]{11,}$/
      if (!reg.test(value)) {
        callback(new Error('请详细填写借阅原因（内容长度需大于10）！'))
      } else {
        callback();
      }
    }
    return {
      outPubArr: ['', '公开', '内部', '受控', '广发商密三级', '广发商密二级', '广发商密一级'],
      activeName: 'second',
      // 借阅
      deleteFlage: false,
      outTable: [],
      outParams: {
        page: 1,
        rows: 8,
        totals: null
      },
      outLength: null,
      outIds: [],
      tableData: [],
      currentPage1: 1,
      borrowFlag: false,
      showParams: {
        type: 'p',
        personName: null,
        deptName: null,
        tel: null,
        borrowType: null,
        startDate: null,
        endDate: null,
        watermarkFlag: null,
        reason: null,
        brFaceTo: null,
      },
      rulesAudit: {
        deptCode: [
          { required: true, message: '请选择借阅人', trigger: 'change' }
        ],
        userId: [
          { required: true, message: '请选择用户名', trigger: 'change' }
        ],
      },
      rules: {
        personName: [
          { required: true, message: '请输入借阅人', trigger: 'blur' }
        ],
        deptName: [
          { required: true, message: '请输入借阅部门', trigger: 'blur' }
        ],
        tel: [
          { required: true, message: '请输入联系方式', trigger: 'blur' }
        ],
        startDate: [
          { required: true, message: '请输入申请日期', trigger: 'blur' }
        ],
        region: [
          { required: true, message: '请选择活动区域', trigger: 'change' }
        ],
        borrowType: [
          { required: true, message: '请选择借阅方式', trigger: 'change' }
        ],
        endDate: [
          { required: true, message: '请选择借阅时间', trigger: 'change' }
        ],
        watermarkFlag: [
          { required: true, message: '请选择是否加水印', trigger: 'change' }
        ],
        brFaceTo: [
          { required: true, message: '请选择使用方式', trigger: 'change' }
        ],
        brExternalDep1: [
          { required: true, message: '请选择对外使用单位', trigger: 'change' }
        ],
        reason: [
          { required: true, message: '请输入借阅原因', trigger: 'blur' },
          { validator: validateRe, trigger: 'blur' }
        ],
        acceptName: [
          { required: true, message: '请输入实体档案接收人姓名', trigger: 'blur' }
        ],
        acceptTel: [
          { required: true, message: '请输入实体档案接收人联系电话', trigger: 'blur' }
        ],
        acceptAddr: [
          { required: true, message: '请输入实体档案接收人地址', trigger: 'blur' }
        ],
        brChange: [
          { required: true, message: '请选择是否修改', trigger: 'change' }
        ],
        watermarkReason: [
          { required: true, message: '请输入选择无水印原因', trigger: 'blur' }
        ],
        agreement2: [
          { required: true, message: '请勾选借阅协议!', trigger: 'change' }
        ]
      },
      paramsAdd: {},
      oneTable: [],
      relAddFlag: false,
      orgArr: [],
      userArr: [],
      confirmFlag: false,
      // 借阅方式
      borrowArr: [{ 'name': '电子借阅', 'itemValue': '1' }, { 'name': '实体借阅', 'itemValue': '2' }],
      // 借阅时间
      borrowDayArr: [{ 'name': '2', 'itemValue': '2' }, { 'name': '3', 'itemValue': '3' }, { 'name': '4', 'itemValue': '4' }, { 'name': '5', 'itemValue': '5' }, { 'name': '6', 'itemValue': '6' }, { 'name': '7', 'itemValue': '7' }, { 'name': '8', 'itemValue': '8' }, { 'name': '9', 'itemValue': '9' }, { 'name': '10', 'itemValue': '10' }, { 'name': '20', 'itemValue': '20' }, { 'name': '30', 'itemValue': '30' }, { 'name': '50', 'itemValue': '50' }],
      // 是否加水印
      waterArr: [{ name: '电子文档添加水印', itemValue: '1' }, { name: '电子文档无水印', itemValue: '2' }],
      // 对内/外部使用
      faceArr: [{ 'name': '内部', 'itemValue': '0' }, { 'name': '外部', 'itemValue': '1' }],
      // 对外使用单位
      exterArr: [{ 'name': '证监会', 'itemValue': '证监会' }, { 'name': '人民银行', 'itemValue': '人民银行' }, { 'name': '公安机关', 'itemValue': '公安机关' }, { 'name': '外汇管理局', 'itemValue': '外汇管理局' }, { 'name': '纪委', 'itemValue': '纪委' }, { 'name': '审计署', 'itemValue': '审计署' }, { 'name': '财政部门', 'itemValue': '财政部门' }, { 'name': '税务部门', 'itemValue': '税务部门' }, { 'name': '政府机关', 'itemValue': '政府机关' }, { 'name': '其他', 'itemValue': '其他' }],
      diaParams: {
        type: 'p'
      },
      // 移交
      transFlag: false,
      transParams1: {
        page: 1,
        rows: 6,
        totals: null
      },
      transData1: [],
      transParams2: {
        page: 1,
        rows: 6,
        totals: null
      },
      transData2: [],
      // 档案查询
      keyWords: null,
      // 通知公告
      newParams: {
        columnId: '8a8262025a49cb81015a49ce29740001',
        rows: 5
      },
      newArr: [],
      newFlage: false,
      newTable: [],
      newListPar: {
        page: 1,
        rows: 10,
        totals: null
      },
      readFlag: false,
      newsId: null,
      newContent: {},
      // 流程指引
      flowFlag: false,
      active: null,
      flowData: [
        { title: '替代文字', content: '替代文字替代文字替代文字替代文字替代文字替代文字11' },
        { title: '替代文字', content: '替代文字替代文字替代文字替代文字替代文字替代文字22' }
      ],
      // 专责小组
      groupFlag: false,
      groupsTable: []
    }
  },
  methods: {
    parentClick(e) {
      if (e.target.tagName == 'SPAN') { // 判断事件源是否是SPAN标签
        if (e.target.dataset.id) { // 这里获取点击节点的 data-id
          this.openShow(e.target.dataset.id)
        }
      }
    },
    handleClick(tab, event) {
      console.log(tab, event)
    },
    // 借阅最外层列表
    searchOutOne() {
      this.outParams.page = 1;
      this.searchOut()
    },
    searchOut() {
      outList(this.outParams).then(res => {
        if (res.code == 0) {
          this.outTable = res.data.rows
          this.outParams.totals = res.data.total
        } else this.$message.error(res.message)
      })
    },
    outCurrChange(val) {
      this.outParams.page = val
      this.searchOut()
    },
    // 最外层列表选中下拉框
    outSelect(val) {
      this.outLength = val.length
      this.outIds = []
      val.forEach(item => {
        this.outIds.push(item.id)
      })
    },
    // 借阅单删除(最外层)
    openDelete() {
      if (this.outLength < 1) {
        this.$message.error('请选择数据！')
      } else {
        this.deleteFlage = true
      }
    },
    clickDelete() {
      let ids = this.outIds.join(',')
      outDelete({ borrowCarIds: ids }).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
          this.searchOutOne();
          this.deleteFlage = false
        } else this.$message.error(res.message)
      })
    },
    //关联借阅人
    openOutRel() {
      if (this.outLength < 1) {
        this.$message.error('请选择数据！')
      } else {
        this.searchOrg();
        this.paramsAdd = {};
        this.relAddFlag = true;
        if (this.$refs['paramsAdd']) {
          this.$nextTick(() => {
            this.$refs['paramsAdd'].clearValidate();
          })
        }
      }
    },
    //获取关联借阅人--下拉部门
    searchOrg(val) {
      getListOrg({ id: val }).then(res => {
        if (res.code == 0) {
          this.orgArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //获取关联借阅人--下拉用户(选中部门查询用户)
    searchUser(val) {
      getListDept({ id: val }).then(res => {
        if (res.code == 0) {
          this.userArr = res.data || [];
        } else this.$message.error(res.message)
      })
    },
    //关联借阅人前-确认
    clickCom() {
      this.$refs['paramsAdd'].validate((valid) => {
        if (valid) {
          this.relAddFlag = false;
          this.confirmFlag = true;
        }
      })
    },
    //关联借阅人
    clickOutAdd() {
      let ids = this.outIds.join(',')
      this.paramsAdd.borrowCarIds = ids;
      saveRead(this.paramsAdd).then(res => {
        if (res.code == 0) {
          this.confirmFlag = false;
          this.$message.success('操作成功!');
          this.searchOutOne();
        } else this.$message.error(res.message)
      })
    },
    // 打开借阅弹框
    openBorrow() {
      if (this.outLength < 1) {
        this.$message.error('请选择数据！')
      } else {
        this.searchBorrowDetail()
        this.searchBorrowList()
        this.borrowFlag = true;
        this.showParams = {
          type: 'p',
          personName: null,
          deptName: null,
          tel: null,
          borrowType: null,
          startDate: null,
          endDate: null,
          watermarkFlag: null,
          reason: null,
          brFaceTo: null,
        };
        if (this.$refs['showParams']) {
          this.$nextTick(() => {
            this.$refs['showParams'].clearValidate();
          })
        }
      }
    },
    // 查询借阅弹框列表
    searchBorrowList() {
      let ids = this.outIds.join(',')
      this.diaParams.borrowCarIds = ids
      borrowList(this.diaParams).then(res => {
        if (res.code == 0) {
          this.tableData = res.data
        } else this.$message.error(res.message)
      })
    },
    // 查询弹框详情
    searchBorrowDetail() {
      let ids = this.outIds.join(',')
      let detail = {
        borrowCarIds: ids
      }
      this.showParams.borrowCarIds = ids
      this.showParams.infoIds = ids
      showBorrowDetail(detail).then(res => {
        if (res.code == 0) {
          this.showParams.personName = res.data.userName
          this.showParams.deptName = res.data.tOrgName
          this.showParams.tel = res.data.mobile
          this.showParams.borrowType = res.data.type || null
          this.showParams.startDate = res.data.startDate || null,
            this.showParams.endDate = this.borrowDayArr[0].itemValue
          this.showParams.watermarkFlag = this.waterArr[0].itemValue
        } else this.$message.error(res.message)
      })
    },
    // 提交订阅
    clickOrder() {
      this.showParams.infoIds = this.$onceWay().deleteId(this.oneTable)
      this.$refs['showParams'].validate((valid) => {
        if (valid) {
          if (this.oneTable.length > 0) {
            submitOrder(this.showParams).then(res => {
              if (res.code == 0) {
                this.$message.success(res.message)
                this.searchOutOne()
                this.borrowFlag = false
              } else this.$message.error(res.message)
            })
          }else this.$message.error('请至少选择一条待借阅档案！')
        }
      })
    },
    handleSelectionChange(val) {
      this.oneTable = val;
    },
    //订阅删除
    lendDel() {
      let open = this.$onceWay().onceTableList(this.oneTable);
      if (open == 1) {
        let index = this.tableData.indexOf(this.oneTable[0])
        this.tableData.splice(index, 1);
      }
    },
    // 移交
    // 移交成功列表
    searchTrans1() {
      successTrans(this.transParams1).then(res => {
        if (res.code == 0) {
          /*        this.transData1 = res.data.rows
                  this.transParams1.totals = res.data.total*/
        } else this.$message.error(res.message)
      })
    },
    transCurrChange1(val) {
      this.transParams1.page = val
      this.searchTrans1()
    },
    // 移交失败列表
    searchTrans2() {
      errorTrans(this.transParams2).then(res => {
        if (res.code == 0) {
          /*          this.transData2 = res.data.rows
                    this.transParams2.totals = res.data.total*/
        } else this.$message.error(res.message)
      })
    },
    transCurrChange2(val) {
      this.transParams2.page = val
      this.searchTrans2()
    },
    // 档案查询
    searchKey() {
      searchArchive({ keyWords: this.keyWords }).then(res => {
        if (res.code == 0) {
          window.open(res.data)
        } else this.$message.error(res.message)
      })
    },
    // 通知公告
    // 通知公告--内容
    searchNew() {
      topNew(this.newParams).then(res => {
        if (res.code == 0) {
          this.newArr = res.data
        } else this.$message.error(res.message)
      })
    },
    // 通知公告--通知列表
    openNew() {
      this.searchNewList()
      this.newFlage = true
    },
    searchNewList() {
      listNew(this.newListPar).then(res => {
        if (res.code == 0) {
          this.newTable = res.data.rows
          this.newListPar.totals = res.data.total
        } else this.$message.error(res.message)
      })
    },
    newCurrChange(val) {
      this.newListPar.page = val
      this.searchNewList()
    },
    // 通知公告单选--详情弹框
    openShow(val) {
      this.newDetail(val)
      this.newsId = val
      this.readFlag = true
    },
    selectNews(val) {
      let ids = val.id
      this.newsId = val.id
      this.newDetail(ids)
      this.readFlag = true
    },
    newDetail(val) {
      detailNew({ newsId: val }).then(res => {
        if (res.code == 0) {
          this.newContent = res.data
        } else this.$message.error(res.message)
      })
    },
    // 我的广告--已读
    onRead() {
      readNew({ newsId: this.newsId }).then(res => {
        if (res.code == 0) {
          this.$message.success(res.message)
        } else this.$message.error(res.message)
      })
    },
    // 流程指引
    toContent(index) {
      this.active = index.content
    }
  },
  created() {
    // 我的借阅列表
    this.searchOut()
    // 我的正常移交
    this.searchTrans1()
    // 我的失败移交
    this.searchTrans2()
    // 我的通知公告
    this.searchNew()
  }
}

</script>
<style scoped lang="less">
@import "../../css/dialog";
@import "../../css/public";

.lend-table {
  max-height: 200px;
  overflow-y: auto;
  width: 100%
}

.home-h1 {
  height: 456px !important;
}

.home-t1 {
  width: 100%;
  height: 337px;
  overflow-y: auto;

}

.home-turn {
  width: 100%;
  clear: both;

  .turn-left {
    width: 49.5%;
    float: left;
  }

  .turn-right {
    width: 49.5%;
    float: left;
  }

  .turn-t1 {
    width: 100%;
    height: 249px;
    overflow-y: auto;
  }
}

.c-p {
  cursor: pointer;
}

/deep/.requirIterm {
  margin-top: -20px;

  .el-checkbox,
  .el-checkbox__input.is-checked+.el-checkbox__label {
    color: #F44336;
  }

  .el-checkbox__input.is-checked .el-checkbox__inner {
    background-color: #F44336;
    border-color: #F44336;
  }
}

.el-carousel__item h3 {
  color: #475669;
  font-size: 14px;
  opacity: 0.75;
  line-height: 200px;
  margin: 0;
}

.el-carousel__item:nth-child(2n) {
  background-color: #99a9bf;
}

.el-carousel__item:nth-child(2n+1) {
  background-color: #d3dce6;
}

.headerTop {
  padding: 0;
  background-color: #004892;
  height: 51px !important;
}

.left-p1 {
  width: 100%;
  height: 51px;
  line-height: 51px;
  background-color: #00A7EB;

  img {
    vertical-align: middle;
    margin-left: 8px;
  }
}

.left-p2 {
  height: 43px;
  background-color: #E60E10;
  line-height: 43px;

  span {
    margin-left: 8px;
    color: #fff;
    font-size: 12px;
  }

  img {
    vertical-align: middle;
    margin-left: 120px;
  }

}

.left-search {
  position: fixed;
  bottom: 89px;

  .search-top {
    width: 211px;
    height: 137px;
    margin-left: 10px;
    background-color: #525252;

    .top-one {
      padding-top: 19px;
      clear: both;

      img {
        margin-left: 10px;
        margin-right: 9px;
        float: left;
      }

      .top-p {
        display: inline-block;

        span {
          display: block;
        }

        .top-span1 {
          margin-bottom: 6px;
          font-size: 12px;
          color: #E8EDF4
        }

        .top-span2 {
          width: 144px;
          height: 20px;
        }

      }
    }

  }

  .search-out {
    margin-top: 9px;
    width: 211px;
    height: 31px;
    margin-left: 10px;
    background-color: #525252;

    p {
      text-align: center;
      font-size: 12px;
      color: #E8EDF4;
      height: 31px;
      line-height: 31px;

      img {
        vertical-align: middle;
        margin-top: -3px;
        margin-right: 5px;
      }
    }
  }

}

.home-footer {
  width: 100%;
  height: 28px;
  background-color: #D2EFFF;
  border: 1px solid #0273B4;
  font-size: 12px;
  color: #282828;
  line-height: 28px;
  clear: both;
  position: fixed;
  bottom: 0px;
  left: 0px;
  z-index: 1299;

  .span1 {
    float: left;
    margin-left: 11px;
  }

  .span2 {
    float: right;
    margin-right: 20px;

    .span3 {
      margin-left: 20px;
      color: #515BED;
    }
  }
}

.main {
  background-color: #E8EDF4;
  width: 100%;
  min-width: 1400px;

  .home-main {
    .home-main-left {
      display: inline-block;
      float: left;
      width: 31%;
      background: #fff;
      padding: 10px;

      .home-left-top {
        height: 320px;
        margin: 0 0 10px 0;
        border: 1px solid #00A7EB;
        overflow: auto;

        .home-left-p1 {
          height: 28px;
          background: #00A7EB;
          color: #fff;
          font-size: 14px;
          line-height: 28px;

          .left-p1-img1 {
            vertical-align: middle;
            margin-left: 6px;
            margin-right: 5px;
            margin-top: -3px;
          }

          .left-p1-img2 {
            float: right;
            margin-top: 4px;
            margin-right: 3px;
            cursor: pointer;
          }
        }

        .home-left-p2 {
          height: 50px;
          line-height: 50px;
          font-size: 14px;
          color: #282828;

          img {
            vertical-align: middle;
            margin-left: 8px;
            margin-right: 7px;
          }

          span {
            margin-right: 18px;
            cursor: pointer;
          }
        }
      }
    }
  }
}

.mt-f14 {
  margin-top: -14px;
}

.home-left-page {
  width: 100%;
  height: 35px;
  line-height: 25px;
  margin-top: 5px;
}

.home-center {
  display: inline-block;
  float: left;
  width: 37%;
  background: #fff;
  margin-left: 0.5%;
  padding: 10px;

  .home-center-top {
    min-height: 380px;
  }

  .home-center-p1 {
    height: 28px;
    background: #0067AD;
    color: #fff;
    font-size: 14px;
    line-height: 28px;

    img {
      vertical-align: middle;
      margin-left: 6px;
      margin-right: 5px;
      margin-top: -3px;
    }
  }

  .home-center-div {
    height: 73px;
    background-color: #E8EDF4;
    line-height: 73px;

    .center-input {
      margin-left: 6%;
      width: 71%;
      height: 34px;
    }

    .center-btn {
      width: 17%;
      background-color: #0067AD;
      color: #fff;
      font-size: 14px;
    }
  }

  .home-center-div1 {
    height: 310px;
  }
}

.home-main-right {
  display: inline-block;
  float: left;
  width: 25%;
  background: #fff;
  padding: 10px;
  margin-left: 0.5%;

  .home-right-top {
    min-height: 246px;
    max-height: 273px;
    margin: 0 0 10px 0;
    border: 1px solid #004892;
    overflow: auto;

    .home-right-p1 {
      height: 28px;
      background: #004892;
      color: #fff;
      font-size: 14px;
      line-height: 28px;

      .right-p1-img1 {
        vertical-align: middle;
        margin-left: 6px;
        margin-right: 5px;
        margin-top: -3px;
      }

      .right-p1-img2 {
        float: right;
        margin-top: 4px;
        margin-right: 3px;
      }

      .right-p1-span {
        font-size: 12px;
        float: right;
        margin-right: 3px;
        margin-top: -1px;
      }
    }

    .home-right-p2 {
      height: 50px;
      line-height: 50px;
      font-size: 14px;
      color: #282828;

      img {
        vertical-align: middle;
        margin-left: 8px;
        margin-right: 7px;
      }

      span {
        margin-right: 18px;
      }
    }
  }
}

.pointerSpan {
  cursor: pointer;
}

//我的广告
.seamless-warp {
  height: 244px;
  overflow: hidden;
  clear: both;
  width: 100%;
  overflow-x: auto;

  li {
    line-height: 32px;
    font-size: 14px;
  }

  .span1 {
    color: #282828;
    margin-left: 12px;
    width: 154px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    display: inline-block;
    cursor: pointer;
  }

  .span2 {
    color: #7E7E7E;
    margin-right: 12px;
    float: right;
  }
}

.right-content {
  span {
    line-height: 32px;
    font-size: 14px;
  }

  .span1 {
    color: #282828;
    margin-left: 12px
  }

  .span2 {
    color: #7E7E7E;
    margin-right: 12px;
    float: right;
  }
}

.right-bottom-content {
  margin-top: 20px;
  clear: both;

  .bottom-div {
    margin-left: 10px;
    float: left;
    display: inline-block;
    width: 22%;
    height: 98px;

    .bottom-div-p1 {
      height: 54px;
      background-color: #004892;
      text-align: center;
      line-height: 54px;

      img {
        vertical-align: middle;
      }
    }

    .bottom-div-p2 {
      text-align: center;
      font-size: 14px;
      color: #282828
    }
  }
}

/deep/.hurdleAll>div>div:first-child {
  padding: 0 !important;

  >div {
    height: 30px;
    line-height: 30px;
    text-indent: 10px;
    font-size: 14px;
    color: #fff;
  }

  button {
    top: 8px;

    i {
      color: #fff;
    }
  }
}

</style>
<style lang="less">
.top-span2 {
  .el-input__inner {
    height: 20px !important;
    line-height: 20px !important;
  }

  .el-input__icon {
    line-height: 20px !important;
  }
}

.sectTitle {
  min-height: 420px;

  .el-tabs__item {
    width: 140px !important;
    text-align: center;
  }

  .el-tab-pane {
    height: 320px;
    overflow: auto;
  }
}

</style>
