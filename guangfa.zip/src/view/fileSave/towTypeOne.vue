<!-- 条件3 -->
<template>
  <div>
    <div>
      <div>
        <div class="headerBtn mb-20">
          <span @click="openView"><img src="../../assets/confirmed/a4.png" alt="">查看</span>
          <span @click="openSea"><img src="../../assets/system/p8.png" alt="">检索</span>
        </div>
        <!-- 表格 -->
        <div>
          <div class='all-Table' style="max-height: 530px;overflow-y: auto;">
            <el-table :data="fileData" stripe border @selection-change="fileSelect">
              <el-table-column type="selection" width="55">
              </el-table-column>
              <el-table-column prop="c18" label="项目编号" width="120px">
              </el-table-column>
              <el-table-column prop="titleProper" label="项目名称" width="140px">
              </el-table-column>
              <el-table-column prop="yearCode" label="年度" width="100px">
              </el-table-column>
              <el-table-column prop="seriesCode" label="分类号" width="150px">
              </el-table-column>
              <el-table-column prop="filingDept" label="归档部门" width="140px">
              </el-table-column>
              <el-table-column prop="filingUser" label="归档人">
              </el-table-column>
              <el-table-column prop="filingDate" label="归档日期" width="120px">
              </el-table-column>
              <el-table-column prop="lastDate" label="提交时间" width="160px">
              </el-table-column>
            </el-table>
          </div>
          <!-- 分页 -->
          <div class="pageLayout">
            <el-pagination @current-change="fileCurr" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
            </el-pagination>
          </div>
        </div>
        <!-- 下方查看 -->
        <div>
          <el-tabs v-model="bottomShow" type="card" @tab-click="bottomClick">
            <el-tab-pane label="案卷层" name="first">
              <div class="headerBtn mb-20">
                <span @click="openSee1"><img src="../../assets/confirmed/a4.png" alt="">查看</span>
              </div>
              <div class='all-Table'>
                <el-table :data="folderData" stripe border @selection-change="folderSelect">
                  <el-table-column type="selection" width="55">
                  </el-table-column>
                  <el-table-column prop="c11" label="项目名称" width="200px">
                  </el-table-column>
                  <el-table-column prop="folderNo" label="案卷号" width="140px">
                  </el-table-column>
                  <el-table-column prop="titleProper" label="案卷题名">
                  </el-table-column>
                  <el-table-column prop="openingType" label="公开属性" width="100px">
                    <template slot-scope="scope">
                      {{pubArr[scope.row.openingType]}}
                    </template>
                  </el-table-column>
                  <el-table-column prop="retentionPeriod" label="保管期限" width="120px">
                    <template slot-scope="scope">
                      {{saveArr[scope.row.retentionPeriod]}}
                    </template>
                  </el-table-column>
                  <el-table-column prop="seriesCode" label="分类号" width="120px">
                  </el-table-column>
                  <el-table-column prop="c19" label="编制单位" width="120px">
                  </el-table-column>
                  <el-table-column prop="filingDept" label="归档部门" width="160px">
                  </el-table-column>
                  <el-table-column prop="filingUser" label="归档人" width="120px">
                  </el-table-column>
                  <el-table-column prop="filingDate" label="归档日期" width="120px">
                  </el-table-column>
                </el-table>
              </div>
              <!-- 分页 -->
              <div class="pageLayout">
                <el-pagination @current-change="folderCurr" :current-page="folderParams.page" :page-size="folderParams.rows" layout="prev, pager, next, jumper" :total="folderParams.total">
                </el-pagination>
              </div>
            </el-tab-pane>
            <el-tab-pane label="文件层" name="second">
              <div class="headerBtn mb-20">
                <span @click="openSee2"><img src="../../assets/confirmed/a4.png" alt="">查看</span>
              </div>
              <div class='all-Table'>
                <el-table :data="hangData" stripe border @selection-change="hangSelect">
                  <el-table-column type="selection" width="55">
                  </el-table-column>
                  <el-table-column prop="c220" label="案卷号" width="120px">
                  </el-table-column>
                  <el-table-column prop="c72" label="章节号" width="120px">
                  </el-table-column>
                  <el-table-column prop="titleProper" label="文件题号" width="400px">
                  </el-table-column>
                  <el-table-column prop="dateOfCreation" label="文件日期" width="120px">
                  </el-table-column>
                  <el-table-column prop="yearCode" label="年度" width="120px">
                  </el-table-column>
                  <el-table-column prop="c229" label="页号" width="120px">
                  </el-table-column>
                  <el-table-column prop="openingType" label="公开属性" width="100px">
                    <template slot-scope="scope">
                      {{pubArr[scope.row.openingType]}}
                    </template>
                  </el-table-column>
                  <el-table-column prop="retentionPeriod" label="保管期限" width="120px">
                    <template slot-scope="scope">
                      {{saveArr[scope.row.retentionPeriod]}}
                    </template>
                  </el-table-column>
                  <el-table-column prop="seriesCode" label="分类号" width="100px">
                  </el-table-column>
                  <el-table-column prop="c76" label="索引备注" width="160px">
                  </el-table-column>
                  <el-table-column prop="c77" label="情况说明" width="160px">
                  </el-table-column>
                  <el-table-column prop="filingDept" label="归档部门" width="160px">
                  </el-table-column>
                  <el-table-column prop="filingUser" label="归档人" width="100px">
                  </el-table-column>
                  <el-table-column prop="filingDate" label="归档日期" width="100px">
                  </el-table-column>
                  <el-table-column prop="caseNo" label="盒号" width="100px">
                  </el-table-column>
                </el-table>
              </div>
              <!-- 分页 -->
              <div class="pageLayout">
                <el-pagination @current-change="hangCurr" :current-page="hangParams.page" :page-size="hangParams.rows" layout="prev, pager, next, jumper" :total="hangParams.total">
                </el-pagination>
              </div>
            </el-tab-pane>
          </el-tabs>
        </div>
      </div>
    </div>
    <!-- 检索系统提示 -->
    <el-dialog :visible.sync="titleFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        {{titleMsg1}}
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>{{titleMsg2}}</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="titleFlag = false">确定</el-button>
      </div>
    </el-dialog>
    <!-- 检索 -->
    <el-dialog :visible.sync="seaFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/u2.png" alt="">
        检索
      </div>
      <el-form :model="paramsSea" label-width="120px" style="height: 419px;overflow-y: auto;">
        <el-form-item label="档案类型：">
          <el-input v-model="paramsSea.thseriesCode"></el-input>
        </el-form-item>
        <el-form-item label="归档部门：">
          <el-select v-model="paramsSea.thfilingDept" class="w-100" filterable>
            <el-option v-for="item in deptArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="项目编号：">
          <el-input v-model="paramsSea.thc18"></el-input>
        </el-form-item>
        <el-form-item label="年度：">
          <el-input v-model="paramsSea.thyearCode"></el-input>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="paramsSea.thc5" class="w-100" filterable>
            <el-option v-for="item in statusArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="股票代码：">
          <el-input v-model="paramsSea.thc10"></el-input>
        </el-form-item>
        <el-form-item label="项目单位全称：">
          <el-input v-model="paramsSea.thc24"></el-input>
        </el-form-item>
        <el-form-item label="项目名称：">
          <el-input v-model="paramsSea.thtitleProper"></el-input>
        </el-form-item>
        <el-form-item label="项目类型：">
          <el-input v-model="paramsSea.thc20"></el-input>
        </el-form-item>
        <el-form-item label="业务类型：">
          <el-input v-model="paramsSea.thc22"></el-input>
        </el-form-item>
        <el-form-item label="承做单位：">
          <el-input v-model="paramsSea.thc28"></el-input>
        </el-form-item>
        <el-form-item label="存址号：">
          <el-input v-model="paramsSea.addressNo"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="searchSea">检索</el-button>
        <el-button type="primary" @click="paramsSea ={}">重置条件</el-button>
        <el-button @click="seaFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 查看 -->
    <!-- 查看中的详情 -->
    <el-dialog :visible.sync="seeFlag" width="1100px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicShow.png" alt="">
        档案查看
      </div>
      <div class="see">
        <div class="see-left">
          <el-tree class="filter-tree" :highlight-current="true" ref="treeShow" node-key="id" :expand-on-click-node="false" :data="dataShow" default-expand-all :props="defaultProps" @node-click="handleNodeClick">
          </el-tree>
        </div>
        <div class="see-right">
          <el-tabs v-model="activeName" type="card">
            <!-- 项目基本信息 -->
            <el-tab-pane label="基本信息" name="first" v-if="showType =='p'">
              <el-form :model="paramsDetail" label-width="120px">
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="档案类型：">
                      <el-input v-model="paramsDetail.seriesCode"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="归档部门：">
                      <el-select v-model="paramsDetail.filingDept" class="w-100" filterable>
                        <el-option v-for="item in deptArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="项目编号：">
                      <el-input v-model="paramsDetail.c18"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="年度：">
                      <el-input v-model="paramsDetail.yearCode"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="股票代码：">
                      <el-input v-model="paramsDetail.c10"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="项目单位全称：">
                      <el-input v-model="paramsDetail.c24"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="项目名称：">
                      <el-input v-model="paramsDetail.titleProper"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="项目类型：">
                      <el-input v-model="paramsDetail.c20"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="业务类型：">
                      <el-input v-model="paramsDetail.c22"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="承做单位：">
                      <el-input v-model="paramsDetail.c28"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
            </el-tab-pane>
            <!-- 案卷基本信息 -->
            <el-tab-pane label="基本信息" name="first" v-if="showType =='v'">
              <el-form :model="paramsDetail" label-width="120px">
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="项目名称：">
                      <el-input v-model="paramsDetail.c11"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="保管期限：">
                      <el-select v-model="paramsDetail.retentionPeriod" class="w-100" filterable>
                        <el-option v-for="item in saveDateArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-form-item label="案卷题名：">
                  <el-input v-model="paramsDetail.titleProper"></el-input>
                </el-form-item>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="编制单位：">
                      <el-input v-model="paramsDetail.c19"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="年度：">
                      <el-input v-model="paramsDetail.yearCode"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="归档日期：">
                      <el-date-picker v-model="paramsDetail.filingDate" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" class="w-100"></el-date-picker>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-form-item label="备注：">
                  <el-input v-model="paramsDetail.folderNote" type="textarea" rows="2"></el-input>
                </el-form-item>
              </el-form>
            </el-tab-pane>
            <!-- 档案基本信息 -->
            <el-tab-pane label="基本信息" name="first" v-if="showType =='f'">
              <el-form :model="paramsDetail" label-width="120px">
                <el-form-item label="题名：">
                  <el-input v-model="paramsDetail.titleProper"></el-input>
                </el-form-item>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="保管期限：">
                      <el-select v-model="paramsDetail.retentionPeriod" class="w-100" filterable>
                        <el-option v-for="item in saveDateArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="章节号：">
                      <el-input v-model="paramsDetail.c72"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="年度：">
                      <el-input v-model="paramsDetail.yearCode"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="页号：">
                      <el-input v-model="paramsDetail.c229"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="归档日期：">
                      <el-date-picker v-model="paramsDetail.filingDate" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" class="w-100"></el-date-picker>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="编制单位：">
                      <el-input v-model="paramsDetail.c133"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-form-item label="索引备注：">
                  <el-input v-model="paramsDetail.c76" type="textarea" rows="2"></el-input>
                </el-form-item>
                <el-form-item label="情况说明：">
                  <el-input v-model="paramsDetail.c77" type="textarea" rows="2"></el-input>
                </el-form-item>
                <el-form-item label="备注：">
                  <el-input v-model="paramsDetail.c8" type="textarea" rows="2"></el-input>
                </el-form-item>
              </el-form>
            </el-tab-pane>
            <!-- 电子全文 -->
            <el-tab-pane label="电子全文" name="second" v-if="showType1 =='d'">
              <div>
                <embed :src='showUrl' type="application/pdf" width="100%" height="500px">
              </div>
            </el-tab-pane>
          </el-tabs>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button @click="seeFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!--  下载前确认 -->
    <el-dialog :visible.sync="isDownFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle1.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/nShow1.png" alt="">
        <div>该电子全文暂不提供在线浏览，您是否要离线下载此文件？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="downSee">确定</el-button>
        <el-button @click="isDownFlag = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { typeList, thDept, typeHangList, typeFolderList, archList, archTree, thStatus, typeLeftTree, newTree1, viewByTh, powerTree } from '@/js/getData';
import { valueIndex } from '@/js/transitionText'
export default {
  name: 'towTypeOne',
  props: {
    paramsNew: {
      type: Object
    },
    tableNew: {
      type: Array
    }
  },
  data() {
    return {
      isDownFlag: false,
      seeData: [],
      seeParams: {
        page: 1,
        rows: 4,
        total: null
      },
      downId: null,
      seeFlag1: false,
      seeFlag1: false,
      notShow2: false,
      notShow1: false,
      seeOne: [],
      seaFlag: false,
      params: this.paramsNew,
      titleFlag: false,
      titleMsg1: null,
      titleMsg2: null,
      fileData: this.tableNew,
      fileOne: [],
      dataShow: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      saveDateArr: [
        { "name": "永久", "itemValue": "3" },
        { "name": "长期", "itemValue": "2" },
        { "name": "短期", "itemValue": "1" },
        { "name": "10年", "itemValue": "5" },
        { "name": "15年", "itemValue": "6" },
        { "name": "30年", "itemValue": "8" }
      ],
      pubArr: ['', '公开', '内部', '受控', '广发商密三级', '广发商密二级', '广发商密一级'],
      saveArr: ['', '短期', '长期', '永久', '', '10年', '15年', '', '30年', '', '35年'],
      seeFlag: false,
      showUrl: null,
      paramsSea: {},
      deptArr: [],
      statusArr: [],
      bottomShow: "first",
      folderData: [],
      folderParams: {
        page: 1,
        rows: 4,
        total: null
      },
      folderArr: [],
      hangData: [],
      hangParams: {
        page: 1,
        rows: 4,
        total: null
      },
      hangArr: [],
      downId: null,
      paramsDetail: {},
      showType: null,
      activeName: null,
      showType1: null,
    }
  },
  methods: {
    //获取档案列表
    searchOne() {
      this.params.page = 1;
      this.searchList();
    },
    searchList() {
      typeList(this.params).then(res => {
        if (res.code == 0) {
          if (res.data.total <= 0) {
            this.titleMsg1 = '系统消息';
            this.titleMsg2 = '该条件下查无数据!';
            this.titleFlag = true;
          }
          this.fileData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    fileCurr(val) {
      this.params.page = val;
      this.searchList();
    },
    fileSelect(val) {
      this.fileOne = val;
      this.folderOneList();
      this.hangOneList();
    },
    //查询
    //归档部门下拉
    getDept() {
      thDept().then(res => {
        if (res.code == 0) {
          this.deptArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    getStatus() {
      thStatus().then(res => {
        if (res.code == 0) {
          this.statusArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //打开检索
    openSea() {
      this.getStatus();
      this.getDept();
      this.paramsSea = {};
      this.seaFlag = true;
    },
    searchSea() {
      this.resetInit();
      Object.assign(this.params, this.paramsSea);
      this.params.searchType = 1; //原系统逻辑
      this.searchOne();
      this.seaFlag = false;
    },
    resetInit() {
      this.params.thseriesCode = null;
      this.params.thfilingDept = null;
      this.params.thc18 = null;
      this.params.thyearCode = null;
      this.params.thc5 = null;
      this.params.thc10 = null;
      this.params.thc24 = null;
      this.params.thtitleProper = null;
      this.params.thc20 = null;
      this.params.thc22 = null;
      this.params.thc28 = null;
      this.params.addressNo = null;
      this.params.searchType = null;
    },

    //查看
    //查看列表
    seeList() {
      this.seeParams.flag = 0;
      this.seeParams.fileId = this.fileOne[0].id;
      archList(this.seeParams).then(res => {
        if (res.code == 0) {
          this.seeData = res.data.rows;
          this.seeParams.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    seeSelect(val) {
      this.seeOne = val;
    },
    seeCurr(val) {
      this.seeParams.page = val;
      this.seeList();
    },
    seeOneList() {
      this.seeParams.page = 1;
      this.seeList();
    },
    //查看--加载树
    //查看--按钮
    openView() {
      let open = this.$onceWay().onceTableList(this.fileOne);
      if (open == 1) {
        this.downId = null;
        this.paramsDetail = {};
        this.showType = "";
        this.dataShow = [];
        this.seeTree();
        this.seeFlag = true;
      }
    },
    //查看--加载树
    seeTree() {
      let seeParams = {
        id: this.fileOne[0].id,
        bs: 'saveTh',
        type: 'p'
      }
      typeLeftTree(seeParams).then(res => {
        if (res.code == 0) {
          this.dataShow = res.data;
          console.log(this.dataShow)
          this.openTabs(res.data[0]);
        } else this.$message.error(res.message);
      })
    },
    //点击右侧数加载树的子节点
    handleNodeClick(val) {
      this.append(val);
      this.openTabs(val);
    },
    //加载子树
    append(data) {
      if (data.attributes.type != "d") {
        let seeParams = {
          id: data.id,
          tm: Date.now(),
          type: data.attributes.type,
          resourceParentId: data.id
        }
        typeLeftTree(seeParams).then(res => {
          if (res.code == 0) {
            if (!data.children) {
              this.$set(data, 'children', []);
            }
            data.children = res.data;
          } else this.$message.error(res.message);
        })
      }
    },
    //打开右侧tab
    openTabs(node) {
      if (node.attributes.docType == "d") { //如果是附件，同时打开2个tab页，并默认选中“电子全文”tab“页
        powerTree({ id: node.attributes.docId }).then(res => {
          if (res.code == 0) {
            if (res.data.optFlag == "-1") {
              //原系统隐藏电子全文的下载按钮（embed自带的）
              this.$message.error("对不起，未找到您需要查看的文件"); //选中基本信息
              this.addTabs(node.attributes.type, node.attributes.id, node.attributes.title);
              this.activeName = "first"
              this.showType1 = "";
            } else {
              //原系统显示电子全文的下载按钮（embed自带的）
              this.addTabs(node.attributes.type, node.attributes.id, node.attributes.title);
              this.addFiles(node.attributes.docType, node.attributes.docId, node.attributes.title2, node.attributes.info2, node.attributes.fileType)
              console.log(node)
              this.activeName = "second"
            }
          } else this.$message.error(res.message)
        })
      } else {
        //原系统隐藏电子全文的下载按钮（embed自带的）
        this.addTabs(node.attributes.type, node.attributes.id, node.attributes.title);
        this.activeName = "first";
        this.showType1 = "";
        //选中基本信息
      }
    },
    //加载基本信息Tab
    addTabs(type, id, title, info) {
      if (type == "d") { //附件
        let viewParams = {
          type: type,
          id: id,
          info: info
        };
        this.addAllTabs(viewParams);
      } else {
        let viewParams = {
          type: type,
          id: id
        };
        this.addAllTabs(viewParams);
      }
    },
    addAllTabs(val) {
      viewByTh(val).then(res => {
        if (res.code == 0) {
          this.showType = res.data.type;
          if (res.data.type == "p") {
            this.paramsDetail = res.data.project;
          }
          if (res.data.type == "v") {
            this.paramsDetail = res.data.folder;
          }
          if (res.data.type == "f") {
            this.paramsDetail = res.data.file;
          }
        } else this.$message.error(res.message)
      })
    },
    //加载电子全文tab
    addFiles(type, id, title, info, fileType) {
      this.showType1 = 'd';
      if (fileType == "pdf") {
        //预览文档
        this.showUrl = BASICURL + '/gdda-new/gdda/util/filepreview/viewRangeFile?fileId=' + id;
      } else {
        this.downId = id;
        /*        this.downName = title;*/
        this.showUrl = null;
        //下载文档
        this.isDownFlag = true
      }
    },
    //下载非pdf文档
    downSee() {
      window.open(BASICURL + '/gdda-new/gdda/util/downLoadFile?id=' + this.downId + "&mode=saveTh")
      this.isDownFlag = false;
    },
    //下方列表
    bottomClick() {},
    //下方列表--案卷层
    folderList() {
      if (this.fileOne.length > 0) {
        this.folderParams.subId = this.fileOne[0].id;
      } else this.folderParams.subId = ""
      typeFolderList(this.folderParams).then(res => {
        if (res.code == 0) {
          this.folderData = res.data.rows;
          this.folderParams.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    folderOneList() {
      this.folderParams.page = 1;
      this.folderList();
    },
    folderSelect(val) {
      this.folderArr = val;
      this.hangOneList();
    },
    folderCurr(val) {
      this.folderParams.page = val;
      this.folderList();
    },
    //下方列表--文件层
    hangList() {
      if (this.fileOne.length > 0) {
        this.hangParams.projectId = this.fileOne[0].id;
      } else this.hangParams.projectId = ""
      if (this.folderArr.length > 0) {
        this.hangParams.folderId = this.folderArr[0].id;
      } else this.hangParams.folderId = "";
      typeHangList(this.hangParams).then(res => {
        if (res.code == 0) {
          this.hangData = res.data.rows;
          this.hangParams.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    hangOneList() {
      this.hangParams.page = 1;
      this.hangList();
    },
    hangSelect(val) {
      this.hangArr = val;
    },
    hangCurr(val) {
      this.hangParams.page = val;
      this.hangList()
    },
    //下方列表--查看
    //案卷层查看
    openSee1() {
      let open = this.$onceWay().onceTableList(this.folderArr);
      if (open == 1) {
        this.downId = null;
        this.paramsDetail = {};
        this.showType = "";
        this.dataShow = [];
        this.seeTree1(this.fileOne[0].id, this.folderArr[0].id);
        this.onPosition(this.folderArr[0].id, this.folderArr[0].type);
        this.seeFlag = true;
      }
    },
    //定位查看
    onPosition(val1, val2) {
      let seeParams = {
        id: val1,
        type: val2
      }
      typeLeftTree(seeParams).then(res => {
        if (res.code == 0) {
          this.openTabs(res.data[0]);
        }
      })
    },
    //文件层--查看
    openSee2() {
      let open = this.$onceWay().onceTableList(this.hangArr);
      if (open == 1) {
        this.downId = null;
        this.paramsDetail = {};
        this.showType = "";
        this.dataShow = [];
        this.seeTree1(this.fileOne[0].id, this.hangArr[0].id);
        this.onPosition(this.hangArr[0].id, this.hangArr[0].type);
        this.seeFlag = true;
      }
    },
    //查看--加载树
    seeTree1(val, val1) {
      let seeParams = {
        id: val,
        type: 'p'
      }
      newTree1(seeParams).then(res => {
        if (res.code == 0) {
          this.dataShow.push(res.data);
          this.$nextTick(() => {
            this.$refs.treeShow.setCurrentKey(val1);
          });
        } else this.$message.error(res.message);
      })
    },
  },
  created() {},
  watch: { // 监听到数据然后赋值
    paramsNew: {
      handler(newV, oldV) {
        this.params = JSON.parse(JSON.stringify(newV));
      },
      deep: true
    },
    tableNew: {
      handler(newV, oldV) {
        this.fileData = JSON.parse(JSON.stringify(newV))
      },
      deep: true
    }
  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.see {
  width: 100%;
  clear: both;
  margin-top: -30px;
  height: 500px;

  .see-left {
    width: 30%;
    float: left;
    padding-top: 20px;
    overflow: auto;
    height: 100%;

    .filter-tree {
      display: inline-block;
    }
  }

  .see-right {
    width: 69%;
    height: 100%;
    padding-top: 20px;
    float: left;
    border-left: 3px solid #1982BF;
  }
}

.address {
  border: 1px solid #6e6e6e;
  border-bottom: 0;
}

.address-show {
  width: 100%;
  height: 74px;
  text-align: center;
  font-size: 20px;
  color: #333;
  background-color: #e7f5ff;
  border-bottom: 1px solid #6e6e6e;
  line-height: 74px;
}

.address-div {
  width: 100%;
  height: 74px;
  border-bottom: 1px solid #6e6e6e;
  clear: both;

  .address-left {
    width: 300px;
    border-right: 1px solid #6e6e6e;
    height: 100%;
    float: left;
    line-height: 74px;
    padding-left: 5px;

    label {
      font-size: 12px;
      color: #282828;
      padding-right: 5px
    }

    .el-input {
      width: 120px;
    }
  }

  .address-cen {
    width: 58px;
    border-right: 1px solid #6e6e6e;
    height: 100%;
    float: left;
    line-height: 74px;
    text-align: center;

  }

  .address-right {
    width: 786px;
    float: left;
    padding-left: 6px;

    span {
      padding-top: 6px;
      display: inline-block;
    }

    label {
      font-size: 12px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 71px;
    }
  }
}

.address-top {
  margin-bottom: 30px;
  margin-left: 170px;

  span {
    display: inline-block;
    color: #282828;
    font-size: 16px;
    cursor: pointer;
    margin-right: 10px;
    cursor: pointer;
  }

  .address-doc {
    label {
      font-size: 16px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 180px;
    }
  }
}

.search-doc {
  margin-top: 10px;

  label {
    font-size: 14px;
    color: #282828;
    padding-right: 5px
  }

  .el-input,
  .el-select {
    width: 200px;
  }
}

.doc-main {
  background-color: #fff;
  min-height: 700px;

  .mb-20 {

    margin-bottom: 20px;
  }

  .doc-down {
    font-size: 13px;
    color: #515BED;
    float: right;
  }

  .doc-doss {
    width: 100%;
    height: 500px;
    overflow: auto;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .mt-f18 {
    margin-top: -18px;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .lend-table {
    max-height: 200px;
    overflow-y: auto;
    width: 100%
  }
}

.w-100 {
  width: 100%
}

</style>
