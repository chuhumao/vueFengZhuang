<template>
  <div>
    <div class="contentPadding doc-main">
      <div class="headerBtn mb-20">
        <span class="search-doc">
          <label>全宗：</label>
          <el-select v-model="params.fonds" @change="changeFonds">
            <el-option v-for="item in fonds" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc">
          <label>类型：</label>
          <el-select v-model="params.series1" @change="changeOne">
            <el-option v-for="item in oneArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc">
          <el-select v-model="params.series2" @change="changeTwo">
            <el-option v-for="item in twoArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc">
          <el-select v-model="params.series3" @change="changeThree">
            <el-option v-for="item in threeArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
          </el-select>
        </span>
        <span class="search-doc" v-show="typeFlag">
          <label>形式：</label>
          <el-select v-model="params.series4" @change="changeType">
            <el-option v-for="item in forthArr" :key="item.value" :value="item.value" :label="item.key"></el-option>
          </el-select>
        </span>
      </div>
      <oneType :params-new="params" v-if="showFlag =='1'" :tableNew="tableData"></oneType>
      <twoType :params-new="params" v-else-if="showFlag =='2'" :tableNew="tableData"></twoType>
      <towTypeOne :params-new="params" v-else-if="showFlag =='21'" :tableNew="tableData"></towTypeOne>
      <towTypeTwo :params-new="params" v-else-if="showFlag =='22'" :tableNew="tableData"></towTypeTwo>
      <threeType :params-new="params" v-else-if="showFlag =='3'" :tableNew="tableData"></threeType>
      <fourType :params-new="params" v-else-if="showFlag =='4'" :tableNew="tableData"></fourType>
      <fiveType :params-new="params" v-else-if="showFlag =='5'" :tableNew="tableData"></fiveType>
      <sixType :params-new="params" v-else-if="showFlag =='6'" :tableNew="tableData"></sixType>
      <sevenType :params-new="params" v-else-if="showFlag =='7'" :tableNew="tableData"></sevenType>
      <div v-else></div>
      <!-- 检索系统提示 -->
      <el-dialog :visible.sync="titleFlag" width="444px" class="hurdleAll">
        <div slot="title" class="dialog-title">
          <img src="../../assets/hurdle/nTitle2.png" alt="">
          {{titleMsg1}}
        </div>
        <div class="dia-delete">
          <img src="../../assets/hurdle/delete.png" alt="">
          <div>{{titleMsg2}}</div>
        </div>
        <div slot="footer" class="dialog-footer all-btn mt-f18">
          <el-button type="primary" @click="titleFlag = false">确定</el-button>
        </div>
      </el-dialog>
    </div>
  </div>
</template>
<script>
import { getFonds, getAndRole, getIdList, manageList, capitalList, listStaff, entityList, videoList, listSheng, debtList, typeList } from '@/js/getData';
import oneType from './oneType.vue';
import twoType from './twoType.vue';
import towTypeOne from './towTypeOne.vue';
import towTypeTwo from './towTypeTwo.vue';
import threeType from './threeType.vue';
import fourType from './fourType.vue';
import fiveType from './fiveType.vue';
import sixType from './sixType.vue';
import sevenType from './sevenType.vue';
export default {
  name: 'fileSave',
  components: {
    oneType,
    twoType,
    towTypeOne,
    towTypeTwo,
    threeType,
    fourType,
    fiveType,
    sixType,
    sevenType
  },
  data() {
    return {
      titleFlag: false,
      titleMsg1: null,
      titleMsg2: null,
      typeFlag: false,
      showFlag: null,
      forthArr: [{ "key": "底稿", "value": "DG" }, { "key": "项目", "value": "XM" }],
      fonds: [],
      oneArr: [],
      twoArr: [],
      threeArr: [],
      params: {
        c0: 20,
        page: 1,
        rows: 7,
        total: null,
        series4: "",
      },
      tableData: [],
    }
  },
  methods: {
    //获取全宗
    searchFond() {
      getFonds().then(res => {
        if (res.code == 0) {
          this.fonds = res.data;
          this.initFond();
        } else this.$message.error(res.message)
      })
    },
    //初始化选中全宗--原系统逻辑
    initFond(val) {
      if ("8106" == val) {
        this.params.fonds = 1463117877850; //广发乾和
      } else {
        this.params.fonds = 1374133141812 //新广发证券
      }
      this.fondsM();
    },
    //全宗方法
    fondsM() {
      this.searchType(this.params.fonds);
      this.initType();
    },
    //改变选中全宗
    changeFonds() {
      this.$forceUpdate();
      this.fondsM();
    },
    //根据全宗获取档案分类
    searchType(val) {
      getAndRole({ id: val }).then(res => {
        if (res.code == 0) {
          this.oneArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //初始化选中档案分类--原系统逻辑
    initType() {
      if (this.params.fonds == 1463117877850) {
        this.params.series1 = 1463318429461 //管理类档案
      } else if (this.params.fonds == 1374133141812) {
        this.params.series1 = 1379482316593 //管理类案件(按件)
      } else {
        this.params.series1 = null;
      }
      this.params.series2 = null;
      this.params.series3 = null;
      this.searchType1(this.params.series1, 1);
      this.initType1();
    },
    //改变第一个类型
    changeOne() {
      this.$forceUpdate();
      this.searchType1(this.params.series1, 1);
      this.initType1();
      this.params.series2 = null;
      this.params.series3 = null;
      this.typeFlag = false
    },
    //根据档案分类id获取下级分类
    searchType1(val, val1) {
      getIdList({ id: val }).then(res => {
        if (res.code == 0) {
          if (val1 == 1) {
            this.twoArr = res.data;
          } else this.threeArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //初始化获取下级分类--原系统逻辑
    initType1() {
      this.params.series2 = null;
      this.searchType1(this.params.series2, 2);
      this.initList();
    },
    //改变第二个类型
    changeTwo() {
      this.$forceUpdate();
      this.searchType1(this.params.series2, 2);
      this.params.series3 = null;
      if (this.params.series2 == 1388742017297) {
        this.typeFlag = true;
      } else {
        this.typeFlag = false;
      }
      this.initList();
    },
    //改变第三个类型
    changeThree() {
      this.$forceUpdate();
      this.initList();
    },
    resetParams() {
      this.params.c0 = null;
      this.params.c10 = null;
      this.params.c5 = null;
    },
    //改变形式
    changeType() {
      this.$forceUpdate();
      this.initList();
    },
    //初始化获取档案列表--原系统逻辑
    initList() {
      if (this.params.series1) {
        //第一种情况 管理类档案（按件）|| 管理类档案 || 管理类档案（按件历史）
        if (this.params.series1 == 1379482316593 || this.params.series1 == 1463318429461 || this.params.series1 == 1383033168454) {
          this.oneState();
          //第二种情况 业务档案/投资银行
        } else if (this.params.series1 == 1388742017296) {
          if (this.params.series2 == 1388742017297) {
            if (this.params.series4 == "" || this.params.series4 == "DG") {
              this.twoState()
            } else {
              this.oneTwoState();
            }
          } else if (this.params.series2 == 1388742017298) { //债券业务
            this.towTwoState();
          } else this.showFlag = "0";
          //第三种情况（会计档案）series2选中凭证||工资册及其他||报表||账簿
        } else if (this.params.series1 == 1388742017269) {
          this.threeState();
        } else if (this.params.series1 == 1384966177247) { //第四种情况（基建档案）
          this.fourState();
        } else if (this.params.series1 == 1379398885203) { //第五种情况（员工档案）series2选中分支机构员工档案 || 经纪人
          this.fiveState();
        } else if (this.params.series1 == 1374133285843) { //第6种情况（实物档案）series2选中印章||奖杯奖牌||外事礼品||其他||证书||证照
          this.sixState()
        } else if (this.params.series1 == 1374133285828) { //第七种情况（声想档案） series2选中底片正片 || 录音 || 录像 || 磁盘
          this.sevenState();
        }
      } else this.showFlag = "0";
    },
    //第一种情况
    oneState() {
      this.resetParams();
      this.params.c0 = 20;
      this.params.page = 1;
      manageList(this.params).then(res => {
        if (res.code == 0) {
          if (res.data.total <= 0) {
            this.titleMsg1 = '系统消息';
            this.titleMsg2 = '该条件下查无数据!';
            this.titleFlag = true;
          }
          this.tableData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
      this.showFlag = "1";
    },
    //第二种情况
    twoState() {
      this.resetParams();
      this.params.c0 = 20;
      this.params.series4 = "DG";
      typeList(this.params).then(res => {
        if (res.code == 0) {
          if (res.data.total <= 0) {
            this.titleMsg1 = '系统消息';
            this.titleMsg2 = '该条件下查无数据!';
            this.titleFlag = true;
          }
          this.tableData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
      this.showFlag = "2"
    },
    //第二种情况//业务管理--投资银行--项目
    oneTwoState() {
      this.resetParams();
      this.params.c0 = 20;
      this.params.page = 1;
      typeList(this.params).then(res => {
        if (res.code == 0) {
          if (res.data.total <= 0) {
            this.titleMsg1 = '系统消息';
            this.titleMsg2 = '该条件下查无数据!';
            this.titleFlag = true;
          }
          this.tableData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
      this.showFlag = "21"
    },
    //第二种情况//债券业务
    towTwoState() {
      this.resetParams();
      this.params.c5 = 3;
      debtList(this.params).then(res => {
        if (res.code == 0) {
          if (res.data.total <= 0) {
            this.titleMsg1 = '系统消息';
            this.titleMsg2 = '该条件下查无数据!';
            this.titleFlag = true;
          }
          this.tableData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
      this.showFlag = "22";
    },
    //第三种情况
    threeState() {
      if (this.params.series2 == 1392602311170 || this.params.series2 == 1392602326170 || this.params.series2 == 1392602256951 || this.params.series2 == 1392602290904) {
        this.resetParams();
        this.params.page = 1;
        this.params.c0 = 20;
        listSheng(this.params).then(res => {
          if (res.code == 0) {
            if (res.data.total <= 0) {
              this.titleMsg1 = '系统消息';
              this.titleMsg2 = '该条件下查无数据!';
              this.titleFlag = true;
            }
            this.tableData = res.data.rows;
            this.params.total = res.data.total;
          } else this.$message.error(res.message)
        })
        this.showFlag = "3"
      } else this.showFlag = "0";
    },
    //第四种情况（基建档案）
    fourState() {
      this.tableData = [];
      this.resetParams();
      this.params.c5 = 3;
      this.params.page = 1;
      capitalList(this.params).then(res => {
        if (res.code == 0) {
          if (res.data.total <= 0) {
            this.titleMsg1 = '系统消息';
            this.titleMsg2 = '该条件下查无数据!';
            this.titleFlag = true;
          }
          this.tableData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
      this.showFlag = "4"
    },
    //第五种情况（员工档案）
    fiveState() {
      this.tableData = [];
      if (this.params.series2 == 1379398885209 || this.params.series2 == 1415689929208) {
        this.resetParams();
        this.params.c10 = 2;
        this.params.page = 1;
        listStaff(this.params).then(res => {
          if (res.code == 0) {
            if (res.data.total <= 0) {
              this.titleMsg1 = '系统消息';
              this.titleMsg2 = '该条件下查无数据!';
              this.titleFlag = true;
            }
            this.tableData = res.data.rows;
            this.params.total = res.data.total;
          } else this.$message.error(res.message)
        })
        this.showFlag = "5"
      } else this.showFlag = "0";
    },
    //第6种情况
    sixState() {
      if (this.params.series2 == 1374133285844 || this.params.series2 == 1374133285845 || this.params.series2 == 1374133285846 || this.params.series2 == 1374133285847 || this.params.series2 == 1374133285848 || this.params.series2 == 1547110001600) {
        this.resetParams();
        this.params.c0 = 20;
        this.params.page = 1;
        entityList(this.params).then(res => {
          if (res.code == 0) {
            if (res.data.total <= 0) {
              this.titleMsg1 = '系统消息';
              this.titleMsg2 = '该条件下查无数据!';
              this.titleFlag = true;
            }
            this.tableData = res.data.rows;
            this.params.total = res.data.total;
          } else this.$message.error(res.message)
        })
        this.showFlag = "6"
      } else this.showFlag = "0";
    },
    //第七种情况
    sevenState() {
      if (this.params.series2 == 1374133285829 || this.params.series2 == 1374133285830 || this.params.series2 == 1374133285831 || this.params.series2 == 1374133285832) {
        this.resetParams();
        this.params.page = 1;
        this.params.c10 = 2;
        videoList(this.params).then(res => {
          if (res.code == 0) {
            if (res.data.total <= 0) {
              this.titleMsg1 = '系统消息';
              this.titleMsg2 = '该条件下查无数据!';
              this.titleFlag = true;
            }
            this.tableData = res.data.rows;
            this.params.total = res.data.total;
          } else this.$message.error(res.message)
        })
        this.showFlag = "7";
      } else this.showFlag = "0";
    }
  },
  created() {
    this.searchFond();
  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.see {
  width: 100%;
  clear: both;
  margin-top: -30px;
  height: 500px;

  .see-left {
    width: 40%;
    float: left;
    padding-top: 20px;
    overflow: auto;
    height: 100%;

    .filter-tree {
      display: inline-block;
    }
  }

  .see-right {
    width: 59%;
    height: 100%;
    padding-top: 20px;
    float: left;
    border-left: 3px solid #1982BF;
  }
}

.address {
  border: 1px solid #6e6e6e;
  border-bottom: 0;
}

.address-show {
  width: 100%;
  height: 74px;
  text-align: center;
  font-size: 20px;
  color: #333;
  background-color: #e7f5ff;
  border-bottom: 1px solid #6e6e6e;
  line-height: 74px;
}

.address-div {
  width: 100%;
  height: 74px;
  border-bottom: 1px solid #6e6e6e;
  clear: both;

  .address-left {
    width: 300px;
    border-right: 1px solid #6e6e6e;
    height: 100%;
    float: left;
    line-height: 74px;
    padding-left: 5px;

    label {
      font-size: 12px;
      color: #282828;
      padding-right: 5px
    }

    .el-input {
      width: 120px;
    }
  }

  .address-cen {
    width: 58px;
    border-right: 1px solid #6e6e6e;
    height: 100%;
    float: left;
    line-height: 74px;
    text-align: center;

  }

  .address-right {
    width: 786px;
    float: left;
    padding-left: 6px;

    span {
      padding-top: 6px;
      display: inline-block;
    }

    label {
      font-size: 12px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 71px;
    }
  }
}

.address-top {
  margin-bottom: 30px;
  margin-left: 170px;

  span {
    display: inline-block;
    color: #282828;
    font-size: 16px;
    cursor: pointer;
    margin-right: 10px;
    cursor: pointer;
  }

  .address-doc {
    label {
      font-size: 16px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 180px;
    }
  }
}

.search-doc {
  margin-top: 10px;

  label {
    font-size: 14px;
    color: #282828;
    padding-right: 5px
  }

  .el-input,
  .el-select {
    width: 200px;
  }
}

.doc-main {
  background-color: #fff;
  min-height: 700px;

  .mb-20 {

    margin-bottom: 20px;
  }

  .doc-down {
    font-size: 13px;
    color: #515BED;
    float: right;
  }

  .doc-doss {
    width: 100%;
    height: 500px;
    overflow: auto;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .mt-f18 {
    margin-top: -18px;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .lend-table {
    max-height: 200px;
    overflow-y: auto;
    width: 100%
  }
}

.w-100 {
  width: 100%
}

</style>
