<!-- 声像档案 -->
<template>
  <div>
    <div>
      <div>
        <div class="headerBtn mb-20">
          <span @click="openRk"><img src="../../assets/save/s1.png" alt="">入库</span>
          <span @click="openBack"><img src="../../assets/save/s2.png" alt="">退回整理</span>
          <span @click="openNo"><img src="../../assets/save/s3.png" alt="">去除存址号</span>
          <span @click="openAddress"><img src="../../assets/save/s5.png" alt="">生成存址号</span>
          <span @click="openSea"><img src="../../assets/system/p8.png" alt="">检索</span>
          <span @click="openAll"><img src="../../assets/save/s6.png" alt="">打印目录</span>
          <span @click="openPrint"><img src="../../assets/save/s6.png" alt="">打印脊背</span>
        </div>
        <!-- 表格 -->
        <div>
          <div class='all-Table' style="max-height: 530px;overflow-y: auto;">
            <el-table :data="fileData" stripe border @selection-change="fileSelect" :row-class-name="rowClassName">
              <el-table-column type="selection" width="55">
              </el-table-column>
              <el-table-column prop="officeArchivalCode" label="档号" width="140px">
              </el-table-column>
              <el-table-column prop="storagePlace" label="存址号" width="140px">
              </el-table-column>
              <el-table-column prop="seriesCode" label="分类号" width="100px">
              </el-table-column>
              <el-table-column prop="itemNo" label="件号" width="100px">
              </el-table-column>
              <el-table-column prop="titleProper" label="题名" width="400px">
              </el-table-column>
              <el-table-column prop="c63" label="主题" width="100px">
              </el-table-column>
              <el-table-column prop="takePhotoDate" label="拍摄时间" width="100px">
              </el-table-column>
              <el-table-column prop="takePhotoPlace" label="地点" width="200px">
              </el-table-column>
              <el-table-column prop="c64" label="背景" width="100px">
              </el-table-column>
              <el-table-column prop="c65" label="人物(职位)" width="140px">
              </el-table-column>
              <el-table-column prop="takePhotoPerson" label="摄(录)者" width="140px">
              </el-table-column>
              <el-table-column prop="c68" label="所属部门" width="140px">
              </el-table-column>
              <el-table-column prop="contentDescription" label="内容简介" width="300px">
              </el-table-column>
              <el-table-column prop="containerStatus" label="是否在库" width="100px">
                <template slot-scope="scope">
                  <span v-if="scope.row.containerStatus ==1">是</span>
                  <span v-else-if="scope.row.containerStatus ==2">出库</span>
                  <span v-else>否</span>
                </template>
              </el-table-column>
            </el-table>
          </div>
          <!-- 分页 -->
          <div class="pageLayout">
            <el-pagination @current-change="fileCurr" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
            </el-pagination>
          </div>
        </div>
        <!-- 查看 -->
        <div>
          <div class="headerBtn mb-20">
            <span @click="openSee"><img src="../../assets/confirmed/a4.png" alt="">查看</span>
          </div>
          <div class='all-Table'>
            <el-table :data="seeData" stripe border @selection-change="seeSelect">
              <el-table-column type="selection" width="55">
              </el-table-column>
              <el-table-column prop="itemNo" label="序号" width="140px">
              </el-table-column>
              <el-table-column prop="titleProper" label="题名" width="700px">
              </el-table-column>
              <el-table-column prop="yearCode" label="年度" width="140px">
              </el-table-column>
              <el-table-column prop="c11" label="片长" width="140px">
              </el-table-column>
              <el-table-column prop="seriesCode" label="分类号" width="140px">
              </el-table-column>
              <el-table-column prop="retentionPeriod" label="保管期限" width="120px">
                <template slot-scope="scope">
                  {{saveArr[scope.row.retentionPeriod]}}
                </template>
              </el-table-column>
              <el-table-column prop="openingType" label="公开属性" width="120px">
                <template slot-scope="scope">
                  {{pubArr[scope.row.openingType]}}
                </template>
              </el-table-column>
              <el-table-column prop="filingDeptName" label="归档部门" width="120px">
              </el-table-column>
            </el-table>
          </div>
          <!-- 分页 -->
          <div class="pageLayout">
            <el-pagination @current-change="seeCurr" :current-page="seeParams.page" :page-size="seeParams.rows" layout="prev, pager, next, jumper" :total="seeParams.total">
            </el-pagination>
          </div>
        </div>
      </div>
    </div>
    <!-- 检索系统提示 -->
    <el-dialog :visible.sync="titleFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        {{titleMsg1}}
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>{{titleMsg2}}</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="titleFlag = false">确定</el-button>
      </div>
    </el-dialog>
    <!-- 入库 -->
    <el-dialog :visible.sync="jumpFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/save/s7.png" alt="">
        入库意见
      </div>
      <div>
        <el-form label-width="80px">
          <el-form-item label="意见：">
            <el-input type="textarea" :rows="5" v-model="remark" style="width: 90%"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="clickJump">保存</el-button>
        <el-button @click="jumpFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 入库前确认 -->
    <el-dialog :visible.sync="confirmRkFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要入库？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="confirmRk">确定</el-button>
        <el-button @click="confirmRkFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 去除存址号 -->
    <el-dialog :visible.sync="noFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定去除存址号吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="confirmNo">确定</el-button>
        <el-button @click="noFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 检索 -->
    <el-dialog :visible.sync="seaFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/u2.png" alt="">
        检索
      </div>
      <el-form :model="paramsSea" label-width="120px">
        <el-form-item label="档号：">
          <el-input v-model="paramsSea.officeArchivalCode"></el-input>
        </el-form-item>
        <el-form-item label="题名：">
          <el-input v-model="paramsSea.titleProper"></el-input>
        </el-form-item>
        <el-form-item label="主题：">
          <el-input v-model="paramsSea.c63"></el-input>
        </el-form-item>
        <el-form-item label="存址号：">
          <el-input v-model="paramsSea.storagePlace"></el-input>
        </el-form-item>
        <el-form-item label="所属部门：">
          <el-input v-model="paramsSea.c68"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="searchSea">检索</el-button>
        <el-button type="primary" @click="paramsSea ={}">重置条件</el-button>
        <el-button @click="seaFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 打印目录--全部 -->
    <el-dialog :visible.sync="allFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>您没有选择要打印的归档文件，是否要打印全部？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="confirmAll">确定</el-button>
        <el-button @click="allFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 打印脊背 -->
    <el-dialog :visible.sync="printFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/save/s10.png" alt="">
        打印
      </div>
      <div>
        <el-form label-width="120px">
          <el-form-item label="选择尺寸：">
            <el-select v-model="scopes" class="w-100">
              <el-option v-for="item in scopeArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
            </el-select>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="confirmPrint">确定</el-button>
        <el-button @click="printFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 生成存址号 -->
    <el-dialog :visible.sync="addressFlag" width="1200px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/save/s9.png" alt="">
        生成存址号
      </div>
      <div>
        <div>
          <!-- 头部 -->
          <div class="address-top">
            <span class="address-doc">
              <label>年份</label>
              <el-select v-model.trim="paramsAdd.yearCode" @change="getRange">
                <el-option v-for="item in yearArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
              </el-select>
            </span>
            <span class="address-doc">
              <label>保管期限</label>
              <el-select v-model.trim="paramsAdd.retentionPeriod" @change="getRange1">
                <el-option v-for="item in perArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
              </el-select>
            </span>
            <span>档号范围： {{labFileMinFile}}至{{labFileMaxFile}}</span>
          </div>
          <!-- 表数据 -->
          <div class="address">
            <div class="address-div">
              <div class="address-left">
                <span><label>起-</label>
                  <el-input size="mini" v-model.trim="paramsAdd.startMin" maxlength="18"></el-input>
                </span>
                <span><label>止-</label>
                  <el-input size="mini" v-model.trim="paramsAdd.startMax" maxlength="18"></el-input>
                </span>
              </div>
              <span class="address-cen">存址号</span>
              <div class="address-right">
                <span><label>库房</label>
                  <el-select size="mini" v-model.trim="paramsAdd.store" @change="((val)=>{getShow(val,1)})">
                    <el-option v-for="item in storeArr" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>矩阵</label>
                  <el-select size="mini" v-model.trim="paramsAdd.matrix" @change="((val)=>{getBend(val,1)})">
                    <el-option v-for="item in matrixArr" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>排架</label>
                  <el-select size="mini" v-model.trim="paramsAdd.bent" @change="((val)=>{getFace(val,1)})">
                    <el-option v-for="item in bentArr" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>面</label>
                  <el-select size="mini" v-model.trim="paramsAdd.face" @change="((val)=>{getGrid(val,1)})">
                    <el-option v-for="item in faceArr" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>列行</label>
                  <el-select size="mini" v-model.trim="paramsAdd.grid" @change="$forceUpdate()">
                    <el-option v-for="item in gridArr" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>箱号</label>
                  <el-input size="mini" v-model.trim="paramsAdd.boxNo" maxlength="12"></el-input>
                </span>
                <span><label>重量</label>
                  <el-input size="mini" v-model.trim="paramsAdd.weight" maxlength="12"></el-input>
                </span>
                <span><label>号</label>
                  <el-input size="mini" style="width: 103px" v-model.trim="paramsAdd.addrNo" maxlength="25" @change="initAddress(1)"></el-input>
                </span>
              </div>
            </div>
            <div class="address-div">
              <div class="address-left">
                <span><label>起-</label>
                  <el-input size="mini" v-model.trim="paramsAdd.startMin1" maxlength="18"></el-input>
                </span>
                <span><label>止-</label>
                  <el-input size="mini" v-model.trim="paramsAdd.startMax1" maxlength="18"></el-input>
                </span>
              </div>
              <span class="address-cen">存址号</span>
              <div class="address-right">
                <span><label>库房</label>
                  <el-select size="mini" v-model.trim="paramsAdd.store1" @change="((val)=>{getShow(val,2)})">
                    <el-option v-for="item in storeArr" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>矩阵</label>
                  <el-select size="mini" v-model.trim="paramsAdd.matrix1" @change="((val)=>{getBend(val,2)})">
                    <el-option v-for="item in matrixArr1" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>排架</label>
                  <el-select size="mini" v-model.trim="paramsAdd.bent1" @change="((val)=>{getFace(val,2)})">
                    <el-option v-for="item in bentArr1" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>面</label>
                  <el-select size="mini" v-model.trim="paramsAdd.face1" @change="((val)=>{getGrid(val,2)})">
                    <el-option v-for="item in faceArr1" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>列行</label>
                  <el-select size="mini" v-model.trim="paramsAdd.grid1" @change="$forceUpdate()">
                    <el-option v-for="item in gridArr1" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>箱号</label>
                  <el-input size="mini" v-model.trim="paramsAdd.boxNo1" maxlength="12"></el-input>
                </span>
                <span><label>重量</label>
                  <el-input size="mini" v-model.trim="paramsAdd.weight1" maxlength="12"></el-input>
                </span>
                <span><label>号</label>
                  <el-input size="mini" style="width: 103px" v-model.trim="paramsAdd.addrNo1" maxlength="25"></el-input>
                </span>
              </div>
            </div>
            <div class="address-div">
              <div class="address-left">
                <span><label>起-</label>
                  <el-input size="mini" v-model.trim="paramsAdd.startMin2" maxlength="18"></el-input>
                </span>
                <span><label>止-</label>
                  <el-input size="mini" v-model.trim="paramsAdd.startMax2" maxlength="18"></el-input>
                </span>
              </div>
              <span class="address-cen">存址号</span>
              <div class="address-right">
                <span><label>库房</label>
                  <el-select size="mini" v-model.trim="paramsAdd.store2" @change="((val)=>{getShow(val,3)})">
                    <el-option v-for="item in storeArr" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>矩阵</label>
                  <el-select size="mini" v-model.trim="paramsAdd.matrix2" @change="((val)=>{getBend(val,3)})">
                    <el-option v-for="item in matrixArr2" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>排架</label>
                  <el-select size="mini" v-model.trim="paramsAdd.bent2" @change="((val)=>{getFace(val,3)})">
                    <el-option v-for="item in bentArr2" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>面</label>
                  <el-select size="mini" v-model.trim="paramsAdd.face2" @change="((val)=>{getGrid(val,3)})">
                    <el-option v-for="item in faceArr2" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>列行</label>
                  <el-select size="mini" v-model.trim="paramsAdd.grid2" @change="$forceUpdate()">
                    <el-option v-for="item in gridArr2" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>箱号</label>
                  <el-input size="mini" v-model.trim="paramsAdd.boxNo2" maxlength="12"></el-input>
                </span>
                <span><label>重量</label>
                  <el-input size="mini" v-model.trim="paramsAdd.weight2" maxlength="12"></el-input>
                </span>
                <span><label>号</label>
                  <el-input size="mini" style="width: 103px" v-model.trim="paramsAdd.addrNo2" maxlength="25"></el-input>
                </span>
              </div>
            </div>
            <div class="address-div">
              <div class="address-left">
                <span><label>起-</label>
                  <el-input size="mini" v-model.trim="paramsAdd.startMin3" maxlength="18"></el-input>
                </span>
                <span><label>止-</label>
                  <el-input size="mini" v-model.trim="paramsAdd.startMax3" maxlength="18"></el-input>
                </span>
              </div>
              <span class="address-cen">存址号</span>
              <div class="address-right">
                <span><label>库房</label>
                  <el-select size="mini" v-model.trim="paramsAdd.store3" @change="((val)=>{getShow(val,4)})">
                    <el-option v-for="item in storeArr" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>矩阵</label>
                  <el-select size="mini" v-model.trim="paramsAdd.matrix3" @change="((val)=>{getBend(val,4)})">
                    <el-option v-for="item in matrixArr3" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>排架</label>
                  <el-select size="mini" v-model.trim="paramsAdd.bent3" @change="((val)=>{getFace(val,4)})">
                    <el-option v-for="item in bentArr3" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>面</label>
                  <el-select size="mini" v-model.trim="paramsAdd.face3" @change="((val)=>{getGrid(val,4)})">
                    <el-option v-for="item in faceArr3" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>列行</label>
                  <el-select size="mini" v-model.trim="paramsAdd.grid3" @change="$forceUpdate()">
                    <el-option v-for="item in gridArr3" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>箱号</label>
                  <el-input size="mini" v-model.trim="paramsAdd.boxNo3" maxlength="12"></el-input>
                </span>
                <span><label>重量</label>
                  <el-input size="mini" v-model.trim="paramsAdd.weight3" maxlength="12"></el-input>
                </span>
                <span><label>号</label>
                  <el-input size="mini" style="width: 103px" v-model.trim="paramsAdd.addrNo3" maxlength="25"></el-input>
                </span>
              </div>
            </div>
            <div class="address-div">
              <div class="address-left">
                <span><label>起-</label>
                  <el-input size="mini" v-model.trim="paramsAdd.startMin4" maxlength="18"></el-input>
                </span>
                <span><label>止-</label>
                  <el-input size="mini" v-model.trim="paramsAdd.startMax4" maxlength="18"></el-input>
                </span>
              </div>
              <span class="address-cen">存址号</span>
              <div class="address-right">
                <span><label>库房</label>
                  <el-select size="mini" v-model.trim="paramsAdd.store4" @change="((val)=>{getShow(val,5)})">
                    <el-option v-for="item in storeArr" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>矩阵</label>
                  <el-select size="mini" v-model.trim="paramsAdd.matrix4" @change="((val)=>{getBend(val,5)})">
                    <el-option v-for="item in matrixArr4" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>排架</label>
                  <el-select size="mini" v-model.trim="paramsAdd.bent4" @change="((val)=>{getFace(val,5)})">
                    <el-option v-for="item in bentArr4" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>面</label>
                  <el-select size="mini" v-model.trim="paramsAdd.face4" @change="((val)=>{getGrid(val,5)})">
                    <el-option v-for="item in faceArr4" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>列行</label>
                  <el-select size="mini" v-model.trim="paramsAdd.grid4" @change="$forceUpdate()">
                    <el-option v-for="item in gridArr4" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>箱号</label>
                  <el-input size="mini" v-model.trim="paramsAdd.boxNo4" maxlength="12"></el-input>
                </span>
                <span><label>重量</label>
                  <el-input size="mini" v-model.trim="paramsAdd.weight4" maxlength="12"></el-input>
                </span>
                <span><label>号</label>
                  <el-input size="mini" style="width: 103px" v-model.trim="paramsAdd.addrNo4" maxlength="25"></el-input>
                </span>
              </div>
            </div>
            <div class="address-div">
              <div class="address-left">
                <span><label>起-</label>
                  <el-input size="mini" v-model.trim="paramsAdd.startMin5" maxlength="18"></el-input>
                </span>
                <span><label>止-</label>
                  <el-input size="mini" v-model.trim="paramsAdd.startMax5" maxlength="18"></el-input>
                </span>
              </div>
              <span class="address-cen">存址号</span>
              <div class="address-right">
                <span><label>库房</label>
                  <el-select size="mini" v-model.trim="paramsAdd.store5" @change="((val)=>{getShow(val,6)})">
                    <el-option v-for="item in storeArr" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>矩阵</label>
                  <el-select size="mini" v-model.trim="paramsAdd.matrix5" @change="((val)=>{getBend(val,6)})">
                    <el-option v-for="item in matrixArr5" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>排架</label>
                  <el-select size="mini" v-model.trim="paramsAdd.bent5" @change="((val)=>{getFace(val,6)})">
                    <el-option v-for="item in bentArr5" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>面</label>
                  <el-select size="mini" v-model.trim="paramsAdd.face5" @change="((val)=>{getGrid(val,6)})">
                    <el-option v-for="item in faceArr5" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>列行</label>
                  <el-select size="mini" v-model.trim="paramsAdd.grid5" @change="$forceUpdate()">
                    <el-option v-for="item in gridArr5" :key="item.name" :value="item.name" :label="item.name"></el-option>
                  </el-select>
                </span>
                <span><label>箱号</label>
                  <el-input size="mini" v-model.trim="paramsAdd.boxNo5" maxlength="12"></el-input>
                </span>
                <span><label>重量</label>
                  <el-input size="mini" v-model.trim="paramsAdd.weight5" maxlength="12"></el-input>
                </span>
                <span><label>号</label>
                  <el-input size="mini" style="width: 103px" v-model.trim="paramsAdd.addrNo5" maxlength="25"></el-input>
                </span>
              </div>
            </div>
            <div class="address-show">
              请仔细检查档号的连续性
            </div>
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="confirmAddFlag = true">保存</el-button>
        <el-button @click="addressFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 生成存址号前确认 -->
    <el-dialog :visible.sync="confirmAddFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定生成存址号吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="confirmAdd">确定</el-button>
        <el-button @click="confirmAddFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 查看 -->
    <!-- 查看中的详情 -->
    <el-dialog :visible.sync="seeFlag" width="1100px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicShow.png" alt="">
        查看材料
      </div>
      <div class="see">
        <div class="see-left">
          <el-tree class="filter-tree" :highlight-current="true" :expand-on-click-node="false" :data="dataShow" default-expand-all :props="defaultProps" @node-click="handleNodeClick">
          </el-tree>
        </div>
        <div class="see-right">
          <embed :src='showUrl' type="application/pdf" width="100%" height="100%">
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button type="primary" @click="seeFlag1 = true" :disabled="clickFlag">下载</el-button>
        <el-button @click="seeFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!--  下载前确认 -->
    <el-dialog :visible.sync="seeFlag1" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle1.png" alt="">
        下载确认
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/nShow1.png" alt="">
        <div>确定要进行下载吗?</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="downSee">确定</el-button>
        <el-button @click="seeFlag1 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--  该文件非PDF,是否需要进行下载(查看失败) -->
    <el-dialog :visible.sync="notShow1" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle1.png" alt="">
        下载确认
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/nShow1.png" alt="">
        <div>该文档非PDF文件，是否要进行下载？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="clickDown">确定</el-button>
        <el-button @click="notShow1 = false">取消</el-button>
      </div>
    </el-dialog>
    <!--     对不起，您访问的材料还未扫描。(查看失败) -->
    <el-dialog :visible.sync="notShow2" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/nShow2.png" alt="">
        <div>对不起，您访问的材料还未扫描。</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="notShow2 = false">确定</el-button>
        <el-button @click="notShow2 = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { videoList, manageRk, manageBack, manageNo, manageKf, listYear, getYear, getScope, getStore, saveFileAdd, archList, archTree, BASICURL, powerTree } from '@/js/getData';
import { valueIndex } from '@/js/transitionText'
export default {
  name: 'sevenType',
  props: {
    paramsNew: {
      type: Object
    },
    tableNew: {
      type: Array
    }
  },
  data() {
    return {
      clickFlag: true,
      seeData: [],
      seeParams: {
        page: 1,
        rows: 4,
        total: null
      },
      downId: null,
      seeFlag1: false,
      seeFlag1: false,
      notShow2: false,
      notShow1: false,
      seeOne: [],
      pubArr: ['', '公开', '内部', '受控', '广发商密三级', '广发商密二级', '广发商密一级'],
      saveArr: ['', '短期', '长期', '永久', '', '10年', '15年', '', '30年', '', '35年'],
      typeFlag: false,
      showFlag: false,
      cArr: ['是', '否'],
      twoType: [],
      threeType: [],
      jumpFlag: false,
      seaFlag: false,
      params: this.paramsNew,
      titleFlag: false,
      titleMsg1: null,
      titleMsg2: null,
      fileData: this.tableNew,
      fileOne: [],
      remark: null,
      confirmRkFlag: false,
      noFlag: false,
      dataShow: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      seeFlag: false,
      showUrl: null,
      paramsSea: {},
      allFlag: false,
      printFlag: false,
      scopes: 3,
      scopeArr: [
        { id: 3, text: '3cm' },
        { id: 5, text: '5cm' }
      ],
      addressFlag: false,
      yearArr: [],
      perArr: [],
      labFileMaxFile: null,
      labFileMinFile: null,
      paramsAdd: {},
      matrixArr: [],
      matrixArr1: [],
      matrixArr2: [],
      matrixArr3: [],
      matrixArr4: [],
      matrixArr5: [],
      storeArr: [],
      bentArr: [],
      bentArr1: [],
      bentArr2: [],
      bentArr3: [],
      bentArr4: [],
      bentArr5: [],
      faceArr: [],
      faceArr1: [],
      faceArr2: [],
      faceArr3: [],
      faceArr4: [],
      faceArr5: [],
      gridArr: [],
      gridArr1: [],
      gridArr2: [],
      gridArr3: [],
      gridArr4: [],
      gridArr5: [],
      confirmAddFlag: false
    }
  },
  methods: {
    //获取档案列表
    searchOne() {
      this.params.page = 1;
      this.searchList();
    },
    searchList() {
      videoList(this.params).then(res => {
        if (res.code == 0) {
          if (res.data.total <= 0) {
            this.titleMsg1 = '系统消息';
            this.titleMsg2 = '该条件下查无数据!';
            this.titleFlag = true;
          }
          this.fileData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    fileCurr(val) {
      this.params.page = val;
      this.searchList();
    },
    fileSelect(val) {
      this.fileOne = val;
      this.seeOneList();
    },
    rowClassName({ row, rowIndex }) {
      //把每一行的索引放进row
      row.index = rowIndex;
    },
    //入库
    openRk() {
      let open = this.$onceWay().onceTableListTwo(this.fileOne);
      if (open == 1) {
        this.jumpFlag = true;
        this.remark = null
      }
    },
    clickJump() {
      let index = "";
      let tmp = false;
      let tmp1 = false;
      this.fileOne.forEach(item => {
        if (item.storagePlace == "" || item.storagePlace == null) {
          index = index + (item.index + 1) + " ";
          tmp = true;
        }
        if (item.containerStatus == "1") {
          index = index + (item.index + 1) + " ";
          tmp1 = true;
        }
      })
      if (tmp) {
        this.$message.error("行号为" + index + "没有存址号");
        return;
      }
      if (tmp1) {
        this.$message.error("行号为" + index + "已在库，无需再次入库");
        return;
      }
      if (this.remark == "" || this.remark == null) {
        this.$message.error("请填写意见");
        return;
      }
      this.confirmRkFlag = true;
    },
    confirmRk() {
      this.confirmRkFlag = false;
      let rkParams = {
        ids: this.$onceWay().deleteId(this.fileOne),
        remark: this.remark,
        type: 0,
      }
      manageRk(rkParams).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == "1") {
            this.$message.success("入库成功");
            this.jumpFlag = false;
            this.searchOne();
          } else if (res.data.optFlag == "-1") {
            this.$message.error("存在未生成存址号或者档案号的文件,入库失败");
          } else if (res.data.optFlag == "-2") {
            this.$message.error("该项目已入库");
          }
        } else this.$message.error(res.message)
      })
    },
    //退回整理
    openBack() {
      let open = this.$onceWay().onceTableListTwo(this.fileOne);
      if (open == 1) {
        let ids = this.$onceWay().deleteId(this.fileOne);
        manageBack({ ids: ids }).then(res => {
          if (res.code == 0) {
            if (res.data.optFlag == "-1") {
              this.$message.error("退回失败");
            } else {
              this.$message.success("退回成功");
              this.searchOne();
            }
          } else this.$message.error(res.message)
        })
      }
    },
    //去除存址号
    openNo() {
      let open = this.$onceWay().onceTableListTwo(this.fileOne);
      if (open == 1) {
        this.noFlag = true;
      }
    },
    confirmNo() {
      let index = "";
      let tmp = false;
      let tmp1 = false;
      this.fileOne.forEach(item => {
        if (item.storagePlace == "" || item.storagePlace == null) {
          index = index + (item.index + 1) + " ";
          tmp = true;
        }
        if (item.containerStatus == "1" || item.containerStatus == "2") {
          index = index + (item.index + 1) + " ";
          tmp1 = true;
        }
      })
      if (tmp) {
        this.$message.error("行号为" + index + "没有存址号");
        return;
      }
      if (tmp1) {
        this.$message.error("行号为" + index + "已在库，无法去除存址号");
        return;
      }
      let ids = this.$onceWay().deleteId(this.fileOne);
      manageNo({ ids: ids }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == "-1") {
            this.$message.error("操作失败");
          } else if (res.data.optFlag == "1") {
            this.$message.success("操作成功");
            this.noFlag = false;
            this.searchOne();
          }
        } else this.$message.error(res.message)
      })
    },
    //查询
    //打开检索
    openSea() {
      this.paramsSea = {};
      this.seaFlag = true;
    },
    searchSea() {
      this.resetInit();
      Object.assign(this.params, this.paramsSea);
      this.searchOne();
      this.seaFlag = false;
    },
    resetInit() {
      this.params.officeArchivalCode = null;
      this.params.titleProper = null;
      this.params.c63 = null;
      this.params.storagePlace = null;
      this.params.c68 = null;
    },
    //打印目录
    openAll() {
      if (this.fileOne.length <= 0) {
        this.allFlag = true;
      } else {
        this.allFlag = false;
        this.clickOther();
      }
    },
    confirmAll() {
      let alls = {
        fileIds: 'all',
        fonds: this.params.fonds,
        series: this.params.series1 || this.params.series2 || this.params.series3
      };
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/print', alls, '归档文件目录.doc', 'get');
      this.allFlag = false;
    },
    //打印选中的目录
    clickOther() {
      let flag = true;
      this.fileOne.forEach(item => {
        let index = item.index + 1;
        if (item.itemNo == "" || item.itemNo == null) {
          this.$message.error("行号为：" + index + "的数据没有件号，不可以打印!");
          flag = false;
          return;
        }
        if (item.caseNo == "" || item.caseNo == null) {
          this.$message.error("行号为：" + index + "的数据没有盒号，不可以打印!");
          flag = false;
          return;
        }
        if (item.retentionPeriod == "" || item.retentionPeriod == null) {
          this.$message.error("行号为：" + index + "的数据没有保管期限，不可以打印!");
          flag = false;
          return;
        }
      })
      if (flag) {
        let alls = {
          fileIds: this.$onceWay().deleteId(this.fileOne),
        };
        valueIndex().exportFiles('/gdda-new/gdda/archiveZL/print', alls, '归档文件目录.docx', 'get');
      }
    },
    //打印脊背
    openPrint() {
      if (this.fileOne.length <= 0) {
        this.$message.error("请选择需要打印脊背的档案!");
      } else {
        this.scopes = 3;
        let flag = true;
        this.fileOne.forEach(item => {
          let index = item.index + 1;
          if (item.itemNo == "" || item.itemNo == null) {
            this.$message.error("行号为：" + index + "的数据没有件号，不可以打印脊背!");
            flag = false;
            return;
          }
          if (item.caseNo == "" || item.caseNo == null) {
            this.$message.error("行号为：" + index + "的数据没有盒号，不可以打印脊背!");
            flag = false;
            return;
          }
          if (item.retentionPeriod == "" || item.retentionPeriod == null) {
            this.$message.error("行号为：" + index + "的数据没有保管期限，不可以打印脊背!");
            flag = false;
            return;
          }
        })
        if (flag) {
          this.printFlag = true;
        }
      }
    },
    confirmPrint() {
      let alls = {
        fileIds: this.$onceWay().deleteId(this.fileOne),
        scope: this.scopes
      };
      valueIndex().exportFiles('/gdda-new/gdda/archiveZL/printAnjianJibei', alls, '文书档案脊背.docx', 'get');
      this.printFlag = false;
    },
    //生成存址号
    openAddress() {
      this.getAllYear();
      this.getPer();
      this.getShow(0, 0);
      this.resetAdd();
      this.addressFlag = true;
    },
    //生成存址号--获取年份
    getAllYear() {
      let yearParam = {
        fonds: this.params.fonds,
        series1: this.params.series1,
        series2: this.params.series2,
        series3: this.params.series3,
        c0: 6
      };
      getYear(yearParam).then(res => {
        if (res.code == 0) {
          this.yearArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //生成存址号--保管期限下拉
    getPer() {
      listYear().then(res => {
        if (res.code == 0) {
          this.perArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //生成存址号--选中年份获取档号范围
    getRange() {
      let yearParam = {
        fonds: this.params.fonds,
        series1: this.params.series1,
        series2: this.params.series2,
        series3: this.params.series3,
        yearCode: this.paramsAdd.yearCode,
      };
      getScope(yearParam).then(res => {
        if (res.code == 0) {
          if (res.data.MaxboxFileNo2 == null || res.MaxboxFileNo2 == "") {
            this.labFileMinFile = res.data.MinboxFileNo;
            this.labFileMaxFile = res.data.MaxboxFileNo;
            this.paramsAdd.startMin = res.data.MinboxFileNo;
            this.paramsAdd.startMax = res.data.MaxboxFileNo;
          } else {
            this.labFileMinFile = res.data.MinboxFileNo;
            this.labFileMaxFile = res.data.MaxboxFileNo2;
            this.paramsAdd.startMin = res.data.MinboxFileNo;
            this.paramsAdd.startMax = res.data.MaxboxFileNo;
            this.paramsAdd.startMin3 = res.data.MinboxFileNo2;
            this.paramsAdd.startMax3 = res.data.MaxboxFileNo2;
          }
        } else this.$message.error(res.message)
      })
    },
    //生成存址号--选中保管期限获取档号范围
    getRange1() {
      let yearParam = {
        fonds: this.params.fonds,
        series1: this.params.series1,
        series2: this.params.series2,
        series3: this.params.series3,
        yearCode: this.paramsAdd.yearCode,
        retentionPeriod: this.paramsAdd.retentionPeriod
      };
      getScope(yearParam).then(res => {
        if (res.code == 0) {
          if (res.data.MaxboxFileNo2 == null || res.MaxboxFileNo2 == "") {
            this.labFileMinFile = res.data.MinboxFileNo;
            this.labFileMaxFile = res.data.MaxboxFileNo;
            this.paramsAdd.startMin = res.data.MinboxFileNo;
            this.paramsAdd.startMax = res.data.MaxboxFileNo;
          } else {
            this.labFileMinFile = res.data.MinboxFileNo;
            this.labFileMaxFile = res.data.MaxboxFileNo2;
            this.paramsAdd.startMin = res.data.MinboxFileNo;
            this.paramsAdd.startMax = res.data.MaxboxFileNo;
            this.paramsAdd.startMin3 = res.data.MinboxFileNo2;
            this.paramsAdd.startMax3 = res.data.MaxboxFileNo2;
          }
        } else this.$message.error(res.message)
      })
    },
    //获取存址联动集合
    getShow(val, flag) { //flag:0库房下拉 else 矩阵下拉
      let parentId = null;
      if (flag == 0) {
        parentId = 0
      } else {
        let obj = {};
        obj = this.storeArr.find(function(item) {
          return item.name === val
        })
        parentId = obj.itemValue;
      }
      getStore({ parentId: parentId }).then(res => {
        if (res.code == 0) {
          if (flag == 0) {
            this.storeArr = res.data;
          }
          if (flag == 1) {
            if (!this.paramsAdd.addrNo) {
              this.paramsAdd.matrix = ""
            }
            this.matrixArr = res.data;
          }
          if (flag == 2) {
            if (!this.paramsAdd.addrNo1) {
              this.paramsAdd.matrix1 = ""
            }
            this.matrixArr1 = res.data;
          }
          if (flag == 3) {
            if (!this.paramsAdd.addrNo2) {
              this.paramsAdd.matrix2 = ""
            }
            this.matrixArr2 = res.data;
          }
          if (flag == 4) {
            if (!this.paramsAdd.addrNo3) {
              this.paramsAdd.matrix3 = ""
            }
            this.matrixArr3 = res.data;
          }
          if (flag == 5) {
            if (!this.paramsAdd.addrNo4) {
              this.paramsAdd.matrix4 = ""
            }
            this.matrixArr4 = res.data;
          }
          if (flag == 6) {
            if (!this.paramsAdd.addrNo5) {
              this.paramsAdd.matrix5 = ""
            }
            this.matrixArr5 = res.data;
          }

        } else this.$message.error(res.message)

      })
    },
    //获取排架下拉
    getBend(val, flag) { //原逻辑后期优化（主要是select显示绑定label,下拉查接口又是value）
      let bend = null;
      if (flag == 1) {
        let obj = {};
        obj = this.matrixArr.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      if (flag == 2) {
        let obj = {};
        obj = this.matrixArr1.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      if (flag == 3) {
        let obj = {};
        obj = this.matrixArr2.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      if (flag == 4) {
        let obj = {};
        obj = this.matrixArr3.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      if (flag == 5) {
        let obj = {};
        obj = this.matrixArr4.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      if (flag == 6) {
        let obj = {};
        obj = this.matrixArr5.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      getStore({ parentId: bend }).then(res => {
        if (res.code == 0) {
          if (flag == 1) {
            if (!this.paramsAdd.addrNo) {
              this.paramsAdd.bent = ""
            }
            this.bentArr = res.data;
          }
          if (flag == 2) {
            if (!this.paramsAdd.addrNo1) {
              this.paramsAdd.bent1 = ""
            }
            this.bentArr1 = res.data;
          }
          if (flag == 3) {
            if (!this.paramsAdd.addrNo2) {
              this.paramsAdd.bent2 = ""
            }
            this.bentArr2 = res.data;
          }
          if (flag == 4) {
            if (!this.paramsAdd.addrNo3) {
              this.paramsAdd.bent3 = ""
            }
            this.bentArr3 = res.data;
          }
          if (flag == 5) {
            if (!this.paramsAdd.addrNo4) {
              this.paramsAdd.bent4 = ""
            }
            this.bentArr4 = res.data;
          }
          if (flag == 6) {
            if (!this.paramsAdd.addrNo5) {
              this.paramsAdd.bent5 = ""
            }
            this.bentArr5 = res.data;
          }
        } else this.$message.error(res.message)

      })
    },
    //获取面下拉
    getFace(val, flag) {
      let bend = null;
      if (flag == 1) {
        let obj = {};
        obj = this.bentArr.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      if (flag == 2) {
        let obj = {};
        obj = this.bentArr1.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      if (flag == 3) {
        let obj = {};
        obj = this.bentArr2.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      if (flag == 4) {
        let obj = {};
        obj = this.bentArr3.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      if (flag == 5) {
        let obj = {};
        obj = this.bentArr4.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      if (flag == 6) {
        let obj = {};
        obj = this.bentArr5.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      getStore({ parentId: bend }).then(res => {
        if (res.code == 0) {
          if (flag == 1) {
            if (!this.paramsAdd.addrNo) {
              this.paramsAdd.face = ""
            }
            this.faceArr = res.data;
          }
          if (flag == 2) {
            if (!this.paramsAdd.addrNo1) {
              this.paramsAdd.face1 = ""
            }
            this.faceArr1 = res.data;
          }
          if (flag == 3) {
            if (!this.paramsAdd.addrNo2) {
              this.paramsAdd.face2 = ""
            }
            this.faceArr2 = res.data;
          }
          if (flag == 4) {
            if (!this.paramsAdd.addrNo3) {
              this.paramsAdd.face3 = ""
            }
            this.faceArr3 = res.data;
          }
          if (flag == 5) {
            if (!this.paramsAdd.addrNo4) {
              this.paramsAdd.face4 = ""
            }
            this.faceArr4 = res.data;
          }
          if (flag == 6) {
            if (!this.paramsAdd.addrNo5) {
              this.paramsAdd.face5 = ""
            }
            this.faceArr5 = res.data;
          }
        } else this.$message.error(res.message)

      })
    },
    //获取行列下拉
    getGrid(val, flag) {
      let bend = null;
      if (flag == 1) {
        let obj = {};
        obj = this.faceArr.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      if (flag == 2) {
        let obj = {};
        obj = this.faceArr1.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      if (flag == 3) {
        let obj = {};
        obj = this.faceArr2.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      if (flag == 4) {
        let obj = {};
        obj = this.faceArr3.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      if (flag == 5) {
        let obj = {};
        obj = this.faceArr4.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      if (flag == 6) {
        let obj = {};
        obj = this.faceArr5.find(function(item) {
          return item.name === val
        })
        bend = obj.itemValue;
      }
      getStore({ parentId: bend }).then(res => {
        if (res.code == 0) {
          if (flag == 1) {
            if (!this.paramsAdd.addrNo) {
              this.paramsAdd.grid = ""
            }
            this.gridArr = res.data;
          }
          if (flag == 2) {
            if (!this.paramsAdd.addrNo1) {
              this.paramsAdd.grid1 = ""
            }
            this.gridArr1 = res.data;
          }
          if (flag == 3) {
            if (!this.paramsAdd.addrNo2) {
              this.paramsAdd.grid2 = ""
            }
            this.gridArr2 = res.data;
          }
          if (flag == 4) {
            if (!this.paramsAdd.addrNo3) {
              this.paramsAdd.grid3 = ""
            }
            this.gridArr3 = res.data;
          }
          if (flag == 5) {
            if (!this.paramsAdd.addrNo4) {
              this.paramsAdd.grid4 = ""
            }
            this.gridArr4 = res.data;
          }
          if (flag == 6) {
            if (!this.paramsAdd.addrNo5) {
              this.paramsAdd.grid5 = ""
            }
            this.gridArr5 = res.data;
          }
        } else this.$message.error(res.message)

      })
    },
    confirmAdd() {
      //数字验证正则表达式
      let reg = /^(0+(\.[0-9]{1,3}))$|^([0-9]{1,16})$|^([0-9]{1,16}\.[0-9]{1,3})$/;
      if (!this.paramsAdd.startMin || !this.paramsAdd.startMax) {} else {
        if (!this.paramsAdd.face || !this.paramsAdd.store || !this.paramsAdd.matrix || !this.paramsAdd.bent || !this.paramsAdd.grid || !this.paramsAdd.boxNo) {
          this.$message.error("请填写正确的存址号");
          return;
        } else {
          if (!reg.test(this.paramsAdd.weight) || !reg.test(this.paramsAdd.boxNo)) {
            this.$message.error("请检查第1行的箱号和重量是否为数字(最多3位小数，最大16整数)！");
            return
          }
        }
      }
      if (!this.paramsAdd.startMin1 || !this.paramsAdd.startMax1) {} else {
        if (!this.paramsAdd.face1 || !this.paramsAdd.store1 || !this.paramsAdd.matrix1 || !this.paramsAdd.bent1 || !this.paramsAdd.grid1 || !this.paramsAdd.boxNo1) {
          this.$message.error("请填写正确的存址号");
          return;
        } else {
          if (!reg.test(this.paramsAdd.weight1) || !reg.test(this.paramsAdd.boxNo1)) {
            this.$message.error("请检查第2行的箱号和重量是否为数字(最多3位小数，最大16整数)！");
            return
          }
        }
      }
      if (!this.paramsAdd.startMin2 || !this.paramsAdd.startMax2) {} else {
        if (!this.paramsAdd.face2 || !this.paramsAdd.store2 || !this.paramsAdd.matrix2 || !this.paramsAdd.bent2 || !this.paramsAdd.grid2 || !this.paramsAdd.boxNo2) {
          this.$message.error("请填写正确的存址号");
          return;
        } else {
          if (!reg.test(this.paramsAdd.weight2) || !reg.test(this.paramsAdd.boxNo2)) {
            this.$message.error("请检查第3行的箱号和重量是否为数字(最多3位小数，最大16整数)！");
            return
          }
        }
      }
      if (!this.paramsAdd.startMin3 || !this.paramsAdd.startMax3) {} else {
        if (!this.paramsAdd.face3 || !this.paramsAdd.store3 || !this.paramsAdd.matrix3 || !this.paramsAdd.bent3 || !this.paramsAdd.grid3 || !this.paramsAdd.boxNo3) {
          this.$message.error("请填写正确的存址号");
          return;
        } else {
          if (!reg.test(this.paramsAdd.weight3) || !reg.test(this.paramsAdd.boxNo3)) {
            this.$message.error("请检查第4行的箱号和重量是否为数字(最多3位小数，最大16整数)！");
            return
          }
        }
      }
      if (!this.paramsAdd.startMin4 || !this.paramsAdd.startMax4) {} else {
        if (!this.paramsAdd.face4 || !this.paramsAdd.store4 || !this.paramsAdd.matrix4 || !this.paramsAdd.bent4 || !this.paramsAdd.grid4 || !this.paramsAdd.boxNo4) {
          this.$message.error("请填写正确的存址号");
          return;
        } else {
          if (!reg.test(this.paramsAdd.weight4) || !reg.test(this.paramsAdd.boxNo4)) {
            this.$message.error("请检查第5行的箱号和重量是否为数字(最多3位小数，最大16整数)！");
            return
          }
        }
      }
      if (!this.paramsAdd.startMin5 || !this.paramsAdd.startMax5) {} else {
        if (!this.paramsAdd.face5 || !this.paramsAdd.store5 || !this.paramsAdd.matrix5 || !this.paramsAdd.bent5 || !this.paramsAdd.grid5 || !this.paramsAdd.boxNo5) {
          this.$message.error("请填写正确的存址号");
          return;
        } else {
          if (!reg.test(this.paramsAdd.weight5) || !reg.test(this.paramsAdd.boxNo5)) {
            this.$message.error("请检查第6行的箱号和重量是否为数字(最多3位小数，最大16整数)！");
            return
          }
        }
      }
      if (!this.paramsAdd.startMax && !this.paramsAdd.startMax1) {} else {
        if (this.paramsAdd.startMax.substr(0, this.paramsAdd.startMax.lastIndexOf('-')) == this.paramsAdd.startMin1.substr(0, this.paramsAdd.startMin1.lastIndexOf('-'))) {
          if (parseInt(this.paramsAdd.startMax.substr(this.paramsAdd.startMax.lastIndexOf('-') + 1)) + 1 != this.paramsAdd.startMin1.substr(this.paramsAdd.startMin1.lastIndexOf('-') + 1)) {
            this.$message.error("填写的档案号不连续");
            return;
          }
        }
      }
      if (!this.paramsAdd.startMax1 && !this.paramsAdd.startMax2) {} else {
        if (this.paramsAdd.startMax1.substr(0, this.paramsAdd.startMax1.lastIndexOf('-')) == this.paramsAdd.startMin2.substr(0, this.paramsAdd.startMin2.lastIndexOf('-'))) {
          if (parseInt(this.paramsAdd.startMax1.substr(this.paramsAdd.startMax1.lastIndexOf('-') + 1)) + 1 != this.paramsAdd.startMin2.substr(this.paramsAdd.startMin2.lastIndexOf('-') + 1)) {
            this.$message.error("填写的档案号不连续");
            return;
          }
        }
      }
      if (!this.paramsAdd.startMax2 && !this.paramsAdd.startMax3) {} else {
        if (this.paramsAdd.startMax2.substr(0, this.paramsAdd.startMax2.lastIndexOf('-')) == this.paramsAdd.startMin3.substr(0, this.paramsAdd.startMin3.lastIndexOf('-'))) {
          if (parseInt(this.paramsAdd.startMax2.substr(this.paramsAdd.startMax2.lastIndexOf('-') + 1)) + 1 != this.paramsAdd.startMin3.substr(this.paramsAdd.startMin3.lastIndexOf('-') + 1)) {
            this.$message.error("填写的档案号不连续");
            return;
          }
        }
      }
      if (!this.paramsAdd.startMax3 && !this.paramsAdd.startMax4) {} else {
        if (this.paramsAdd.startMax3.substr(0, this.paramsAdd.startMax3.lastIndexOf('-')) == this.paramsAdd.startMin4.substr(0, this.paramsAdd.startMin4.lastIndexOf('-'))) {
          if (parseInt(this.paramsAdd.startMax3.substr(this.paramsAdd.startMax3.lastIndexOf('-') + 1)) + 1 != this.paramsAdd.startMin4.substr(this.paramsAdd.startMin4.lastIndexOf('-') + 1)) {
            this.$message.error("填写的档案号不连续");
            return;
          }
        }
      }
      if (!this.paramsAdd.startMax4 && !this.paramsAdd.startMax5) {} else {
        if (this.paramsAdd.startMax4.substr(0, this.paramsAdd.startMax4.lastIndexOf('-')) == this.paramsAdd.startMin5.substr(0, this.paramsAdd.startMin5.lastIndexOf('-'))) {
          if (parseInt(this.paramsAdd.startMax4.substr(this.paramsAdd.startMax4.lastIndexOf('-') + 1)) + 1 != this.paramsAdd.startMin5.substr(this.paramsAdd.startMin5.lastIndexOf('-') + 1)) {
            this.$message.error("填写的档案号不连续");
            return;
          }
        }
      }
      this.paramsAdd.c0 = 20;
      this.paramsAdd.fonds = this.params.fonds;
      this.paramsAdd.series1 = this.params.series1;
      this.paramsAdd.series2 = this.params.series2;
      this.paramsAdd.series3 = this.params.series3;
      saveFileAdd(this.paramsAdd).then(res => {
        if (res.code == 0) {
          if (res.data.flag == "0") {
            this.$message.error(res.msg)
          } else if (res.data.flag == "1") {
            this.$message.success("操作成功");
            this.searchOne();
            this.confirmAddFlag = false;
            this.addressFlag = false;
          }
        } else this.$message.error(res.message)
      })
    },
    resetAdd() {
      this.paramsAdd = {
        startMin: "",
        startMin1: "",
        startMin2: "",
        startMin3: "",
        startMin4: "",
        startMin5: "",
        startMax: "",
        startMax1: "",
        startMax2: "",
        startMax3: "",
        startMax4: "",
        startMax5: ""
      }
    },
    //获取号值
    initAddress(flag) {
      if (flag == 1) {
        let address = this.paramsAdd.store + this.paramsAdd.matrix + this.paramsAdd.bent + this.paramsAdd.face + this.paramsAdd.grid;
        if (this.paramsAdd.addrNo != address && this.paramsAdd.addrNo.length >= 8) {
          this.validateAdd("");
        } else this.paramsAdd.addrNo = address
      }
      if (flag == 2) {
        let address = this.paramsAdd.store1 + this.paramsAdd.matrix1 + this.paramsAdd.bent1 + this.paramsAdd.face1 + this.paramsAdd.grid1;
        if (this.paramsAdd.addrNo1 != address && this.paramsAdd.addrNo1.length >= 8) {
          this.validateAdd("1");
        } else this.paramsAdd.addrNo1 = address
      }
      if (flag == 3) {
        let address = this.paramsAdd.store2 + this.paramsAdd.matrix2 + this.paramsAdd.bent2 + this.paramsAdd.face2 + this.paramsAdd.grid2;
        if (this.paramsAdd.addrNo2 != address && this.paramsAdd.addrNo2.length >= 8) {
          this.validateAdd("2");
        } else this.paramsAdd.addrNo2 = address
      }
      if (flag == 4) {
        let address = this.paramsAdd.store3 + this.paramsAdd.matrix3 + this.paramsAdd.bent3 + this.paramsAdd.face3 + this.paramsAdd.grid3;
        if (this.paramsAdd.addrNo3 != address && this.paramsAdd.addrNo3.length >= 8) {
          this.validateAdd("3");
        } else this.paramsAdd.addrNo3 = address
      }
      if (flag == 5) {
        let address = this.paramsAdd.store4 + this.paramsAdd.matrix4 + this.paramsAdd.bent4 + this.paramsAdd.face4 + this.paramsAdd.grid4;
        if (this.paramsAdd.addrNo4 != address && this.paramsAdd.addrNo4.length >= 8) {
          this.validateAdd("4");
        } else this.paramsAdd.addrNo4 = address
      }
      if (flag == 6) {
        let address = this.paramsAdd.store5 + this.paramsAdd.matrix5 + this.paramsAdd.bent5 + this.paramsAdd.face5 + this.paramsAdd.grid5;
        if (this.paramsAdd.addrNo5 != address && this.paramsAdd.addrNo5.length >= 8) {
          this.validateAdd("5");
        } else this.paramsAdd.addrNo5 = address
      }
    },
    validateAdd(val) {
      let addrNo = "";
      if (val == "") {
        addrNo = this.paramsAdd.addrNo
      } else if (val == "1") {
        addrNo = this.paramsAdd.addrNo1
      } else if (val == "2") {
        addrNo = this.paramsAdd.addrNo2
      } else if (val == "3") {
        addrNo = this.paramsAdd.addrNo3
      } else if (val == "4") {
        addrNo = this.paramsAdd.addrNo4
      } else if (val == "5") {
        addrNo = this.paramsAdd.addrNo5
      }
      if (addrNo != "" && addrNo != null && addrNo.length >= 8) {
        this.checkAddrNo(val, addrNo);
      }
    },
    checkAddrNo(id, val) {
      checkStore({ storeValue: val }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 1) {
            this.setAddress(id, val)
          }
        } else this.$message.error(res.message)
      })
    },
    setAddress(id, addrNo) {
      var store = addrNo.substr(0, 2);
      var matrix = addrNo.substr(2, 1);
      var bent = addrNo.substr(3, 2);
      var face = addrNo.substr(5, 1);
      var grid = addrNo.substr(6, 2);
      var boxNo = addrNo.substr(9, 5);
      if (id == "") {
        this.paramsAdd.store = store;
        this.paramsAdd.matrix = matrix;
        this.paramsAdd.bent = bent;
        this.paramsAdd.face = face;
        this.paramsAdd.grid = grid;
        this.paramsAdd.boxNo = boxNo;
      }
      if (id == "1") {
        this.paramsAdd.store1 = store;
        this.paramsAdd.matrix1 = matrix;
        this.paramsAdd.bent1 = bent;
        this.paramsAdd.face1 = face;
        this.paramsAdd.grid1 = grid;
        this.paramsAdd.boxNo1 = boxNo;
      }
      if (id == "2") {
        this.paramsAdd.store2 = store;
        this.paramsAdd.matrix2 = matrix;
        this.paramsAdd.bent2 = bent;
        this.paramsAdd.face2 = face;
        this.paramsAdd.grid2 = grid;
        this.paramsAdd.boxNo2 = boxNo;
      }
      if (id == "3") {
        this.paramsAdd.store3 = store;
        this.paramsAdd.matrix3 = matrix;
        this.paramsAdd.bent3 = bent;
        this.paramsAdd.face3 = face;
        this.paramsAdd.grid3 = grid;
        this.paramsAdd.boxNo3 = boxNo;
      }
      if (id == "4") {
        this.paramsAdd.store4 = store;
        this.paramsAdd.matrix4 = matrix;
        this.paramsAdd.bent4 = bent;
        this.paramsAdd.face4 = face;
        this.paramsAdd.grid4 = grid;
        this.paramsAdd.boxNo4 = boxNo;
      }
      if (id == "5") {
        this.paramsAdd.store5 = store;
        this.paramsAdd.matrix5 = matrix;
        this.paramsAdd.bent5 = bent;
        this.paramsAdd.face5 = face;
        this.paramsAdd.grid5 = grid;
        this.paramsAdd.boxNo5 = boxNo;
      }
    },
    //查看
    //查看列表
    seeList() {
      if (this.fileOne.length > 0) {
        this.seeParams.fileId = this.fileOne[0].id;
      } else this.seeParams.fileId = "";
      this.seeParams.flag = 0;
      archList(this.seeParams).then(res => {
        if (res.code == 0) {
          this.seeData = res.data.rows;
          this.seeParams.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    seeSelect(val) {
      this.seeOne = val;
    },
    seeCurr(val) {
      this.seeParams.page = val;
      this.seeList();
    },
    seeOneList() {
      this.seeParams.page = 1;
      this.seeList();
    },
    //查看--加载树
    openSee(val) {
      let open = this.$onceWay().onceTableList(this.seeOne);
      if (open == 1) {
        this.downName = "";
        this.dataShow = [];
        this.seeTree();
        this.seeFlag = true;
      }
    },
    seeTree() {
      let seeParams = {
        id: this.fileOne[0].id,
        bs: 'saveAj'
      }
      archTree(seeParams).then(res => {
        if (res.code == 0) {
          this.dataShow = res.data;
        } else this.$message.error(res.message);
      })
    },
    handleNodeClick(val) {
      if (val.id != "0") {
        this.downName = val.text;
        this.showUrl = null;
        this.downId = val.id;
        powerTree({ id: val.id }).then(res => {
          if (res.code == 0) {
            if (res.data.optFlag == "2") { //页面会显示 该文件非PDF,是否需要进行下载
              this.clickFlag = true;
              this.notShow1 = true;
            } else if (res.data.optFlag == "-1") { //会显示 对不起，你访问的文件还未扫描
              this.clickFlag = true;
              this.notShow2 = true;
            } else {
              this.clickFlag = false;
              this.showUrl = BASICURL + '/gdda-new/gdda/util/viewPdf?docId=' + val.id;
            }
          } else this.$message.error(res.message);
        })
      }
    },
    //下载文件
    clickDown() {
      let ids = {
        id: this.downId,
        mode: 'saveAj'
      }
      valueIndex().exportFiles('/gdda-new/gdda/util/downLoadFile', ids, this.downName, 'get');
      this.notShow1 = false;
    },
    downSee() {
      let ids = { id: this.downId }
      valueIndex().exportFiles('/gdda-new/gdda/util/downLoadFile', ids, this.downName, 'get');
    }
  },
  watch: { // 监听到数据然后赋值
    paramsNew: {
      handler(newV, oldV) {
        this.params = JSON.parse(JSON.stringify(newV));
      },
      deep: true
    },
    tableNew: {
      handler(newV, oldV) {
        this.fileData = JSON.parse(JSON.stringify(newV))
      },
      deep: true
    }
  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.see {
  width: 100%;
  clear: both;
  margin-top: -30px;
  height: 500px;

  .see-left {
    width: 40%;
    float: left;
    padding-top: 20px;
    overflow: auto;
    height: 100%;

    .filter-tree {
      display: inline-block;
    }
  }

  .see-right {
    width: 59%;
    height: 100%;
    padding-top: 20px;
    float: left;
    border-left: 3px solid #1982BF;
  }
}

.address {
  border: 1px solid #6e6e6e;
  border-bottom: 0;
}

.address-show {
  width: 100%;
  height: 74px;
  text-align: center;
  font-size: 20px;
  color: #333;
  background-color: #e7f5ff;
  border-bottom: 1px solid #6e6e6e;
  line-height: 74px;
}

.address-div {
  width: 100%;
  height: 74px;
  border-bottom: 1px solid #6e6e6e;
  clear: both;

  .address-left {
    width: 300px;
    border-right: 1px solid #6e6e6e;
    height: 100%;
    float: left;
    line-height: 74px;
    padding-left: 5px;

    label {
      font-size: 12px;
      color: #282828;
      padding-right: 5px
    }

    .el-input {
      width: 120px;
    }
  }

  .address-cen {
    width: 58px;
    border-right: 1px solid #6e6e6e;
    height: 100%;
    float: left;
    line-height: 74px;
    text-align: center;

  }

  .address-right {
    width: 786px;
    float: left;
    padding-left: 6px;

    span {
      padding-top: 6px;
      display: inline-block;
    }

    label {
      font-size: 12px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 71px;
    }
  }
}

.address-top {
  margin-bottom: 30px;
  margin-left: 170px;

  span {
    display: inline-block;
    color: #282828;
    font-size: 16px;
    cursor: pointer;
    margin-right: 10px;
    cursor: pointer;
  }

  .address-doc {
    label {
      font-size: 16px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 180px;
    }
  }
}

.search-doc {
  margin-top: 10px;

  label {
    font-size: 14px;
    color: #282828;
    padding-right: 5px
  }

  .el-input,
  .el-select {
    width: 200px;
  }
}

.doc-main {
  background-color: #fff;
  min-height: 700px;

  .mb-20 {

    margin-bottom: 20px;
  }

  .doc-down {
    font-size: 13px;
    color: #515BED;
    float: right;
  }

  .doc-doss {
    width: 100%;
    height: 500px;
    overflow: auto;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .mt-f18 {
    margin-top: -18px;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .lend-table {
    max-height: 200px;
    overflow-y: auto;
    width: 100%
  }
}

.w-100 {
  width: 100%
}

</style>
<style lang="less">
.filter-tree {
  .el-tree__empty-block {
    width: 200px;
  }
}

</style>
