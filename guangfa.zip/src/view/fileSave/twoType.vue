<!-- 条件2--业务档案 -->
<template>
  <div>
    <div>
      <div>
        <div class="headerBtn mb-20">
          <span @click="openRk"><img src="../../assets/save/s1.png" alt="">入库</span>
          <span @click="openView"><img src="../../assets/confirmed/a4.png" alt="">查看</span>
          <span @click="openBack"><img src="../../assets/save/s2.png" alt="">退回整理</span>
          <span @click="openBackTou"><img src="../../assets/save/s2.png" alt="">退回整理(入库档案)</span>
          <span @click="openNo"><img src="../../assets/save/s3.png" alt="">去除存址号</span>
          <span @click="openCase"><img src="../../assets/save/s11.png" alt="">修改存址号</span>
          <span @click="openAddress"><img src="../../assets/save/s5.png" alt="">生成存址号</span>
          <span @click="openSea"><img src="../../assets/system/p8.png" alt="">检索</span>
          <span @click="openDiur"><img src="../../assets/save/s4.png" alt="">查看日志</span>
        </div>
        <!-- 表格 -->
        <div>
          <div class='all-Table' style="max-height: 530px;overflow-y: auto;">
            <el-table :data="fileData" stripe border @selection-change="fileSelect">
              <el-table-column type="selection" width="55">
              </el-table-column>
              <el-table-column prop="c5" label="状态" width="100px">
                <template slot-scope="scope">
                  {{c5Arr[scope.row.c5]}}
                </template>
              </el-table-column>
              <el-table-column prop="c18" label="项目编号" width="120px">
              </el-table-column>
              <el-table-column prop="titleProper" label="项目名称" width="140px">
              </el-table-column>
              <el-table-column prop="yearCode" label="年度" width="100px">
              </el-table-column>
              <el-table-column prop="c20" label="项目类型" width="150px">
              </el-table-column>
              <el-table-column prop="c22" label="业务类型" width="140px">
              </el-table-column>
              <el-table-column prop="c24" label="项目单位全称" width="300px">
              </el-table-column>
              <el-table-column prop="c10" label="股票代码" width="120px">
              </el-table-column>
              <el-table-column prop="c28" label="承做单位" width="150px">
              </el-table-column>
              <el-table-column prop="openingType" label="公开属性" width="100px">
                <template slot-scope="scope">
                  {{pubArr[scope.row.openingType]}}
                </template>
              </el-table-column>
              <el-table-column prop="retentionPeriod" label="保管期限" width="120px">
                <template slot-scope="scope">
                  {{saveArr[scope.row.retentionPeriod]}}
                </template>
              </el-table-column>
              <el-table-column prop="seriesCode" label="分类号" width="100px">
              </el-table-column>
              <el-table-column prop="filingDept" label="归档部门" width="120px">
              </el-table-column>
              <el-table-column prop="filingUser" label="归档人" width="120px">
              </el-table-column>
              <el-table-column prop="filingDate" label="归档日期" width="120px">
              </el-table-column>
              <el-table-column prop="lastDate" label="提交日期" width="150px">
              </el-table-column>
              <el-table-column prop="addressNo" label="存址号" width="120px">
              </el-table-column>
            </el-table>
          </div>
          <!-- 分页 -->
          <div class="pageLayout">
            <el-pagination @current-change="fileCurr" :current-page="params.page" :page-size="params.rows" layout="prev, pager, next, jumper" :total="params.total">
            </el-pagination>
          </div>
        </div>
        <!-- 下方查看 -->
        <div>
          <el-tabs v-model="bottomShow" type="card" @tab-click="bottomClick">
            <el-tab-pane label="案卷层" name="first">
              <div class="headerBtn mb-20">
                <span @click="openSee1"><img src="../../assets/confirmed/a4.png" alt="">查看</span>
              </div>
              <div class='all-Table'>
                <el-table :data="folderData" stripe border @selection-change="folderSelect">
                  <el-table-column type="selection" width="55">
                  </el-table-column>
                  <el-table-column prop="c11" label="项目名称" width="300px">
                  </el-table-column>
                  <el-table-column prop="folderNo" label="案卷号" width="140px">
                  </el-table-column>
                  <el-table-column prop="titleProper" label="案卷题名">
                  </el-table-column>
                  <el-table-column prop="openingType" label="公开属性" width="100px">
                    <template slot-scope="scope">
                      {{pubArr[scope.row.openingType]}}
                    </template>
                  </el-table-column>
                  <el-table-column prop="retentionPeriod" label="保管期限" width="120px">
                    <template slot-scope="scope">
                      {{saveArr[scope.row.retentionPeriod]}}
                    </template>
                  </el-table-column>
                  <el-table-column prop="seriesCode" label="分类号" width="120px">
                  </el-table-column>
                  <el-table-column prop="c19" label="编制单位" width="120px">
                  </el-table-column>
                  <el-table-column prop="filingDept" label="归档部门" width="120px">
                  </el-table-column>
                  <el-table-column prop="filingDate" label="归档日期" width="120px">
                  </el-table-column>
                </el-table>
              </div>
              <!-- 分页 -->
              <div class="pageLayout">
                <el-pagination @current-change="folderCurr" :current-page="folderParams.page" :page-size="folderParams.rows" layout="prev, pager, next, jumper" :total="folderParams.total">
                </el-pagination>
              </div>
            </el-tab-pane>
            <el-tab-pane label="文件层" name="second">
              <div class="headerBtn mb-20">
                <span @click="openSee2"><img src="../../assets/confirmed/a4.png" alt="">查看</span>
              </div>
              <div class='all-Table'>
                <el-table :data="hangData" stripe border @selection-change="hangSelect">
                  <el-table-column type="selection" width="55">
                  </el-table-column>
                  <el-table-column prop="officeArchivalCode" label="档案号" width="120px">
                  </el-table-column>
                  <el-table-column prop="storagePlace" label="存址号" width="140px">
                  </el-table-column>
                  <el-table-column prop="c220" label="案卷号" width="120px">
                  </el-table-column>
                  <el-table-column prop="caseNo" label="盒号" width="120px">
                  </el-table-column>
                  <el-table-column prop="itemNo" label="件号" width="120px">
                  </el-table-column>
                  <el-table-column prop="titleProper" label="文件题名" width="300px">
                  </el-table-column>
                  <el-table-column prop="c72" label="章节号" width="100px">
                  </el-table-column>
                  <el-table-column prop="dateOfCreation" label="文件日期" width="160px">
                  </el-table-column>
                  <el-table-column prop="yearCode" label="年度" width="100px">
                  </el-table-column>
                  <el-table-column prop="c229" label="页号" width="100px">
                  </el-table-column>
                  <el-table-column prop="seriesCode" label="分类号" width="100px">
                  </el-table-column>
                  <el-table-column prop="filingDept" label="归档部门" width="100px">
                  </el-table-column>
                  <el-table-column prop="filingDate" label="归档日期" width="100px">
                  </el-table-column>
                  <el-table-column prop="c76" label="索引备注" width="100px">
                  </el-table-column>
                  <el-table-column prop="c77" label="情况说明" width="100px">
                  </el-table-column>
                </el-table>
              </div>
              <!-- 分页 -->
              <div class="pageLayout">
                <el-pagination @current-change="hangCurr" :current-page="hangParams.page" :page-size="hangParams.rows" layout="prev, pager, next, jumper" :total="hangParams.total">
                </el-pagination>
              </div>
            </el-tab-pane>
          </el-tabs>
        </div>
      </div>
    </div>
    <!-- 检索系统提示 -->
    <el-dialog :visible.sync="titleFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        {{titleMsg1}}
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>{{titleMsg2}}</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="titleFlag = false">确定</el-button>
      </div>
    </el-dialog>
    <!-- 入库 -->
    <el-dialog :visible.sync="jumpFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/save/s7.png" alt="">
        入库意见
      </div>
      <div>
        <el-form label-width="80px">
          <el-form-item label="意见：">
            <el-input type="textarea" :rows="5" v-model="remark" style="width: 90%"></el-input>
          </el-form-item>
        </el-form>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="clickJump">保存</el-button>
        <el-button @click="jumpFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 入库前确认 -->
    <el-dialog :visible.sync="confirmRkFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定要入库？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="confirmRk">确定</el-button>
        <el-button @click="confirmRkFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 去除存址号 -->
    <el-dialog :visible.sync="noFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定去除存址号吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="confirmNo">确定</el-button>
        <el-button @click="noFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 日志 -->
    <el-dialog :visible.sync="diurFlag" class="hurdleAll" width="1100px">
      <div slot="title" class="dialog-title">
        <img src="../../assets/save/s8.png" alt />
        库房日志
      </div>
      <div>
        <div class="all-Table">
          <el-table :data="tableDiur" border>
            <el-table-column prop="module" label="模块" width="140"></el-table-column>
            <el-table-column prop="storeType" label="操作功能" width="140"></el-table-column>
            <el-table-column prop="operator" label="操作人" width="140"></el-table-column>
            <el-table-column prop="createTime" label="操作时间" width="180"></el-table-column>
            <el-table-column prop="remark" label="意见"></el-table-column>
          </el-table>
        </div>
        <!-- 分页 -->
        <div class="pageLayout">
          <el-pagination @current-change="diurCurrChange" :current-page="diurParams.page" :page-size="diurParams.rows" layout="prev, pager, next, jumper" :total="diurParams.total">
          </el-pagination>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button @click="diurFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 检索 -->
    <el-dialog :visible.sync="seaFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/system/u2.png" alt="">
        检索
      </div>
      <el-form :model="paramsSea" label-width="120px" style="height: 419px;overflow-y: auto;">
        <el-form-item label="档案类型：">
          <el-input v-model="paramsSea.thseriesCode"></el-input>
        </el-form-item>
        <el-form-item label="归档部门：">
          <el-select v-model="paramsSea.thfilingDept" class="w-100" filterable>
            <el-option v-for="item in deptArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="项目编号：">
          <el-input v-model="paramsSea.thc18"></el-input>
        </el-form-item>
        <el-form-item label="年度：">
          <el-input v-model="paramsSea.thyearCode"></el-input>
        </el-form-item>
        <el-form-item label="状态">
          <el-select v-model="paramsSea.thc5" class="w-100" filterable>
            <el-option v-for="item in statusArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="股票代码：">
          <el-input v-model="paramsSea.thc10"></el-input>
        </el-form-item>
        <el-form-item label="项目单位全称：">
          <el-input v-model="paramsSea.thc24"></el-input>
        </el-form-item>
        <el-form-item label="项目名称：">
          <el-input v-model="paramsSea.thtitleProper"></el-input>
        </el-form-item>
        <el-form-item label="项目类型：">
          <el-input v-model="paramsSea.thc20"></el-input>
        </el-form-item>
        <el-form-item label="业务类型：">
          <el-input v-model="paramsSea.thc22"></el-input>
        </el-form-item>
        <el-form-item label="承做单位：">
          <el-input v-model="paramsSea.thc28"></el-input>
        </el-form-item>
        <el-form-item label="存址号：">
          <el-input v-model="paramsSea.addressNo"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer all-btn mt-31">
        <el-button type="primary" @click="searchSea">检索</el-button>
        <el-button type="primary" @click="paramsSea ={}">重置条件</el-button>
        <el-button @click="seaFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 查看 -->
    <!-- 查看中的详情 -->
    <el-dialog :visible.sync="seeFlag" width="1100px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/topicShow.png" alt="">
        档案查看
      </div>
      <div class="see">
        <div class="see-left">
          <el-tree class="filter-tree" :highlight-current="true" ref="treeShow" node-key="id" :expand-on-click-node="false" :data="dataShow" default-expand-all :props="defaultProps" @node-click="handleNodeClick">
          </el-tree>
        </div>
        <div class="see-right">
          <el-tabs v-model="activeName" type="card" @tab-click="handleClick">
            <!-- 项目基本信息 -->
            <el-tab-pane label="基本信息" name="first" v-if="showType =='p'">
              <el-form :model="paramsDetail" label-width="120px">
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="档案类型：">
                      <el-input v-model="paramsDetail.seriesCode"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="归档部门：">
                      <el-select v-model="paramsDetail.filingDept" class="w-100" filterable>
                        <el-option v-for="item in deptArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="项目编号：">
                      <el-input v-model="paramsDetail.c18"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="年度：">
                      <el-input v-model="paramsDetail.yearCode"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="股票代码：">
                      <el-input v-model="paramsDetail.c10"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="项目单位全称：">
                      <el-input v-model="paramsDetail.c24"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="项目名称：">
                      <el-input v-model="paramsDetail.titleProper"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="项目类型：">
                      <el-input v-model="paramsDetail.c20"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="业务类型：">
                      <el-input v-model="paramsDetail.c22"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="承做单位：">
                      <el-input v-model="paramsDetail.c28"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
              </el-form>
            </el-tab-pane>
            <!-- 案卷基本信息 -->
            <el-tab-pane label="基本信息" name="first" v-if="showType =='v'">
              <el-form :model="paramsDetail" label-width="120px">
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="项目名称：">
                      <el-input v-model="paramsDetail.c11"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="保管期限：">
                      <el-select v-model="paramsDetail.retentionPeriod" class="w-100" filterable>
                        <el-option v-for="item in saveDateArr" :key="item.itemValue" :value="item.itemValue" :label="item.name"></el-option>
                      </el-select>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-form-item label="案卷题名：">
                  <el-input v-model="paramsDetail.titleProper"></el-input>
                </el-form-item>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="编制单位：">
                      <el-input v-model="paramsDetail.c19"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="年度：">
                      <el-input v-model="paramsDetail.yearCode"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="归档日期：">
                      <el-date-picker v-model="paramsDetail.filingDate" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" class="w-100"></el-date-picker>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-form-item label="备注：">
                  <el-input v-model="paramsDetail.folderNote" type="textarea" rows="2"></el-input>
                </el-form-item>
              </el-form>
            </el-tab-pane>
            <!-- 档案基本信息 -->
            <el-tab-pane label="基本信息" name="first" v-if="showType =='f'">
              <el-form :model="paramsDetail" label-width="120px">
                <el-form-item label="题名：">
                  <el-input v-model="paramsDetail.titleProper"></el-input>
                </el-form-item>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="保管期限：">
                      <el-input v-model="paramsDetail.retentionPeriod"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="章节号：">
                      <el-input v-model="paramsDetail.c72"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="年度：">
                      <el-input v-model="paramsDetail.yearCode"></el-input>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="页号：">
                      <el-input v-model="paramsDetail.c229"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row :gutter="20">
                  <el-col :span="12">
                    <el-form-item label="归档日期：">
                      <el-date-picker v-model="paramsDetail.filingDate" type="date" format="yyyy-MM-dd" value-format="yyyy-MM-dd" class="w-100"></el-date-picker>
                    </el-form-item>
                  </el-col>
                  <el-col :span="12">
                    <el-form-item label="编制单位：">
                      <el-input v-model="paramsDetail.c133"></el-input>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-form-item label="索引备注：">
                  <el-input v-model="paramsDetail.c76" type="textarea" rows="2"></el-input>
                </el-form-item>
                <el-form-item label="情况说明：">
                  <el-input v-model="paramsDetail.c77" type="textarea" rows="2"></el-input>
                </el-form-item>
                <el-form-item label="备注：">
                  <el-input v-model="paramsDetail.c8" type="textarea" rows="2"></el-input>
                </el-form-item>
              </el-form>
            </el-tab-pane>
            <!-- 电子全文 -->
            <el-tab-pane label="电子全文" name="second" v-if="showType1 =='d'">
              <div>
                <embed :src='showUrl' type="application/pdf" width="100%" height="400px">
              </div>
            </el-tab-pane>
          </el-tabs>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn">
        <el-button @click="seeFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!--  下载前确认 -->
    <el-dialog :visible.sync="isDownFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle1.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/nShow1.png" alt="">
        <div>该电子全文暂不提供在线浏览，您是否要离线下载此文件？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="downSee">确定</el-button>
        <el-button @click="isDownFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 修改存址号 -->
    <el-dialog :visible.sync="updateFlag" width="1200px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/home/submit.png" alt />
        修改存址号
      </div>
      <div>
        <div>
          <!-- 头部 -->
          <div class="address-top">
            <span class="address-doc">
              <label>盒号</label>
              <el-select v-model.trim="paramsAdd.caseNo" @change="getCase">
                <el-option v-for="item in caseArr" :key="item.id" :value="item.id" :label="item.text"></el-option>
              </el-select>
            </span>
            <span class="address-doc">
              <label>年份</label>
              <el-select v-model.trim="paramsAdd.year" @change="getCase">
                <el-option v-for="item in yearArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
              </el-select>
            </span>
            <span>档号范围： {{paramsAdd.labMin}}至{{paramsAdd.labMax}}</span>
          </div>
          <!-- 表数据 -->
          <div class="address">
            <div v-for="(oneNo,index) in allNo">
              <div class="address-div">
                <div class="address-left">
                  <span><label>起-{{startMin}}</label>
                    <el-input size="mini" v-model.trim="oneNo.startMin" maxlength="12"></el-input>
                  </span>
                  <span><label>止-{{startMax}}</label>
                    <el-input size="mini" v-model.trim="oneNo.startMax" maxlength="12"></el-input>
                  </span>
                </div>
                <span class="address-cen">存址号</span>
                <div class="address-right">
                  <span><label>库房</label>
                    <el-select size="mini" v-model.trim="oneNo.store" @change="((val)=>{getMatrix(val,index+1)})">
                      <el-option v-for="item in storeArr" :key="item.name" :value="item.name" :label="item.name"></el-option>
                    </el-select>
                  </span>
                  <span><label>矩阵</label>
                    <el-select size="mini" v-model.trim="oneNo.matrix" @change="((val)=>{getBend(val,index+1)})">
                      <el-option v-for="item in oneNo.matrixArr" :key="item.itemVlaue" :value="item.name" :label="item.name"></el-option>
                    </el-select>
                  </span>
                  <span><label>排架</label>
                    <el-select size="mini" v-model.trim="oneNo.bent" @change="((val)=>{getFace(val,index+1)})">
                      <el-option v-for="item in oneNo.bentArr" :key="item.name" :value="item.name" :label="item.name"></el-option>
                    </el-select>
                  </span>
                  <span><label>面</label>
                    <el-select size="mini" v-model.trim="oneNo.face" @change="((val)=>{getGrid(val,index+1)})">
                      <el-option v-for="item in oneNo.faceArr" :key="item.name" :value="item.name" :label="item.name"></el-option>
                    </el-select>
                  </span>
                  <span><label>列行</label>
                    <el-select size="mini" v-model.trim="oneNo.grid" @change="$forceUpdate()">
                      <el-option v-for="item in oneNo.gridArr" :key="item.name" :value="item.name" :label="item.name"></el-option>
                    </el-select>
                  </span>
                  <span><label>箱号</label>
                    <el-input size="mini" v-model.trim="oneNo.boxNo" maxlength="12"></el-input>
                  </span>
                  <span><label>重量</label>
                    <el-input size="mini" v-model.trim="oneNo.weight" maxlength="12"></el-input>
                  </span>
                  <span><label>号</label>
                    <el-input size="mini" style="width: 130px" v-model.trim="oneNo.addrNo" maxlength="25" @change="initAddress(index+1)"></el-input>
                  </span>
                </div>
              </div>
            </div>
            <div class="address-show">
              请仔细检查档号的连续性
            </div>
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="confirmAddFlag = true">保存</el-button>
        <el-button type="primary" @click="addNewNo">增加</el-button>
        <el-button @click="updateFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 生成存址号前确认 -->
    <el-dialog :visible.sync="confirmAddFlag" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定生成存址号吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="saveNewIds">确定</el-button>
        <el-button @click="confirmAddFlag = false">取消</el-button>
      </div>
    </el-dialog>
    <!-- 生成存址号 -->
    <el-dialog :visible.sync="addFlag" width="1200px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/save/s9.png" alt="">
        生成存址号
      </div>
      <div>
        <div>
          <!-- 头部 -->
          <div class="address-top">
            <span class="address-doc">
              <label>年份</label>
              <el-select v-model.trim="paramsAdd1.year" @change="getAllYear">
                <el-option v-for="item in yearArr" :key="item.id" :value="item.id" :label="item.name"></el-option>
              </el-select>
            </span>
            <span>档号范围： {{paramsAdd1.labMin}}至{{paramsAdd1.labMax}}</span>
          </div>
          <!-- 表数据 -->
          <div class="address">
            <div v-for="(oneNo,index) in addTotalNo">
              <div class="address-div">
                <div class="address-left">
                  <span><label>起-{{oneNo.labStartMin}}</label>
                    <el-input size="mini" v-model.trim="oneNo.startMin" maxlength="12"></el-input>
                  </span>
                  <span><label>止-{{oneNo.labStartMax}}</label>
                    <el-input size="mini" v-model.trim="oneNo.startMax" maxlength="12"></el-input>
                  </span>
                </div>
                <span class="address-cen">存址号</span>
                <div class="address-right">
                  <span><label>库房</label>
                    <el-select size="mini" v-model.trim="oneNo.store" @change="((val)=>{getMatrix1(val,index+1)})">
                      <el-option v-for="item in storeArr1" :key="item.name" :value="item.name" :label="item.name"></el-option>
                    </el-select>
                  </span>
                  <span><label>矩阵</label>
                    <el-select size="mini" v-model.trim="oneNo.matrix" @change="((val)=>{getBend1(val,index+1)})">
                      <el-option v-for="item in oneNo.matrixArr1" :key="item.itemVlaue" :value="item.name" :label="item.name"></el-option>
                    </el-select>
                  </span>
                  <span><label>排架</label>
                    <el-select size="mini" v-model.trim="oneNo.bent" @change="((val)=>{getFace1(val,index+1)})">
                      <el-option v-for="item in oneNo.bentArr1" :key="item.name" :value="item.name" :label="item.name"></el-option>
                    </el-select>
                  </span>
                  <span><label>面</label>
                    <el-select size="mini" v-model.trim="oneNo.face" @change="((val)=>{getGrid1(val,index+1)})">
                      <el-option v-for="item in oneNo.faceArr1" :key="item.name" :value="item.name" :label="item.name"></el-option>
                    </el-select>
                  </span>
                  <span><label>列行</label>
                    <el-select size="mini" v-model.trim="oneNo.grid" @change="$forceUpdate()">
                      <el-option v-for="item in oneNo.gridArr1" :key="item.name" :value="item.name" :label="item.name"></el-option>
                    </el-select>
                  </span>
                  <span><label>箱号</label>
                    <el-input size="mini" v-model.trim="oneNo.boxNo" maxlength="12"></el-input>
                  </span>
                  <span><label>重量</label>
                    <el-input size="mini" v-model.trim="oneNo.weight" maxlength="12"></el-input>
                  </span>
                  <span><label>号</label>
                    <el-input size="mini" style="width: 130px" v-model.trim="oneNo.addrNo" maxlength="25" @change="initAddress1(index+1)"></el-input>
                  </span>
                </div>
              </div>
            </div>
            <div class="address-show">
              请仔细检查档号的连续性
            </div>
          </div>
        </div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="addFlagShow= true">保存</el-button>
        <el-button type="primary" @click="initTotal(0)">增加</el-button>
        <el-button @click="addFlag = false">关闭</el-button>
      </div>
    </el-dialog>
    <!-- 生成存址号前确认 -->
    <el-dialog :visible.sync="addFlagShow" width="444px" class="hurdleAll">
      <div slot="title" class="dialog-title">
        <img src="../../assets/hurdle/nTitle2.png" alt="">
        系统提示
      </div>
      <div class="dia-delete">
        <img src="../../assets/hurdle/delete.png" alt="">
        <div>确定生成存址号吗？</div>
      </div>
      <div slot="footer" class="dialog-footer all-btn mt-f18">
        <el-button type="primary" @click="saveAdd">确定</el-button>
        <el-button @click="addFlagShow = false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
import { saveCase, checkStore, getByYear, openMakeAdd, typeList, typeRk, typeBack, typeBackTou, typeAddress, manageKf, listYear, thDept, getYear, getScope, getStore, saveFileAdd, typeLeftTree, thStatus, viewByTh, powerTree, typeFolderList, typeHangList, BASICURL, validateAddressNo, caseInit, caseChange, newTree1 } from '@/js/getData';
import { valueIndex } from '@/js/transitionText'
export default {
  name: 'twoType',
  props: {
    paramsNew: {
      type: Object
    },
    tableNew: {
      type: Array
    }
  },
  data() {
    return {
      activeName: null,
      seeData: [],
      seeParams: {
        page: 1,
        rows: 4,
        total: null
      },
      downId: null,
      seeFlag1: false,
      seeFlag1: false,
      notShow2: false,
      notShow1: false,
      seeOne: [],
      c5Arr: ["已移交", "整理中", "已挂接", "已归档", "在库", "出库"],
      pubArr: ['', '公开', '内部', '受控', '广发商密三级', '广发商密二级', '广发商密一级'],
      saveArr: ['', '短期', '长期', '永久', '', '10年', '15年', '', '30年', '', '35年'],
      saveDateArr: [
        { "name": "永久", "itemValue": "3" },
        { "name": "长期", "itemValue": "2" },
        { "name": "短期", "itemValue": "1" },
        { "name": "10年", "itemValue": "5" },
        { "name": "15年", "itemValue": "6" },
        { "name": "30年", "itemValue": "8" }
      ],
      typeFlag: false,
      showFlag: false,
      cArr: ['是', '否'],
      twoType: [],
      threeType: [],
      jumpFlag: false,
      seaFlag: false,
      gzArr: [],
      lwArr: [],
      params: this.paramsNew,
      titleFlag: false,
      titleMsg1: null,
      titleMsg2: null,
      fileData: this.tableNew,
      fileOne: [],
      remark: null,
      confirmRkFlag: false,
      noFlag: false,
      diurFlag: false,
      diurParams: {
        page: 1,
        rows: 6,
        total: null,
        flag: 0
      },
      tableDiur: [],
      dataShow: [],
      defaultProps: {
        children: 'children',
        label: 'text'
      },
      seeFlag: false,
      showUrl: null,
      paramsSea: {},
      deptArr: [],
      statusArr: [],
      userArr: [],
      typeArr: [],
      printFlag: false,
      scopes: 3,
      scopeArr: [
        { id: 3, text: '3cm' },
        { id: 5, text: '5cm' }
      ],
      addressFlag: false,
      yearArr: [],
      perArr: [],
      bottomShow: "first",
      folderData: [],
      folderParams: {
        page: 1,
        rows: 4,
        total: null
      },
      folderArr: [],
      hangData: [],
      hangParams: {
        page: 1,
        rows: 4,
        total: null
      },
      hangArr: [],
      paramsDetail: {},
      showType: null,
      showType1: null,
      isDownFlag: false,
      addFlag: false,
      addFlagShow: false,
      profilenoHead: null,
      addTotalNo: [],
      updateFlag: false,
      paramsAdd: {},
      caseArr: [],
      startMin: null,
      startMax: null,
      allNo: [],
      yearArr: [],
      storeArr: [],
      storeArr1: [],
      matrixArr1: [],
      bentArr1: [],
      faceArr1: [],
      gridArr1: [],
      confirmAddFlag: false,
      paramsAdd1: {},
    }
  },
  methods: {
    //获取档案列表
    searchOne() {
      this.params.page = 1;
      this.searchList();
    },
    searchList() {
      typeList(this.params).then(res => {
        if (res.code == 0) {
          if (res.data.total <= 0) {
            this.titleMsg1 = '系统消息';
            this.titleMsg2 = '该条件下查无数据!';
            this.titleFlag = true;
          }
          this.fileData = res.data.rows;
          this.params.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    fileCurr(val) {
      this.params.page = val;
      this.searchList();
    },
    fileSelect(val) {
      this.fileOne = val;
      this.folderOneList();
      this.hangOneList();

    },
    //入库
    openRk() {
      let open = this.$onceWay().onceTableList(this.fileOne);
      if (open == 1) {
        this.jumpFlag = true;
        this.remark = null
      }
    },
    clickJump() {
      if (this.remark == "" || this.remark == null) {
        this.$message.error("请填写意见");
      } else this.confirmRkFlag = true;
    },
    confirmRk() {
      this.confirmRkFlag = false;
      let rkParams = {
        infoId: this.fileOne[0].id,
        remark: this.remark,
      }
      typeRk(rkParams).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == '1') {
            this.$message.success("入库成功");
            this.jumpFlag = false;
            this.searchOne();
          } else if (res.data.optFlag == '-1') {
            this.$message.error("存在未生成存址号或者档案号的文件,入库失败");
          } else if (res.data.optFlag == '-2') {
            this.$message.error("该项目已入库");
          }
        } else this.$message.error(res.message)
      })
    },
    //退回整理
    openBack() {
      let open = this.$onceWay().onceTableList(this.fileOne);
      if (open == 1) {
        typeBack({ ids: this.fileOne[0].id }).then(res => {
          if (res.code == 0) {
            if (res.data.optFlag == "-1") {
              this.$message.error("退回失败");
            } else if (res.data.optFlag == "-2") {
              this.$message.success("该项目已入/出库不可回退！");
            } else {
              this.$message.success("退回成功");
              this.searchOne();
            }
          } else this.$message.error(res.message)
        })
      }
    },
    //退回整理(入库档案)
    openBackTou() {
      let open = this.$onceWay().onceTableList(this.fileOne);
      if (open == 1) {
        typeBackTou({ ids: this.fileOne[0].id }).then(res => {
          if (res.code == 0) {
            if (res.data.optFlag == "-1") {
              this.$message.error("退回失败");
            } else if (res.data.optFlag == "-2") {
              this.$message.success("非档案管理员无法进行当前操作");
            } else if (res.data.optFlag == "-3") {
              this.$message.success("当前处理项目非已入库项目");
            } else {
              this.$message.success("退回成功");
              this.searchOne();
            }
          } else this.$message.error(res.message)
        })
      }
    },
    //去除存址号
    openNo() {
      let open = this.$onceWay().onceTableList(this.fileOne);
      if (open == 1) {
        this.noFlag = true;
      }
    },
    confirmNo() {
      typeAddress({ id: this.fileOne[0].id }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 1) {
            this.$message.success("操作成功");
            this.noFlag = false;
            this.searchOne();
          } else {
            this.$message.error("操作失败");
          }
        } else this.$message.error(res.message)
      })
    },
    //查看日志
    openDiur() {
      let open = this.$onceWay().onceTableList(this.fileOne);
      if (open == 1) {
        this.diurFlag = true;
        this.searchDiurOne();
      }
    },
    searchDiur() {
      this.diurParams.infoId = this.fileOne[0].id;
      manageKf(this.diurParams).then(res => {
        if (res.code == 0) {
          this.tableDiur = res.data.rows;
          this.diurParams.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    searchDiurOne() {
      this.diurParams.page == 1;
      this.searchDiur();
    },
    diurCurrChange(val) {
      this.diurParams.page == val;
      this.searchDiur();
    },
    //查询
    //归档部门下拉
    getDept() {
      thDept().then(res => {
        if (res.code == 0) {
          this.deptArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    getStatus() {
      thStatus().then(res => {
        if (res.code == 0) {
          this.statusArr = res.data;
        } else this.$message.error(res.message)
      })
    },
    //打开检索
    openSea() {
      this.getStatus();
      this.getDept();
      this.paramsSea = {};
      this.seaFlag = true;
    },
    searchSea() {
      this.resetInit();
      Object.assign(this.params, this.paramsSea);
      this.params.searchType = 1; //原系统逻辑
      this.searchOne();
      this.seaFlag = false;
    },
    resetInit() {
      this.params.thseriesCode = null;
      this.params.thfilingDept = null;
      this.params.thc18 = null;
      this.params.thyearCode = null;
      this.params.thc5 = null;
      this.params.thc10 = null;
      this.params.thc24 = null;
      this.params.thtitleProper = null;
      this.params.thc20 = null;
      this.params.thc22 = null;
      this.params.thc28 = null;
      this.params.addressNo = null;
      this.params.searchType = null;
    },


    //查看--按钮
    openView() {
      let open = this.$onceWay().onceTableList(this.fileOne);
      if (open == 1) {
        this.downName = "";
        this.downId = null;
        this.paramsDetail = {};
        this.showType = "";
        this.dataShow = [];
        this.seeTree();
        this.seeFlag = true;
      }
    },
    //查看--加载树
    seeTree() {
      let seeParams = {
        id: this.fileOne[0].id,
        bs: 'saveTh',
        type: 'p'
      }
      typeLeftTree(seeParams).then(res => {
        if (res.code == 0) {
          this.dataShow = res.data;
          this.openTabs(res.data[0]);
        } else this.$message.error(res.message);
      })
    },
    //点击右侧数加载树的子节点
    handleNodeClick(val) {
      this.append(val);
      this.openTabs(val);
    },
    //加载子树
    append(data) {
      if (data.attributes.type != "d") {
        let seeParams = {
          id: data.id,
          tm: Date.now(),
          type: data.attributes.type,
          resourceParentId: data.id
        }
        typeLeftTree(seeParams).then(res => {
          if (res.code == 0) {
            if (!data.children) {
              this.$set(data, 'children', []);
            }
            data.children = res.data;
          } else this.$message.error(res.message);
        })
      }
    },
    //打开右侧tab
    openTabs(node) {
      if (node.attributes.docType == "d") { //如果是附件，同时打开2个tab页，并默认选中“电子全文”tab“页
        powerTree({ id: node.attributes.docId }).then(res => {
          if (res.code == 0) {
            if (res.data.optFlag == "-1") {
              //原系统隐藏电子全文的下载按钮（embed自带的）
              this.$message.error("对不起，未找到您需要查看的文件"); //选中基本信息
              this.addTabs(node.attributes.type, node.attributes.id, node.attributes.title);
              this.activeName = "first"
              this.showType1 = "";
            } else {
              //原系统显示电子全文的下载按钮（embed自带的）
              this.addTabs(node.attributes.type, node.attributes.id, node.attributes.title);
              this.addFiles(node.attributes.docType, node.attributes.docId, node.attributes.title2, node.attributes.info2, node.attributes.fileType)
              console.log(node)
              this.activeName = "second"
            }
          } else this.$message.error(res.message)
        })
      } else {
        //原系统隐藏电子全文的下载按钮（embed自带的）
        this.addTabs(node.attributes.type, node.attributes.id, node.attributes.title);
        this.activeName = "first";
        this.showType1 = "";
        //选中基本信息
      }
    },
    //加载基本信息Tab
    addTabs(type, id, title, info) {
      if (type == "d") { //附件
        let viewParams = {
          type: type,
          id: id,
          info: info
        };
        this.addAllTabs(viewParams);
      } else {
        let viewParams = {
          type: type,
          id: id
        };
        this.addAllTabs(viewParams);
      }
    },
    addAllTabs(val) {
      viewByTh(val).then(res => {
        if (res.code == 0) {
          this.showType = res.data.type;
          if (res.data.type == "p") {
            this.paramsDetail = res.data.project;
          }
          if (res.data.type == "v") {
            this.paramsDetail = res.data.folder;
          }
          if (res.data.type == "f") {
            this.paramsDetail = res.data.file;
          }
        } else this.$message.error(res.message)
      })
    },
    //加载电子全文tab
    addFiles(type, id, title, info, fileType) {
      this.showType1 = 'd';
      if (fileType == "pdf") {
        //预览文档
        this.showUrl = BASICURL + '/gdda-new/gdda/util/filepreview/viewRangeFile?fileId=' + id;
      } else {
        this.downId = id;
        this.downName = title;
        this.showUrl = null;
        //下载文档
        this.isDownFlag = true
      }
    },
    //下载非pdf文档
    downSee() {
      window.open(BASICURL + '/gdda-new/gdda/util/downLoadFile?id=' + this.downId + "&mode=saveTh")
      this.isDownFlag = false;
      /* let ids = { id: this.downId, mode: 'saveTh' }
       valueIndex().exportFiles('/gdda-new/gdda/util/downLoadFile', ids, this.downName, 'get');*/
    },

    handleClick() {

    },
    //下方列表
    bottomClick() {

    },
    //下方列表--案卷层
    folderList() {
      if (this.fileOne.length > 0) {
        this.folderParams.subId = this.fileOne[0].id;
      } else this.folderParams.subId = ""
      typeFolderList(this.folderParams).then(res => {
        if (res.code == 0) {
          this.folderData = res.data.rows;
          this.folderParams.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    folderOneList() {
      this.folderParams.page = 1;
      this.folderList();
    },
    folderSelect(val) {
      this.folderArr = val;
      this.hangOneList();
    },
    folderCurr(val) {
      this.folderParams.page = val;
      this.folderList();
    },
    //案卷层查看
    openSee1() {
      let open = this.$onceWay().onceTableList(this.folderArr);
      if (open == 1) {
        console.log(this.folderArr)
        this.downName = "";
        this.downId = null;
        this.paramsDetail = {};
        this.showType = "";
        this.dataShow = [];
        this.seeTree1(this.fileOne[0].id, this.folderArr[0].id);
        this.onPosition(this.folderArr[0].id, this.folderArr[0].type);
        this.seeFlag = true;
      }

    },
    //定位查看
    onPosition(val1, val2) {
      let seeParams = {
        id: val1,
        type: val2
      }
      typeLeftTree(seeParams).then(res => {
        if (res.code == 0) {
          this.openTabs(res.data[0]);
        }
      })
    },
    //查看--加载树
    seeTree1(val, val1) {
      let seeParams = {
        id: val,
        type: 'p'
      }
      newTree1(seeParams).then(res => {
        if (res.code == 0) {
          this.dataShow.push(res.data);
          this.$nextTick(() => {
            this.$refs.treeShow.setCurrentKey(val1);
          });
        } else this.$message.error(res.message);
      })
    },
    //下方列表--文件层
    hangList() {
      if (this.fileOne.length > 0) {
        this.hangParams.projectId = this.fileOne[0].id;
      } else this.hangParams.projectId = ""
      if (this.folderArr.length > 0) {
        this.hangParams.folderId = this.folderArr[0].id;
      } else this.hangParams.folderId = "";
      typeHangList(this.hangParams).then(res => {
        if (res.code == 0) {
          this.hangData = res.data.rows;
          this.hangParams.total = res.data.total;
        } else this.$message.error(res.message)
      })
    },
    hangOneList() {
      this.hangParams.page = 1;
      this.hangList();
    },
    hangSelect(val) {
      this.hangArr = val;
    },
    hangCurr(val) {
      this.hangParams.page = val;
      this.hangList()
    },
    openSee2() {
      let open = this.$onceWay().onceTableList(this.hangArr);
      if (open == 1) {
        this.downId = null;
        this.paramsDetail = {};
        this.showType = "";
        this.dataShow = [];
        this.seeTree1(this.fileOne[0].id, this.hangArr[0].id);
        this.onPosition(this.hangArr[0].id, this.hangArr[0].type);
        this.seeFlag = true;
      }
    },
    //修改存址号--获取回显信息
    showCase() {
      let caseParams = {
        proId: this.fileOne[0].id,
        type: 1
      }
      caseInit(caseParams).then(res => {
        if (res.code == 0) {
          this.paramsAdd.labMin = res.data.min;
          this.paramsAdd.labMax = res.data.max;
          this.showYear(res.data.year);
        } else this.$message.error(res.message);

      })
    },
    //修改存址号--获取年份下拉框
    showYear(val) {
      let year1 = val;
      let years = val.split(",");
      let tmp = [];
      if (years.length > 1) {
        years.forEach(item => {
          let items = {
            id: item,
            name: item
          };
          tmp.push(items);
        })
      } else {
        let items = {
          id: year1,
          name: year1
        };
        tmp.push(items);
      }
      this.yearArr = tmp;
    },
    //改变年份/盒号--获取旧存址信息
    getCase() {
      let caseParams = {
        proId: this.fileOne[0].id,
        year: this.paramsAdd.year,
        caseNo: this.paramsAdd.caseNo
      }
      caseChange(caseParams).then(res => {
        if (res.code == 0) {
          this.startMin = res.data.startMin;
          this.startMax = res.data.startMax;
          let arr = res.data.content.split(";"); //原系统是";" 
          this.allNo = [];
          for (let i = 0; i < arr.length; i++) {
            let arr2 = arr[i].split(",");
            this.startMax = arr2[1].substring(0, arr2[1].indexOf("-", 5));
            this.startMin = arr2[0].substring(0, arr2[0].indexOf("-", 5));
            let val1 = arr2[0].substring(arr2[0].indexOf("-", 5) + 1);
            let val2 = arr2[1].substring(arr2[1].indexOf("-", 5) + 1);
            this.addAllNo(i, val1, val2, arr2[3], arr2[2]);
          }
        } else this.$message.error(res.message)

      })
    },
    //新增存址号
    addAllNo(val, val1, val2, val3, val4) {
      this.allNo.push({
        startMin: val1,
        startMax: val2,
        weight: val3,
        addrNo: val4,
        store: "",
        matrix: "",
        bent: "",
        face: "",
        grid: "",
        boxNo: "",
        matrixArr: [],
        bentArr: [],
        faceArr: [],
        gridArr: [],
      })
      this.initAddress(val + 1);
      this.newId = val + 1;
    },
    //获取盒号下拉框
    showNo() {
      caseList({ proId: this.fileOne[0].id }).then(res => {
        if (res.code == 0) {
          this.caseArr = res.data;
        } else this.$message.error(res.message);
      })
    },
    //获取矩阵下拉框
    getMatrix(val, flag) { //flag:0库房下拉 else 矩阵下拉
      console.log(flag)
      let index = flag - 1;
      let parentId = null;
      if (val != 0) {
        let obj = {};
        obj = this.storeArr.find(function(item) {
          return item.name === val
        })
        parentId = obj.itemValue;
      } else parentId = 0;
      getStore({ parentId: parentId }).then(res => {
        if (res.code == 0) {
          if (flag == 0) {
            this.storeArr = res.data;
          } else {
            if (!this.allNo[index].addrNo) {
              this.allNo[index].matrix = ""
            }
            this.allNo[index].matrixArr = res.data;
          }

        } else this.$message.error(res.message)

      })
    },
    //获取排架下拉
    getBend(val, flag) { //原逻辑后期优化（主要是select显示绑定label,下拉查接口又是value）
      let bend = null;
      let obj = {};
      let index = flag - 1;
      obj = this.allNo[index].matrixArr.find(function(item) {
        return item.name === val
      })
      bend = obj.itemValue;
      getStore({ parentId: bend }).then(res => {
        if (res.code == 0) {
          if (!this.allNo[index].addrNo) {
            this.allNo[index].bent = ""
          }
          this.allNo[index].bentArr = res.data;
        } else this.$message.error(res.message)

      })
    },
    //获取面下拉
    getFace(val, flag) {
      let bend = null;
      let index = flag - 1;
      let obj = {};
      obj = this.allNo[index].bentArr.find(function(item) {
        return item.name === val
      })
      bend = obj.itemValue;
      getStore({ parentId: bend }).then(res => {
        if (res.code == 0) {
          if (!this.allNo[index].addrNo) {
            this.allNo[index].face = ""
          }
          this.allNo[index].faceArr = res.data;
        } else this.$message.error(res.message)

      })
    },
    //获取行列下拉
    getGrid(val, flag) {
      let bend = null;
      let index = flag - 1;
      let obj = {};
      obj = this.allNo[index].faceArr.find(function(item) {
        return item.name === val
      })
      bend = obj.itemValue;
      getStore({ parentId: bend }).then(res => {
        if (res.code == 0) {
          if (!this.allNo[index].addrNo) {
            this.allNo[index].grid = ""
          }
          this.allNo[index].gridArr = res.data;
        } else this.$message.error(res.message)

      })
    },
    //获取号值
    initAddress(flag) {
      let index = flag - 1;
      let address = this.allNo[index].store + this.allNo[index].matrix + this.allNo[index].bent + this.allNo[index].face + this.allNo[index].grid;
      if (this.allNo[index].addrNo != address && this.allNo[index].addrNo.length >= 8) {
        this.validateAdd(this.allNo[index].addrNo, flag);
      } else this.allNo[index].addrNo = address

    },
    validateAdd(addrNo, val) {
      if (addrNo != "" && addrNo != null && addrNo.length >= 8) {
        this.checkAddrNo(val, addrNo);
      }
    },
    checkAddrNo(id, val) {
      checkStore({ storeValue: val }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 1) {
            this.setAddress(id, val)
          }
        } else this.$message.error(res.message)
      })
    },
    setAddress(id, addrNo) {
      let index = id - 1;
      var store = addrNo.substr(0, 2);
      var matrix = addrNo.substr(2, 1);
      var bent = addrNo.substr(3, 2);
      var face = addrNo.substr(5, 1);
      var grid = addrNo.substr(6, 2);
      var boxNo = addrNo.substr(9, 5);
      this.allNo[index].store = store;
      this.allNo[index].matrix = matrix;
      this.allNo[index].bent = bent;
      this.allNo[index].face = face;
      this.allNo[index].grid = grid;
      this.allNo[index].boxNo = boxNo;
    },
    //打开修改存址号
    openCase() {
      let open = this.$onceWay().onceTableList(this.fileOne);
      if (open == 1) {
        this.paramsAdd = {};
        this.newId = 0;
        this.startMax = null;
        this.startMin = null;
        this.allNo = [];
        this.getMatrix(0, 0);
        this.showCase();
        this.updateFlag = true;
      }
    },
    //修改存址号--新增
    addNewNo() {
      this.allNo.push({
        startMin: "",
        startMax: "",
        store: "",
        matrix: "",
        bent: "",
        face: "",
        grid: "",
        boxNo: "",
        weight: "",
        addrNo: "",
        matrixArr: [],
        bentArr: [],
        faceArr: [],
        gridArr: [],
      })
    },
    //修改存址号 --保存
    saveNewIds() {
      this.confirmAddFlag = false;
      let reg = /^(0+(\.[0-9]{1,3}))$|^([0-9]{1,16})$|^([0-9]{1,16}\.[0-9]{1,3})$/;
      var address = "";
      var flag = true;
      var boxNoArr = [];
      var xh = "";
      for (let i = 0; i < this.allNo.length; i++) {
        if (!this.allNo[i].startMin || !this.allNo[i].startMax) {} else {
          if (!this.allNo[i].face || !this.allNo[i].store || !this.allNo[i].matrix || !this.allNo[i].bent || !this.allNo[i].grid || !this.allNo[i].boxNo) {
            this.$message.error("请填写正确的存址号");
            flag = false;
            return;
          } else {
            if (!reg.test(this.allNo[i].weight) || !reg.test(this.allNo[i].boxNo)) {
              this.$message.error("请检查第" + (i + 1) + "行的箱号和重量是否为数字(最多3位小数，最大16整数)！");
              flag = false;
              return
            }
          }
        }
        if (i >= 1) {
          if (!this.allNo[i].startMax && !this.allNo[i - 1].startMax) {} else {
            if (this.allNo[i - 1].startMax.substr(0, this.allNo[i - 1].startMax.lastIndexOf('-')) == this.allNo[i].startMin.substr(0, this.allNo[i].startMin.lastIndexOf('-'))) {
              if (parseInt(this.allNo[i - 1].startMax.substr(this.allNo[i - 1].startMax.lastIndexOf('-') + 1)) + 1 != this.allNo[i].startMin.substr(this.allNo[i].startMin.lastIndexOf('-') + 1)) {
                this.$message.error("填写的档案号不连续");
                flag = false;
                return;
              }
            }
          }
        }
        if (!this.allNo[i].store || !this.allNo[i].matrix || !this.allNo[i].bent || !this.allNo[i].face || !this.allNo[i].grid || !this.allNo[i].boxNo || !this.allNo[i].startMin || !this.allNo[i].startMax) {} else {
          if (!address) {
            address = address + this.allNo[i].store + ":" + this.allNo[i].matrix + ":" + this.allNo[i].bent + ":" + this.allNo[i].face + ":" + this.allNo[i].grid + ":" + this.allNo[i].boxNo + ":" + this.allNo[i].weight + ":" + this.allNo[i].startMin + ":" + this.allNo[i].startMax;
          } else {
            address = address + "," + this.allNo[i].store + ":" + this.allNo[i].matrix + ":" + this.allNo[i].bent + ":" + this.allNo[i].face + ":" + this.allNo[i].grid + ":" + this.allNo[i].boxNo + ":" + this.allNo[i].weight + ":" + this.allNo[i].startMin + ":" + this.allNo[i].startMax;
          }
          boxNoArr.push(this.allNo[i].boxNo);
          //添加序号，
          xh = xh + (i + 1) + ",";
        }
      }
      xh = xh.substring(0, xh.length - 1);
      for (var i = 0; i < boxNoArr.length; i++) {
        for (var j = i + 1; j < boxNoArr.length; j++) {
          if (boxNoArr[i] == boxNoArr[j]) {
            this.$message.error("填写的存址号不可以重复！");
            flag = false;
            return false;
          }
        }
      }
      if (flag) {
        let saveParams = {
          address: address,
          profilenoHead: this.startMax,
          proId: this.fileOne[0].id,
          xh: xh
        }
        saveCase(saveParams).then(res => {
          if (res.code == 0) {
            if (res.data.optFlag == 1) {
              this.$message.success("操作成功");
              this.searchOne();
              this.updateFlag = false;
            } else this.$message.error(res.data.msg);
          } else this.$message.error(res.message);
        })
      }
    },
    //生成存址号
    openAddress() {
      let open = this.$onceWay().onceTableList(this.fileOne);
      if (open == 1) {
        validateAddressNo({ proId: this.fileOne[0].id }).then(res => {
          if (res.code == 0) {
            if (res.data.optFlag == 1) {
              this.paramsAdd1 = {};
              this.profilenoHead = null;
              this.getShowMsg();
              this.addTotalNo = [];
              this.initTotal(5);
              this.getMatrix1(0, 0);
              this.addFlag = true;
            } else this.$message.error("该项目已经完成存址号生成工作")
          } else this.$message.error(res.message)
        })
      }
    },
    //初始化生成数组
    initTotal(val) {
      for (let i = 0; i <= val; i++) {
        this.addTotalNo.push({
          labStartMin: "",
          labStartMax: "",
          startMin: "",
          startMax: "",
          store: "",
          matrix: "",
          bent: "",
          face: "",
          grid: "",
          boxNo: "",
          weight: "",
          addrNo: "",
          matrixArr1: [],
          bentArr1: [],
          faceArr1: [],
          gridArr1: [],
        })
      }
    },
    //获取存址号显示信息
    getShowMsg() {
      openMakeAdd({ proId: this.fileOne[0].id }).then(res => {
        if (res.code == 0) {
          this.paramsAdd1.labMin = res.data.min;
          this.paramsAdd1.labMax = res.data.max;
          this.showYear(res.data.year);
        } else this.$message.error(res.message)
      })
    },
    //change年份
    getAllYear() {
      let allParams = {
        year: this.paramsAdd1.year,
        proId: this.fileOne[0].id
      }
      getByYear(allParams).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 1) {
            for (let i = 0; i < this.addTotalNo.length; i++) {
              this.addTotalNo[i].labStartMin = res.data.startMin;
              this.addTotalNo[i].labStartMax = res.data.startMax;
            }
            this.paramsAdd1.labMin = res.data.MinboxFileNo;
            this.paramsAdd1.labMax = res.data.MaxboxFileNo;
            this.addTotalNo[0].startMin = res.data.endMin;
            this.addTotalNo[0].startMax = res.data.endMax;
            this.profilenoHead = res.data.startMax;
          }
        } else this.$message.error(res.message)
      })
    },
    //获取矩阵下拉框
    getMatrix1(val, flag) { //flag:0库房下拉 else 矩阵下拉
      let index = flag - 1;
      let parentId = null;
      if (val != 0) {
        let obj = {};
        obj = this.storeArr1.find(function(item) {
          return item.name === val
        })
        parentId = obj.itemValue;
      } else parentId = 0;
      getStore({ parentId: parentId }).then(res => {
        if (res.code == 0) {
          if (flag == 0) {
            this.storeArr1 = res.data;
          } else {
            if (!this.addTotalNo[index].addrNo) {
              this.addTotalNo[index].matrix = ""
            }
            this.addTotalNo[index].matrixArr1 = res.data;
          }

        } else this.$message.error(res.message)

      })
    },
    //获取排架下拉
    getBend1(val, flag) { //原逻辑后期优化（主要是select显示绑定label,下拉查接口又是value）
      let bend = null;
      let obj = {};
      let index = flag - 1;
      obj = this.addTotalNo[index].matrixArr1.find(function(item) {
        return item.name === val
      })
      bend = obj.itemValue;
      getStore({ parentId: bend }).then(res => {
        if (res.code == 0) {
          if (!this.addTotalNo[index].addrNo) {
            this.addTotalNo[index].bent = ""
          }
          this.addTotalNo[index].bentArr1 = res.data;
        } else this.$message.error(res.message)

      })
    },
    //获取面下拉
    getFace1(val, flag) {
      let bend = null;
      let index = flag - 1;
      let obj = {};
      obj = this.addTotalNo[index].bentArr1.find(function(item) {
        return item.name === val
      })
      bend = obj.itemValue;
      getStore({ parentId: bend }).then(res => {
        if (res.code == 0) {
          if (!this.addTotalNo[index].addrNo) {
            this.addTotalNo[index].face = ""
          }
          this.addTotalNo[index].faceArr1 = res.data;
        } else this.$message.error(res.message)

      })
    },
    //获取行列下拉
    getGrid1(val, flag) {
      let bend = null;
      let index = flag - 1;
      let obj = {};
      obj = this.addTotalNo[index].faceArr1.find(function(item) {
        return item.name === val
      })
      bend = obj.itemValue;
      getStore({ parentId: bend }).then(res => {
        if (res.code == 0) {
          if (!this.addTotalNo[index].addrNo) {
            this.addTotalNo[index].grid = ""
          }
          this.addTotalNo[index].gridArr1 = res.data;
        } else this.$message.error(res.message)

      })
    },
    //获取号值
    initAddress1(flag) {
      let index = flag - 1;
      let address = this.addTotalNo[index].store + this.addTotalNo[index].matrix + this.addTotalNo[index].bent + this.addTotalNo[index].face + this.addTotalNo[index].grid;
      if (this.addTotalNo[index].addrNo != address && this.addTotalNo[index].addrNo.length >= 8) {
        this.validateAdd1(this.addTotalNo[index].addrNo, flag);
      } else this.addTotalNo[index].addrNo = address

    },
    validateAdd1(addrNo, val) {
      if (addrNo != "" && addrNo != null && addrNo.length >= 8) {
        this.checkAddrNo1(val, addrNo);
      }
    },
    checkAddrNo1(id, val) {
      checkStore({ storeValue: val }).then(res => {
        if (res.code == 0) {
          if (res.data.optFlag == 1) {
            this.setAddress1(id, val)
          }
        } else this.$message.error(res.message)
      })
    },
    setAddress1(id, addrNo) {
      let index = id - 1;
      var store = addrNo.substr(0, 2);
      var matrix = addrNo.substr(2, 1);
      var bent = addrNo.substr(3, 2);
      var face = addrNo.substr(5, 1);
      var grid = addrNo.substr(6, 2);
      var boxNo = addrNo.substr(9, 5);
      this.addTotalNo[index].store = store;
      this.addTotalNo[index].matrix = matrix;
      this.addTotalNo[index].bent = bent;
      this.addTotalNo[index].face = face;
      this.addTotalNo[index].grid = grid;
      this.addTotalNo[index].boxNo = boxNo;
    },
    saveAdd() {
      this.addFlagShow = false;
      let reg = /^(0+(\.[0-9]{1,3}))$|^([0-9]{1,16})$|^([0-9]{1,16}\.[0-9]{1,3})$/;
      var address = "";
      var flag = true;
      var boxNoArr = [];
      var xh = "";
      for (let i = 0; i < this.addTotalNo.length; i++) {
        if (!this.addTotalNo[i].startMin || !this.addTotalNo[i].startMax) {} else {
          if (!this.addTotalNo[i].face || !this.addTotalNo[i].store || !this.addTotalNo[i].matrix || !this.addTotalNo[i].bent || !this.addTotalNo[i].grid || !this.addTotalNo[i].boxNo) {
            this.$message.error("存址号有误，请检查第" + (i + 1) + "行！");
            flag = false;
            return;
          } else {
            if (!reg.test(this.addTotalNo[i].weight) || !reg.test(this.addTotalNo[i].boxNo)) {
              this.$message.error("请检查第" + (i + 1) + "行的箱号和重量是否为数字(最多3位小数，最大16整数)！");
              flag = false;
              return
            }
          }
        }
        if (i >= 1) {
          if (!this.addTotalNo[i].startMax && !this.addTotalNo[i - 1].startMax) {} else {
            if (this.addTotalNo[i - 1].startMax.substr(0, this.addTotalNo[i - 1].startMax.lastIndexOf('-')) == this.addTotalNo[i].startMin.substr(0, this.addTotalNo[i].startMin.lastIndexOf('-'))) {
              if (parseInt(this.addTotalNo[i - 1].startMax.substr(this.addTotalNo[i - 1].startMax.lastIndexOf('-') + 1)) + 1 != this.addTotalNo[i].startMin.substr(this.addTotalNo[i].startMin.lastIndexOf('-') + 1)) {
                this.$message.error("填写的档案号不连续");
                flag = false;
                return;
              }
            }
          }
        }
        if (!this.addTotalNo[i].store || !this.addTotalNo[i].matrix || !this.addTotalNo[i].bent || !this.addTotalNo[i].face || !this.addTotalNo[i].grid || !this.addTotalNo[i].boxNo || !this.addTotalNo[i].startMin || !this.addTotalNo[i].startMax) {} else {
          if (!address) {
            address = address + this.addTotalNo[i].store + ":" + this.addTotalNo[i].matrix + ":" + this.addTotalNo[i].bent + ":" + this.addTotalNo[i].face + ":" + this.addTotalNo[i].grid + ":" + this.addTotalNo[i].boxNo + ":" + this.addTotalNo[i].weight + ":" + this.addTotalNo[i].startMin + ":" + this.addTotalNo[i].startMax;
          } else {
            address = address + "," + this.addTotalNo[i].store + ":" + this.addTotalNo[i].matrix + ":" + this.addTotalNo[i].bent + ":" + this.addTotalNo[i].face + ":" + this.addTotalNo[i].grid + ":" + this.addTotalNo[i].boxNo + ":" + this.addTotalNo[i].weight + ":" + this.addTotalNo[i].startMin + ":" + this.addTotalNo[i].startMax;
          }
          boxNoArr.push(this.addTotalNo[i].boxNo);
          //添加序号，
          xh = xh + (i + 1) + ",";
        }
      }
      xh = xh.substring(0, xh.length - 1);
      for (var i = 0; i < boxNoArr.length; i++) {
        for (var j = i + 1; j < boxNoArr.length; j++) {
          if (boxNoArr[i] == boxNoArr[j]) {
            this.$message.error("填写的存址号不可以重复！");
            flag = false;
            return false;
          }
        }
      }
      if (flag) {
        let saveParams = {
          address: address,
          profilenoHead: this.profilenoHead,
          proId: this.fileOne[0].id,
          xh: xh
        }
        saveCase(saveParams).then(res => {
          if (res.code == 0) {
            if (res.data.optFlag == 1) {
              this.$message.success("操作成功");
              this.searchOne();
              this.addFlag = false;
            } else this.$message.error(res.data.msg);
          } else this.$message.error(res.message);
        })
      }
    }
  },
  created() {
    this.getDept();
  },
  watch: { // 监听到数据然后赋值
    paramsNew: {
      handler(newV, oldV) {
        this.params = JSON.parse(JSON.stringify(newV));
      },
      deep: true
    },
    tableNew: {
      handler(newV, oldV) {
        this.fileData = JSON.parse(JSON.stringify(newV))
      },
      deep: true
    }
  }
}

</script>
<style scoped lang="less">
@import "../../css/public";

.see {
  width: 100%;
  clear: both;
  margin-top: -30px;
  height: 500px;

  .see-left {
    width: 30%;
    float: left;
    padding-top: 20px;
    overflow: auto;
    height: 100%;

    .filter-tree {
      display: inline-block;
    }
  }

  .see-right {
    width: 69%;
    height: 100%;
    padding-top: 20px;
    float: left;
    border-left: 3px solid #1982BF;
  }
}

.address {
  border: 1px solid #6e6e6e;
  border-bottom: 0;
  max-height: 526px;
  overflow-y: auto;
}

.address-show {
  width: 100%;
  height: 74px;
  text-align: center;
  font-size: 20px;
  color: #333;
  background-color: #e7f5ff;
  border-bottom: 1px solid #6e6e6e;
  line-height: 74px;
}

.address-div {
  width: 100%;
  height: 74px;
  border-bottom: 1px solid #6e6e6e;
  clear: both;

  .address-left {
    width: 337px;
    border-right: 1px solid #6e6e6e;
    height: 100%;
    float: left;
    line-height: 74px;
    padding-left: 5px;

    label {
      font-size: 12px;
      color: #282828;
      padding-right: 5px
    }

    .el-input {
      width: 90px;
    }
  }

  .address-cen {
    width: 58px;
    border-right: 1px solid #6e6e6e;
    height: 100%;
    float: left;
    line-height: 74px;
    text-align: center;

  }

  .address-right {
    width: 732px;
    float: left;
    padding-left: 6px;

    span {
      padding-top: 6px;
      display: inline-block;
    }

    label {
      font-size: 12px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 71px;
    }
  }
}

.address-top {
  margin-bottom: 30px;
  margin-left: 170px;

  span {
    display: inline-block;
    color: #282828;
    font-size: 16px;
    cursor: pointer;
    margin-right: 10px;
    cursor: pointer;
  }

  .address-doc {
    label {
      font-size: 16px;
      color: #282828;
      padding-right: 5px
    }

    .el-input,
    .el-select {
      width: 180px;
    }
  }
}

.search-doc {
  margin-top: 10px;

  label {
    font-size: 14px;
    color: #282828;
    padding-right: 5px
  }

  .el-input,
  .el-select {
    width: 200px;
  }
}

.doc-main {
  background-color: #fff;
  min-height: 700px;

  .mb-20 {

    margin-bottom: 20px;
  }

  .doc-down {
    font-size: 13px;
    color: #515BED;
    float: right;
  }

  .doc-doss {
    width: 100%;
    height: 500px;
    overflow: auto;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .mt-f18 {
    margin-top: -18px;
  }

  .mt-f14 {
    margin-top: -14px;
  }

  .lend-table {
    max-height: 200px;
    overflow-y: auto;
    width: 100%
  }
}

.w-100 {
  width: 100%
}

</style>
<style lang="less">
.filter-tree {
  .el-tree__empty-block {
    width: 200px;
  }
}

</style>
