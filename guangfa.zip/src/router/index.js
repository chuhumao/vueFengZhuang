import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export default new Router({
  routes: [{
    path: '/',
    name: 'Login',
    component: () => import('../view/login.vue')
  },
  {
    path: '/home',
    name: 'Home',
    component: () => import('../view/home.vue'),
    meta: { title: '首页' },
    children: [{
      path: '/homeIndex',
      name: 'HomeIndex',
      component: () => import('../view/homeTwo/homeIndex.vue'),
      meta: { title: '子菜单' },
      children: [{
        path: '/test',
        name: 'Test',
        component: () => import('../view/test.vue'),
        meta: { title: '测试页面' }
      }]
    },
    {
      path: '/specialTopicManage',
      name: 'SpecialTopicManage',
      component: () => import('../view/hurdleManage/specialTopicManage.vue'),
      meta: { title: '专题管理' }
    },
    {
      path: '/homePage',
      name: 'HomePage',
      component: () => import('../view/inform/homePage.vue'),
      meta: { title: '首页' }
    },
    {
      path: '/hurdleManage',
      name: 'HurdleManage',
      component: () => import('../view/hurdleManage/hurdleManage.vue'),
      meta: { title: '栏目管理' }
    },
    {
      path: '/newManage',
      name: 'NewManage',
      component: () => import('../view/hurdleManage/NewManage.vue'),
      meta: { title: '新闻管理' }
    },
    {
      path: '/roleManage',
      name: 'roleManage',
      component: () => import('../view/system/roleManage.vue'),
      meta: { title: '角色管理' }
    },
    {
      path: '/userManage',
      name: 'UserManage',
      component: () => import('../view/system/userManage.vue'),
      meta: { title: '用户管理' }
    },
    {
      path: '/functionManage',
      name: 'FunctionManage',
      component: () => import('../view/system/functionManage.vue'),
      meta: { title: '功能模块管理' }
    },
    {
      path: '/cacheManage',
      name: 'CacheManage',
      component: () => import('../view/system/cacheManage.vue'),
      meta: { title: '缓存管理' }
    },
    {
      path: '/indexManage',
      name: 'IndexManage',
      component: () => import('../view/system/indexManage.vue'),
      meta: { title: '索引管理' }
    },
    {
      path: '/userData',
      name: 'UserData',
      component: () => import('../view/dataMange/userData.vue'),
      meta: { title: '用户数据权限' }
    },
    {
      path: '/roleData',
      name: 'RoleData',
      component: () => import('../view/dataMange/roleData.vue'),
      meta: { title: '角色数据权限' }
    },
    {
      path: '/applyForList',
      name: 'ApplyForList',
      component: () => import('../view/recordMange/ApplyForList.vue'),
      meta: { title: '移交申请' }
    },
    {
      path: '/applyAudit',
      name: 'ApplyAudit',
      component: () => import('../view/recordMange/applyAudit.vue'),
      meta: { title: '移交申请审核' }
    },
    {
      path: '/accomplishList',
      name: 'AccomplishList',
      component: () => import('../view/recordMange/accomplishList.vue'),
      meta: { title: '移交申请完成' }
    },
    {
      path: '/cancellationList',
      name: 'CancellationList',
      component: () => import('../view/recordMange/cancellationList.vue'),
      meta: { title: '移交申请作废' }
    },
    {
      path: '/arrearsMange',
      name: 'ArrearsMange',
      component: () => import('../view/turnOver/arrearsMange.vue'),
      meta: { title: '欠交' }
    },
    {
      path: '/synthesizeAuditMange',
      name: 'SynthesizeAuditMange',
      component: () => import('../view/turnOver/synthesizeAuditMange.vue'),
      meta: { title: '综合员审核' }
    },
    {
      path: '/bossAuditMange',
      name: 'BossAuditMange',
      component: () => import('../view/turnOver/bossAuditMange.vue'),
      meta: { title: '综合员审核' }
    },
    {
      path: '/recordMange',
      name: 'RecordMange',
      component: () => import('../view/turnOver/recordMange.vue'),
      meta: { title: '档案管理审核' }
    },
    {
      path: '/recordTurnOverMange',
      name: 'RecordTurnOverMange',
      component: () => import('../view/turnOver/recordTurnOverMange.vue'),
      meta: { title: '档案已移交' }
    },
    {
      path: '/allMange',
      name: 'AllMange',
      component: () => import('../view/turnOver/allMange.vue'),
      meta: { title: '移交(全部)' }
    },
    {
      path: '/testSelect',
      name: 'testSelect',
      component: () => import('../test/testSelect.vue')
    },
    {
      path: '/documentSearch',
      name: 'DocumentSearch',
      component: () => import('../components/specialScheme/documentSearch.vue')
    },
    {
      path: '/agencyFailure',
      name: 'AgencyFailure',
      component: () => import('../view/fileConfirme/agencyFailure.vue'),
      meta: { title: '代办失败' } // 综合档案确认
    },
    {
      path: '/designate',
      name: 'Designate',
      component: () => import('../view/fileConfirme/designate.vue'),
      meta: { title: '指定承办人' } // 综合档案确认
    },
    {
      path: '/confirmed',
      name: 'Confirmed',
      component: () => import('../view/fileConfirme/confirmed.vue'),
      meta: { title: '已确认' } // 综合档案确认
    },
    {
      path: '/confirm',
      name: 'Confirm',
      component: () => import('../view/fileConfirme/confirm.vue'),
      meta: { title: '待确认' } // 综合档案确认
    },
    {
      path: '/fileMange',
      name: 'FileMange',
      component: () => import('../view/fileMange/fileMange.vue'),
      meta: { title: '综合档案整理' } // 综合档案整理
    },
    {
      path: '/materials',
      name: 'Materials',
      component: () => import('../view/materials/mateMange.vue'),
      meta: { title: '材料模板管理' } // 综合档案整理
    },
    {
      path: '/fileSave',
      name: 'FileSave',
      component: () => import('../view/fileSave/fileSave.vue'),
      meta: { title: '综合档案保存' } // 综合档案保存
    },
    {
      path: '/storehouse',
      name: 'storehouse',
      component: () => import('../view/warehouse/storehouse.vue'),
      meta: { title: '库房管理' } // 综合档案保存
    }
    ]
  },
  {
    path: '/404',
    name: '404',
    component: () => import('../components/mistake/404.vue')
  }
  ]
})
